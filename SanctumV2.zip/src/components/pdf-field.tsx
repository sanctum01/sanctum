import { FileText, X } from "lucide-react";
import { useRef, useState, type ChangeEvent } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { isPdfFile, MAX_PDFS, readPdfFile } from "@/lib/pdf";
import type { PdfAttachment } from "@/lib/types";
import { cn } from "@/lib/utils";

export function PdfField({
  pdfs,
  onChange,
  max = MAX_PDFS,
  label = "PDFs",
}: {
  pdfs: PdfAttachment[];
  onChange: (next: PdfAttachment[]) => void;
  max?: number;
  label?: string;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  async function onPick(event: ChangeEvent<HTMLInputElement>) {
    const files = Array.from(event.currentTarget.files ?? []);
    event.currentTarget.value = "";
    if (!files.length) return;
    const room = max - pdfs.length;
    if (room <= 0) {
      toast.error(`You can attach up to ${max} PDFs.`);
      return;
    }
    setBusy(true);
    try {
      const next = [...pdfs];
      for (const file of files.slice(0, room)) {
        if (!isPdfFile(file)) {
          toast.error(`${file.name} is not a PDF.`);
          continue;
        }
        next.push(await readPdfFile(file));
      }
      onChange(next);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not read that PDF.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-2">
      <div className="flex items-baseline justify-between">
        <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">
          {label}
        </p>
        <p className="text-xs text-muted-foreground">
          {pdfs.length}/{max}
        </p>
      </div>
      {pdfs.length ? (
        <ul className="space-y-1.5">
          {pdfs.map((item, index) => (
            <li
              key={`${item.name}-${index}`}
              className="flex items-center gap-2 rounded-md bg-secondary px-2 py-2"
            >
              <FileText className="size-4 shrink-0 text-primary" />
              <span className="min-w-0 flex-1 truncate text-sm">{item.name}</span>
              <button
                type="button"
                className="grid size-9 place-items-center rounded-md text-muted-foreground hover:text-foreground"
                onClick={() => onChange(pdfs.filter((_, i) => i !== index))}
                aria-label={`Remove ${item.name}`}
              >
                <X className="size-3.5" />
              </button>
            </li>
          ))}
        </ul>
      ) : null}
      {pdfs.length < max ? (
        <>
          <label
            className={cn(
              "relative flex h-11 w-full cursor-pointer items-center justify-center gap-2 rounded-md border border-dashed border-input text-sm text-muted-foreground hover:border-primary/50 hover:text-foreground",
              busy && "pointer-events-none opacity-60",
            )}
          >
            <FileText className="size-4" />
            {busy ? "Adding…" : "Add PDF"}
            <input
              ref={inputRef}
              type="file"
              accept="application/pdf,.pdf"
              multiple={max - pdfs.length > 1}
              className="absolute inset-0 cursor-pointer opacity-0"
              onChange={(event) => void onPick(event)}
            />
          </label>
          <p className="text-xs text-muted-foreground">Up to {max} files, 2 MB each. Opens from the entry later.</p>
        </>
      ) : null}
    </div>
  );
}

export function PdfStrip({
  pdfs,
  className,
}: {
  pdfs: PdfAttachment[];
  className?: string;
}) {
  if (!pdfs.length) return null;
  return (
    <ul className={cn("space-y-1", className)}>
      {pdfs.map((item, index) => (
        <li key={`${item.name}-${index}`}>
          <a
            href={item.data}
            download={item.name}
            target="_blank"
            rel="noreferrer"
            className="flex h-10 items-center gap-2 rounded-md bg-secondary px-2 text-sm text-foreground hover:bg-raised"
          >
            <FileText className="size-4 shrink-0 text-primary" />
            <span className="min-w-0 truncate">{item.name}</span>
          </a>
        </li>
      ))}
    </ul>
  );
}

export function PdfOpenButton({ item }: { item: PdfAttachment }) {
  return (
    <Button asChild size="sm" variant="outline">
      <a href={item.data} download={item.name} target="_blank" rel="noreferrer">
        <FileText className="size-4" />
        {item.name}
      </a>
    </Button>
  );
}
