import type { PdfAttachment } from "@/lib/types";

export const PDF_META_KEY = "_pdfs";
export const MAX_PDFS = 3;
export const MAX_PDF_BYTES = 2_000_000;

export function isPdfFile(file: File) {
  if (file.type === "application/pdf") return true;
  return /\.pdf$/i.test(file.name);
}

export function parsePdfs(raw: string | undefined | null): PdfAttachment[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(
        (item): item is PdfAttachment =>
          Boolean(
            item &&
              typeof item === "object" &&
              typeof (item as PdfAttachment).name === "string" &&
              typeof (item as PdfAttachment).data === "string" &&
              (item as PdfAttachment).data.startsWith("data:"),
          ),
      )
      .slice(0, MAX_PDFS)
      .map((item) => ({
        name: item.name.replace(/[^\w.\- ()]+/g, "").slice(0, 80) || "document.pdf",
        data: item.data,
      }));
  } catch {
    return [];
  }
}

export function encodePdfs(list: PdfAttachment[]) {
  return JSON.stringify(
    list.slice(0, MAX_PDFS).map((item) => ({
      name: item.name.slice(0, 80),
      data: item.data,
    })),
  );
}

export function applyPdfs(meta: Record<string, string>, pdfs: PdfAttachment[]) {
  const next = { ...meta };
  if (!pdfs.length) delete next[PDF_META_KEY];
  else next[PDF_META_KEY] = encodePdfs(pdfs);
  return next;
}

function readAsDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") resolve(reader.result);
      else reject(new Error("Could not read that PDF."));
    };
    reader.onerror = () => reject(new Error("Could not read that PDF."));
    reader.readAsDataURL(file);
  });
}

export async function readPdfFile(file: File): Promise<PdfAttachment> {
  if (!isPdfFile(file)) throw new Error("Choose a PDF file.");
  if (file.size > MAX_PDF_BYTES) {
    throw new Error("Each PDF needs to be under 2 MB.");
  }
  const data = await readAsDataUrl(file);
  if (!data.startsWith("data:")) throw new Error("Could not read that PDF.");
  const base = file.name.replace(/\.pdf$/i, "").trim() || "document";
  return { name: `${base.slice(0, 72)}.pdf`, data };
}

export function pdfHref(item: PdfAttachment) {
  return item.data;
}
