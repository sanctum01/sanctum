//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-6DXasNPy.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/catalog",
			"/challenges",
			"/games",
			"/habits",
			"/house",
			"/journal",
			"/login",
			"/notes",
			"/playbook",
			"/profile",
			"/punishments",
			"/rabbits",
			"/reset-password",
			"/rewards",
			"/roleplay",
			"/scenes",
			"/talk",
			"/tasks",
			"/toys",
			"/training",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-DzWfR1fg.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/dist-DwNkUmYB.js",
			"/assets/link-D_iiqktK.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DzWfR1fg.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-HrqjrhQR.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/use-current-user-DVhsA0Of.js",
			"/assets/kind-page-1LFYZH9j.js",
			"/assets/input-DH2_79CR.js"
		]
	},
	"/catalog": {
		filePath: "/workspace/src/routes/catalog.tsx",
		children: void 0,
		preloads: [
			"/assets/catalog-DNW94Xn9.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/kind-page-1LFYZH9j.js"
		]
	},
	"/challenges": {
		filePath: "/workspace/src/routes/challenges.tsx",
		children: void 0,
		preloads: [
			"/assets/challenges-Bg8eqT5B.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/use-current-user-DVhsA0Of.js",
			"/assets/kind-page-1LFYZH9j.js",
			"/assets/input-DH2_79CR.js"
		]
	},
	"/games": {
		filePath: "/workspace/src/routes/games.tsx",
		children: void 0,
		preloads: [
			"/assets/games-ByOIKHe1.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/use-current-user-DVhsA0Of.js",
			"/assets/kind-page-1LFYZH9j.js",
			"/assets/input-DH2_79CR.js"
		]
	},
	"/habits": {
		filePath: "/workspace/src/routes/habits.tsx",
		children: void 0,
		preloads: [
			"/assets/habits-Ddt_6kBz.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/kind-page-1LFYZH9j.js"
		]
	},
	"/house": {
		filePath: "/workspace/src/routes/house.tsx",
		children: void 0,
		preloads: [
			"/assets/house-COE-RCux.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/use-current-user-DVhsA0Of.js",
			"/assets/input-DH2_79CR.js"
		]
	},
	"/journal": {
		filePath: "/workspace/src/routes/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-DPa83kja.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/use-current-user-DVhsA0Of.js",
			"/assets/kind-page-1LFYZH9j.js",
			"/assets/input-DH2_79CR.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-B2e-Iyl7.js",
			"/assets/use-current-user-DVhsA0Of.js",
			"/assets/client-C85fcJ4s.js",
			"/assets/input-DH2_79CR.js"
		]
	},
	"/notes": {
		filePath: "/workspace/src/routes/notes.tsx",
		children: void 0,
		preloads: [
			"/assets/notes-BnaU1e5u.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/kind-page-1LFYZH9j.js"
		]
	},
	"/playbook": {
		filePath: "/workspace/src/routes/playbook.tsx",
		children: void 0,
		preloads: [
			"/assets/playbook-D76XNB2_.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/kind-page-1LFYZH9j.js"
		]
	},
	"/punishments": {
		filePath: "/workspace/src/routes/punishments.tsx",
		children: void 0,
		preloads: [
			"/assets/punishments-DNibS6bw.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/kind-page-1LFYZH9j.js"
		]
	},
	"/reset-password": {
		filePath: "/workspace/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-B5kguskL.js",
			"/assets/client-C85fcJ4s.js",
			"/assets/input-DH2_79CR.js"
		]
	},
	"/rewards": {
		filePath: "/workspace/src/routes/rewards.tsx",
		children: void 0,
		preloads: [
			"/assets/rewards-DiiH0TOv.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/kind-page-1LFYZH9j.js"
		]
	},
	"/roleplay": {
		filePath: "/workspace/src/routes/roleplay.tsx",
		children: void 0,
		preloads: [
			"/assets/roleplay-DjWxhXMC.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/kind-page-1LFYZH9j.js"
		]
	},
	"/scenes": {
		filePath: "/workspace/src/routes/scenes.tsx",
		children: void 0,
		preloads: [
			"/assets/scenes-DIKDGyFM.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/kind-page-1LFYZH9j.js"
		]
	},
	"/talk": {
		filePath: "/workspace/src/routes/talk.tsx",
		children: void 0,
		preloads: [
			"/assets/talk-DtF3jQfB.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/use-current-user-DVhsA0Of.js",
			"/assets/kind-page-1LFYZH9j.js",
			"/assets/input-DH2_79CR.js"
		]
	},
	"/tasks": {
		filePath: "/workspace/src/routes/tasks.tsx",
		children: void 0,
		preloads: [
			"/assets/tasks-D_kBoppU.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/kind-page-1LFYZH9j.js"
		]
	},
	"/training": {
		filePath: "/workspace/src/routes/training.tsx",
		children: void 0,
		preloads: [
			"/assets/training-Cn8oCZ3E.js",
			"/assets/badge-BOKlUlxD.js",
			"/assets/kind-page-1LFYZH9j.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
