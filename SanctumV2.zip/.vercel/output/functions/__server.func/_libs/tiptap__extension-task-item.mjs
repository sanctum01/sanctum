import { a as TaskItem } from "./tiptap__extension-list.mjs";
//#region node_modules/@tiptap/extension-task-item/dist/index.js
var src_default = TaskItem;
//#endregion
export { src_default as t };
