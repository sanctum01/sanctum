import { o as TaskList } from "./tiptap__extension-list.mjs";
//#region node_modules/@tiptap/extension-task-list/dist/index.js
var src_default = TaskList;
//#endregion
export { src_default as t };
