import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { d as useRouterState, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { B as parseExperience, J as styleLabel, V as parseKinks, Y as stylesFor, c as SEX_OPTIONS, k as experienceLabel, o as EXPERIENCE_LEVELS } from "./video-DfU4zp6z.mjs";
import { B as parseHouseTab, D as formatWhen, G as roleLabel, K as sexLabel, O as googleMapsEmbed, R as notifyLocationChanged, T as formatMeters, i as EDIT_SCOPES, j as haversineMeters, k as googleMapsLink, o as KINDS, w as formatAgo } from "./format-Dsk7inZY.mjs";
import { i as cn, n as Input, r as Label, t as Button } from "./input-CkY6TqOo.mjs";
import { C as Navigation, G as Clock3, H as ExternalLink, J as ChevronRight, O as MapPin, Y as ChevronLeft } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as deleteEntry, E as disconnectPartner, I as listArchived, K as pingLocation, M as getHouseHistory, N as getLocationBoard, P as getMe, X as removePartner, _t as updateEntry, d as Select, et as saveHouseSettings, it as saveUserOptions, nt as saveProfile, pt as switchPartner, q as playWithCompanion, s as PhotoField, u as RoleStyleField, ut as setLocationSharing, y as connectPartner } from "./use-current-user-nzqgiI2T.mjs";
import { _ as useAutoSave, c as HOUSE_NAV, d as NAV, g as subscribeMe, h as VacationToggle, l as KinkField, m as SaveHint, n as Badge, t as AppShell, u as KinkList, v as useLiveReload } from "./badge-CRftROn_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/house-BtfSRANr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Editor({ profile, lastPartner, partners = [], onSaved }) {
	const [name, setName] = (0, import_react.useState)(profile.displayName);
	const [username, setUsername] = (0, import_react.useState)(profile.username);
	const [age, setAge] = (0, import_react.useState)(profile.age ? String(profile.age) : "");
	const [sex, setSex] = (0, import_react.useState)(profile.sex);
	const [role, setRole] = (0, import_react.useState)(profile.role);
	const [roleStyle, setRoleStyle] = (0, import_react.useState)(profile.roleStyle);
	const [experience, setExperience] = (0, import_react.useState)(parseExperience(profile.experience));
	const [playMode, setPlayMode] = (0, import_react.useState)(profile.playMode || (profile.partnerUserId ? "pair" : "solo"));
	const [photos, setPhotos] = (0, import_react.useState)(profile.avatarData ? [profile.avatarData] : []);
	const [kinks, setKinks] = (0, import_react.useState)(() => parseKinks(profile.kinks));
	const [switching, setSwitching] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setPlayMode(profile.playMode || (profile.partnerUserId ? "pair" : "solo"));
	}, [profile.playMode, profile.partnerUserId]);
	function chooseRole(next) {
		setRole(next);
		if (!stylesFor(next).some((item) => item.value === roleStyle)) setRoleStyle("");
	}
	async function choosePlay(next) {
		if (switching) return;
		if (next === "solo") {
			if (profile.partnerUserId) {
				if (typeof window !== "undefined" && !window.confirm("Switch to solo? Shared pages wait on this bond. You can reconnect later.")) return;
			}
			setSwitching(true);
			try {
				onSaved(await disconnectPartner());
				setPlayMode("solo");
			} catch (err) {
				toast.error(err instanceof Error ? err.message : "Could not switch to solo.");
			} finally {
				setSwitching(false);
			}
			return;
		}
		if (next === "companion") {
			if (profile.partnerUserId) {
				if (typeof window !== "undefined" && !window.confirm("Switch to the companion? Shared pages wait. Everyone stays on your roster.")) return;
			}
			setSwitching(true);
			try {
				onSaved(await playWithCompanion());
				setPlayMode("companion");
				toast.success("Companion pages are live. Solo and partner pages wait.");
			} catch (err) {
				toast.error(err instanceof Error ? err.message : "Could not switch to the companion.");
			} finally {
				setSwitching(false);
			}
			return;
		}
		if (next === "pair" && !profile.partnerUserId) {
			const waiting = partners.filter((item) => !item.active);
			const pick = waiting.find((item) => item.available) ?? lastPartner;
			if (waiting.length > 1) {
				setPlayMode("pair");
				toast.message("Pick who to switch to on their card.");
				return;
			}
			if (pick?.available) {
				setSwitching(true);
				try {
					onSaved(await switchPartner({ data: { userId: pick.userId } }));
					setPlayMode("pair");
					toast.success(`Now with ${pick.username || "them"}.`);
				} catch (err) {
					toast.error(err instanceof Error ? err.message : "Could not switch.");
					setPlayMode("pair");
				} finally {
					setSwitching(false);
				}
				return;
			}
			setPlayMode("pair");
			return;
		}
		setPlayMode(next);
	}
	const ageNum = Number(age);
	const ageOk = Number.isInteger(ageNum) && ageNum >= 18;
	const usernameOk = Boolean(username.trim());
	const canSave = ageOk && usernameOk;
	const signature = JSON.stringify({
		name,
		username,
		age,
		sex,
		role,
		roleStyle,
		experience,
		photo: photos[0] ?? "",
		kinks
	});
	const saveStatus = useAutoSave(signature, async () => {
		await saveProfile({ data: {
			displayName: name.trim(),
			username: username.trim(),
			age: ageNum,
			sex,
			role,
			roleStyle,
			experience,
			avatarData: photos[0] ?? null,
			kinks
		} });
		onSaved(await getMe());
	}, {
		delay: 500,
		enabled: canSave,
		resetKey: `${profile.userId}:${profile.partnerUserId}:${profile.playMode}`
	});
	const typeName = styleLabel(role, roleStyle);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-card p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "You"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: [typeName ? `${typeName} · ` : "", roleLabel(role)] })]
			}),
			photos[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: photos[0],
				alt: "",
				className: "mb-4 h-40 w-full rounded-lg object-cover"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoField, {
						photos,
						onChange: setPhotos,
						max: 1,
						label: "Photo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Name" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: name,
								onChange: (e) => setName(e.target.value),
								maxLength: 80,
								placeholder: "Only you see this"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Hidden from everyone else, including a partner. It only appears here."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Username" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: username,
							onChange: (e) => setUsername(e.target.value.replace(/[^A-Za-z0-9._-]/g, "").slice(0, 32)),
							maxLength: 32,
							placeholder: "What they will see"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Age" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 18,
								max: 99,
								value: age,
								onChange: (e) => setAge(e.target.value)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Sex" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: sex,
								onChange: (e) => setSex(e.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Choose…"
								}), SEX_OPTIONS.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: opt.value,
									children: opt.label
								}, opt.value))]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							"dominant",
							"submissive",
							"switch"
						].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => chooseRole(value),
							className: cn("h-11 rounded-lg border text-sm", role === value ? "border-primary bg-primary/10" : "border-border"),
							children: roleLabel(value)
						}, value))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleStyleField, {
						role,
						value: roleStyle,
						onChange: setRoleStyle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Experience in this role" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: experience,
								onChange: (e) => setExperience(parseExperience(e.target.value)),
								children: EXPERIENCE_LEVELS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item.value,
									children: item.label
								}, item.value))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									EXPERIENCE_LEVELS.find((item) => item.value === experience)?.hint,
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/playbook",
										className: "text-primary underline-offset-2 hover:underline",
										children: [
											"Opens ",
											experienceLabel(experience),
											" in The Playbook"
										]
									}),
									". You can change this as you grow."
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KinkField, {
						role,
						value: kinks,
						onChange: setKinks
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "How you play" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-2",
							children: [
								{
									value: "pair",
									title: "Partner",
									copy: profile.partnerUserId ? "Connected. These shared pages are only for this pair." : partners.length ? "Pick who is live on the other card, or pair a new code. Each bond has its own pages." : "A human bond. Pair with a code on the other card. Separate from solo and the companion."
								},
								{
									value: "companion",
									title: "Companion as partner",
									copy: "Their own pages. The companion may write here. Solo and human bonds wait, unseen."
								},
								{
									value: "solo",
									title: "Solo",
									copy: "Your private pages. The companion can talk, but cannot change anything. Partner pages wait."
								}
							].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: switching,
								onClick: () => void choosePlay(item.value),
								className: cn("rounded-lg border px-3 py-2 text-left", playMode === item.value ? "border-primary bg-primary/10" : "border-border"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: item.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-xs text-muted-foreground",
									children: item.copy
								})]
							}, item.value))
						})]
					}),
					!usernameOk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Choose a username your partner can see."
					}) : !ageOk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Age must be 18 or older."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveHint, { status: saveStatus })
				]
			})
		]
	});
}
function PartnerCard({ me, onChange }) {
	const [code, setCode] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(null);
	const partner = me.partner;
	const roster = (me.partners ?? []).filter((item) => !item.active);
	const mine = me.profile;
	async function connect() {
		setBusy("connect");
		try {
			onChange(await connectPartner({ data: { code } }));
			toast.success("Connected.");
			setCode("");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not connect.");
		} finally {
			setBusy(null);
		}
	}
	async function activate(person) {
		if (person.active) return;
		if (!person.available) {
			if (typeof window !== "undefined" && !window.confirm(`${person.username || "They"} are with someone else. Switch anyway? They'll be pulled here. Shared pages for each pair stay separate.`)) return;
		}
		setBusy(person.userId);
		try {
			onChange(await switchPartner({ data: { userId: person.userId } }));
			toast.success(`Now with ${person.username || "them"}.`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not switch.");
		} finally {
			setBusy(null);
		}
	}
	async function goSolo() {
		if (partner) {
			if (typeof window !== "undefined" && !window.confirm("Switch to solo? Shared pages wait on this bond. Everyone stays on your roster.")) return;
		}
		setBusy("solo");
		try {
			onChange(await disconnectPartner());
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not switch to solo.");
		} finally {
			setBusy(null);
		}
	}
	async function goCompanion() {
		if (partner) {
			if (typeof window !== "undefined" && !window.confirm("Switch to the companion? Shared pages wait. Everyone stays on your roster.")) return;
		}
		setBusy("companion");
		try {
			onChange(await playWithCompanion());
			toast.success("Companion pages are live. Solo and partner pages wait.");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not switch to the companion.");
		} finally {
			setBusy(null);
		}
	}
	async function drop(person) {
		if (typeof window !== "undefined" && !window.confirm(`Drop ${person.username || "them"} from your roster? Shared pages stay if you pair their code again.`)) return;
		setBusy(`drop:${person.userId}`);
		try {
			onChange(await removePartner({ data: { userId: person.userId } }));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not drop them.");
		} finally {
			setBusy(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-card p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: partner ? "Partner" : "Partners"
				}), partner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "outline",
					children: roleLabel(partner.role)
				}) : null]
			}),
			partner ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, { person: partner }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-4 grid grid-cols-2 gap-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Username",
							value: partner.username || partner.displayName || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Age",
							value: partner.age ? String(partner.age) : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Sex",
							value: sexLabel(partner.sex) || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Role",
							value: roleLabel(partner.role)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Type",
							value: styleLabel(partner.role, partner.roleStyle) || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Experience",
							value: experienceLabel(partner.experience)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KinkList, {
					values: parseKinks(partner.kinks),
					role: partner.role
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					className: "mt-5 w-full",
					onClick: () => void goSolo(),
					disabled: Boolean(busy),
					children: busy === "solo" ? "Switching…" : "Switch to solo"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					className: "mt-2 w-full",
					onClick: () => void goCompanion(),
					disabled: Boolean(busy),
					children: busy === "companion" ? "Switching…" : "Switch to the companion"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					className: "mt-2 w-full text-destructive",
					onClick: () => void drop(partner),
					disabled: Boolean(busy),
					children: "Drop from roster"
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: mine.playMode === "companion" ? "The companion is live. Pair a human from the roster, or keep shaping them from Companion." : "No one is live. Switch to someone on the roster, pair a new code, or play with the companion."
			}), mine.playMode === "companion" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm",
				children: "Playing with the companion. These pages are only this house."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "mt-5 w-full",
				onClick: () => void goSolo(),
				disabled: Boolean(busy),
				children: busy === "solo" ? "Switching…" : "Switch to solo"
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "mt-5 w-full",
				onClick: () => void goCompanion(),
				disabled: Boolean(busy),
				children: busy === "companion" ? "Switching…" : "Switch to the companion"
			})] }),
			roster.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground",
					children: "Roster"
				}), roster.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 rounded-lg border border-border px-3 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
							person,
							compact: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-medium",
								children: person.username || "Partner"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs text-muted-foreground",
								children: [roleLabel(person.role), person.available ? "" : " · with someone else"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 flex-col gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => void activate(person),
								disabled: Boolean(busy),
								children: busy === person.userId ? "…" : "Switch"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-[11px] text-muted-foreground hover:text-destructive",
								onClick: () => void drop(person),
								disabled: Boolean(busy),
								children: "Drop"
							})]
						})
					]
				}, person.userId))]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 space-y-3 border-t border-border pt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground",
						children: "Pair someone new"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg bg-secondary px-4 py-5 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
							children: "Your pairing code"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-display text-4xl tracking-[0.28em]",
							children: mine.pairingCode
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Their code" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: code,
							onChange: (e) => setCode(e.target.value.toUpperCase()),
							placeholder: "ABC123",
							className: "tracking-[0.2em]"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						onClick: () => void connect(),
						disabled: Boolean(busy) || code.length < 4,
						children: busy === "connect" ? "Connecting…" : partner ? "Connect and switch" : "Connect"
					})
				]
			})
		]
	});
}
function Portrait({ person, compact }) {
	if (person.avatarData) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: person.avatarData,
		alt: "",
		className: compact ? "size-12 shrink-0 rounded-lg object-cover" : "h-48 w-full rounded-lg object-cover"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: compact ? "grid size-12 shrink-0 place-items-center rounded-lg bg-secondary font-display text-lg text-muted-foreground" : "grid h-48 place-items-center rounded-lg bg-secondary font-display text-5xl text-muted-foreground",
		children: (person.username || person.displayName || "?").charAt(0)
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-xs uppercase tracking-[0.14em] text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "mt-1",
		children: value
	})] });
}
function localDateKey(date) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function monthWindow(year, month) {
	const from = new Date(year, month, 1);
	const to = new Date(year, month + 1, 1);
	return {
		from: from.toISOString(),
		to: to.toISOString()
	};
}
function dayBounds(dateKey) {
	const [y, m, d] = dateKey.split("-").map(Number);
	const start = new Date(y, m - 1, d);
	const end = new Date(y, m - 1, d + 1);
	return {
		start: start.getTime(),
		end: end.getTime()
	};
}
function formatDurationMs(ms) {
	if (!Number.isFinite(ms) || ms <= 0) return "";
	if (ms < 45e3) return "a moment";
	if (ms < 36e5) {
		const minutes = Math.max(1, Math.round(ms / 6e4));
		return minutes === 1 ? "1 min" : `${minutes} min`;
	}
	if (ms < 864e5) {
		const hours = Math.floor(ms / 36e5);
		const minutes = Math.round(ms % 36e5 / 6e4);
		if (!minutes) return hours === 1 ? "1 hour" : `${hours} hours`;
		return `${hours}h ${minutes}m`;
	}
	const days = Math.floor(ms / 864e5);
	return days === 1 ? "1 day" : `${days} days`;
}
function formatOpenCount(count) {
	if (count <= 0) return "did not open Sanctum";
	if (count === 1) return "opened Sanctum 1 time";
	return `opened Sanctum ${count} times`;
}
function entityLabel(entity) {
	if (entity === "rabbit" || entity === "training") return "training";
	if (entity === "task") return "task";
	if (entity === "habit") return "habit";
	if (entity === "punishment") return "punishment";
	if (entity === "reward") return "reward";
	if (entity === "game") return "game";
	if (entity === "scene") return "scene";
	if (entity === "journal") return "journal";
	if (entity === "note") return "note";
	if (entity === "catalog") return "catalogue item";
	if (entity === "roleplay") return "roleplay";
	if (entity === "challenge") return "challenge";
	if (entity === "house") return "the dynamic";
	if (entity === "location") return "location";
	return entity || "entry";
}
function describeChange(change, actorName) {
	const title = change.title.trim();
	const entity = entityLabel(change.entity);
	switch (change.action) {
		case "created": return `${actorName} added ${entity}${title ? ` “${title}”` : ""}`;
		case "completed": return `${actorName} completed${title ? ` “${title}”` : ` ${entity}`}`;
		case "reopened": return `${actorName} reopened${title ? ` “${title}”` : ` ${entity}`}`;
		case "skipped": return `${actorName} skipped${title ? ` “${title}”` : ` ${entity}`}`;
		case "overdue": return `${actorName} missed due time on${title ? ` “${title}”` : ` ${entity}`}`;
		case "archived": return `${actorName} archived${title ? ` “${title}”` : ` ${entity}`}`;
		case "restored": return `${actorName} restored${title ? ` “${title}”` : ` ${entity}`}`;
		case "updated": return `${actorName} edited${title ? ` “${title}”` : ` ${entity}`}`;
		case "deleted": return `${actorName} deleted${title ? ` “${title}”` : ` ${entity}`}`;
		case "weekly_reset": return `${title ? `“${title}”` : entity} was reset for the new week`;
		case "bought": return `${actorName} bought${title ? ` “${title}”` : ` ${entity}`}${change.detail ? ` for ${change.detail}` : ""}`;
		case "vacation_on": return `${actorName} paused duties`;
		case "vacation_off": return `${actorName} resumed duties`;
		case "sharing_on": return `${actorName} started sharing location`;
		case "sharing_off": return `${actorName} stopped sharing location`;
		case "paired": return `${actorName} connected a partner`;
		case "unpaired": return `${actorName} disconnected`;
		case "talk": return `${actorName} answered in Talk${title ? ` — ${title}` : ""}`;
		case "journal": return `${actorName} shared a journal page${title ? ` “${title}”` : ""}`;
		case "points": return `${actorName} moved points${change.detail ? ` (${change.detail})` : ""}`;
		case "permissions": return `${actorName} changed permissions`;
		case "message": return `${actorName} sent a message`;
		case "photo": return `${actorName} sent a photo`;
		case "video": return `${actorName} sent a video`;
		case "voice": return `${actorName} sent a voice note`;
		default: return change.detail || `${actorName} ${change.action}${title ? ` “${title}”` : ""}`;
	}
}
function opensOnDay(history, dateKey) {
	return history.opens.filter((item) => localDateKey(new Date(item.openedAt)) === dateKey);
}
function openCountsByUser(history, dateKey) {
	const counts = /* @__PURE__ */ new Map();
	for (const person of history.people) counts.set(person.userId, 0);
	for (const open of opensOnDay(history, dateKey)) counts.set(open.userId, (counts.get(open.userId) ?? 0) + 1);
	return history.people.map((person) => ({
		person,
		count: counts.get(person.userId) ?? 0
	}));
}
function totalOpensOnDay(history, dateKey) {
	return opensOnDay(history, dateKey).length;
}
function visitsOnDay(history, dateKey, now = Date.now()) {
	const { start, end } = dayBounds(dateKey);
	return history.visits.map((visit) => {
		const arrived = new Date(visit.arrivedAt).getTime();
		const departed = visit.departedAt ? new Date(visit.departedAt).getTime() : now;
		return {
			visit,
			durationMs: Math.max(0, Math.min(departed, end) - Math.max(arrived, start)),
			arrived,
			departed
		};
	}).filter((item) => item.durationMs > 0).sort((a, b) => a.arrived - b.arrived);
}
function changesOnDay(history, dateKey) {
	return history.changes.filter((item) => localDateKey(new Date(item.createdAt)) === dateKey).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}
function personName(people, userId) {
	return people.find((item) => item.userId === userId)?.displayName || "Someone";
}
function monthMarks(history, year, month) {
	const marks = {};
	const last = new Date(year, month + 1, 0).getDate();
	for (let day = 1; day <= last; day += 1) {
		const key = localDateKey(new Date(year, month, day));
		marks[key] = {
			opens: totalOpensOnDay(history, key),
			visits: visitsOnDay(history, key).length,
			changes: changesOnDay(history, key).length
		};
	}
	return marks;
}
function emptyHistory() {
	return {
		people: [],
		opens: [],
		visits: [],
		changes: []
	};
}
var WEEKDAYS = [
	"Sun",
	"Mon",
	"Tue",
	"Wed",
	"Thu",
	"Fri",
	"Sat"
];
function HouseCalendar({ me }) {
	const today = localDateKey(/* @__PURE__ */ new Date());
	const now = /* @__PURE__ */ new Date();
	const [cursor, setCursor] = (0, import_react.useState)({
		year: now.getFullYear(),
		month: now.getMonth()
	});
	const [selected, setSelected] = (0, import_react.useState)(today);
	const [history, setHistory] = (0, import_react.useState)(emptyHistory());
	const [loading, setLoading] = (0, import_react.useState)(true);
	const load = (0, import_react.useCallback)(async () => {
		const range = monthWindow(cursor.year, cursor.month);
		try {
			setHistory(await getHouseHistory({ data: range }));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not load the calendar.");
		} finally {
			setLoading(false);
		}
	}, [cursor.month, cursor.year]);
	(0, import_react.useEffect)(() => {
		load();
	}, [load]);
	useLiveReload(load);
	const marks = (0, import_react.useMemo)(() => monthMarks(history, cursor.year, cursor.month), [
		cursor.month,
		cursor.year,
		history
	]);
	const firstWeekday = new Date(cursor.year, cursor.month, 1).getDay();
	const daysInMonth = new Date(cursor.year, cursor.month + 1, 0).getDate();
	const title = new Intl.DateTimeFormat(void 0, {
		month: "long",
		year: "numeric"
	}).format(new Date(cursor.year, cursor.month, 1));
	const selectedLabel = new Intl.DateTimeFormat(void 0, {
		weekday: "long",
		month: "long",
		day: "numeric"
	}).format(/* @__PURE__ */ new Date(`${selected}T12:00:00`));
	const openRows = openCountsByUser(history, selected);
	const visitRows = visitsOnDay(history, selected);
	const changeRows = changesOnDay(history, selected);
	const myId = me.profile?.userId;
	function shiftMonth(delta) {
		setCursor((prev) => {
			const date = new Date(prev.year, prev.month + delta, 1);
			return {
				year: date.getFullYear(),
				month: date.getMonth()
			};
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-xl border border-border bg-card p-4 sm:p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "Shared with both of you — opens, places, and every change in Sanctum."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex shrink-0 gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-10 place-items-center rounded-lg bg-secondary text-muted-foreground hover:text-foreground",
							onClick: () => shiftMonth(-1),
							"aria-label": "Previous month",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-10 place-items-center rounded-lg bg-secondary text-muted-foreground hover:text-foreground",
							onClick: () => shiftMonth(1),
							"aria-label": "Next month",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-7 gap-1 text-center text-xs uppercase tracking-[0.12em] text-muted-foreground",
					children: WEEKDAYS.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "py-1",
						children: day
					}, day))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 grid grid-cols-7 gap-1",
					children: [Array.from({ length: firstWeekday }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}, `pad-${i}`)), Array.from({ length: daysInMonth }, (_, i) => {
						const day = i + 1;
						const key = localDateKey(new Date(cursor.year, cursor.month, day));
						const mark = marks[key];
						const isToday = key === today;
						const isSelected = key === selected;
						const opens = mark?.opens ?? 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSelected(key),
							className: cn("flex min-h-14 flex-col items-center justify-center rounded-lg px-1 py-1.5 text-sm", isSelected ? "bg-primary text-primary-foreground" : isToday ? "bg-secondary text-foreground" : "text-foreground hover:bg-secondary/70"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums leading-none",
								children: day
							}), opens > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: cn("mt-1 text-xs tabular-nums", isSelected ? "text-primary-foreground/80" : "text-primary"),
								children: [opens, "×"]
							}) : mark && (mark.visits > 0 || mark.changes > 0) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("mt-1 size-1 rounded-full", isSelected ? "bg-primary-foreground/80" : "bg-primary") }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1 h-1" })]
						}, key);
					})]
				}),
				loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-muted-foreground",
					children: "Reading the log…"
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-xl border border-border bg-card p-4 sm:p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-2xl",
					children: selectedLabel
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Visible to both of you."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground",
						children: "Opens"
					}), openRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-lg bg-secondary px-3 py-3 text-sm text-muted-foreground",
						children: "No one is connected to this bond yet."
					}) : openRows.map(({ person, count }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 rounded-lg bg-secondary/70 px-3 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
								name: person.displayName,
								src: person.avatarData
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: person.userId === myId ? "You" : person.displayName || "Partner"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: formatOpenCount(count)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "ml-auto font-display text-2xl tabular-nums leading-none",
								children: count
							})
						]
					}, person.userId))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground",
						children: "Places"
					}), visitRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-lg bg-secondary px-3 py-3 text-sm text-muted-foreground",
						children: "No shared locations this day."
					}) : visitRows.map(({ visit, durationMs }) => {
						const who = visit.userId === myId ? "You" : personName(history.people, visit.userId);
						const stay = formatDurationMs(durationMs) || "a moment";
						const href = visit.lat != null && visit.lng != null ? googleMapsLink(visit.lat, visit.lng) : null;
						const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 size-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: visit.placeName || "Unnamed place"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-0.5 flex items-center gap-1 text-xs text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-3" }),
									who,
									" · stayed ",
									stay
								]
							})]
						})] });
						return href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href,
							target: "_blank",
							rel: "noreferrer",
							className: "flex items-start gap-3 rounded-lg bg-secondary/70 px-3 py-3 hover:bg-secondary",
							children: inner
						}, visit.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-start gap-3 rounded-lg bg-secondary/70 px-3 py-3",
							children: inner
						}, visit.id);
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground",
						children: "Changes"
					}), changeRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-lg bg-secondary px-3 py-3 text-sm text-muted-foreground",
						children: "Nothing was changed this day."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "space-y-2",
						children: changeRows.map((change) => {
							const name = change.actorId === myId ? "You" : personName(history.people, change.actorId);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-lg bg-secondary/70 px-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm",
									children: describeChange(change, name)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: formatWhen(change.createdAt)
								})]
							}, change.id);
						})
					})]
				})
			]
		})]
	});
}
function Avatar({ name, src }) {
	if (src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: "",
		className: "size-10 rounded-lg object-cover outline outline-1 -outline-offset-1 outline-foreground/15"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid size-10 place-items-center rounded-lg bg-background font-display text-lg text-muted-foreground",
		children: (name || "?").charAt(0)
	});
}
function HouseView() {
	const hash = useRouterState({ select: (s) => s.location.hash });
	const tab = parseHouseTab(hash);
	const [me, setMe] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const load = (0, import_react.useCallback)(async () => {
		try {
			setMe(await getMe());
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not open settings.");
		} finally {
			setLoading(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		load();
	}, [load]);
	(0, import_react.useEffect)(() => subscribeMe(setMe), []);
	useLiveReload(load);
	if (loading || !me?.profile) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 animate-pulse rounded-xl bg-card" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.2em] text-primary",
					children: "Settings"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-4xl font-medium",
					children: HOUSE_NAV.find((item) => item.hash === tab)?.label ?? "Settings"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm text-muted-foreground",
					children: "Profiles, options, the shared calendar, archived entries, location, and the Dominant's lock on who may write in each category."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 overflow-x-auto pb-1 md:hidden",
				children: HOUSE_NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/house",
					hash: item.hash,
					className: cn("h-10 shrink-0 rounded-full border px-3 text-sm", tab === item.hash ? "border-primary bg-primary/10 text-foreground" : "border-border text-muted-foreground"),
					children: item.label
				}, item.hash))
			}),
			tab === "you" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
				profile: me.profile,
				lastPartner: me.lastPartner,
				partners: me.partners,
				onSaved: setMe
			}) : null,
			tab === "partner" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartnerCard, {
				me,
				onChange: setMe
			}) : null,
			tab === "options" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OptionsPanel, {
				me,
				onChange: setMe
			}) : null,
			tab === "app" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppPanel, {
				me,
				onChange: setMe
			}) : null,
			tab === "calendar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HouseCalendar, { me }) : null,
			tab === "archive" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArchivePanel, {}) : null,
			tab === "location" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocationPanel, { me }) : null,
			tab === "permissions" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionsPanel, {
				me,
				onChange: setMe
			}) : null
		]
	});
}
function ArchivePanel() {
	const [rows, setRows] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [busyId, setBusyId] = (0, import_react.useState)(null);
	const load = (0, import_react.useCallback)(async () => {
		try {
			setRows(await listArchived());
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not load archived entries.");
		} finally {
			setLoading(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		load();
	}, [load]);
	useLiveReload(load);
	async function restore(entry) {
		setBusyId(entry.id);
		try {
			await updateEntry({ data: {
				id: entry.id,
				kind: entry.kind,
				status: "open"
			} });
			toast.success(`Restored “${entry.title}”.`);
			await load();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not restore.");
		} finally {
			setBusyId(null);
		}
	}
	async function remove(entry) {
		if (typeof window !== "undefined" && !window.confirm(`Permanently delete “${entry.title}”? This cannot be undone.`)) return;
		setBusyId(entry.id);
		try {
			await deleteEntry({ data: { id: entry.id } });
			toast.success("Deleted permanently.");
			await load();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not delete.");
		} finally {
			setBusyId(null);
		}
	}
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 animate-pulse rounded-xl bg-card" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-4 rounded-xl border border-border bg-card p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl",
			children: "Archived"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "Restore anything you filed away, or delete it permanently. Completions still stay on the calendar."
		})] }), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-lg bg-secondary px-3 py-8 text-center text-sm text-muted-foreground",
			children: "Nothing is archived. Archive a task, habit, reward, or anything else from its page, then it lands here."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: rows.map((entry) => {
				const kindLabel = entry.kind === "task" && entry.cadence === "habit" ? "Habit" : entry.kind === "rabbit" ? "Training" : KINDS[entry.kind]?.title ?? entityLabel(entry.kind);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-3 rounded-lg bg-secondary/70 px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-medium",
							children: entry.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs uppercase tracking-[0.12em] text-muted-foreground",
							children: [
								kindLabel,
								entry.category ? ` · ${entry.category}` : "",
								` · ${formatWhen(entry.updatedAt || entry.createdAt)}`
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex shrink-0 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							disabled: busyId === entry.id,
							onClick: () => void restore(entry),
							children: "Restore"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							disabled: busyId === entry.id,
							onClick: () => void remove(entry),
							children: "Delete"
						})]
					})]
				}, entry.id);
			})
		})]
	});
}
function OptionsPanel({ me, onChange }) {
	const profile = me.profile;
	const [draft, setDraft] = (0, import_react.useState)(me.options);
	const isDom = profile.role === "dominant";
	const data = {
		honorific: draft.honorific.trim(),
		addressAs: draft.addressAs.trim(),
		safeword: draft.safeword.trim(),
		checkIn: draft.checkIn.trim()
	};
	const dirty = data.honorific !== me.options.honorific || data.addressAs !== me.options.addressAs || data.safeword !== me.options.safeword || data.checkIn !== me.options.checkIn;
	const saveStatus = useAutoSave(JSON.stringify(data), async () => {
		onChange(await saveUserOptions({ data }));
	}, {
		delay: 500,
		enabled: dirty
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-5 rounded-xl border border-border bg-card p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: isDom ? "Dominant options" : "Submissive options"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "How you wish to be addressed, how you address them, and the words that keep the dynamic safe. Changes save as you type."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Address me as" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: draft.honorific,
					onChange: (e) => setDraft((p) => ({
						...p,
						honorific: e.target.value
					})),
					placeholder: isDom ? "Sir, Mistress, Owner…" : "pet, boy, girl…",
					maxLength: 40
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "I address my partner as" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: draft.addressAs,
					onChange: (e) => setDraft((p) => ({
						...p,
						addressAs: e.target.value
					})),
					placeholder: isDom ? "pet, toy…" : "Sir, Mistress…",
					maxLength: 40
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Safeword" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: draft.safeword,
						onChange: (e) => setDraft((p) => ({
							...p,
							safeword: e.target.value
						})),
						placeholder: "Shared with your connected partner",
						maxLength: 40
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Visible to your connected partner. Empty stays private."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Daily check-in" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "time",
					value: draft.checkIn,
					onChange: (e) => setDraft((p) => ({
						...p,
						checkIn: e.target.value
					}))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveHint, { status: saveStatus })
		]
	});
}
function AppPanel({ me, onChange }) {
	const [hideCompleted, setHideCompleted] = (0, import_react.useState)(me.options.hideCompleted);
	const [showReminders, setShowReminders] = (0, import_react.useState)(me.options.showReminders);
	const [quickNav, setQuickNav] = (0, import_react.useState)(me.options.quickNav?.length ? me.options.quickNav : [
		"/",
		"/training",
		"/games",
		"/talk"
	]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function persist(next) {
		setBusy(true);
		try {
			onChange(await saveUserOptions({ data: next }));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not save.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-5 rounded-xl border border-border bg-card p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "App settings"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Hide-completed and reminders stay on your login. Vacation pauses duties for both of you."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingRow, {
				title: "Vacation",
				copy: "Pause every task, habit, training item, and protocol. Either of you can resume at any time.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VacationToggle, {
					me,
					onChange
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingRow, {
				title: "Hide completed on Home",
				copy: "Keep the day list focused on what is still open.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AllowToggle, {
					allowed: hideCompleted,
					labels: ["On", "Off"],
					disabled: busy,
					onChange: (on) => {
						setHideCompleted(on);
						persist({ hideCompleted: on });
					}
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingRow, {
				title: "Home reminders",
				copy: "Show timed tasks and habits at the top of Home.",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AllowToggle, {
					allowed: showReminders,
					labels: ["On", "Off"],
					disabled: busy,
					onChange: (on) => {
						setShowReminders(on);
						persist({ showReminders: on });
					}
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Quick access bar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Pick up to four categories for the bar at the bottom of the screen."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5",
						children: NAV.map((item) => {
							const on = quickNav.includes(item.to);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy,
								onClick: () => {
									const paths = (on ? quickNav.filter((path) => path !== item.to) : quickNav.length >= 4 ? [...quickNav.slice(1), item.to] : [...quickNav, item.to]).slice(0, 4);
									setQuickNav(paths);
									persist({ quickNav: paths });
								},
								className: cn("h-9 rounded-full px-3 text-sm", on ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
								children: item.label
							}, item.to);
						})
					})
				]
			})
		]
	});
}
function PermissionsPanel({ me, onChange }) {
	const isDom = me.profile?.role === "dominant";
	const [house, setHouse] = (0, import_react.useState)(me.house);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const partnerName = me.partner?.displayName || "your submissive";
	async function setKey(key, allowed) {
		if (!isDom) return;
		const next = {
			...house,
			subEdit: {
				...house.subEdit,
				[key]: allowed
			}
		};
		setHouse(next);
		setBusy(true);
		try {
			onChange(await saveHouseSettings({ data: next }));
		} catch (err) {
			setHouse(me.house);
			toast.error(err instanceof Error ? err.message : "Could not update permissions.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-5 rounded-xl border border-border bg-card p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Edit permissions"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: isDom ? `Allow or deny ${partnerName} the ability to write tasks, habits, rewards, punishments, training, and games — whether they may set points costs or change counts on punishments, rewards, scenes, and roleplay — and whether they may set days, hours, and minutes on timers.` : "Your Dominant decides whether you may write in these categories, set points costs, change those counts, or edit timers. Completing, skipping, serving, and buying still belong to you."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: isDom ? "Dominant" : "Read only" })]
			}),
			!me.partner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-lg bg-secondary px-3 py-3 text-sm text-muted-foreground",
				children: "Connect a partner to apply these locks to a bond. You can still set them now."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: EDIT_SCOPES.map((scope) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingRow, {
					title: scope.label,
					copy: scope.hint,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AllowToggle, {
						allowed: house.subEdit[scope.key],
						disabled: busy || !isDom,
						onChange: (allowed) => void setKey(scope.key, allowed)
					})
				}, scope.key))
			})
		]
	});
}
function LocationPanel({ me }) {
	const [board, setBoard] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [geoError, setGeoError] = (0, import_react.useState)("");
	const load = (0, import_react.useCallback)(async () => {
		try {
			setBoard(await getLocationBoard());
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not load location.");
		}
	}, []);
	(0, import_react.useEffect)(() => {
		load();
		const id = window.setInterval(() => void load(), 12e3);
		return () => window.clearInterval(id);
	}, [load]);
	useLiveReload(load);
	function sendFix(pos) {
		pingLocation({ data: {
			lat: pos.coords.latitude,
			lng: pos.coords.longitude,
			accuracy: Number.isFinite(pos.coords.accuracy) ? pos.coords.accuracy : null
		} }).then((fix) => {
			setBoard((prev) => prev ? {
				...prev,
				mine: fix
			} : prev);
			setGeoError("");
		}).catch((err) => {
			setGeoError(err instanceof Error ? err.message : "Could not send location.");
		});
	}
	async function toggleShare(sharing) {
		setBusy(true);
		try {
			const next = await setLocationSharing({ data: { sharing } });
			setBoard(next);
			notifyLocationChanged();
			if (sharing && navigator.geolocation) navigator.geolocation.getCurrentPosition(sendFix, (err) => {
				setGeoError(err.message || "Location permission was denied.");
			}, {
				enableHighAccuracy: true,
				timeout: 2e4
			});
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not update sharing.");
		} finally {
			setBusy(false);
		}
	}
	if (!board) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 animate-pulse rounded-xl bg-card" });
	const partnerFix = board.partner;
	const partnerLive = Boolean(partnerFix?.sharing && partnerFix.lat != null && partnerFix.lng != null);
	const mineLive = Boolean(board.mine.sharing && board.mine.lat != null && board.mine.lng != null);
	const distance = partnerLive && mineLive ? haversineMeters({
		lat: board.mine.lat,
		lng: board.mine.lng
	}, {
		lat: partnerFix.lat,
		lng: partnerFix.lng
	}) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-xl border border-border bg-card p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-2xl",
					children: [me.partner?.displayName || "Partner", " on the map"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Live pin on Google Maps, only while they choose to share it."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: partnerLive ? "default" : "outline",
					children: partnerLive ? "Live" : "Hidden"
				})]
			}), !me.partner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-lg bg-secondary px-3 py-3 text-sm text-muted-foreground",
				children: "Connect a partner from Settings → Partner to see their location."
			}) : partnerLive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapCard, {
				lat: partnerFix.lat,
				lng: partnerFix.lng,
				label: me.partner.displayName || "Partner",
				place: partnerFix.placeName,
				updatedAt: partnerFix.updatedAt,
				accuracy: partnerFix.accuracy,
				distance
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-lg bg-secondary px-3 py-3 text-sm text-muted-foreground",
				children: [me.partner.displayName || "Your partner", " is not sharing a location right now."]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-xl border border-border bg-card p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingRow, {
					title: "Share my location",
					copy: "Sends a live pin to your connected partner. You can stop at any time. Passenger / public use only — never while driving.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AllowToggle, {
						allowed: board.mine.sharing,
						labels: ["Share", "Hide"],
						disabled: busy,
						onChange: (on) => void toggleShare(on)
					})
				}),
				geoError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-destructive",
					children: geoError
				}) : null,
				mineLive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapCard, {
						lat: board.mine.lat,
						lng: board.mine.lng,
						label: "You",
						place: board.mine.placeName,
						updatedAt: board.mine.updatedAt,
						accuracy: board.mine.accuracy
					})
				}) : board.mine.sharing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: "Waiting for a GPS fix from this device…"
				}) : null
			]
		})]
	});
}
function MapCard({ lat, lng, label, place, updatedAt, accuracy, distance }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-hidden rounded-xl border border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
				title: `${label} on Google Maps`,
				src: googleMapsEmbed(lat, lng),
				className: "h-72 w-full border-0 sm:h-96",
				loading: "lazy",
				referrerPolicy: "no-referrer-when-downgrade",
				allowFullScreen: true
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-1.5 font-medium",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-primary" }), place || `${lat.toFixed(5)}, ${lng.toFixed(5)}`]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: [
						formatAgo(updatedAt),
						accuracy != null ? ` · ±${Math.round(accuracy)} m` : "",
						distance != null ? ` · ${formatMeters(distance)} away` : ""
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "outline",
				size: "sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: googleMapsLink(lat, lng),
					target: "_blank",
					rel: "noreferrer",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, { className: "size-4" }),
						"Open in Google Maps",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5" })
					]
				})
			})]
		})]
	});
}
function SettingRow({ title, copy, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3 rounded-lg bg-secondary/60 px-3 py-3 sm:flex-row sm:items-center sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 sm:pr-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: copy
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "w-full shrink-0 sm:w-44",
			children
		})]
	});
}
function AllowToggle({ allowed, onChange, disabled, labels = ["Allow", "Deny"] }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-2 rounded-lg bg-background p-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			disabled,
			onClick: () => onChange(true),
			className: cn("h-10 rounded-md text-sm", allowed ? "bg-primary text-primary-foreground" : "text-muted-foreground"),
			children: labels[0]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			disabled,
			onClick: () => onChange(false),
			className: cn("h-10 rounded-md text-sm", !allowed ? "bg-primary text-primary-foreground" : "text-muted-foreground"),
			children: labels[1]
		})]
	});
}
function House() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HouseView, {}) });
}
//#endregion
export { House as component };
