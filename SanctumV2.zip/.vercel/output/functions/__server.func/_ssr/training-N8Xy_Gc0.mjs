import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as AppShell } from "./badge-CRftROn_.mjs";
import { a as KindPage } from "./kind-page-GHqW5OYA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/training-N8Xy_Gc0.js
var import_jsx_runtime = require_jsx_runtime();
function Training() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindPage, { kind: "rabbit" }) });
}
//#endregion
export { Training as component };
