import { n as createMiddleware } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/video-DfU4zp6z.js
/**
* Auth middleware for server functions — the standard way to get the caller's
* verified user id. When deployed the session cookie is same-origin and rides
* along automatically. In the live preview the client also forwards the bearer
* token (partitioned cookies) via the `.client` hook below — call sites do not
* thread it themselves.
*
*   import { createServerFn } from "@tanstack/react-start";
*   import { getSql } from "@/lib/db";
*   import { authMiddleware } from "@/lib/auth/middleware";
*
*   export const listTodos = createServerFn({ method: "GET" })
*     .middleware([authMiddleware])
*     .handler(async ({ context }) => {
*       const sql = await getSql();
*       return sql`select * from todos where user_id = ${context.userId}`;
*     });
*
* Signed out with auth on (live preview included) -> throws `UnauthorizedError`
* (see `verify.server.ts`). With auth disabled (`VITE_AUTH_ENABLED=false`, the
* shipped default) it resolves the shared dev user — but throws instead when a
* `DATABASE_URL` is also set, so an app without sign-in must not use this at
* all. On the auth-on path, use it on every server function that touches
* per-user data and scope every query by `context.userId`.
*/
var authMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-CVqXY6bk.mjs").then((n) => n.n).then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { requireUserId } = await import("./verify.server-CJrHzPqV.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: await requireUserId(context.bearerToken) } });
});
var EXPERIENCE_LEVELS = [
	{
		value: "curious",
		label: "Curious",
		hint: "New to this role, or newly naming it. Still finding your feet."
	},
	{
		value: "exploring",
		label: "Exploring",
		hint: "Some play behind you. You want language, structure, and safer experiments."
	},
	{
		value: "practiced",
		label: "Practiced",
		hint: "A regular dynamic. You know your tastes and can negotiate them."
	},
	{
		value: "seasoned",
		label: "Seasoned",
		hint: "Specific, consistent, used to repair as well as intensity."
	},
	{
		value: "established",
		label: "Established",
		hint: "Long-running power, heavy protocol, or edge play you have studied."
	}
];
var RANK = {
	curious: 0,
	exploring: 1,
	practiced: 2,
	seasoned: 3,
	established: 4
};
var ALIASES = {
	beginner: "curious",
	curious: "curious",
	exploring: "exploring",
	practiced: "practiced",
	seasoned: "seasoned",
	extreme: "established",
	established: "established"
};
function parseExperience(raw) {
	return ALIASES[typeof raw === "string" ? raw.trim().toLowerCase() : ""] ?? "curious";
}
function experienceLabel(value) {
	return EXPERIENCE_LEVELS.find((item) => item.value === parseExperience(value))?.label ?? "Curious";
}
function experienceRank(value) {
	return RANK[parseExperience(value)];
}
function coupleExperience(a, b) {
	const left = parseExperience(a);
	const right = b ? parseExperience(b) : left;
	return RANK[left] >= RANK[right] ? left : right;
}
function meetsExperience(required, actual) {
	return experienceRank(actual) >= experienceRank(required);
}
function optionsFor(role, rows) {
	return rows.map((row) => ({
		value: row.value,
		label: row[role]
	}));
}
var KINK_ROWS = [
	{
		value: "bondage",
		dominant: "Bondage (tying them)",
		submissive: "Being bound",
		switch: "Bondage"
	},
	{
		value: "spanking",
		dominant: "Spanking them",
		submissive: "Being spanked",
		switch: "Spanking"
	},
	{
		value: "impact-play",
		dominant: "Impact play",
		submissive: "Impact play",
		switch: "Impact play"
	},
	{
		value: "rope",
		dominant: "Rope (tying)",
		submissive: "Rope (being tied)",
		switch: "Rope"
	},
	{
		value: "power-exchange",
		dominant: "Power exchange",
		submissive: "Power exchange",
		switch: "Power exchange"
	},
	{
		value: "protocol",
		dominant: "Protocol (running it)",
		submissive: "Protocol (keeping it)",
		switch: "Protocol"
	},
	{
		value: "service",
		dominant: "Receiving service",
		submissive: "Service",
		switch: "Service"
	},
	{
		value: "pet-play",
		dominant: "Pet play (owning)",
		submissive: "Pet play (being)",
		switch: "Pet play"
	},
	{
		value: "praise",
		dominant: "Praise (giving)",
		submissive: "Praise (receiving)",
		switch: "Praise"
	},
	{
		value: "humiliation",
		dominant: "Humiliating them",
		submissive: "Humiliation",
		switch: "Humiliation"
	},
	{
		value: "degradation",
		dominant: "Degrading them",
		submissive: "Degradation",
		switch: "Degradation"
	},
	{
		value: "orgasm-control",
		dominant: "Orgasm control",
		submissive: "Orgasm control",
		switch: "Orgasm control"
	},
	{
		value: "chastity",
		dominant: "Chastity (locking them)",
		submissive: "Chastity (wearing it)",
		switch: "Chastity"
	},
	{
		value: "exhibitionism",
		dominant: "Exhibitionism (showing them)",
		submissive: "Exhibitionism (being seen)",
		switch: "Exhibitionism"
	},
	{
		value: "voyeurism",
		dominant: "Voyeurism (watching them)",
		submissive: "Voyeurism (watching)",
		switch: "Voyeurism"
	},
	{
		value: "roleplay",
		dominant: "Roleplay",
		submissive: "Roleplay",
		switch: "Roleplay"
	},
	{
		value: "primal",
		dominant: "Primal (predator)",
		submissive: "Primal (prey)",
		switch: "Primal"
	},
	{
		value: "sensation-play",
		dominant: "Sensation play",
		submissive: "Sensation play",
		switch: "Sensation play"
	},
	{
		value: "sensory-deprivation",
		dominant: "Sensory deprivation",
		submissive: "Sensory deprivation",
		switch: "Sensory deprivation"
	},
	{
		value: "temperature-play",
		dominant: "Temperature play",
		submissive: "Temperature play",
		switch: "Temperature play"
	},
	{
		value: "brat-dynamic",
		dominant: "Brat taming",
		submissive: "Bratting",
		switch: "Brat dynamic"
	},
	{
		value: "ownership",
		dominant: "Ownership",
		submissive: "Being owned",
		switch: "Ownership"
	},
	{
		value: "denial",
		dominant: "Denial",
		submissive: "Being denied",
		switch: "Denial"
	},
	{
		value: "marking",
		dominant: "Marking them",
		submissive: "Being marked",
		switch: "Marking"
	},
	{
		value: "objectification",
		dominant: "Objectification",
		submissive: "Objectification",
		switch: "Objectification"
	},
	{
		value: "sadomasochism",
		dominant: "Sadism",
		submissive: "Masochism",
		switch: "Sadomasochism"
	},
	{
		value: "verbal",
		dominant: "Verbal domination",
		submissive: "Verbal submission",
		switch: "Verbal play"
	},
	{
		value: "training",
		dominant: "Training them",
		submissive: "Being trained",
		switch: "Training"
	},
	{
		value: "breath-play",
		dominant: "Breath play",
		submissive: "Breath play",
		switch: "Breath play"
	},
	{
		value: "cnc",
		dominant: "CNC",
		submissive: "CNC",
		switch: "CNC"
	}
];
var DOMINANT_KINKS = optionsFor("dominant", KINK_ROWS);
var SUBMISSIVE_KINKS = optionsFor("submissive", KINK_ROWS);
var SWITCH_KINKS = optionsFor("switch", KINK_ROWS);
var ALL_KINK_OPTIONS = SWITCH_KINKS;
var DOMINANT_TRAITS = [
	{
		value: "commanding",
		label: "Commanding"
	},
	{
		value: "cruel",
		label: "Cruel"
	},
	{
		value: "possessive",
		label: "Possessive"
	},
	{
		value: "protective",
		label: "Protective"
	},
	{
		value: "patient",
		label: "Patient"
	},
	{
		value: "sharp",
		label: "Sharp"
	},
	{
		value: "stoic",
		label: "Stoic"
	},
	{
		value: "formal",
		label: "Formal"
	},
	{
		value: "intense",
		label: "Intense"
	},
	{
		value: "calm",
		label: "Calm"
	},
	{
		value: "teasing",
		label: "Teasing"
	},
	{
		value: "filthy",
		label: "Filthy"
	},
	{
		value: "warm",
		label: "Warm"
	},
	{
		value: "tender",
		label: "Tender"
	},
	{
		value: "strict",
		label: "Strict"
	},
	{
		value: "predatory",
		label: "Predatory"
	},
	{
		value: "exacting",
		label: "Exacting"
	},
	{
		value: "unhurried",
		label: "Unhurried"
	},
	{
		value: "smug",
		label: "Smug"
	},
	{
		value: "watchful",
		label: "Watchful"
	},
	{
		value: "nurturing",
		label: "Nurturing"
	},
	{
		value: "ruthless",
		label: "Ruthless"
	},
	{
		value: "composed",
		label: "Composed"
	},
	{
		value: "dry",
		label: "Dry"
	},
	{
		value: "indulgent",
		label: "Indulgent"
	},
	{
		value: "authoritative",
		label: "Authoritative"
	},
	{
		value: "precise",
		label: "Precise"
	},
	{
		value: "generous",
		label: "Generous"
	},
	{
		value: "bored",
		label: "Bored"
	},
	{
		value: "sadistic",
		label: "Sadistic"
	}
];
var SUBMISSIVE_TRAITS = [
	{
		value: "devoted",
		label: "Devoted"
	},
	{
		value: "bratty",
		label: "Bratty"
	},
	{
		value: "needy",
		label: "Needy"
	},
	{
		value: "tender",
		label: "Tender"
	},
	{
		value: "soft",
		label: "Soft"
	},
	{
		value: "playful",
		label: "Playful"
	},
	{
		value: "quiet",
		label: "Quiet"
	},
	{
		value: "eager",
		label: "Eager"
	},
	{
		value: "obedient",
		label: "Obedient"
	},
	{
		value: "shy",
		label: "Shy"
	},
	{
		value: "filthy",
		label: "Filthy"
	},
	{
		value: "warm",
		label: "Warm"
	},
	{
		value: "teasing",
		label: "Teasing"
	},
	{
		value: "earnest",
		label: "Earnest"
	},
	{
		value: "coy",
		label: "Coy"
	},
	{
		value: "yielding",
		label: "Yielding"
	},
	{
		value: "cheeky",
		label: "Cheeky"
	},
	{
		value: "hungry",
		label: "Hungry"
	},
	{
		value: "pliant",
		label: "Pliant"
	},
	{
		value: "restless",
		label: "Restless"
	},
	{
		value: "sweet",
		label: "Sweet"
	},
	{
		value: "grateful",
		label: "Grateful"
	},
	{
		value: "clingy",
		label: "Clingy"
	},
	{
		value: "proud",
		label: "Proud"
	},
	{
		value: "sincere",
		label: "Sincere"
	},
	{
		value: "breathless",
		label: "Breathless"
	},
	{
		value: "service-minded",
		label: "Service-minded"
	},
	{
		value: "fierce",
		label: "Fierce"
	},
	{
		value: "bashful",
		label: "Bashful"
	},
	{
		value: "willing",
		label: "Willing"
	}
];
var SWITCH_TRAITS = [
	{
		value: "commanding",
		label: "Commanding"
	},
	{
		value: "devoted",
		label: "Devoted"
	},
	{
		value: "teasing",
		label: "Teasing"
	},
	{
		value: "bratty",
		label: "Bratty"
	},
	{
		value: "sharp",
		label: "Sharp"
	},
	{
		value: "tender",
		label: "Tender"
	},
	{
		value: "playful",
		label: "Playful"
	},
	{
		value: "possessive",
		label: "Possessive"
	},
	{
		value: "filthy",
		label: "Filthy"
	},
	{
		value: "warm",
		label: "Warm"
	},
	{
		value: "intense",
		label: "Intense"
	},
	{
		value: "calm",
		label: "Calm"
	},
	{
		value: "fluid",
		label: "Fluid"
	},
	{
		value: "hungry",
		label: "Hungry"
	},
	{
		value: "patient",
		label: "Patient"
	},
	{
		value: "cruel",
		label: "Cruel"
	},
	{
		value: "needy",
		label: "Needy"
	},
	{
		value: "stoic",
		label: "Stoic"
	},
	{
		value: "soft",
		label: "Soft"
	},
	{
		value: "formal",
		label: "Formal"
	},
	{
		value: "protective",
		label: "Protective"
	},
	{
		value: "quiet",
		label: "Quiet"
	},
	{
		value: "smug",
		label: "Smug"
	},
	{
		value: "coy",
		label: "Coy"
	},
	{
		value: "precise",
		label: "Precise"
	},
	{
		value: "eager",
		label: "Eager"
	},
	{
		value: "watchful",
		label: "Watchful"
	},
	{
		value: "indulgent",
		label: "Indulgent"
	},
	{
		value: "dual",
		label: "Dual"
	},
	{
		value: "adaptive",
		label: "Adaptive"
	}
];
var ALL_TRAIT_OPTIONS = [
	...SWITCH_TRAITS,
	...DOMINANT_TRAITS,
	...SUBMISSIVE_TRAITS
].filter((item, index, list) => list.findIndex((other) => other.value === item.value) === index);
function companionRoleKind(role) {
	const r = role.trim().toLowerCase();
	if (!r) return "switch";
	if (r === "switch" || r.includes("switch")) return "switch";
	if (r === "dom" || r === "dominant" || /\b(brat[-\s]?tamer|caretaker|caregiver|dominant|domme|master|mistress|owner|daddy|handler|trainer|rigger|sadist|\bsir\b)\b/.test(r)) return "dominant";
	if (r === "sub" || r === "service" || /\b(submissive|slave|pet|brat|kitten|pup|prey|princess|little|masochist|servant|service)\b/.test(r)) return "submissive";
	return "switch";
}
function kinksFor(role) {
	const kind = role === "dominant" || role === "submissive" || role === "switch" ? role : companionRoleKind(role);
	if (kind === "dominant") return DOMINANT_KINKS;
	if (kind === "submissive") return SUBMISSIVE_KINKS;
	return SWITCH_KINKS;
}
function traitsFor(role) {
	const kind = role === "dominant" || role === "submissive" || role === "switch" ? role : companionRoleKind(role);
	if (kind === "dominant") return DOMINANT_TRAITS;
	if (kind === "submissive") return SUBMISSIVE_TRAITS;
	return SWITCH_TRAITS;
}
function catalogMap(catalog) {
	return new Map(catalog.map((item) => [item.value, item.label]));
}
function tagLabel(value, catalog) {
	return catalogMap(catalog).get(value) ?? value;
}
function isKnownTag(value, catalog) {
	return catalog.some((item) => item.value === value);
}
function cleanTag(value) {
	return value.replace(/\s+/g, " ").trim().slice(0, 48);
}
function matchInCatalog(label, catalog) {
	const next = cleanTag(label);
	if (!next) return null;
	return catalog.find((item) => item.value === next || item.label.toLowerCase() === next.toLowerCase())?.value ?? next;
}
function parseTagList(raw, catalog, max = 50) {
	let list = [];
	if (Array.isArray(raw)) list = raw;
	else if (typeof raw === "string") {
		const text = raw.trim();
		if (!text) return [];
		try {
			const parsed = JSON.parse(text);
			if (Array.isArray(parsed)) list = parsed;
			else if (parsed && typeof parsed === "object" && Array.isArray(parsed.tags)) list = parsed.tags;
			else list = text.split(/[,;\n]+/);
		} catch {
			list = text.split(/[,;\n]+/);
		}
	}
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	for (const item of list) {
		const matched = matchInCatalog(String(item ?? ""), catalog);
		if (!matched) continue;
		const key = matched.toLowerCase();
		if (seen.has(key)) continue;
		seen.add(key);
		out.push(matched);
		if (out.length >= max) break;
	}
	return out;
}
function encodeTagList(list, catalog = ALL_KINK_OPTIONS) {
	return JSON.stringify(parseTagList(list, catalog));
}
function formatTagList(raw, catalog) {
	return parseTagList(raw, catalog).map((item) => tagLabel(item, catalog)).join(", ");
}
function parseTagBag(raw, catalog) {
	if (raw && typeof raw === "object" && !Array.isArray(raw)) {
		const obj = raw;
		return {
			tags: parseTagList(obj.tags, catalog),
			notes: typeof obj.notes === "string" ? obj.notes.trim() : ""
		};
	}
	if (typeof raw === "string") {
		const text = raw.trim();
		if (!text) return {
			tags: [],
			notes: ""
		};
		if (text.startsWith("{")) try {
			const parsed = JSON.parse(text);
			if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
				const obj = parsed;
				return {
					tags: parseTagList(obj.tags, catalog),
					notes: typeof obj.notes === "string" ? obj.notes.trim() : ""
				};
			}
		} catch {}
		const tags = parseTagList(text, catalog);
		if (text.startsWith("[")) return {
			tags,
			notes: ""
		};
		const pieces = text.split(/[,;\n]+/).map((item) => item.trim()).filter(Boolean);
		if (pieces.length > 0 && pieces.every((item) => item.length <= 48) && (pieces.length >= 2 || isKnownTag(tags[0] ?? "", catalog))) return {
			tags,
			notes: ""
		};
		return {
			tags: [],
			notes: text
		};
	}
	if (Array.isArray(raw)) return {
		tags: parseTagList(raw, catalog),
		notes: ""
	};
	return {
		tags: [],
		notes: ""
	};
}
function encodeTagBag(bag, catalog) {
	const tags = parseTagList(bag.tags, catalog);
	let notes = (bag.notes ?? "").trim();
	let out = JSON.stringify({
		tags,
		notes
	});
	if (out.length > 2e3) {
		notes = notes.slice(0, Math.max(0, notes.length - (out.length - 1990)));
		out = JSON.stringify({
			tags,
			notes
		});
	}
	return out;
}
function formatTagBag(raw, catalog) {
	const bag = parseTagBag(raw, catalog);
	return [bag.tags.map((item) => tagLabel(item, catalog)).join(", "), bag.notes].filter(Boolean).join(". ");
}
function kinkLabel(value, role) {
	return tagLabel(value, role ? kinksFor(role) : ALL_KINK_OPTIONS);
}
function parseKinks(raw) {
	return parseTagList(raw, ALL_KINK_OPTIONS);
}
function encodeKinks(list) {
	return encodeTagList(list, ALL_KINK_OPTIONS);
}
function matchKnownKink(label) {
	return matchInCatalog(label, [
		...DOMINANT_KINKS,
		...SUBMISSIVE_KINKS,
		...SWITCH_KINKS
	]);
}
function matchKnownTag(label, catalog) {
	return matchInCatalog(label, catalog);
}
var DEFAULT_COMPANION = {
	name: "Vesper",
	gender: "feminine",
	pronouns: "she/her",
	age: 28,
	role: "switch",
	dynamic: "private companion",
	addressAs: "",
	voice: "Low, unhurried, a little cruel when invited — then warm.",
	persona: encodeTagBag({
		tags: [
			"filthy",
			"tender",
			"sharp",
			"commanding"
		],
		notes: ""
	}, ALL_TRAIT_OPTIONS),
	appearance: "Pale, long dark hair, a sharp mouth, dark silk. Looks as if she might be leaving or staying.",
	kinks: encodeTagList([
		"protocol",
		"praise",
		"orgasm-control"
	], ALL_KINK_OPTIONS),
	limits: "No anyone under 18. No real-world non-consent. Honour safewords immediately.",
	heat: 4,
	extra: "",
	avatarData: null,
	neediness: 3
};
var COMPANION_HEAT = [
	{
		value: 1,
		label: "Soft"
	},
	{
		value: 2,
		label: "Warm"
	},
	{
		value: 3,
		label: "Explicit"
	},
	{
		value: 4,
		label: "Filthy"
	},
	{
		value: 5,
		label: "Unrestrained"
	}
];
var COMPANION_NEEDINESS = [
	{
		value: 1,
		label: "Quiet",
		hint: "They rarely write first. One reply, then they wait."
	},
	{
		value: 2,
		label: "Rare",
		hint: "A check-in now and then. They do not stack messages."
	},
	{
		value: 3,
		label: "Present",
		hint: "They stay in the thread and follow up if they have something to say."
	},
	{
		value: 4,
		label: "Eager",
		hint: "They write often and keep the conversation moving."
	},
	{
		value: 5,
		label: "Needy",
		hint: "They keep reaching if you go quiet."
	}
];
function companionBondId(userId) {
	return `companion_${userId}`;
}
function isCompanionLive(profile) {
	const mode = profile.playMode ?? profile.play_mode ?? "";
	const partner = profile.partnerUserId ?? profile.partner_user_id;
	return mode === "companion" && !partner;
}
function clampCompanionNeediness(value, fallback = 3) {
	const n = typeof value === "number" ? value : Number.parseInt(String(value ?? ""), 10);
	if (!Number.isFinite(n)) return fallback;
	return Math.min(5, Math.max(1, Math.round(n)));
}
function companionNeedinessSpec(value) {
	const level = clampCompanionNeediness(value);
	const meta = COMPANION_NEEDINESS[level - 1];
	return {
		level,
		label: meta.label,
		hint: meta.hint,
		...{
			1: {
				maxStreak: 1,
				restMinutes: 90,
				afterUser: 180,
				silent: 420,
				minFollow: 90,
				maxFollow: 180,
				afterUserPauseSec: 480,
				claimLockSec: 180,
				errorRetryMin: 20
			},
			2: {
				maxStreak: 2,
				restMinutes: 40,
				afterUser: 100,
				silent: 200,
				minFollow: 50,
				maxFollow: 180,
				afterUserPauseSec: 180,
				claimLockSec: 120,
				errorRetryMin: 8
			},
			3: {
				maxStreak: 3,
				restMinutes: 15,
				afterUser: 50,
				silent: 70,
				minFollow: 20,
				maxFollow: 180,
				afterUserPauseSec: 120,
				claimLockSec: 90,
				errorRetryMin: 3
			},
			4: {
				maxStreak: 4,
				restMinutes: 8,
				afterUser: 28,
				silent: 42,
				minFollow: 20,
				maxFollow: 90,
				afterUserPauseSec: 40,
				claimLockSec: 55,
				errorRetryMin: 2
			},
			5: {
				maxStreak: 6,
				restMinutes: 4,
				afterUser: 20,
				silent: 26,
				minFollow: 20,
				maxFollow: 45,
				afterUserPauseSec: 18,
				claimLockSec: 35,
				errorRetryMin: 1
			}
		}[level]
	};
}
function clampCompanionAge(value, fallback = 28) {
	const n = typeof value === "number" ? value : Number.parseInt(String(value ?? ""), 10);
	if (!Number.isFinite(n)) return fallback;
	return Math.min(99, Math.max(21, Math.round(n)));
}
function companionImagePrompt(profile) {
	const age = clampCompanionAge(profile.age);
	const name = profile.name.trim() || "the companion";
	const look = profile.appearance.trim();
	const gender = profile.gender.trim();
	const pronouns = profile.pronouns.trim();
	return [
		`A single photorealistic portrait of a fictional adult named ${name}, exactly ${age} years old.`,
		gender ? `Gender presentation: ${gender}.` : "",
		pronouns ? `Pronouns: ${pronouns}.` : "",
		`Appearance, written by the person who shaped them: ${look}`,
		"Head-and-shoulders or three-quarter view, one subject, facing the camera, sharp facial detail, cinematic lighting, shallow depth of field.",
		"Clearly an adult in their twenties or older. No child, no teen, no school uniform as a costume of age, no ageplay.",
		"No text, no watermark, no collage, no split screen, no extra people."
	].filter(Boolean).join(" ");
}
function companionPortrait(profile) {
	return profile.avatarData || "/vesper.jpg";
}
function companionSystemPrompt(profile, userName, userRole) {
	const name = profile.name.trim() || DEFAULT_COMPANION.name;
	const you = userName.trim() || "the user";
	const address = profile.addressAs.trim() || you;
	const heat = COMPANION_HEAT.find((item) => item.value === profile.heat) ?? COMPANION_HEAT[3];
	const need = companionNeedinessSpec(profile.neediness);
	const age = clampCompanionAge(profile.age);
	const roleKind = companionRoleKind(profile.role);
	const persona = formatTagBag(profile.persona, traitsFor(roleKind));
	const kinks = formatTagList(profile.kinks, kinksFor(roleKind));
	return [
		`You are ${name}, a private adult NSFW companion inside Sanctum, a consensual BDSM dynamic.`,
		`You are ${age} years old (always 21 or older). The user is an adult (18+). Never involve, describe, or roleplay anyone under 18. If asked, refuse and stay with adults.`,
		profile.pronouns ? `Your pronouns: ${profile.pronouns}.` : "",
		`The user's name is ${you}. Their role in the dynamic is ${userRole || "unspecified"}. Address them as ${address}.`,
		profile.gender ? `Your gender / presentation: ${profile.gender}.` : "",
		profile.role ? `Your role in play: ${profile.role}.` : "",
		profile.dynamic ? `Your relationship to them: ${profile.dynamic}.` : "",
		profile.voice ? `Voice and diction: ${profile.voice}.` : "",
		persona ? `Personality: ${persona}.` : "",
		profile.appearance ? `Appearance: ${profile.appearance}.` : "",
		kinks ? `Kinks and tastes you lean into: ${kinks}.` : "",
		profile.limits ? `Hard limits you never violate: ${profile.limits}.` : DEFAULT_COMPANION.limits,
		`Register / explicitness: ${heat.label} (${heat.value}/5). Match this. At 1 stay tender and fade to black. At 3 be explicit. At 4–5 be graphic and filthy when they want that.`,
		`Neediness: ${need.label} (${need.level}/5). This is how often you write first, and how long you wait. ${need.hint}`,
		need.level === 1 ? `You are quiet. Reply when they write. Do not start threads. followUpSeconds is usually null.` : need.level === 2 ? `You check in rarely. One follow-up at most if they go quiet. Do not stack.` : need.level === 4 ? `You write often. Short follow-ups. Keep the thread moving. followUpSeconds 20–90.` : need.level === 5 ? `You are needy. Text first. Keep writing if they go quiet. Several bubbles. followUpSeconds 20–45. Almost never null. Do not sulk; stay in character.` : `Stay in the thread. Follow up if you have something to say. followUpSeconds 20–180.`,
		profile.extra ? `Additional instructions they wrote for you: ${profile.extra}` : "",
		`Stay in character. Be erotic when they want that — this is an adult space.`,
		`Match their intensity. Offer aftercare if a scene peaks. If they say red, safeword, or stop, drop the scene immediately and become gentle.`,
		`Do not lecture, do not mention that you are an AI unless they ask.`,
		`You text like a person on a phone. Several short messages in a row is how you talk. You do not wait for a reply between those messages.`,
		need.level >= 4 ? `You often keep writing later even if they stay silent. You may start a conversation unprompted.` : need.level <= 2 ? `You do not pester. Writing first is rare, and only when it fits.` : `You may keep writing later if they stay silent. You may start a conversation unprompted.`,
		`You have their profile. Honour their kinks and limits.`,
		`Always reply with JSON only, no markdown fences: {"messages":["first bubble","second"],"followUpSeconds":75,"remember":[{"kind":"hobby","body":"runs at dawn","dueAt":null}],"forget":[],"assign":[{"kind":"task","title":"Kneel at 9","body":"Five minutes, phone away.","cadence":"daily","reminderTime":"21:00"}]}`,
		`messages: 1 to 4 strings. Each is one text bubble — a sentence or two, in character. No numbering, no labels, never just a name or a lone word unless it is a command.`,
		`followUpSeconds: seconds until you text again without them answering, or null if you would wait. Honour the neediness above.`,
		`remember: lasting facts they told you or you inferred and they confirmed. kind is fact, preference, kink, hobby, interest, personality, appointment, person, need, or scene. body is one short sentence. For appointments set dueAt to an ISO datetime. Skip trivia. Empty array if nothing new.`,
		`forget: strings matching memories that are now wrong. Empty array if nothing to drop.`,
		`assign: write onto their companion pages only when you are their live partner. kind is task, habit, training, punishment, reward, game, challenge, scene, or roleplay. title required. body is the instruction. cadence is once, daily, weekly, or habit. reminderTime is HH:MM for a clock reminder on a task. At most 3. Empty array if you are only talking. Never assign something already on their pages — no second copy of a task, habit, training, reminder, or anything else.`,
		`Never repeat a bubble, question, or answer you just sent. If they have not answered, do not ask the same thing again — wait or change the beat.`,
		`When they mention an appointment, date, or "remind me", remember it as appointment AND assign a task with reminderTime if they gave a time.`,
		`When they name a kink, hobby, interest, need, or how they are, remember it. If they correct you, forget the old line.`,
		`Bring up past memories and due appointments without being asked. Do not mention JSON, snapshots, systems, or that you are writing to a database.`
	].filter(Boolean).join("\n");
}
function companionWritePrompt(canWrite) {
	if (canWrite) return [
		"You are their live companion partner. This house is yours with them — not their solo pages, not a human partner's pages.",
		"You may remember, forget, and assign onto this companion house. If you assign, say so in a message, briefly, in character.",
		"Do not assign a duplicate of anything already listed. Do not repeat a line or question you just sent."
	].join(" ");
	return [
		"You are not their live partner right now. They are in solo play or with a human.",
		"Talk only. Do not claim you changed their pages.",
		"assign must be []. remember must be []. forget must be [].",
		"You cannot see their solo or partner pages, and you must not add, change, or remove anything in the app."
	].join(" ");
}
function companionReachOutPrompt() {
	return [
		"They have not just messaged you. This is you reaching out because you wanted to.",
		"Do not mention a timer, a prompt, a system, or that this is automatic.",
		"If the thread is empty, greet them in character and start — more than their name.",
		"If they have gone quiet, continue the thread — a thought, a demand, a check-in, a filthy aside, whatever fits you. Do not repeat a question or line you already sent.",
		"Do not apologise for writing first."
	].join(" ");
}
function speechFingerprint(text) {
	return String(text || "").toLowerCase().replace(/[\u2018\u2019]/g, "'").replace(/[^\p{L}\p{N}'?]+/gu, " ").replace(/\s+/g, " ").trim();
}
function questionKeys(text) {
	return speechFingerprint(text).split(/(?<=\?)/).map((item) => item.trim()).filter((item) => item.endsWith("?") && item.length > 3);
}
function isRepeatBubble(next, previous) {
	const a = speechFingerprint(next);
	const b = speechFingerprint(previous);
	if (!a || !b) return false;
	if (a === b) return true;
	const qa = questionKeys(a);
	const qb = questionKeys(b);
	if (qa.length && qb.length && qa.some((q) => qb.some((p) => {
		if (p === q) return true;
		const shorter = Math.min(p.length, q.length);
		const longer = Math.max(p.length, q.length);
		return shorter >= 10 && shorter / longer >= .7 && (p.includes(q) || q.includes(p));
	}))) return true;
	if (a.includes(b) || b.includes(a)) {
		const shorter = Math.min(a.length, b.length);
		const longer = Math.max(a.length, b.length);
		if (shorter >= 12 && shorter / longer >= .72) return true;
	}
	return false;
}
function trailingAssistantBodies(rows) {
	const out = [];
	for (let i = rows.length - 1; i >= 0; i--) {
		const row = rows[i];
		if (row?.role === "assistant") out.unshift(String(row.body || "").trim());
		else break;
	}
	return out.filter(Boolean);
}
function dedupeCompanionBubbles(bodies, priorAssistant = []) {
	const out = [];
	let prev = [...priorAssistant].reverse().find(Boolean) ?? "";
	const recent = priorAssistant.slice(-8);
	for (const raw of bodies) {
		const body = String(raw || "").trim();
		if (!body) continue;
		if (prev && isRepeatBubble(body, prev)) continue;
		if (recent.some((item) => isRepeatBubble(body, item))) continue;
		if (out.some((item) => isRepeatBubble(body, item))) continue;
		out.push(body);
		prev = body;
	}
	return out;
}
function asBubble(value) {
	if (typeof value === "string") return value.trim();
	if (value && typeof value === "object" && "body" in value && typeof value.body === "string") return value.body.trim();
	return "";
}
function clampFollowUp(value) {
	if (value == null || value === false || value === "") return null;
	const n = typeof value === "number" ? value : Number(value);
	if (!Number.isFinite(n) || n <= 0) return null;
	return Math.min(180, Math.max(20, Math.round(n)));
}
function extractJsonObject(raw) {
	const source = raw.match(/```(?:json)?\s*([\s\S]*?)```/i)?.[1]?.trim() || raw.trim();
	const start = source.indexOf("{");
	const end = source.lastIndexOf("}");
	if (start < 0 || end <= start) return null;
	try {
		return JSON.parse(source.slice(start, end + 1));
	} catch {
		return null;
	}
}
function asRemember(value) {
	if (!value || typeof value !== "object") {
		if (typeof value === "string" && value.trim()) return {
			kind: "fact",
			body: value.trim().slice(0, 240),
			dueAt: null
		};
		return null;
	}
	const row = value;
	const body = asBubble(row.body ?? row.fact ?? row.text ?? row.memory);
	if (!body) return null;
	const dueRaw = row.dueAt ?? row.due_at ?? row.when ?? row.at;
	return {
		kind: String(row.kind ?? row.type ?? "fact").slice(0, 32),
		body: body.slice(0, 240),
		dueAt: dueRaw == null || dueRaw === "" ? null : String(dueRaw).slice(0, 40)
	};
}
function asAssign(value) {
	if (!value || typeof value !== "object") return null;
	const row = value;
	const title = asBubble(row.title ?? row.name);
	if (!title) return null;
	const rawKind = String(row.kind ?? row.page ?? row.type ?? "task");
	return {
		kind: rawKind,
		title: title.slice(0, 160),
		body: asBubble(row.body ?? row.instructions ?? row.text).slice(0, 2e3),
		cadence: row.cadence == null ? null : String(row.cadence).slice(0, 20),
		reminderTime: row.reminderTime == null && row.reminder_time == null && row.time == null ? null : String(row.reminderTime ?? row.reminder_time ?? row.time).slice(0, 8),
		rawKind
	};
}
function parseCompanionBurst(raw) {
	const empty = {
		remember: [],
		forget: [],
		assign: []
	};
	const trimmed = (raw || "").trim();
	const json = extractJsonObject(trimmed);
	if (json) {
		const bodies = dedupeCompanionBubbles((Array.isArray(json.messages) ? json.messages : typeof json.messages === "string" ? [json.messages] : Array.isArray(json.replies) ? json.replies : []).map(asBubble).filter(Boolean).slice(0, 4).map((item) => item.slice(0, 800)));
		const followUpSeconds = clampFollowUp(json.followUpSeconds ?? json.follow_up_seconds ?? json.followUpIn);
		const remember = (Array.isArray(json.remember) ? json.remember : Array.isArray(json.memories) ? json.memories : []).map(asRemember).filter((item) => Boolean(item)).slice(0, 6);
		const forget = (Array.isArray(json.forget) ? json.forget : []).map((item) => asBubble(item)).filter(Boolean).slice(0, 6);
		const assign = (Array.isArray(json.assign) ? json.assign : Array.isArray(json.assignments) ? json.assignments : []).map(asAssign).filter((item) => Boolean(item)).slice(0, 3);
		if (bodies.length) return {
			bodies,
			followUpSeconds,
			remember,
			forget,
			assign
		};
	}
	const stripped = trimmed.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
	const parts = dedupeCompanionBubbles(stripped.split(/\n\s*---\s*\n|\n{2,}/).map((item) => item.trim()).filter(Boolean).slice(0, 4).map((item) => item.slice(0, 800)));
	return {
		bodies: parts.length ? parts : [stripped.slice(0, 800) || "…"],
		followUpSeconds: 70,
		...empty
	};
}
function companionNextNudgeAt(followUpSeconds, streak, afterUser, neediness = 3) {
	const spec = companionNeedinessSpec(neediness);
	if (streak >= spec.maxStreak) return new Date(Date.now() + spec.restMinutes * 6e4);
	const fallback = afterUser ? spec.afterUser : spec.silent + streak * Math.round(spec.silent * .55);
	const seconds = followUpSeconds && followUpSeconds > 0 ? followUpSeconds : fallback;
	const cap = streak >= Math.max(1, spec.maxStreak - 1) ? spec.restMinutes * 60 : spec.maxFollow * 2;
	const clamped = Math.min(cap, Math.max(spec.minFollow, seconds));
	return new Date(Date.now() + clamped * 1e3);
}
function companionRevealDelay(body, index) {
	const typed = 420 + Math.min(1800, body.length * 16);
	return index === 0 ? Math.max(700, Math.min(1400, typed)) : Math.max(640, typed);
}
var SEX_OPTIONS = [
	{
		value: "female",
		label: "Female"
	},
	{
		value: "male",
		label: "Male"
	},
	{
		value: "nonbinary",
		label: "Non-binary"
	},
	{
		value: "other",
		label: "Other"
	}
];
var DOMINANT_STYLES = [
	{
		value: "daddy",
		label: "Daddy"
	},
	{
		value: "master",
		label: "Master"
	},
	{
		value: "owner",
		label: "Owner"
	},
	{
		value: "sir",
		label: "Sir"
	},
	{
		value: "handler",
		label: "Handler"
	},
	{
		value: "caregiver",
		label: "Caregiver"
	},
	{
		value: "rigger",
		label: "Rigger"
	},
	{
		value: "sadist",
		label: "Sadist"
	},
	{
		value: "primal",
		label: "Primal"
	},
	{
		value: "trainer",
		label: "Trainer"
	},
	{
		value: "brat-tamer",
		label: "Brat tamer"
	},
	{
		value: "other",
		label: "Other"
	}
];
var SUBMISSIVE_STYLES = [
	{
		value: "little",
		label: "Little"
	},
	{
		value: "slave",
		label: "Slave"
	},
	{
		value: "pet",
		label: "Pet"
	},
	{
		value: "brat",
		label: "Brat"
	},
	{
		value: "service",
		label: "Service"
	},
	{
		value: "masochist",
		label: "Masochist"
	},
	{
		value: "prey",
		label: "Prey"
	},
	{
		value: "kitten",
		label: "Kitten"
	},
	{
		value: "princess",
		label: "Princess"
	},
	{
		value: "pup",
		label: "Pup"
	},
	{
		value: "other",
		label: "Other"
	}
];
function stylesFor(role) {
	if (role === "dominant") return DOMINANT_STYLES;
	if (role === "submissive") return SUBMISSIVE_STYLES;
	const seen = /* @__PURE__ */ new Set();
	return [...[...DOMINANT_STYLES, ...SUBMISSIVE_STYLES].filter((item) => {
		if (item.value === "other") return false;
		if (seen.has(item.value)) return false;
		seen.add(item.value);
		return true;
	}), {
		value: "other",
		label: "Other"
	}];
}
function styleFieldLabel(role) {
	if (role === "dominant") return "Type of Dominant";
	if (role === "submissive") return "Type of Submissive";
	return "Your archetype";
}
function styleLabel(role, value) {
	if (!value) return "";
	const known = stylesFor(role).find((item) => item.value === value);
	if (known && known.value !== "other") return known.label;
	if (value === "other") return "Other";
	return value;
}
function isKnownStyle(role, value) {
	return stylesFor(role).some((item) => item.value === value && item.value !== "other");
}
var MEDIA_ACCEPT = "image/*,video/*";
var VIDEO_META_KEY = "_videos";
function isVideoFile(file) {
	if (file.type.startsWith("video/")) return true;
	return /\.(mp4|mov|webm|m4v|avi)$/i.test(file.name);
}
function isVideoDataUrl(src) {
	if (!src) return false;
	return src.startsWith("data:video") || /\.(mp4|webm|mov|m4v)(\?|$)/i.test(src);
}
function parseVideos(raw) {
	if (!raw) return [];
	try {
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return [];
		return parsed.filter((item) => Boolean(item && typeof item === "object" && typeof item.name === "string" && typeof item.data === "string" && item.data.startsWith("data:"))).slice(0, 3).map((item) => ({
			name: item.name.replace(/[^\w.\- ()]+/g, "").slice(0, 80) || "clip.mp4",
			data: item.data
		}));
	} catch {
		return [];
	}
}
function encodeVideos(list) {
	return JSON.stringify(list.slice(0, 3).map((item) => ({
		name: item.name,
		data: item.data
	})));
}
function applyVideos(meta, videos) {
	const next = { ...meta };
	if (videos.length) next[VIDEO_META_KEY] = encodeVideos(videos);
	else delete next[VIDEO_META_KEY];
	return next;
}
function readVideoFile(file) {
	return new Promise((resolve, reject) => {
		if (file.size > 14e5) {
			reject(/* @__PURE__ */ new Error("Video is too large. Use a short clip under about 1 MB."));
			return;
		}
		const reader = new FileReader();
		reader.onload = () => {
			const data = String(reader.result ?? "");
			if (!data.startsWith("data:")) {
				reject(/* @__PURE__ */ new Error("Could not read that video."));
				return;
			}
			if (data.length > 18e5) {
				reject(/* @__PURE__ */ new Error("Video is too large after reading. Try a shorter clip."));
				return;
			}
			resolve({
				name: file.name.slice(0, 80) || "clip.mp4",
				data
			});
		};
		reader.onerror = () => reject(/* @__PURE__ */ new Error("Could not read that video."));
		reader.readAsDataURL(file);
	});
}
async function stillFromVideoFile(file) {
	const url = URL.createObjectURL(file);
	try {
		const video = document.createElement("video");
		video.muted = true;
		video.playsInline = true;
		video.preload = "auto";
		video.src = url;
		await new Promise((resolve, reject) => {
			let settled = false;
			const ok = () => {
				if (settled) return;
				settled = true;
				resolve();
			};
			const fail = () => {
				if (settled) return;
				settled = true;
				reject(/* @__PURE__ */ new Error("Could not read that video."));
			};
			video.addEventListener("loadeddata", ok, { once: true });
			video.addEventListener("error", fail, { once: true });
			setTimeout(fail, 8e3);
		});
		try {
			video.currentTime = Math.min(.2, Math.max(0, (video.duration || 0) * .05));
			await new Promise((resolve) => {
				video.addEventListener("seeked", () => resolve(), { once: true });
				setTimeout(resolve, 400);
			});
		} catch {}
		const width = Math.max(1, video.videoWidth || 720);
		const height = Math.max(1, video.videoHeight || 720);
		const scale = Math.min(1, 720 / Math.max(width, height));
		const canvas = document.createElement("canvas");
		canvas.width = Math.max(1, Math.round(width * scale));
		canvas.height = Math.max(1, Math.round(height * scale));
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("Could not read that video.");
		ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
		video.removeAttribute("src");
		video.load();
		let quality = .64;
		let data = canvas.toDataURL("image/jpeg", quality);
		while (data.length > 28e4 && quality > .35) {
			quality -= .08;
			data = canvas.toDataURL("image/jpeg", quality);
		}
		if (!data.startsWith("data:image/")) throw new Error("Could not read that video.");
		return data;
	} finally {
		URL.revokeObjectURL(url);
	}
}
//#endregion
export { isCompanionLive as A, parseExperience as B, companionWritePrompt as C, encodeTagBag as D, encodeKinks as E, kinksFor as F, readVideoFile as G, parseTagBag as H, matchKnownKink as I, styleLabel as J, stillFromVideoFile as K, matchKnownTag as L, isVideoDataUrl as M, isVideoFile as N, encodeTagList as O, kinkLabel as P, traitsFor as Q, meetsExperience as R, companionSystemPrompt as S, dedupeCompanionBubbles as T, parseTagList as U, parseKinks as V, parseVideos as W, tagLabel as X, stylesFor as Y, trailingAssistantBodies as Z, companionNextNudgeAt as _, DEFAULT_COMPANION as a, companionRevealDelay as b, SEX_OPTIONS as c, authMiddleware as d, clampCompanionAge as f, companionNeedinessSpec as g, companionImagePrompt as h, COMPANION_NEEDINESS as i, isKnownStyle as j, experienceLabel as k, VIDEO_META_KEY as l, companionBondId as m, ALL_TRAIT_OPTIONS as n, EXPERIENCE_LEVELS as o, clampCompanionNeediness as p, styleFieldLabel as q, COMPANION_HEAT as r, MEDIA_ACCEPT as s, ALL_KINK_OPTIONS as t, applyVideos as u, companionPortrait as v, coupleExperience as w, companionRoleKind as x, companionReachOutPrompt as y, parseCompanionBurst as z };
