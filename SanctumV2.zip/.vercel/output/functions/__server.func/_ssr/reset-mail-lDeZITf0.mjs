import { r as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { bn as string, gn as object } from "../_libs/@better-auth/core+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reset-mail-lDeZITf0.js
var peekPreviewResetLink_createServerFn_handler = createServerRpc({
	id: "9ffe4cb406a7f11773e8c8e2b1153ebae178bea98de164e6854dd3928c8cab36",
	name: "peekPreviewResetLink",
	filename: "src/lib/reset-mail.ts"
}, (opts) => peekPreviewResetLink.__executeServer(opts));
var peekPreviewResetLink = createServerFn({ method: "POST" }).validator((input) => object({ email: string().email() }).parse(input)).handler(peekPreviewResetLink_createServerFn_handler, async ({ data }) => {
	const { isWorkspacePreview } = await import("./env.server-B4a86VpI.mjs").then((n) => n.n).then((n) => n.n);
	if (!isWorkspacePreview()) return { url: null };
	const { takePreviewResetUrl } = await import("./email-password-D0yGpERU.mjs").then((n) => n.t).then((n) => n.t);
	return { url: takePreviewResetUrl(data.email) };
});
//#endregion
export { peekPreviewResetLink_createServerFn_handler };
