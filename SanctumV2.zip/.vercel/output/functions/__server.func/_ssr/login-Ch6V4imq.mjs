import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as createServerFn } from "./ssr.mjs";
import { bn as string, gn as object } from "../_libs/@better-auth/core+[...].mjs";
import { r as signIn, t as authClient } from "./client-CVqXY6bk.mjs";
import { t as GROK_PROVIDERS } from "./server-mSvqDINc.mjs";
import { n as Input, r as Label, t as Button } from "./input-CkY6TqOo.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as createSsrRpc } from "./router-SKpFfkOD.mjs";
import { Y as rememberRole, yt as useCurrentUserState } from "./use-current-user-nzqgiI2T.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-Ch6V4imq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var peekPreviewResetLink = createServerFn({ method: "POST" }).validator((input) => object({ email: string().email() }).parse(input)).handler(createSsrRpc("9ffe4cb406a7f11773e8c8e2b1153ebae178bea98de164e6854dd3928c8cab36"));
function Login() {
	const { user, isPending } = useCurrentUserState();
	const [door, setDoor] = (0, import_react.useState)(null);
	const [mode, setMode] = (0, import_react.useState)("signup");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [previewResetUrl, setPreviewResetUrl] = (0, import_react.useState)(null);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-background vignette px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-4xl tracking-tight",
				children: "Sanctum"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Opening Sanctum"
			})]
		})
	});
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	async function submit(event) {
		event.preventDefault();
		if (mode === "forgot" || mode === "forgot-sent") {
			await sendReset();
			return;
		}
		if (!door) {
			toast.error("Choose Dominant or Submissive first.");
			return;
		}
		rememberRole(door);
		setBusy(true);
		try {
			if (mode === "signup") {
				const { error } = await authClient.signUp.email({
					email,
					password,
					name: name.trim() || (door === "dominant" ? "Dominant" : "Submissive")
				});
				if (error) throw new Error(error.message ?? "Could not create the account.");
			} else {
				const { error } = await authClient.signIn.email({
					email,
					password
				});
				if (error) throw new Error(error.message ?? "Could not sign in.");
			}
			window.location.href = "/";
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Sign-in failed.");
		} finally {
			setBusy(false);
		}
	}
	async function sendReset() {
		setBusy(true);
		try {
			const { error } = await authClient.requestPasswordReset({
				email,
				redirectTo: "/reset-password"
			});
			if (error) throw new Error(error.message ?? "Could not send the reset email.");
			let previewUrl = null;
			try {
				previewUrl = (await peekPreviewResetLink({ data: { email } })).url;
			} catch {
				previewUrl = null;
			}
			setPreviewResetUrl(previewUrl);
			setMode("forgot-sent");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not send the reset email.");
		} finally {
			setBusy(false);
		}
	}
	function openForgot() {
		setMode("forgot");
		setPreviewResetUrl(null);
	}
	const forgotOpen = mode === "forgot" || mode === "forgot-sent";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "relative min-h-dvh overflow-hidden bg-background vignette chamber-grid",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh w-full max-w-5xl flex-col px-5 py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl tracking-tight",
					children: "Sanctum"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-md text-sm text-muted-foreground",
					children: "A private space for one Dominant and one Submissive. Separate doors. One bond."
				}),
				!door && !forgotOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "my-auto py-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 md:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setDoor("dominant"),
							className: "min-h-44 rounded-xl border border-border bg-card p-8 text-left hover:border-primary/50 md:min-h-56",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
									children: "Enter as"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "mt-3 font-display text-5xl",
									children: "Dominant"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-xs text-sm text-muted-foreground",
									children: "Assign the day, write the protocol, hold the key."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setDoor("submissive"),
							className: "min-h-44 rounded-xl border border-border bg-card p-8 text-left hover:border-primary/50 md:min-h-56",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
									children: "Enter as"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "mt-3 font-display text-5xl",
									children: "Submissive"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-xs text-sm text-muted-foreground",
									children: "Receive the day, keep the journal, offer the work."
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 flex justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							className: "w-full max-w-md",
							onClick: openForgot,
							children: "Forgot password"
						})
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "my-auto w-full max-w-md py-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							if (forgotOpen) {
								setMode("signin");
								setPreviewResetUrl(null);
								return;
							}
							setDoor(null);
						},
						className: "text-xs uppercase tracking-[0.16em] text-muted-foreground hover:text-foreground",
						children: "Back"
					}), forgotOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 font-display text-4xl",
							children: "Forgot password"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: mode === "forgot-sent" ? "If that email has a door, a reset link is on its way. It expires in one hour." : "Enter the email on your door. We will send a link to choose a new password."
						}),
						mode === "forgot-sent" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 space-y-3",
							children: [previewResetUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "This preview cannot send mail, so the reset link is here instead."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								className: "w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: previewResetUrl,
									children: "Open reset link"
								})
							})] }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								className: "w-full",
								onClick: () => {
									setMode("signin");
									setPreviewResetUrl(null);
								},
								children: "Back to sign in"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "mt-6 space-y-3",
							onSubmit: (e) => void submit(e),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "block space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "forgot-email",
									children: "Email"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "forgot-email",
									type: "email",
									required: true,
									autoComplete: "email",
									value: email,
									onChange: (e) => setEmail(e.target.value)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								className: "w-full",
								disabled: busy || false,
								children: busy ? "Please wait…" : "Send reset link"
							})]
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 font-display text-4xl",
							children: door === "dominant" ? "Dominant door" : "Submissive door"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: mode === "signup" ? "Create your private account." : "Return to Sanctum."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "mt-6 space-y-3",
							onSubmit: (e) => void submit(e),
							children: [
								mode === "signup" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "block space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "login-name",
										children: "Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "login-name",
										value: name,
										onChange: (e) => setName(e.target.value),
										placeholder: "How you are addressed"
									})]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "block space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "login-email",
										children: "Email"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "login-email",
										type: "email",
										required: true,
										autoComplete: "email",
										value: email,
										onChange: (e) => setEmail(e.target.value)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "block space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "login-password",
										children: "Password"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "login-password",
										type: "password",
										required: true,
										minLength: 8,
										autoComplete: mode === "signup" ? "new-password" : "current-password",
										value: password,
										onChange: (e) => setPassword(e.target.value)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									className: "w-full",
									disabled: busy || false,
									children: busy ? "Please wait…" : mode === "signup" ? "Create account" : "Sign in"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							className: "mt-3 w-full",
							onClick: openForgot,
							children: "Forgot password"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-3 text-sm text-muted-foreground hover:text-foreground",
							onClick: () => setMode((m) => m === "signup" ? "signin" : "signup"),
							children: mode === "signup" ? "Already have a door? Sign in" : "Need a door? Create an account"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
								children: "Or continue with"
							}), GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								className: "w-full",
								onClick: () => {
									if (door) rememberRole(door);
									signIn(provider.providerId, { callbackURL: "/" });
								},
								children: ["Continue with ", provider.label]
							}, provider.providerId))]
						})
					] })]
				})
			]
		})
	});
}
//#endregion
export { Login as component };
