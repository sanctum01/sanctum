import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { l as require_react_dom } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { r as createServerFn } from "./ssr.mjs";
import { G as readVideoFile, K as stillFromVideoFile, N as isVideoFile, Y as stylesFor, a as DEFAULT_COMPANION, c as SEX_OPTIONS, d as authMiddleware, f as clampCompanionAge, i as COMPANION_NEEDINESS, j as isKnownStyle, o as EXPERIENCE_LEVELS, p as clampCompanionNeediness, q as styleFieldLabel, s as MEDIA_ACCEPT } from "./video-DfU4zp6z.mjs";
import { bn as string, cn as _enum, dn as boolean, gn as object, hn as number, un as array, vn as preprocess, yn as record } from "../_libs/@better-auth/core+[...].mjs";
import { t as authClient } from "./client-CVqXY6bk.mjs";
import { i as cn, n as Input, r as Label, t as Button } from "./input-CkY6TqOo.mjs";
import { F as Images, X as ChevronDown, Z as Camera, t as X, v as Send } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as createSsrRpc } from "./router-SKpFfkOD.mjs";
import { a as PolarGrid, i as PolarRadiusAxis, n as Radar, o as ResponsiveContainer, r as PolarAngleAxis, t as RadarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-current-user-nzqgiI2T.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom());
var MAX_EDGE = 720;
var JPEG_QUALITY = .64;
var MAX_CHARS = 28e4;
var IMAGE_ACCEPT = "image/*";
function isImageFile(file) {
	if (file.type.startsWith("video/")) return false;
	if (!file.type || file.type.startsWith("image/")) return true;
	return /\.(heic|heif|jpe?g|png|webp|gif|bmp|avif)$/i.test(file.name);
}
function readAsDataUrl(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result ?? ""));
		reader.onerror = () => reject(/* @__PURE__ */ new Error("Could not read that photo from your gallery."));
		reader.readAsDataURL(file);
	});
}
async function bitmapFromBlob(blob) {
	try {
		return await createImageBitmap(blob, { imageOrientation: "from-image" });
	} catch {
		return await createImageBitmap(blob);
	}
}
async function bitmapFromFile(file) {
	try {
		return await bitmapFromBlob(file);
	} catch {
		const url = URL.createObjectURL(file);
		try {
			const img = await new Promise((resolve, reject) => {
				const image = new Image();
				image.onload = () => resolve(image);
				image.onerror = () => reject(/* @__PURE__ */ new Error("Could not read that photo from your gallery. Try JPEG or PNG, or use the camera."));
				image.src = url;
			});
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, img.naturalWidth);
			canvas.height = Math.max(1, img.naturalHeight);
			const ctx = canvas.getContext("2d");
			if (!ctx) throw new Error("Could not read this image");
			ctx.drawImage(img, 0, 0);
			return await bitmapFromBlob(await new Promise((resolve, reject) => {
				canvas.toBlob((next) => next ? resolve(next) : reject(/* @__PURE__ */ new Error("Could not read this image")), "image/jpeg", .92);
			}));
		} finally {
			URL.revokeObjectURL(url);
		}
	}
}
function encodeCanvas(canvas) {
	let quality = JPEG_QUALITY;
	let data = canvas.toDataURL("image/jpeg", quality);
	while (data.length > MAX_CHARS && quality > .35) {
		quality -= .08;
		data = canvas.toDataURL("image/jpeg", quality);
	}
	if (data.length > MAX_CHARS) {
		const scale = Math.sqrt(MAX_CHARS / data.length) * .92;
		const next = document.createElement("canvas");
		next.width = Math.max(1, Math.round(canvas.width * scale));
		next.height = Math.max(1, Math.round(canvas.height * scale));
		const ctx = next.getContext("2d");
		if (!ctx) throw new Error("Could not compress this photo.");
		ctx.drawImage(canvas, 0, 0, next.width, next.height);
		data = next.toDataURL("image/jpeg", .55);
	}
	if (data.length > MAX_CHARS) throw new Error("Photo is still too large after compressing. Try a smaller image or use the camera.");
	return data;
}
function compressBitmap(bitmap) {
	const scale = Math.min(1, MAX_EDGE / Math.max(bitmap.width, bitmap.height));
	const width = Math.max(1, Math.round(bitmap.width * scale));
	const height = Math.max(1, Math.round(bitmap.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Could not read this image");
	ctx.drawImage(bitmap, 0, 0, width, height);
	bitmap.close();
	return encodeCanvas(canvas);
}
async function compressImage(file) {
	try {
		return compressBitmap(await bitmapFromFile(file));
	} catch (err) {
		const raw = await readAsDataUrl(file);
		if (!raw.startsWith("data:image/")) throw err instanceof Error ? err : /* @__PURE__ */ new Error("Could not read that photo.");
		if (/^data:image\/(jpeg|jpg|png|webp|gif)/i.test(raw) && raw.length <= MAX_CHARS) return raw;
		try {
			return compressBitmap(await bitmapFromBlob(await (await fetch(raw)).blob()));
		} catch {
			throw err instanceof Error ? err : /* @__PURE__ */ new Error("Could not read that photo from your gallery.");
		}
	}
}
var CONSENT_KEY = {
	gallery: "sanctum.media.gallery",
	camera: "sanctum.media.camera"
};
function grantMediaConsent(kind) {
	if (typeof localStorage === "undefined") return;
	localStorage.setItem(CONSENT_KEY[kind], "allow");
}
function isIosDevice() {
	if (typeof navigator === "undefined") return false;
	return /iPad|iPhone|iPod/i.test(navigator.userAgent) || navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1;
}
function isMobileDevice() {
	if (typeof navigator === "undefined") return false;
	if (isIosDevice() || /Android|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) return true;
	if (typeof window !== "undefined" && navigator.maxTouchPoints > 1 && window.matchMedia?.("(pointer: coarse)")?.matches) return true;
	return false;
}
function filesFromList(list) {
	if (!list) return [];
	return Array.from(list);
}
async function requestCameraStream() {
	if (!navigator.mediaDevices?.getUserMedia) throw new Error("Camera is not available in this browser.");
	return navigator.mediaDevices.getUserMedia({
		video: {
			facingMode: { ideal: "environment" },
			width: { ideal: 1280 },
			height: { ideal: 720 }
		},
		audio: false
	});
}
function stopMediaStream(stream) {
	stream?.getTracks().forEach((track) => track.stop());
}
function snapshotFromVideo(video) {
	const canvas = document.createElement("canvas");
	canvas.width = Math.max(1, video.videoWidth || 720);
	canvas.height = Math.max(1, video.videoHeight || 720);
	const ctx = canvas.getContext("2d");
	if (!ctx) return Promise.reject(/* @__PURE__ */ new Error("Could not take that photo."));
	ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
	return new Promise((resolve, reject) => {
		canvas.toBlob((blob) => blob ? resolve(blob) : reject(/* @__PURE__ */ new Error("Could not take that photo.")), "image/jpeg", .92);
	});
}
function fileFromBlob(blob, name) {
	return new File([blob], name, { type: blob.type || "image/jpeg" });
}
async function stageFiles(list, options = {}) {
	const allowImage = options.allowImage !== false;
	const allowVideo = Boolean(options.allowVideo);
	const max = options.max ?? 8;
	const staged = [];
	for (const file of filesFromList(list)) {
		if (staged.length >= max) break;
		if (allowVideo && isVideoFile(file)) try {
			const clip = await readVideoFile(file);
			staged.push({
				kind: "video",
				data: clip.data,
				name: clip.name
			});
			continue;
		} catch (err) {
			if (!allowImage) throw err;
			try {
				const still = await stillFromVideoFile(file);
				staged.push({
					kind: "image",
					data: still,
					name: `${(file.name.replace(/\.[^.]+$/, "") || "clip").slice(0, 60)}.jpg`
				});
				toast.message("That clip is too large to send. Attached a still from it instead.");
				continue;
			} catch {
				throw err;
			}
		}
		if (allowImage && isImageFile(file)) staged.push({
			kind: "image",
			data: await compressImage(file),
			name: file.name.slice(0, 80) || "photo.jpg"
		});
	}
	return staged;
}
function nativeAccept(value) {
	const hasVideo = /video/i.test(value);
	if ((/image/i.test(value) || !hasVideo) && hasVideo) return "image/*,video/*";
	if (hasVideo) return "video/*";
	return "image/*";
}
var pickClass = "relative flex h-11 w-full cursor-pointer items-center justify-center overflow-hidden rounded-md border border-dashed border-input text-sm text-muted-foreground";
function FilePickLabel({ accept, capture, multiple = false, disabled = false, onChange, label, icon: Icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: cn(pickClass, disabled && "pointer-events-none opacity-60"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "pointer-events-none relative z-0 flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), label]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "file",
			accept,
			...capture ? { capture } : {},
			multiple,
			disabled,
			className: "media-hit absolute inset-0 z-10 h-full w-full cursor-pointer opacity-[0.02]",
			onClick: (event) => event.stopPropagation(),
			onChange,
			"aria-label": label
		})]
	});
}
function PhotoSourceButtons({ onFiles, busy = false, multiple = false, galleryLabel = "Gallery", cameraLabel = "Camera", accept = IMAGE_ACCEPT }) {
	const videoRef = (0, import_react.useRef)(null);
	const [live, setLive] = (0, import_react.useState)(null);
	const [host, setHost] = (0, import_react.useState)(null);
	const mediaAccept = nativeAccept(accept);
	const liveCameraOk = !isMobileDevice() && mediaAccept.includes("image/") && typeof navigator !== "undefined" && typeof navigator.mediaDevices?.getUserMedia === "function";
	(0, import_react.useEffect)(() => {
		setHost(document.body);
	}, []);
	(0, import_react.useEffect)(() => {
		const node = videoRef.current;
		if (!node || !live) return;
		node.srcObject = live;
		node.play().catch(() => void 0);
		return () => {
			node.srcObject = null;
		};
	}, [live]);
	(0, import_react.useEffect)(() => () => stopMediaStream(live), [live]);
	function emitFiles(files, kind) {
		if (!files || files.length === 0) return;
		grantMediaConsent(kind);
		onFiles(files);
	}
	function handleGallery(event) {
		const files = Array.from(event.currentTarget.files ?? []);
		event.currentTarget.value = "";
		emitFiles(files, "gallery");
	}
	function handleCamera(event) {
		const files = Array.from(event.currentTarget.files ?? []);
		event.currentTarget.value = "";
		emitFiles(files, "camera");
	}
	async function startLiveCamera() {
		if (busy) return;
		try {
			const stream = await requestCameraStream();
			grantMediaConsent("camera");
			setLive(stream);
		} catch {
			toast.error("Camera access was denied. You can still choose a photo from your gallery.");
		}
	}
	function cancelLive() {
		stopMediaStream(live);
		setLive(null);
	}
	async function snap() {
		const node = videoRef.current;
		if (!node) return;
		try {
			const blob = await snapshotFromVideo(node);
			cancelLive();
			emitFiles([fileFromBlob(blob, "camera.jpg")], "camera");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not take that photo.");
		}
	}
	const blocked = busy || Boolean(live);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePickLabel, {
					accept: mediaAccept,
					multiple,
					disabled: blocked,
					onChange: handleGallery,
					label: galleryLabel,
					icon: Images
				}), liveCameraOk ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: pickClass,
					disabled: blocked,
					onClick: () => void startLiveCamera(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" }), cameraLabel]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePickLabel, {
					accept: mediaAccept,
					capture: "environment",
					disabled: blocked,
					onChange: handleCamera,
					label: cameraLabel,
					icon: Camera
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Gallery opens this device’s Photos. Camera opens the camera. Allow the prompt when the phone asks."
			}),
			live && host ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-[90] grid place-items-center bg-ink/90 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						ref: videoRef,
						autoPlay: true,
						muted: true,
						playsInline: true,
						className: "aspect-[3/4] w-full rounded-xl bg-secondary object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							className: "flex-1",
							variant: "outline",
							onClick: cancelLive,
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							className: "flex-1",
							onClick: () => void snap(),
							children: "Take photo"
						})]
					})]
				})
			}), host) : null
		]
	});
}
function PendingMediaTray({ items, onRemove, onCommit, onDiscard, commitLabel = "Send", busy = false }) {
	const tray = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!items.length) return;
		tray.current?.scrollIntoView({
			block: "nearest",
			behavior: "smooth"
		});
	}, [items.length]);
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: tray,
		className: "space-y-2 rounded-lg border border-border bg-secondary/60 p-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 text-[11px] uppercase tracking-[0.14em] text-muted-foreground",
				children: "Ready to send"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-2",
				children: items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative aspect-square overflow-hidden rounded-md bg-secondary",
					children: [item.kind === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						src: item.data,
						className: "size-full object-cover",
						muted: true,
						playsInline: true
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: item.data,
						alt: "",
						className: "size-full object-cover"
					}), onRemove ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "absolute top-1 right-1 grid size-7 place-items-center rounded-full bg-ink/70 text-foreground",
						onClick: () => onRemove(index),
						"aria-label": "Remove",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					}) : null]
				}, `${item.kind}-${item.name}-${index}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					className: "h-11",
					onClick: onDiscard,
					disabled: busy,
					children: "Discard"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					className: "h-11 flex-1",
					onClick: onCommit,
					disabled: busy,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {}), busy ? "Sending…" : commitLabel]
				})]
			})
		]
	});
}
function PhotoField({ photos, onChange, max = 4, label = "Photos", commitLabel = "Send" }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [pending, setPending] = (0, import_react.useState)([]);
	const replacing = max === 1 && photos.length >= 1;
	const room = replacing ? Math.max(0, 1 - pending.length) : Math.max(0, max - photos.length - pending.length);
	async function onPick(files) {
		if (!files?.length) return;
		if (room <= 0) {
			toast.error(replacing ? "Send or discard the photo waiting first." : `You can attach up to ${max} photos.`);
			return;
		}
		setBusy(true);
		try {
			const staged = await stageFiles(files, {
				allowImage: true,
				max: room
			});
			if (!staged.length) {
				toast.error("That file is not a photo. Choose a JPEG, PNG, or HEIC from your gallery.");
				return;
			}
			setPending((prev) => [...prev, ...staged]);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not read that photo.");
		} finally {
			setBusy(false);
		}
	}
	function commit() {
		if (!pending.length) return;
		onChange(replacing ? pending.map((item) => item.data) : [...photos, ...pending.map((item) => item.data)]);
		setPending([]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						photos.length,
						"/",
						max
					]
				})]
			}),
			photos.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-2",
				children: photos.map((src, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative aspect-square overflow-hidden rounded-md bg-secondary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src,
						alt: "",
						className: "size-full object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "absolute top-1 right-1 grid size-7 place-items-center rounded-full bg-ink/70 text-foreground",
						onClick: () => onChange(photos.filter((_, i) => i !== index)),
						"aria-label": "Remove photo",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					})]
				}, `${src.slice(0, 24)}-${index}`))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendingMediaTray, {
				items: pending,
				onRemove: (index) => setPending((prev) => prev.filter((_, i) => i !== index)),
				onCommit: commit,
				onDiscard: () => setPending([]),
				commitLabel,
				busy
			}),
			room > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoSourceButtons, {
				onFiles: onPick,
				busy,
				multiple: !replacing && max - photos.length > 1
			}) : null
		]
	});
}
function MediaField({ photos, videos, onPhotos, onVideos, maxPhotos = 4, maxVideos = 3, commitLabel = "Send" }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [pending, setPending] = (0, import_react.useState)([]);
	const pendingPhotos = pending.filter((item) => item.kind === "image").length;
	const pendingVideos = pending.filter((item) => item.kind === "video").length;
	const room = Math.max(0, maxPhotos - photos.length - pendingPhotos) + Math.max(0, maxVideos - videos.length - pendingVideos);
	async function onPick(files) {
		if (!files?.length) return;
		if (room <= 0) {
			toast.error("Send or discard what is waiting first, or remove a still or clip.");
			return;
		}
		setBusy(true);
		try {
			const staged = await stageFiles(files, {
				allowImage: true,
				allowVideo: true,
				max: room
			});
			const next = [];
			let usedPhotos = pendingPhotos;
			let usedVideos = pendingVideos;
			for (const item of staged) {
				if (item.kind === "video") {
					if (videos.length + usedVideos >= maxVideos) continue;
					usedVideos += 1;
					next.push(item);
					continue;
				}
				if (photos.length + usedPhotos >= maxPhotos) continue;
				usedPhotos += 1;
				next.push(item);
			}
			const skipped = staged.length - next.length;
			if (!next.length) {
				toast.error(skipped ? "No room left for that file." : "Choose a photo or video from your gallery.");
				return;
			}
			setPending((prev) => [...prev, ...next]);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not read that file.");
		} finally {
			setBusy(false);
		}
	}
	function commit() {
		if (!pending.length) return;
		onPhotos([...photos, ...pending.filter((item) => item.kind === "image").map((item) => item.data)]);
		onVideos([...videos, ...pending.filter((item) => item.kind === "video").map((item) => ({
			name: item.name,
			data: item.data
		}))]);
		setPending([]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground",
				children: "Photos & videos"
			}),
			photos.length || videos.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-4 gap-2",
				children: [photos.map((src, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative aspect-square overflow-hidden rounded-md bg-secondary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src,
						alt: "",
						className: "size-full object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "absolute top-1 right-1 grid size-7 place-items-center rounded-full bg-ink/70 text-foreground",
						onClick: () => onPhotos(photos.filter((_, i) => i !== index)),
						"aria-label": "Remove photo",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					})]
				}, `${src.slice(0, 24)}-${index}`)), videos.map((clip, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative aspect-square overflow-hidden rounded-md bg-secondary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						src: clip.data,
						className: "size-full object-cover",
						muted: true,
						playsInline: true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "absolute top-1 right-1 grid size-7 place-items-center rounded-full bg-ink/70 text-foreground",
						onClick: () => onVideos(videos.filter((_, i) => i !== index)),
						"aria-label": "Remove video",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					})]
				}, `${clip.name}-${index}`))]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendingMediaTray, {
				items: pending,
				onRemove: (index) => setPending((prev) => prev.filter((_, i) => i !== index)),
				onCommit: commit,
				onDiscard: () => setPending([]),
				commitLabel,
				busy
			}),
			room > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoSourceButtons, {
				onFiles: onPick,
				busy,
				multiple: true,
				accept: MEDIA_ACCEPT,
				galleryLabel: "Gallery",
				cameraLabel: "Camera"
			}) : null
		]
	});
}
function PhotoStrip({ photos, className, onOpen }) {
	if (!photos.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex gap-2 overflow-x-auto", className),
		children: photos.map((src, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onOpen?.(src),
			className: "h-20 w-20 shrink-0 overflow-hidden rounded-md bg-secondary",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src,
				alt: "",
				className: "size-full object-cover"
			})
		}, `${src.slice(0, 18)}-${index}`))
	});
}
function Lightbox({ src, onClose }) {
	if (!src) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "fixed inset-0 z-[80] grid place-items-center bg-ink/90 p-4",
		onClick: onClose,
		"aria-label": "Close photo",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: "",
			className: "max-h-[90dvh] max-w-full rounded-lg object-contain"
		})
	});
}
function VideoStrip({ videos }) {
	if (!videos.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-2 sm:grid-cols-2",
		children: videos.map((clip, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			src: clip.data,
			controls: true,
			playsInline: true,
			className: "max-h-48 w-full rounded-md bg-secondary"
		}, `${clip.name}-${index}`))
	});
}
function NeedinessField({ value, onChange }) {
	const level = clampCompanionNeediness(value);
	const current = COMPANION_NEEDINESS[level - 1];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Neediness" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "How often they write to you first."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-5 gap-1",
				children: COMPANION_NEEDINESS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onChange(item.value),
					className: cn("h-11 rounded-lg text-[11px]", level === item.value ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
					children: item.label
				}, item.value))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: current.hint
			})
		]
	});
}
var ROLE = _enum([
	"dominant",
	"submissive",
	"switch"
]);
var KIND = _enum([
	"task",
	"rabbit",
	"punishment",
	"reward",
	"game",
	"scene",
	"journal",
	"note",
	"catalog",
	"talk",
	"roleplay",
	"challenge",
	"playbook"
]);
var getMe = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("4ca0e640a65ed12abad4b14cff9dab3700c6b87e68cdfb1ea5a507f52c4711c1"));
var getBondSync = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("c2c111856e22a1bb6446e5980860260655728fd0067db20e01652dd83fd59d73"));
var listRecentEvents = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("e5ec663b10eeea32526ea8204c94940140cc71b7a7f61af5c7a79248a07cb2a9"));
var saveProfileInput = object({
	role: ROLE.optional(),
	displayName: string().max(80).optional(),
	username: string().max(32).optional(),
	avatarData: string().nullable().optional(),
	age: number().int().min(18).max(99).nullable().optional(),
	sex: string().max(24).optional(),
	roleStyle: string().max(80).optional(),
	experience: string().max(24).optional(),
	playMode: string().max(24).optional(),
	setupDone: boolean().optional(),
	kinks: array(string().max(48)).max(40).optional()
});
var saveProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => saveProfileInput.parse(input)).handler(createSsrRpc("d54d694599f19a01227c519721059d0a08f68e4a5c1da118f523c0d4c92f3e35"));
var connectInput = object({ code: string().min(4).max(16) });
var connectPartner = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => connectInput.parse(input)).handler(createSsrRpc("3649da42247e7d5ea4a9e740f8de79545b0ae6b66ba8ecf80a17418d056a6719"));
var disconnectPartner = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("8acb7c7113d08a6ab5c4dac91f25badcb88faf15a37fdff0699dac0a18745083"));
var playWithCompanion = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("6d6c4a52281553ced27a566258457f68b65a68defb6eef572060201e88dca12f"));
var switchInput = object({ userId: string().min(1).max(80) });
var switchPartner = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => switchInput.parse(input)).handler(createSsrRpc("90142c2ae35b4af07ce7e4c0bfafe9f1a1f390e273968e98a9dd956c97b88598"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("8747733cdbe9e7ef083ac3cc8230d731c7111541db352ceee6c15cd9d524fd2a"));
var removePartner = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => switchInput.parse(input)).handler(createSsrRpc("575653698e49c8b9397f546b826fe0982ffcaa2c950f22cb62f70045ba7e890f"));
var listInput = object({ kind: KIND });
var listEntries = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((input) => listInput.parse(input)).handler(createSsrRpc("af469a4b83b2d1dbf802968d7ffe99d0513413e1793fe26ebb22501d984c2b91"));
var listArchived = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("4db0472ea18d1b7959cbae26fc803989f5eb9510b3b7e146577bdda35e0d470c"));
var getDashboard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("9702758c6fd0cb855b9213cc5e565c91c6cccffe5c6a276226117b92c405025e"));
var entryFields = object({
	kind: KIND,
	title: string().min(1).max(160),
	body: string().max(4e4).optional(),
	cadence: string().max(20).nullable().optional(),
	weekday: number().int().min(0).max(6).nullable().optional(),
	status: string().max(24).optional(),
	category: string().max(40).nullable().optional(),
	subcategory: string().max(40).nullable().optional(),
	assignedTo: string().max(80).nullable().optional(),
	intensity: number().int().min(1).max(5).nullable().optional(),
	photoData: string().max(2e6).nullable().optional(),
	photos: array(string().max(2e6)).max(6).optional(),
	meta: record(string(), string()).optional()
});
var createEntry = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => entryFields.parse(input)).handler(createSsrRpc("84ce5e7931fe5e79efa37ee5563868704ebad401590ed9a4ca5af9aaa582d445"));
var updateFields = entryFields.partial().extend({
	id: number().int(),
	kind: KIND.optional()
});
var updateEntry = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => updateFields.parse(input)).handler(createSsrRpc("945a48daea4d7604d324408eb041748924bbc1bbc39724fdef0bc4ec6c28b9e7"));
var idInput = object({ id: number().int() });
var deleteEntry = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => idInput.parse(input)).handler(createSsrRpc("a4be0897da32c8d64e6961f09965b405e590569b2f2ad2faff1489af68d83b37"));
var toggleInput = object({
	id: number().int(),
	done: boolean()
});
var toggleEntry = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => toggleInput.parse(input)).handler(createSsrRpc("e6bb0967dcc5882087bc4573fa71425a22da898d1e03aa11c35b92d1ac3b9283"));
var buyEntry = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => idInput.parse(input)).handler(createSsrRpc("e2eb1f9c1e73d29db0ba11221b5534acf1b91409f1975e9a60d7a5db3f47d405"));
var listMessages = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("e7931bd90803fe77bdf7cc25f7a1ef7b7abd6dac7d92cdacdcfb9a30a151f557"));
var sendMessageInput = object({
	body: string().max(4e3).optional(),
	photoData: string().max(2e6).nullable().optional(),
	audioData: string().max(2e6).nullable().optional()
});
var sendMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => sendMessageInput.parse(input)).handler(createSsrRpc("8ddc7afeeb6af8011968dbd586bf937aa4c3aeec03b755f9e060762ad6405e83"));
var listPrivatePhotos = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("8dc911881c45cfa1c5a81bde59d36201bfc5e7f2c296e731be416fe70c66c408"));
var addPhotoInput = object({
	photoData: string().min(20).max(2e6),
	caption: string().max(200).optional()
});
var addPrivatePhoto = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => addPhotoInput.parse(input)).handler(createSsrRpc("79c86dba41bee9ca8f29a4383c994eefa576ea180a5b1dceb0b030dd44a9033a"));
var deletePrivatePhoto = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => idInput.parse(input)).handler(createSsrRpc("cdd0a6b21c58622e8b986d457a3cc6cf15752ffa7bd998c507df32e47b4e6e70"));
var kindOnly = object({ kind: KIND });
var listCategories = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((input) => kindOnly.parse(input)).handler(createSsrRpc("a4f3bfe5676e73ad63a13f24becfce190982ab9b839410fd3a214443dab7b170"));
var addCategoryInput = object({
	kind: KIND,
	name: string().min(1).max(40),
	parentSlug: string().max(40).nullable().optional()
});
var addCategory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => addCategoryInput.parse(input)).handler(createSsrRpc("b5e971d98abaacd45695c7eeceab4acb60d458358b6cf9446de8922229e68695"));
var categoryKey = object({
	id: number().int().optional(),
	kind: KIND.optional(),
	slug: string().max(40).optional(),
	name: string().min(1).max(40).optional(),
	parentSlug: string().max(40).nullable().optional(),
	archived: boolean().optional()
});
var updateCategory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => categoryKey.parse(input)).handler(createSsrRpc("e463ea9b3a583ab4bf0171de1351829b8c229e788890f6b510f6fe8111b8b4ce"));
var deleteCategory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => categoryKey.parse(input)).handler(createSsrRpc("275cd3b65decbb40021d5864e6e12101f8ad2f21f154f071b18bef1edf213f3e"));
var reorderEntriesInput = object({ ids: array(number().int()).min(1).max(200) });
var reorderEntries = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => reorderEntriesInput.parse(input)).handler(createSsrRpc("3455f21a352baa26819565b2e25726f6ff705b14f9f0955eee0a8a3f9bb59588"));
var reorderCategoriesInput = object({
	kind: KIND,
	slugs: array(string().max(40)).min(1).max(80)
});
var reorderCategories = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => reorderCategoriesInput.parse(input)).handler(createSsrRpc("4e009b7f3431aa39ac662d05bf56f5ee881cbb14998554f330bb88b36ff22c60"));
var setUrgencyInput = object({
	id: number().int(),
	urgency: _enum([
		"low",
		"normal",
		"high",
		"urgent"
	])
});
var setUrgency = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => setUrgencyInput.parse(input)).handler(createSsrRpc("35c05e1b823211e2ce5e81182551a9fd4ace577440cd1f3ed4b3a16f4f0b66c5"));
var setEarnedCountInput = object({
	id: number().int(),
	count: number().int().min(0).max(999)
});
var setEarnedCount = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => setEarnedCountInput.parse(input)).handler(createSsrRpc("299cef55e31f3e5900311ae14f841c50a43ed5ec319e63f9a1a29ca3893140ce"));
var listTalkAnswers = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("84dd6a1d36bfff44d1267ce0810910bfd89a376868312f4f5bb366ada4afca50"));
var talkInput = object({
	topic: string().min(1).max(160),
	body: string().max(8e3).optional(),
	rating: string().max(24).nullable().optional(),
	visibility: _enum(["shared", "private"]).optional()
});
var saveTalkAnswer = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => talkInput.parse(input)).handler(createSsrRpc("fad5f025e7255056d2fa25dbe80da637f4a72cf6b671e9bc56a74d96db2e9371"));
var seedStarter = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("a70c500dd2cf319c477b5fb0547716d69ac42a8a77876c034738b281ff0c9091"));
var getPoints = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("3265d8010e8b5e8cb1b9bd268eaf6a9900d4825d030c48979ae63fe952d017ff"));
var adjustPointsInput = object({
	userId: string().min(1).max(80),
	delta: number().int().min(-1e4).max(1e4),
	reason: string().max(160).optional()
});
var adjustPoints = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => adjustPointsInput.parse(input)).handler(createSsrRpc("4faa525eb45d4757e8f16d39d8e249e6fb8abd106592c96d410fa5ee30b8b777"));
var listJournalComments = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("34129f33579a7018f45d8765fc09ee72679440e546d4c4fe370b6bb3a38a4117"));
var commentInput = object({
	entryId: number().int(),
	body: string().max(4e3).optional(),
	photoData: string().max(2e6).nullable().optional()
});
var addJournalComment = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => commentInput.parse(input)).handler(createSsrRpc("c71e98a17fc1361f3621b05b072586be730aeec0a6922c0aaeb886aabdf8db57"));
var deleteJournalComment = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => idInput.parse(input)).handler(createSsrRpc("37739de315e5e2c4f69770038e12ed7368430b3c2f6321ea2900e4e8607e958c"));
createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("b0ebb168abb8cead542a020486436fe21859652ca85fd4871c246a7811bc7d25"));
var patternInput = object({
	title: string().min(1).max(80),
	steps: array(object({
		intensity: number().int().min(0).max(100),
		intensity2: number().int().min(0).max(100).optional(),
		ms: number().int().min(100).max(12e4)
	})).min(1).max(80)
});
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => patternInput.parse(input)).handler(createSsrRpc("e9677559cfbed168a469df3bae6173fa5514f5c3a808ee4513e61c0ae5669e2e"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => idInput.parse(input)).handler(createSsrRpc("746456416afc20a8ba7585f7845481733e738b5427d6a60d933e9e41e557b8a4"));
var spotifyInput = object({ url: string().min(8).max(400) });
createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((input) => spotifyInput.parse(input)).handler(createSsrRpc("faca0c56a141f7e9c01c795b475a66afc955921bea47e3c2a54bac40f9643aa5"));
var getCompanion = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("a13469c9cd24845616a32d25770ba7b3f042a57dfc8748ba2770111830641c53"));
var companionFields = object({
	name: string().max(80),
	gender: string().max(40),
	pronouns: string().max(40).optional(),
	age: preprocess((value) => {
		if (value == null || value === "") return void 0;
		const n = typeof value === "number" ? value : Number(value);
		if (!Number.isFinite(n)) return void 0;
		return clampCompanionAge(n);
	}, number().int().min(21).max(99).optional()),
	role: string().max(40),
	dynamic: string().max(80).optional(),
	addressAs: string().max(80),
	voice: string().max(400),
	persona: string().max(2e3),
	appearance: string().max(4e3),
	kinks: string().max(2e3),
	limits: string().max(2e3),
	heat: number().int().min(1).max(5).optional(),
	neediness: number().int().min(1).max(5).optional(),
	extra: string().max(2e3).optional(),
	avatarData: string().nullable().optional()
});
var saveCompanion = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => companionFields.parse(input)).handler(createSsrRpc("ce3639daf9d5fa5d4d9a22658b03756d18afa01242b40ad78df4acff6d522982"));
var portraitInput = object({
	appearance: string().min(8).max(4e3),
	name: string().max(80).optional(),
	gender: string().max(40).optional(),
	pronouns: string().max(40).optional(),
	age: preprocess((value) => {
		if (value == null || value === "") return void 0;
		const n = typeof value === "number" ? value : Number(value);
		if (!Number.isFinite(n)) return void 0;
		return clampCompanionAge(n);
	}, number().int().min(21).max(99).optional())
});
var generateCompanionPortrait = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => portraitInput.parse(input)).handler(createSsrRpc("f289cc01650d3b633314c04e34d44c68ced6b65fe9733f11eb48438f8bacc4d7"));
var listCompanionMessages = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("7dbdfc9769c1d61842bb71c39d17da05fa19dbca973657b4e7bdbbb443f6b94c"));
var clearCompanionMessages = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("ba59cd3412fa2696ebc504161476d99bc04bfb53cc294f1a06c64ec540cc8022"));
var chatInput = object({
	body: string().max(4e3).optional(),
	photoData: string().max(2e6).nullable().optional()
});
var sendCompanionMessage = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => chatInput.parse(input)).handler(createSsrRpc("53da5c0863190517fa2981be31fb1b710bfc223ba7fbb6aa5067ec8ebba566d4"));
var tickCompanion = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("39d022dae3a4d99fbd44d0868a3d9af0acce16ab5ab6d0c4c0909adb0dbea1dd"));
var listCompanionMemories = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("b0110c6e4eb12c78e7a3ac4a8aea65167b70c98804a3c8ec497a0e70bf17fa94"));
var dropMemoryInput = object({ id: number().int() });
var dropCompanionMemory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => dropMemoryInput.parse(input)).handler(createSsrRpc("91afd2cfc401b6f3012acea0637af3f521562fecaf9dc701224fd5b9ddc5a1e2"));
var houseInput = object({ subEdit: object({
	tasks: boolean(),
	habits: boolean(),
	rewards: boolean(),
	punishments: boolean(),
	training: boolean(),
	games: boolean(),
	costs: boolean().optional(),
	earnedCounts: boolean().optional(),
	countdowns: boolean().optional()
}) });
var saveHouseSettings = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => houseInput.parse(input)).handler(createSsrRpc("23ae13bf746bfb14a5be66cfe766ad5e1731fe4e9b949558906292ae5e7d1356"));
var saveVacation = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ on: boolean() }).parse(input)).handler(createSsrRpc("4c3ce0dfbd1d209e4197b524194f7906acf91a389b99b8bfc8605e84f0471e61"));
var playInput = object({
	play: object({
		wheelTitle: string().max(80).optional(),
		wheelSlices: array(string().max(80)).max(24).optional(),
		wheelBody: string().max(4e3).optional(),
		wheelPrompts: array(string().max(200)).max(40).optional(),
		wheelCatalogIds: array(string().max(24)).max(24).optional(),
		drawTitle: string().max(80).optional(),
		drawCards: array(object({
			title: string().max(80),
			body: string().max(800)
		})).max(40).optional(),
		drawBody: string().max(4e3).optional(),
		drawPrompts: array(string().max(200)).max(40).optional(),
		drawCatalogIds: array(string().max(24)).max(24).optional(),
		diceTitle: string().max(80).optional(),
		diceActs: array(string().max(160)).max(6).optional(),
		diceBody: string().max(4e3).optional(),
		dicePrompts: array(string().max(200)).max(40).optional(),
		diceCatalogIds: array(string().max(24)).max(24).optional(),
		timerTitle: string().max(80).optional(),
		timerBody: string().max(4e3).optional()
	}).optional(),
	wheels: record(string(), array(string().max(80)).max(40)).optional()
});
var savePlay = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => playInput.parse(input)).handler(createSsrRpc("fbc89f80cf0b4f7504c39b99cb006e61af2c3fcf042e79f810acdc42f3e21445"));
var optionsInput = object({
	honorific: string().max(40).optional(),
	addressAs: string().max(40).optional(),
	safeword: string().max(40).optional(),
	checkIn: string().max(8).optional(),
	hideCompleted: boolean().optional(),
	showReminders: boolean().optional(),
	autoCompleteNote: boolean().optional(),
	noteTask: string().max(800).optional(),
	noteHabit: string().max(800).optional(),
	noteTraining: string().max(800).optional(),
	quickNav: array(string().max(40)).max(4).optional()
});
var saveUserOptions = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => optionsInput.parse(input)).handler(createSsrRpc("ee2414619a18a5c472d5f4dd31b15cde201b2dd08753e48921c7fec09062feb9"));
var getLocationBoard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("3704f34fcc1d818841024ca36f0b8c8bca7d3793318600441b9ada92adae1864"));
var setLocationSharing = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => object({ sharing: boolean() }).parse(input)).handler(createSsrRpc("0e5a527d3f41a94e0d940376d5ecca4cde60d9617ffded5e335ee5444b4e5cc1"));
var pingInput = object({
	lat: number().min(-90).max(90),
	lng: number().min(-180).max(180),
	accuracy: number().nullable().optional()
});
var pingLocation = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => pingInput.parse(input)).handler(createSsrRpc("fa8c16e53688284881679a6691cf7b2833a750c7c9b03210f1e69c89de0fc52c"));
var recordAppOpen = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("5e27fbbbe1665d8b28050ccd62782e4fa2ea7f2de41ea0e03ddeba8fe9e024d5"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("eef9a9df9c5ee2b86cde8892389b36bf627bdf3a94ed759df0f5daccf6550719"));
var historyInput = object({
	from: string().min(10),
	to: string().min(10)
});
var getHouseHistory = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => historyInput.parse(input)).handler(createSsrRpc("5df9f4abce48952db09aede88c83f40180a9d09a4270c9a88e69125f119d2794"));
var deleteAccount = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("b048e6946c185c4855af156bac0c635404db122491eaa4d5bfa4d2d74245a7c9"));
function Select({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		className: cn("flex h-11 w-full appearance-none rounded-md border border-input bg-secondary bg-[length:12px] bg-[right_12px_center] bg-no-repeat px-3 pr-10 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring/60 disabled:opacity-50", className),
		style: { backgroundImage: "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='none' stroke='%23a89890' stroke-width='1.6' viewBox='0 0 16 16'><path d='m3 6 5 5 5-5'/></svg>\")" },
		...props,
		children
	});
}
function q(prompt, axes) {
	return {
		prompt,
		axes
	};
}
var LIKERT_OPTIONS = [
	{
		label: "Strongly disagree",
		value: 0
	},
	{
		label: "Disagree",
		value: 1
	},
	{
		label: "Slightly disagree",
		value: 2
	},
	{
		label: "Unsure",
		value: 3
	},
	{
		label: "Slightly agree",
		value: 4
	},
	{
		label: "Agree",
		value: 5
	},
	{
		label: "Strongly agree",
		value: 6
	}
];
var QUICK_LABELS = {
	dominance: "Dominance",
	submission: "Submission",
	sensation: "Sensation & Impact",
	psychological: "Psychological Play",
	bondage: "Bondage & Restraint",
	trust: "Trust & Vulnerability",
	adventurous: "Adventurousness"
};
var QUICK_SHORT_LABELS = {
	dominance: "Dominance",
	submission: "Submission",
	sensation: "Sensation",
	psychological: "Psychological",
	bondage: "Bondage",
	trust: "Trust",
	adventurous: "Adventure"
};
var QUICK_BLURBS = {
	dominance: "You may enjoy taking the lead, giving direction, or creating structure within an agreed power dynamic.",
	submission: "You may enjoy yielding decisions, following a lead, or offering control to someone you trust.",
	sensation: "You may be drawn to intensity on the body — impact, temperature, ache, or overload — when it is paced and wanted.",
	psychological: "You may be more turned on by the head than the toy: praise, protocol, mind games, or being seen.",
	bondage: "You may want restriction — rope, cuffs, being held still, or holding someone still — as the point of the scene.",
	trust: "You may get heat from dropping your guard, being held through it, or being the person someone can drop with.",
	adventurous: "You may like trying new shapes, pushing a known edge, or saying yes to experiments that stay inside consent."
};
var FULL_LABELS = {
	dominant: "Dominant",
	submissive: "Submissive",
	switch: "Switch",
	master: "Master/Mistress",
	slave: "Slave",
	daddy: "Daddy/Mommy",
	little: "Little",
	sadist: "Sadist",
	masochist: "Masochist",
	rigger: "Rigger",
	"rope-bunny": "Rope Bunny",
	degrader: "Degrader",
	degradee: "Degradee",
	hunter: "Primal (Hunter)",
	prey: "Primal (Prey)",
	voyeur: "Voyeur",
	exhibitionist: "Exhibitionist",
	brat: "Brat",
	"brat-tamer": "Brat Tamer",
	owner: "Owner",
	pet: "Pet",
	vanilla: "Vanilla",
	experimentalist: "Experimentalist",
	"non-hierarchical": "Non-Hierarchical"
};
var FULL_BLURBS = {
	dominant: "You may enjoy taking the lead, giving direction, or creating structure within an agreed power dynamic.",
	submissive: "You may enjoy following, serving, or handing decisions to someone whose lead you trust.",
	switch: "You may want both seats — leading some nights, following others — and the trade itself can be the heat.",
	master: "You may want a fuller authority than a scene: rules, titles, and a dynamic that still exists when the clothes are on.",
	slave: "You may want to belong in a deeper, more total way — service, obedience, and being claimed as more than a scene partner.",
	daddy: "You may like a guiding, caring authority — structure mixed with warmth, not only strictness.",
	little: "You may want to drop into a smaller, held headspace and be looked after by someone steady.",
	sadist: "You may enjoy giving pain or intensity on purpose, watching it land, and pacing it as care.",
	masochist: "You may enjoy receiving pain or intensity as pleasure, release, or proof of trust.",
	rigger: "You may enjoy tying, wrapping, and composing a body in rope or restraint.",
	"rope-bunny": "You may enjoy being tied, held in rope, and giving your movement to someone else's knots.",
	degrader: "You may enjoy using filthy or lowering language as a scripted, consented act — then repairing it.",
	degradee: "You may enjoy being spoken to that way, when the words were agreed and the landing is kind.",
	hunter: "You may enjoy chase, catch, pin — a predatory heat in a house you have both safetied.",
	prey: "You may enjoy being hunted, caught, and held, with a tap that still works.",
	voyeur: "You may get more from watching than from being the one on display.",
	exhibitionist: "You may get more from being seen — by a partner, a mirror, a chosen audience — than from watching.",
	brat: "You may poke the frame on purpose, and want to be caught, not ignored or actually hurt.",
	"brat-tamer": "You may like the smirk, the chase of the rule, and gathering someone back in without trapping them.",
	owner: "You may want the language of mine — collar, claim, everyday belonging — with a clock and an out.",
	pet: "You may want to stop being in charge of yourself for a while: cushion, name, simple tasks, then your name back.",
	vanilla: "You may prefer affection, sex, and closeness without power play, and that is a complete profile.",
	experimentalist: "You may like trying new kinks more than settling on a single identity — curiosity as the orientation.",
	"non-hierarchical": "You may want kink and intensity without a Dominant/submissive ranking — play as equals."
};
var BDSM_QUICK_QUESTIONS = [
	q("I like being the one in charge during sex or play.", { dominance: 1 }),
	q("Giving orders and watching my partner follow them turns me on.", { dominance: 1 }),
	q("I naturally gravitate toward holding the lead.", { dominance: 1 }),
	q("I like it when my partner takes control during intimate moments.", { submission: 1 }),
	q("Following a clear instruction can be hotter than deciding the night myself.", { submission: 1 }),
	q("Having rules to follow during play makes me feel settled.", { submission: 1 }),
	q("I like some scenes where I lead and some where I follow.", {
		dominance: .5,
		submission: .5
	}),
	q("I like giving pain or strong sensation during play, when it is wanted.", { sensation: 1 }),
	q("I like receiving pain or strong sensation during play.", { sensation: 1 }),
	q("Paddles, floggers, or crops interest me — using them or taking them.", { sensation: 1 }),
	q("I want to explore sensation at intensities I choose.", { sensation: 1 }),
	q("Being praised during play makes me melt.", { psychological: 1 }),
	q("I like praising my partner during play.", { psychological: 1 }),
	q("Dirty talk that stays inside what we agreed turns me on.", { psychological: 1 }),
	q("Making a partner wait or beg, with consent, is a turn-on.", { psychological: 1 }),
	q("I like tying my partner with rope or cuffs.", { bondage: 1 }),
	q("Being tied or held still by a partner excites me.", { bondage: 1 }),
	q("I like blindfolding a partner, or being blindfolded.", {
		bondage: .7,
		psychological: .3
	}),
	q("Play works better for me when we say what we want and what is off limits.", { trust: 1 }),
	q("I can drop my guard with a partner and let them see me messy or needy.", { trust: 1 }),
	q("Check-ins and aftercare are part of what makes play good, not extra.", { trust: 1 }),
	q("Trying a kink I have not done before excites me, if we can stop it.", { adventurous: 1 }),
	q("I like suggesting new things so sex does not feel repetitive.", { adventurous: 1 }),
	q("I would enjoy going to a kink event or club that felt safe for me.", { adventurous: 1 }),
	q("I like trying intense activities that come close to my limits, not past them.", { adventurous: 1 })
];
var BDSM_FULL_QUESTIONS = [
	q("I like telling a partner what to do, and having them do it.", { dominant: 1 }),
	q("Being in charge during a scene feels natural to me.", { dominant: 1 }),
	q("I enjoy giving instructions within an agreed power dynamic.", { dominant: 1 }),
	q("I want the last word on what we do tonight, once we have agreed the limits.", { dominant: 1 }),
	q("People relaxing because I am handling it is a turn-on.", { dominant: 1 }),
	q("I like letting my partner take control during intimate moments.", { submissive: 1 }),
	q("I enjoy receiving instructions within an agreed power dynamic.", { submissive: 1 }),
	q("Following a clear order can be hotter than inventing the night myself.", { submissive: 1 }),
	q("I want someone else to decide the shape of the evening, with a way to stop.", { submissive: 1 }),
	q("Kneeling, waiting, or asking permission can feel like coming home.", { submissive: 1 }),
	q("I like switching between taking control and letting my partner take control.", { switch: 1 }),
	q("Some nights I need to lead. Other nights I need to follow. Both are me.", { switch: 1 }),
	q("I get bored if I only ever take charge, or only ever give it up.", { switch: 1 }),
	q("I can hold someone and then ask to be held, without it breaking us.", { switch: 1 }),
	q("Trading who is in charge from one scene to the next keeps things alive for me.", { switch: 1 }),
	q("I like a more formal dynamic where I am in charge and my partner uses a title.", { master: 1 }),
	q("I would enjoy writing standing rules for times when I am in control.", { master: 1 }),
	q("Protocol and honorifics appeal to me more than a loose, one-off scene.", { master: 1 }),
	q("I want authority that still exists when the clothes are on.", { master: 1 }),
	q("I take responsibility for what I open, including the boring parts of running a dynamic.", { master: 1 }),
	q("I like a role where I belong to my partner while they are in charge.", { slave: 1 }),
	q("Making service a real part of the relationship would feel fulfilling.", { slave: 1 }),
	q("Written rules feel meaningful when my partner is in control.", { slave: 1 }),
	q("I want to be claimed as more than a play partner — with a way out that still works.", { slave: 1 }),
	q("Obedience and belonging are part of my sexuality, not only a favour.", { slave: 1 }),
	q("I like taking a nurturing caregiver role with my partner.", { daddy: 1 }),
	q("Comforting and guiding someone in a Little headspace feels like me.", { daddy: 1 }),
	q("Structure mixed with warmth is the kind of authority I want to give.", { daddy: 1 }),
	q("I like looking after food, rest, and a held day — not only sex.", { daddy: 1 }),
	q("Praise and guidance from me should feel like a home, not a test.", { daddy: 1 }),
	q("I like taking a Little role where I can feel playful and cared for.", { little: 1 }),
	q("I like setting adult responsibilities aside for a while, on purpose.", { little: 1 }),
	q("Being cared for — snacks, voice, simple rules — appeals to me.", { little: 1 }),
	q("I can enjoy a Little role even when I am not pretending to be younger.", { little: 1 }),
	q("I want a caregiver more than I want a tyrant.", { little: 1 }),
	q("I like giving my partner pain during play, when they want it.", { sadist: 1 }),
	q("I like finding the kinds and levels of pain my partner enjoys.", { sadist: 1 }),
	q("I like hitting with paddles, floggers, or crops.", { sadist: 1 }),
	q("Pacing hurt — and stopping it — is a skill I want to use.", { sadist: 1 }),
	q("I like the look of marks we both chose.", { sadist: 1 }),
	q("I like receiving pain during intimate play.", { masochist: 1 }),
	q("The rush of taking pain during play is something I want.", { masochist: 1 }),
	q("I like being hit with paddles, floggers, or crops.", { masochist: 1 }),
	q("Ache I asked for can put me in my body in a way vanilla sex does not.", { masochist: 1 }),
	q("I can like pain without wanting to be degraded. They are different asks.", { masochist: 1 }),
	q("I like using rope to tie my partner.", { rigger: 1 }),
	q("I like making restraint look considered, not only tight.", { rigger: 1 }),
	q("I would enjoy learning more complex ties.", { rigger: 1 }),
	q("The craft of bondage — tension, safety, a body in a shape I made — is a draw.", { rigger: 1 }),
	q("I like being the person with the rope and the plan for how they come out of it.", { rigger: 1 }),
	q("Being tied in a position that works for my body excites me.", { "rope-bunny": 1 }),
	q("I like how rope feels against my skin.", { "rope-bunny": 1 }),
	q("Being snugly wrapped or partly tied, while I can still move, appeals.", { "rope-bunny": 1 }),
	q("Being comfortably restrained helps me relax and stop overthinking.", { "rope-bunny": 1 }),
	q("Giving up movement to someone else's knots is a specific hunger.", { "rope-bunny": 1 }),
	q("I like using lowering or filthy language as a consented part of play.", { degrader: 1 }),
	q("I like choosing humiliating words that actually turn my partner on.", { degrader: 1 }),
	q("I like treating my partner like an object during degradation play they asked for.", { degrader: 1 }),
	q("I can use hard words in a scene and still see my partner as my equal when it ends.", { degrader: 1 }),
	q("Aftercare after verbal play should be extra kind. That is part of running it.", { degrader: 1 }),
	q("Being called degrading names during play can turn me on.", { degradee: 1 }),
	q("Humiliating words that fit what I asked for can work. Surprise humiliation usually does not.", { degradee: 1 }),
	q("Being treated like an object during a timed scene can turn me on.", { degradee: 1 }),
	q("I want the opposite sentences afterwards, said as true.", { degradee: 1 }),
	q("I can like degradation even when there is no pain.", { degradee: 1 }),
	q("I like physical, animal-like play that feels instinctive instead of scripted.", { hunter: 1 }),
	q("I enjoy growling, biting, or rough movement during primal play.", { hunter: 1 }),
	q("I like chasing my partner like prey during primal play.", { hunter: 1 }),
	q("A grab and a hold against a wall we agreed was safe is more me than formal protocol.", { hunter: 1 }),
	q("Prey who can stop being prey in a full sentence is the only prey I want.", { hunter: 1 }),
	q("Being chased and caught during primal play turns me on.", { prey: 1 }),
	q("I want to be hunted, caught, and held, with a way to stop that still works.", { prey: 1 }),
	q("Running and being caught is hotter for me than kneeling on a cushion.", { prey: 1 }),
	q("A pin, a breath, my name back: that landing matters as much as the catch.", { prey: 1 }),
	q("I like feeling taken — in a scene we built — more than feeling instructed.", { prey: 1 }),
	q("Watching adults have sex turns me on when everyone agrees I can watch.", { voyeur: 1 }),
	q("I like watching kink play without taking part, when that was agreed.", { voyeur: 1 }),
	q("Watching my partner put on a sexual show for me turns me on.", { voyeur: 1 }),
	q("I get more heat from seeing than from being on display.", { voyeur: 1 }),
	q("A mirror I watch them in can be enough audience.", { voyeur: 1 }),
	q("Being watched during kink play turns me on when everyone involved has agreed.", { exhibitionist: 1 }),
	q("I like showing my body to people who have agreed to watch.", { exhibitionist: 1 }),
	q("I would enjoy my partner showing me off to an audience that wants to watch.", { exhibitionist: 1 }),
	q("Being looked at can be the whole scene. Sex can wait.", { exhibitionist: 1 }),
	q("A little risk of being almost-caught, still reversible, interests me.", { exhibitionist: 1 }),
	q("I like playfully disobeying as part of brat play.", { brat: 1 }),
	q("I have fun teasing or provoking my partner during brat play.", { brat: 1 }),
	q("I like breaking a small rule so my partner gives me a playful consequence.", { brat: 1 }),
	q("I like being cheeky to get a reaction, then being gathered back in.", { brat: 1 }),
	q("If no one plays back, bratting just feels lonely. I need the catch.", { brat: 1 }),
	q("I like finding clever ways to get a playfully defiant partner to cooperate.", { "brat-tamer": 1 }),
	q("I like giving playful consequences for bratty behaviour.", { "brat-tamer": 1 }),
	q("Brats are fun for me. Actual contempt is not.", { "brat-tamer": 1 }),
	q("I will gather someone who pushed, and I will not invent a new punishment in anger.", { "brat-tamer": 1 }),
	q("The game is: they push, I catch, we both still like each other.", { "brat-tamer": 1 }),
	q("I like giving a partner a collar to show they are mine, as play we both meant.", { owner: 1 }),
	q("Everyday belonging — not only bedroom belonging — interests me.", { owner: 1 }),
	q("I like leaving a temporary mark during ownership play we agreed.", { owner: 1 }),
	q("I like training a partner when they play my pet.", {
		owner: 1,
		pet: .2
	}),
	q("Mine is a word I want to use, with a clock and an out.", { owner: 1 }),
	q("I would enjoy playing a pet role for my partner.", { pet: 1 }),
	q("Wearing a collar to show I am my partner's pet would make me feel close to them.", { pet: 1 }),
	q("Stopping being in charge of myself for a timed evening is the point.", { pet: 1 }),
	q("I like being kept, not humiliated, unless humiliation was listed.", { pet: 1 }),
	q("Simple tasks, a cushion, then my name back at the end, works for me.", { pet: 1 }),
	q("I prefer sex without BDSM roles most of the time.", { vanilla: 1 }),
	q("I currently have little interest in BDSM activities.", { vanilla: 1 }),
	q("Gentle, mutual, no protocol — that is a complete good night.", { vanilla: 1 }),
	q("I can enjoy kink ideas in theory and still prefer a night that stays ordinary.", { vanilla: 1 }),
	q("I do not need a scene to feel close. I might not want one.", { vanilla: 1 }),
	q("Trying a kink I have not explored before excites me.", { experimentalist: 1 }),
	q("I like suggesting new things so sex does not feel repetitive.", { experimentalist: 1 }),
	q("I like trying intense activities that come close to my limits.", { experimentalist: 1 }),
	q("A menu I have not used yet is more exciting than a title I already know.", { experimentalist: 1 }),
	q("Curiosity is my orientation as much as Dominant or submissive is.", { experimentalist: 1 }),
	q("I enjoy BDSM activities without either partner taking control of the other.", { "non-hierarchical": 1 }),
	q("I like sharing control during kink without either partner being in charge.", { "non-hierarchical": 1 }),
	q("I would rather have sex without either partner being the boss.", { "non-hierarchical": 1 }),
	q("Top and bottom can be technical, not a ranking of who we are.", { "non-hierarchical": 1 }),
	q("A scene between equals, with heat and a safeword, is enough structure for me.", { "non-hierarchical": 1 }),
	q("I think about rope specifically — tying or being tied — often enough to call it an interest.", {
		rigger: .5,
		"rope-bunny": .5
	}),
	q("Pain that I give or take is a real part of my sexuality, not a maybe.", {
		sadist: .5,
		masochist: .5
	}),
	q("Being watched or watching is a hunger I would put on a list.", {
		voyeur: .5,
		exhibitionist: .5
	}),
	q("Care-and-control, not only sex-and-control, belongs in my profile.", {
		daddy: .5,
		little: .5
	}),
	q("I want a partner who will compare this profile with me, not a score I hide.", {
		experimentalist: .4,
		vanilla: .2
	})
];
var BDSM_SECTION_TITLES = {};
var LOVE_LABELS = {
	words: "Words of affirmation",
	time: "Quality time",
	touch: "Physical touch",
	acts: "Acts of service",
	gifts: "Receiving gifts"
};
var w = (weights) => weights;
var QUICK_AXIS_KEYS = [
	"dominance",
	"submission",
	"sensation",
	"psychological",
	"bondage",
	"trust",
	"adventurous"
];
var FULL_ROLE_KEYS = [
	"dominant",
	"submissive",
	"switch",
	"master",
	"slave",
	"daddy",
	"little",
	"sadist",
	"masochist",
	"rigger",
	"rope-bunny",
	"degrader",
	"degradee",
	"hunter",
	"prey",
	"voyeur",
	"exhibitionist",
	"brat",
	"brat-tamer",
	"owner",
	"pet",
	"vanilla",
	"experimentalist",
	"non-hierarchical"
];
var BDSM_QUICK_QUIZ = {
	id: "bdsm-quick",
	title: "Quick Quiz",
	blurb: "See seven scores across Dominance, Submission, Bondage and more.",
	topic: "discovery:bdsm-quick",
	likert: true,
	scoring: "independent",
	chart: "radar",
	timeHint: "About 5 min",
	countHint: "25 questions",
	labels: QUICK_LABELS,
	shortLabels: QUICK_SHORT_LABELS,
	blurbs: QUICK_BLURBS,
	groups: [{
		id: "interests",
		title: "Your seven scores",
		keys: [...QUICK_AXIS_KEYS]
	}],
	questions: BDSM_QUICK_QUESTIONS
};
var BDSM_FULL_QUIZ = {
	id: "bdsm-full",
	title: "Full Profile",
	blurb: "See all 24 roles and interests ranked, including Dominant, Submissive, Switch, Brat and Rigger.",
	topic: "discovery:bdsm-full",
	likert: true,
	scoring: "independent",
	timeHint: "About 15 min",
	countHint: "125 questions",
	labels: FULL_LABELS,
	blurbs: FULL_BLURBS,
	groups: [{
		id: "roles",
		title: "Your top BDSM roles and interests",
		keys: [...FULL_ROLE_KEYS]
	}],
	questions: BDSM_FULL_QUESTIONS
};
var LOVE_QUIZ = {
	id: "love",
	title: "Love languages",
	blurb: "Twelve questions about how care actually lands — in the dynamic and out of it. Percentages, not a single winner. Retake whenever you like.",
	topic: "discovery:love",
	labels: LOVE_LABELS,
	groups: [{
		id: "languages",
		title: "How you receive love",
		keys: [
			"words",
			"time",
			"touch",
			"acts",
			"gifts"
		]
	}],
	questions: [
		{
			prompt: "I feel most loved when you…",
			options: [
				{
					label: "Tell me, specifically, what I did well.",
					weights: w({ words: 3 })
				},
				{
					label: "Give me undivided time with no phones.",
					weights: w({ time: 3 })
				},
				{
					label: "Reach for me without it having to become a scene.",
					weights: w({ touch: 3 })
				},
				{
					label: "Do the unglamorous thing I asked for last week.",
					weights: w({ acts: 3 })
				},
				{
					label: "Leave something small that says you thought of me.",
					weights: w({ gifts: 3 })
				}
			]
		},
		{
			prompt: "When I am dropping, the first thing I need is…",
			options: [
				{
					label: "Words: I am safe, I did well, you are here.",
					weights: w({ words: 3 })
				},
				{
					label: "You staying, even if we say nothing.",
					weights: w({ time: 3 })
				},
				{
					label: "Quiet touch and a blanket.",
					weights: w({ touch: 3 })
				},
				{
					label: "Water, food, the lights down.",
					weights: w({ acts: 3 })
				},
				{
					label: "A comfort I already own from you — tea, a hoodie, the good chocolate.",
					weights: w({
						gifts: 2,
						acts: 1
					})
				}
			]
		},
		{
			prompt: "A fight is repaired, for me, when you…",
			options: [
				{
					label: "Name what you did and what you will do differently.",
					weights: w({ words: 3 })
				},
				{
					label: "Sit with me until the charge leaves the room.",
					weights: w({ time: 3 })
				},
				{
					label: "Hold me, or let me have space and then reach.",
					weights: w({
						touch: 2,
						time: 1
					})
				},
				{
					label: "Fix the practical thing we fought about.",
					weights: w({ acts: 3 })
				},
				{
					label: "Come back with a small peace offering that is not a bribe.",
					weights: w({ gifts: 3 })
				}
			]
		},
		{
			prompt: "On an ordinary Tuesday, love looks like…",
			options: [
				{
					label: "A message that is about me, not logistics.",
					weights: w({ words: 3 })
				},
				{
					label: "Twenty minutes that are actually ours.",
					weights: w({ time: 3 })
				},
				{
					label: "A hand on the back of my neck in the kitchen.",
					weights: w({ touch: 3 })
				},
				{
					label: "You handling something so I do not have to.",
					weights: w({ acts: 3 })
				},
				{
					label: "A snack, a flower, a link you saved because it was my taste.",
					weights: w({ gifts: 3 })
				}
			]
		},
		{
			prompt: "In protocol, love feels like…",
			options: [
				{
					label: "Exact praise. You meant the words.",
					weights: w({ words: 3 })
				},
				{
					label: "You staying in the room for the whole ritual.",
					weights: w({ time: 3 })
				},
				{
					label: "The collar, the hand, the body that says mine.",
					weights: w({ touch: 3 })
				},
				{
					label: "You running aftercare as carefully as you ran the scene.",
					weights: w({ acts: 3 })
				},
				{
					label: "A token I get to keep — a ribbon, a note, a mark we agreed.",
					weights: w({ gifts: 3 })
				}
			]
		},
		{
			prompt: "I feel neglected fastest when…",
			options: [
				{
					label: "You go quiet. No words, no naming.",
					weights: w({ words: 3 })
				},
				{
					label: "You are in the house but not with me.",
					weights: w({ time: 3 })
				},
				{
					label: "You stop reaching. I become furniture.",
					weights: w({ touch: 3 })
				},
				{
					label: "I am carrying the boring load alone.",
					weights: w({ acts: 3 })
				},
				{
					label: "Every gift and surprise dries up, and so does the thought behind them.",
					weights: w({ gifts: 3 })
				}
			]
		},
		{
			prompt: "A public way you can love me without anyone else clocking it…",
			options: [
				{
					label: "A look or a word we already agreed means I have you.",
					weights: w({
						words: 2,
						time: 1
					})
				},
				{
					label: "Choosing to sit with me instead of working the room.",
					weights: w({ time: 3 })
				},
				{
					label: "A hand on my back that is ours.",
					weights: w({ touch: 3 })
				},
				{
					label: "Handling the bill, the coats, the way home.",
					weights: w({ acts: 3 })
				},
				{
					label: "Tucking something in my pocket before we leave.",
					weights: w({ gifts: 3 })
				}
			]
		},
		{
			prompt: "The love I fake because I think I should is…",
			options: [
				{
					label: "Praise that sounds like a script.",
					weights: w({ words: 3 })
				},
				{
					label: "Time I resent because I wanted to be alone.",
					weights: w({ time: 3 })
				},
				{
					label: "Touch I do not actually want yet.",
					weights: w({ touch: 3 })
				},
				{
					label: "Service I will sulk about later.",
					weights: w({ acts: 3 })
				},
				{
					label: "Gifts I smile at and feel nothing for.",
					weights: w({ gifts: 3 })
				}
			]
		},
		{
			prompt: "After a good scene, the landing that actually feeds me is…",
			options: [
				{
					label: "You telling me what you saw and what you liked.",
					weights: w({ words: 3 })
				},
				{
					label: "You not rushing off. The hour after is the scene too.",
					weights: w({ time: 3 })
				},
				{
					label: "Skin, a bath, being held or holding.",
					weights: w({ touch: 3 })
				},
				{
					label: "Water, food, marks checked, the kit put away.",
					weights: w({ acts: 3 })
				},
				{
					label: "A small thing that belongs to that night — a note, a photo we keep.",
					weights: w({ gifts: 3 })
				}
			]
		},
		{
			prompt: "I believe you are proud of me when…",
			options: [
				{
					label: "You say it, with evidence.",
					weights: w({ words: 3 })
				},
				{
					label: "You make time to hear the thing I did.",
					weights: w({ time: 3 })
				},
				{
					label: "You pull me in.",
					weights: w({ touch: 3 })
				},
				{
					label: "You back it with help — you show up for the boring part.",
					weights: w({ acts: 3 })
				},
				{
					label: "You mark it: a treat, a token, a planned reward.",
					weights: w({ gifts: 3 })
				}
			]
		},
		{
			prompt: "Distance (work trip, a bad week) is easier if you…",
			options: [
				{
					label: "Write. Voice notes. Specific, not 'you good?'",
					weights: w({ words: 3 })
				},
				{
					label: "Book a call and actually keep it.",
					weights: w({ time: 3 })
				},
				{
					label: "Tell me what you will do with me when we are in the same room.",
					weights: w({
						touch: 2,
						words: 1
					})
				},
				{
					label: "Handle something at home so I land in less mess.",
					weights: w({ acts: 3 })
				},
				{
					label: "Send a small thing, or leave one for me to find.",
					weights: w({ gifts: 3 })
				}
			]
		},
		{
			prompt: "If I could keep only one way you love me for the next year…",
			options: [
				{
					label: "Keep talking to me as if I am worth naming.",
					weights: w({ words: 3 })
				},
				{
					label: "Keep giving me hours that are not leftover.",
					weights: w({ time: 3 })
				},
				{
					label: "Keep putting your body in the room with mine.",
					weights: w({ touch: 3 })
				},
				{
					label: "Keep doing the things that make a life possible.",
					weights: w({ acts: 3 })
				},
				{
					label: "Keep the small, thought-through gifts that say you see me.",
					weights: w({ gifts: 3 })
				}
			]
		}
	]
};
function addWeights(into, weights) {
	for (const [key, value] of Object.entries(weights)) into[key] = (into[key] ?? 0) + value;
	return into;
}
function normalizePicks(raw) {
	if (!Array.isArray(raw)) return [];
	return raw.map((item) => {
		if (Array.isArray(item)) return item.filter((n) => typeof n === "number" && n >= 0);
		if (typeof item === "number" && item >= 0) return [item];
		return [];
	});
}
function roundPercents(rows, labels) {
	const total = rows.reduce((sum, row) => sum + row.score, 0);
	if (!total) return rows.map((row) => ({
		key: row.key,
		label: labels[row.key] ?? row.key,
		pct: 0,
		score: 0
	}));
	const floored = rows.map((row) => ({
		...row,
		exact: 100 * row.score / total
	})).map((row) => ({
		...row,
		pct: Math.floor(row.exact)
	}));
	let remainder = 100 - floored.reduce((sum, row) => sum + row.pct, 0);
	const order = [...floored].sort((a, b) => b.exact - a.exact - Math.floor(b.exact) + Math.floor(a.exact) || b.score - a.score);
	for (const item of order) {
		if (remainder <= 0) break;
		if (item.score <= 0) continue;
		item.pct += 1;
		remainder -= 1;
	}
	return floored.map((row) => ({
		key: row.key,
		label: labels[row.key] ?? row.key,
		pct: row.score > 0 ? row.pct : 0,
		score: row.score
	})).sort((a, b) => b.pct - a.pct || b.score - a.score);
}
function independentPercents(rows, labels) {
	return rows.map((row) => ({
		key: row.key,
		label: labels[row.key] ?? row.key,
		pct: row.max > 0 ? Math.round(100 * row.score / row.max) : 0,
		score: row.score
	}));
}
function rankRows(rows) {
	return [...rows].sort((a, b) => b.pct - a.pct || b.score - a.score || a.label.localeCompare(b.label));
}
var LIKERT_MAX = LIKERT_OPTIONS.length - 1;
function scoreQuiz(quiz, picks) {
	const scores = {};
	const maxima = {};
	const normalized = normalizePicks(picks);
	quiz.questions.forEach((item, index) => {
		const chosen = normalized[index] ?? [];
		if (item.axes) {
			if (!chosen.length) return;
			const scale = Math.min(LIKERT_MAX, Math.max(0, chosen[0] ?? 0));
			for (const [key, weight] of Object.entries(item.axes)) {
				const span = LIKERT_MAX * Math.abs(weight);
				maxima[key] = (maxima[key] ?? 0) + span;
				const contrib = weight >= 0 ? scale * weight : (LIKERT_MAX - scale) * Math.abs(weight);
				scores[key] = (scores[key] ?? 0) + contrib;
			}
			return;
		}
		for (const oi of chosen) {
			const option = item.options?.[oi];
			if (option) addWeights(scores, option.weights);
		}
	});
	const independent = quiz.scoring === "independent";
	return {
		scores,
		sections: quiz.groups.map((group) => ({
			id: group.id,
			title: group.title,
			rows: independent ? independentPercents(group.keys.map((key) => ({
				key,
				score: scores[key] ?? 0,
				max: maxima[key] ?? 0
			})), quiz.labels) : roundPercents(group.keys.map((key) => ({
				key,
				score: scores[key] ?? 0
			})), quiz.labels)
		}))
	};
}
function parseQuizBody(body) {
	if (!body) return null;
	try {
		const parsed = JSON.parse(body);
		if (!Array.isArray(parsed.sections)) return null;
		const filter = parsed.filter;
		return {
			picks: normalizePicks(parsed.picks),
			sections: parsed.sections,
			filter: filter === "dominant" || filter === "submissive" || filter === "switch" || filter === "full" ? filter : void 0,
			quizSize: typeof parsed.quizSize === "number" ? parsed.quizSize : void 0
		};
	} catch {
		return null;
	}
}
function topKey(section) {
	return rankRows(section?.rows ?? []).find((row) => row.pct > 0)?.key ?? "";
}
function suggestedRoleFromSections(sections) {
	const rows = sections.flatMap((section) => section.rows);
	const get = (...keys) => Math.max(0, ...keys.map((key) => rows.find((row) => row.key === key)?.pct ?? 0));
	const dominant = get("dominant", "dominance");
	const submissive = get("submissive", "submission");
	const sw = get("switch");
	if (!dominant && !submissive && !sw) return null;
	if (sw >= dominant && sw >= submissive && sw >= 40) return "switch";
	if (dominant >= 45 && submissive >= 45 && Math.abs(dominant - submissive) <= 12) return "switch";
	if (dominant > submissive) return "dominant";
	if (submissive > dominant) return "submissive";
	return "switch";
}
function questionsForFilter(quiz, filter) {
	return quiz.questions.map((item, index) => ({
		item,
		index
	})).filter(({ item }) => filter === "full" ? true : item.role === filter);
}
function hashSeed(seed) {
	let h = 2166136261;
	for (let i = 0; i < seed.length; i += 1) h = Math.imul(h ^ seed.charCodeAt(i), 16777619);
	return h >>> 0;
}
function seededShuffle(items, seed) {
	const out = items.slice();
	let h = hashSeed(seed) || 1;
	for (let i = out.length - 1; i > 0; i -= 1) {
		h ^= h << 13;
		h ^= h >>> 17;
		h ^= h << 5;
		const j = (h >>> 0) % (i + 1);
		const swap = out[i];
		out[i] = out[j];
		out[j] = swap;
	}
	return out;
}
function orderedQuestions(quiz) {
	const items = questionsForFilter(quiz, "full");
	if (!quiz.likert) return items;
	return seededShuffle(items, quiz.id);
}
function picksComplete(picks, indices) {
	return indices.every((index) => (picks[index]?.length ?? 0) > 0);
}
var KINK_TO_TALK = {
	sadist: "sadomasochism",
	masochist: "sadomasochism",
	rigger: "rope",
	"rope-bunny": "rope",
	degrader: "degradation",
	degradee: "degradation",
	hunter: "primal",
	prey: "primal",
	voyeur: "voyeurism",
	exhibitionist: "exhibitionism",
	brat: "brat-dynamic",
	"brat-tamer": "brat-dynamic",
	owner: "ownership",
	pet: "pet-play",
	master: "protocol",
	slave: "service",
	daddy: "praise",
	little: "pet-play",
	dominant: "power-exchange",
	submissive: "power-exchange",
	sensation: "sensation-play",
	bondage: "bondage"
};
function padPicks(raw, len) {
	const next = raw.map((row) => row.slice());
	while (next.length < len) next.push([]);
	return next.slice(0, len);
}
function answeredCount(picks) {
	return picks.filter((row) => row.length > 0).length;
}
function quizStatus(quiz, picks, hasSections, savedSize, savedFilter = "full") {
	if (picksComplete(picks, quiz.questions.map((_, i) => i))) return "done";
	const n = answeredCount(picks);
	if (savedSize === quiz.questions.length && n > 0) {
		if (picksComplete(picks, questionsForFilter(quiz, quiz.multi ? savedFilter : "full").map((row) => row.index))) return "done";
		return "in-progress";
	}
	if (hasSections) return "done";
	if (n > 0) return "in-progress";
	return "fresh";
}
function statusFromAnswers(quiz, answers, meId) {
	const parsed = parseQuizBody(answers.find((item) => item.topic === quiz.topic && item.userId === meId)?.body);
	return quizStatus(quiz, padPicks(parsed?.picks ?? [], quiz.questions.length), Boolean(parsed?.sections?.length), parsed?.quizSize);
}
function InterestRadar({ quiz, rows }) {
	const data = (quiz.groups[0]?.keys ?? []).map((key) => {
		const row = rows.find((item) => item.key === key);
		return {
			axis: quiz.shortLabels?.[key] ?? quiz.labels[key] ?? key,
			value: row?.pct ?? 0
		};
	});
	if (data.length < 3) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto h-72 w-full max-w-md",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadarChart, {
				data,
				cx: "50%",
				cy: "52%",
				outerRadius: "68%",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarGrid, { stroke: "var(--color-border)" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarAngleAxis, {
						dataKey: "axis",
						tick: {
							fill: "var(--color-muted-foreground)",
							fontSize: 11
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarRadiusAxis, {
						domain: [0, 100],
						tick: false,
						axisLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
						dataKey: "value",
						stroke: "var(--color-primary)",
						fill: "var(--color-primary)",
						fillOpacity: .22,
						strokeWidth: 2,
						isAnimationActive: false
					})
				]
			})
		})
	});
}
function ScoreBar({ row, independent, rank }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline justify-between gap-3 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [rank != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "mr-2 tabular-nums text-muted-foreground",
			children: [rank, "."]
		}) : null, row.label] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "tabular-nums text-muted-foreground",
			children: [row.pct, independent ? "" : "%"]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-1 h-1.5 overflow-hidden rounded-full bg-secondary",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full rounded-full bg-primary",
			style: { width: `${row.pct}%` }
		})
	})] });
}
function QuizResults({ quiz, sections, empty = "No scores yet." }) {
	const [showAll, setShowAll] = (0, import_react.useState)(false);
	const visible = sections.map((section) => ({
		...section,
		rows: section.rows.filter((row) => quiz?.scoring === "independent" ? true : row.score > 0)
	})).filter((section) => section.rows.length > 0);
	if (!visible.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: empty
	});
	const independent = quiz?.scoring === "independent";
	const ranked = independent ? rankRows(visible[0]?.rows ?? []) : visible[0]?.rows ?? [];
	const lead = ranked[0];
	const others = ranked.slice(1);
	const preview = independent && others.length > 2 ? others.slice(0, 2) : others;
	const hidden = independent && others.length > 2 ? others.slice(2) : [];
	const collapse = Boolean(independent && quiz?.id === "bdsm-full" && hidden.length);
	const shownOthers = collapse && !showAll ? preview : others;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			quiz?.chart === "radar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InterestRadar, {
				quiz,
				rows: visible[0]?.rows ?? []
			}) : null,
			independent && lead ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-secondary p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
						children: "Strongest match"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-2xl",
							children: lead.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "tabular-nums text-2xl text-primary",
							children: lead.pct
						})]
					}),
					quiz.blurbs?.[lead.key] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted-foreground",
						children: quiz.blurbs[lead.key]
					}) : null
				]
			}) : null,
			visible.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
					children: independent ? quiz?.id === "bdsm-full" ? "Other strong matches" : section.title : section.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 space-y-2",
					children: (independent ? shownOthers : section.rows).map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreBar, {
						row,
						independent: Boolean(independent),
						rank: independent && quiz?.id === "bdsm-full" ? index + 1 : void 0
					}, row.key))
				}),
				collapse ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setShowAll((open) => !open),
					className: "mt-3 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("size-4 transition-transform", showAll && "rotate-180") }), showAll ? "Show less" : `+${hidden.length} more roles and interests`]
				}) : null
			] }, section.id))
		]
	});
}
function LikertScale({ value, onChange, disabled }) {
	const selected = typeof value === "number" ? LIKERT_OPTIONS[value] : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Disagree" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Agree" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center gap-1",
				role: "radiogroup",
				"aria-label": "How much do you agree?",
				children: LIKERT_OPTIONS.map((opt) => {
					const on = value === opt.value;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						role: "radio",
						"aria-checked": on,
						"aria-label": opt.label,
						disabled,
						onClick: () => onChange(opt.value),
						className: "flex h-11 min-h-11 flex-1 items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-7 rounded-full border-2 sm:size-8", on ? "border-primary bg-primary" : "border-border bg-transparent") })
					}, opt.value);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-xs text-muted-foreground",
				children: selected ? selected.label : "How much do you agree?"
			})
		]
	});
}
function BdsmTestChooser({ onPick, answers, meId }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Choose the quick BDSM quiz for seven interest scores, or take the full kink test to rank all 24 roles and interests."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [{
					id: "quick",
					quiz: BDSM_QUICK_QUIZ,
					start: "Start quick quiz"
				}, {
					id: "full",
					quiz: BDSM_FULL_QUIZ,
					start: "Start full profile"
				}].map(({ id, quiz, start }) => {
					const status = answers ? statusFromAnswers(quiz, answers, meId) : "fresh";
					const cta = status === "done" ? "See results" : status === "in-progress" ? "Continue" : start;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onPick(id),
						className: "rounded-xl border border-border bg-card p-5 text-left hover:border-primary/50",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl",
								children: quiz.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs uppercase tracking-[0.16em] text-muted-foreground",
								children: [
									quiz.countHint,
									" · ",
									quiz.timeHint
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-muted-foreground",
								children: quiz.blurb
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-sm font-medium text-primary",
								children: cta
							})
						]
					}, id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-secondary p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
					children: "What this test measures"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted-foreground",
					children: "The Quick Quiz plots seven dimensions on a radar: Dominance, Submission, Sensation & Impact, Psychological Play, Bondage & Restraint, Trust & Vulnerability, and Adventurousness. The Full Profile ranks 24 roles and interests independently — a high Dominant score does not reduce Submissive."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 text-sm text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-foreground",
						children: "How long?"
					}), " About five minutes for 25 questions, or fifteen for 125."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-foreground",
						children: "What do results mean?"
					}), " The Quick Quiz ranks seven interest scores. The Full Profile ranks 24 roles — Dominant, Submissive, Switch, Brat, Rigger, and more — as a starting point for you, or a conversation with a partner."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-foreground",
						children: "Can we compare?"
					}), " Yes. Share the scores, not the individual answers. A connected partner sees the same charts after they take it too."] })
				]
			})
		]
	});
}
function DiscoveryQuizRun({ quiz, answers, meId, onSaved, onFinished, onExit, compact, startOnMount }) {
	const existing = answers.find((item) => item.topic === quiz.topic && item.userId === meId);
	const parsed = parseQuizBody(existing?.body);
	const multi = Boolean(quiz.multi);
	const likert = Boolean(quiz.likert);
	const [picks, setPicks] = (0, import_react.useState)(() => padPicks(parsed?.picks ?? [], quiz.questions.length));
	const initialStatus = quizStatus(quiz, padPicks(parsed?.picks ?? [], quiz.questions.length), Boolean(parsed?.sections?.length), parsed?.quizSize, "full");
	const [phase, setPhase] = (0, import_react.useState)(() => {
		if (initialStatus === "done") return "results";
		if (initialStatus === "in-progress") return "questions";
		return startOnMount ? "questions" : "hub";
	});
	const visible = (0, import_react.useMemo)(() => orderedQuestions(quiz), [quiz]);
	const [index, setIndex] = (0, import_react.useState)(() => {
		if (initialStatus === "done") return 0;
		const first = visible.findIndex(({ index: qi }) => (parsed?.picks?.[qi]?.length ?? 0) === 0);
		return first >= 0 ? first : 0;
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [shared, setShared] = (0, import_react.useState)(existing?.visibility !== "private");
	const scored = (0, import_react.useMemo)(() => scoreQuiz(quiz, picks), [quiz, picks]);
	const current = visible[index];
	const question = current?.item;
	const origIndex = current?.index ?? 0;
	const selected = picks[origIndex] ?? [];
	const options = likert ? LIKERT_OPTIONS.map((item) => ({
		label: item.label,
		value: item.value
	})) : (question?.options ?? []).map((item, oi) => ({
		label: item.label,
		value: oi
	}));
	const sectionTitle = question?.section ? BDSM_SECTION_TITLES[question.section] ?? question.section : "";
	async function persist(nextPicks, visibility, final) {
		const padded = padPicks(nextPicks, quiz.questions.length);
		const result = scoreQuiz(quiz, padded);
		if (final) setBusy(true);
		try {
			const saved = await saveTalkAnswer({ data: {
				topic: quiz.topic,
				body: JSON.stringify({
					picks: padded,
					sections: result.sections,
					at: (/* @__PURE__ */ new Date()).toISOString(),
					filter: "full",
					quizSize: quiz.questions.length
				}),
				rating: topKey(result.sections[0]),
				visibility
			} });
			onSaved?.(saved);
			if (final && (quiz.id === "bdsm-full" || quiz.id === "bdsm-quick")) {
				const rows = result.sections[0]?.rows ?? [];
				for (const row of rows) {
					const slug = KINK_TO_TALK[row.key];
					if (!slug || row.pct < 55) continue;
					const rating = row.pct >= 70 ? "yes" : "curious";
					await saveTalkAnswer({ data: {
						topic: `kink:${slug}`,
						body: row.label,
						rating,
						visibility
					} }).catch(() => null);
				}
			}
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not save the quiz.");
		} finally {
			if (final) setBusy(false);
		}
	}
	function toggleOption(optionIndex) {
		const next = padPicks(picks, quiz.questions.length);
		const row = new Set(next[origIndex]);
		if (row.has(optionIndex)) row.delete(optionIndex);
		else row.add(optionIndex);
		next[origIndex] = [...row].sort((a, b) => a - b);
		setPicks(next);
	}
	function chooseSingle(optionIndex) {
		const next = padPicks(picks, quiz.questions.length);
		next[origIndex] = [optionIndex];
		setPicks(next);
		if (index + 1 >= visible.length) {
			setPhase("results");
			persist(next, shared ? "shared" : "private", true);
			return;
		}
		setIndex(index + 1);
		if ((index + 1) % 5 === 0) persist(next, shared ? "shared" : "private", false);
	}
	function goNext() {
		if (multi && selected.length === 0) {
			toast.error("Pick at least one option. You can pick several.");
			return;
		}
		const last = index + 1 >= visible.length;
		const nextPicks = padPicks(picks, quiz.questions.length);
		if (last) {
			setPhase("results");
			persist(nextPicks, shared ? "shared" : "private", true);
			return;
		}
		setIndex(index + 1);
		persist(nextPicks, shared ? "shared" : "private", false);
	}
	function goBack() {
		if (index <= 0) return;
		setIndex(index - 1);
	}
	async function toggleShare(next) {
		setShared(next);
		if (phase !== "results") return;
		await persist(picks, next ? "shared" : "private", true);
	}
	function startRun(wipe) {
		const next = wipe ? quiz.questions.map(() => []) : padPicks(picks, quiz.questions.length);
		setPicks(next);
		setIndex(0);
		setPhase("questions");
	}
	async function saveAndExit() {
		await persist(picks, shared ? "shared" : "private", false);
		onExit?.();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("rounded-xl border border-border bg-card p-5", compact && "p-4"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: quiz.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: quiz.countHint ? `${quiz.countHint} · ${quiz.timeHint}` : quiz.blurb
				})] }), phase === "results" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => startRun(true),
					disabled: busy,
					children: "Retake"
				}) : phase === "questions" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
					children: [
						"Question ",
						index + 1,
						" of ",
						visible.length
					]
				}) : null]
			}),
			phase === "hub" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						quiz.questions.length,
						" statements. ",
						quiz.timeHint ?? "Work through them in one sitting.",
						" Rate how much you agree with each one."
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => startRun(initialStatus !== "in-progress"),
					children: initialStatus === "in-progress" ? "Continue" : `Start ${quiz.title.toLowerCase()}`
				})]
			}) : null,
			phase === "results" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizResults, {
						quiz,
						sections: scored.sections.length ? scored.sections : parsed?.sections ?? []
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: shared ? "default" : "outline",
							onClick: () => void toggleShare(true),
							disabled: busy,
							children: "Share with partner"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: !shared ? "default" : "outline",
							onClick: () => void toggleShare(false),
							disabled: busy,
							children: "Keep private"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: shared ? "Your partner can see these scores on Talk. Individual answers stay with you." : "Only you can see these results. You can share the scores later."
					}),
					onFinished ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						onClick: () => onFinished(scored.sections.length ? scored.sections : parsed?.sections ?? []),
						children: "Continue"
					}) : null,
					onExit && !onFinished ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "w-full",
						onClick: onExit,
						children: "Back to quizzes"
					}) : null
				]
			}) : null,
			phase === "questions" && question ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 space-y-3",
				children: [
					sectionTitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
						children: sectionTitle
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-1 overflow-hidden rounded-full bg-secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-primary transition-[width]",
							style: { width: `${Math.round((index + 1) / Math.max(visible.length, 1) * 100)}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium leading-relaxed",
						children: question.prompt
					}),
					likert ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LikertScale, {
						value: selected[0],
						disabled: busy,
						onChange: (n) => chooseSingle(n)
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [multi ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Select every option that is true. You can pick more than one."
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-1.5",
						children: options.map((opt) => {
							const on = selected.includes(opt.value);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy,
								onClick: () => multi ? toggleOption(opt.value) : chooseSingle(opt.value),
								className: cn("min-h-11 rounded-md border px-3 py-2.5 text-left text-sm hover:border-primary/50 hover:bg-primary/5", on ? "border-primary bg-primary/10" : "border-border"),
								children: opt.label
							}, `${origIndex}-${opt.value}`);
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2 pt-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: goBack,
								disabled: busy || index === 0,
								children: "Back"
							}),
							multi ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: goNext,
								disabled: busy || selected.length === 0,
								children: index + 1 >= visible.length ? "See results" : "Next"
							}) : null,
							onExit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => void saveAndExit(),
								disabled: busy,
								children: "Save and exit"
							}) : null
						]
					})
				]
			}) : null
		]
	});
}
function DiscoveryQuizzes({ answers, meId, partnerId, partnerName, onSaved }) {
	const [active, setActive] = (0, import_react.useState)(null);
	const partnerQuick = answers.find((item) => item.topic === BDSM_QUICK_QUIZ.topic && item.userId === partnerId);
	const partnerFull = answers.find((item) => item.topic === BDSM_FULL_QUIZ.topic && item.userId === partnerId);
	const partnerLove = answers.find((item) => item.topic === LOVE_QUIZ.topic && item.userId === partnerId);
	const partnerQuickSections = parseQuizBody(partnerQuick?.body)?.sections ?? [];
	const partnerFullSections = parseQuizBody(partnerFull?.body)?.sections ?? [];
	const partnerLoveSections = parseQuizBody(partnerLove?.body)?.sections ?? [];
	const partnerShared = partnerQuickSections.length || partnerFullSections.length || partnerLoveSections.length;
	const running = active === "quick" ? BDSM_QUICK_QUIZ : active === "full" ? BDSM_FULL_QUIZ : active === "love" ? LOVE_QUIZ : null;
	if (running) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiscoveryQuizRun, {
		quiz: running,
		answers,
		meId,
		onSaved,
		startOnMount: true,
		onExit: () => setActive(null)
	});
	const loveStatus = statusFromAnswers(LOVE_QUIZ, answers, meId);
	const loveCta = loveStatus === "done" ? "See results" : loveStatus === "in-progress" ? "Continue" : "Start love languages";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-border bg-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Free BDSM test"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "See your kink profile. Instant results. Share scores, not answers."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BdsmTestChooser, {
							answers,
							meId,
							onPick: setActive
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setActive("love"),
				className: "w-full rounded-xl border border-border bg-card p-5 text-left hover:border-primary/50",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl",
						children: LOVE_QUIZ.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: LOVE_QUIZ.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm font-medium text-primary",
						children: loveCta
					})
				]
			}),
			partnerId && partnerShared ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-border bg-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-2xl",
						children: [partnerName || "Partner", " shared"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "Scores they chose to show you — not their individual answers."
					}),
					partnerQuickSections.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: BDSM_QUICK_QUIZ.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizResults, {
								quiz: BDSM_QUICK_QUIZ,
								sections: partnerQuickSections
							})
						})]
					}) : null,
					partnerFullSections.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: BDSM_FULL_QUIZ.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizResults, {
								quiz: BDSM_FULL_QUIZ,
								sections: partnerFullSections
							})
						})]
					}) : null,
					partnerLoveSections.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: LOVE_QUIZ.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizResults, {
								quiz: LOVE_QUIZ,
								sections: partnerLoveSections
							})
						})]
					}) : null
				]
			}) : null
		]
	});
}
function RoleStyleField({ role, value, onChange }) {
	const options = stylesFor(role);
	const known = isKnownStyle(role, value);
	const selectValue = known ? value : value ? "other" : "";
	const custom = known ? "" : value === "other" ? "" : value;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "block space-y-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: styleFieldLabel(role) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: selectValue,
				onChange: (event) => {
					const next = event.target.value;
					if (next === "other") onChange(custom || "other");
					else onChange(next);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "",
					children: "Choose…"
				}), options.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: opt.value,
					children: opt.label
				}, opt.value))]
			})]
		}), selectValue === "other" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "block space-y-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Your type" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: custom === "other" ? "" : custom,
				onChange: (event) => onChange(event.target.value.trim() ? event.target.value : "other"),
				placeholder: role === "dominant" ? "e.g. Brat tamer, FinDom…" : "e.g. Switchy brat…",
				maxLength: 80
			})]
		}) : null]
	});
}
var ROLE_KEY = "sanctum.role";
var SKIP_BDSM_KEY = "sanctum.onboarding.skip.bdsm";
var SKIP_LOVE_KEY = "sanctum.onboarding.skip.love";
function markQuizSkipped(which) {
	try {
		sessionStorage.setItem(which === "bdsm" ? SKIP_BDSM_KEY : SKIP_LOVE_KEY, "1");
	} catch {}
}
function quizWasSkipped(which) {
	try {
		return sessionStorage.getItem(which === "bdsm" ? SKIP_BDSM_KEY : SKIP_LOVE_KEY) === "1";
	} catch {
		return false;
	}
}
function rememberRole(role) {
	try {
		sessionStorage.setItem(ROLE_KEY, role);
	} catch {}
}
function rememberedRole() {
	try {
		const value = sessionStorage.getItem(ROLE_KEY);
		if (value === "dominant" || value === "submissive" || value === "switch") return value;
	} catch {}
	return null;
}
var STEPS = [
	"You",
	"BDSM quiz",
	"Love languages",
	"Role",
	"How you play"
];
function Onboarding({ userName, me, onDone }) {
	const profile = me?.profile;
	const [step, setStep] = (0, import_react.useState)(1);
	const [role, setRole] = (0, import_react.useState)(profile?.role ?? rememberedRole());
	const [roleStyle, setRoleStyle] = (0, import_react.useState)(profile?.roleStyle ?? "");
	const [experience, setExperience] = (0, import_react.useState)(profile?.experience || "curious");
	const [name, setName] = (0, import_react.useState)(profile?.displayName || userName || "");
	const [username, setUsername] = (0, import_react.useState)(profile?.username || "");
	const [age, setAge] = (0, import_react.useState)(profile?.age ? String(profile.age) : "");
	const [sex, setSex] = (0, import_react.useState)(profile?.sex || "");
	const [photos, setPhotos] = (0, import_react.useState)(profile?.avatarData ? [profile.avatarData] : []);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [code, setCode] = (0, import_react.useState)("");
	const [pairing, setPairing] = (0, import_react.useState)(me?.profile ? me : null);
	const [answers, setAnswers] = (0, import_react.useState)([]);
	const [companionName, setCompanionName] = (0, import_react.useState)(DEFAULT_COMPANION.name);
	const [companionRole, setCompanionRole] = (0, import_react.useState)(DEFAULT_COMPANION.role);
	const [companionNeediness, setCompanionNeediness] = (0, import_react.useState)(DEFAULT_COMPANION.neediness);
	const [bdsmHint, setBdsmHint] = (0, import_react.useState)(null);
	const [bdsmPick, setBdsmPick] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!profile) return;
		listTalkAnswers().then((rows) => {
			setAnswers(rows);
			const bdsm = rows.find((item) => item.topic === BDSM_QUICK_QUIZ.topic || item.topic === BDSM_FULL_QUIZ.topic);
			const love = rows.find((item) => item.topic === LOVE_QUIZ.topic);
			const parsed = parseQuizBody(bdsm?.body);
			if (parsed?.sections) setBdsmHint(parsed.sections);
			if (!profile.setupDone) {
				if (!bdsm && !quizWasSkipped("bdsm")) setStep(2);
				else if (!love && !quizWasSkipped("love")) setStep(3);
				else setStep(4);
			}
		}).catch(() => null);
	}, [profile?.userId]);
	async function saveBasics() {
		const ageNum = Number(age);
		if (!Number.isInteger(ageNum) || ageNum < 18) {
			toast.error("You must be 18 or older.");
			return;
		}
		if (!name.trim()) {
			toast.error("Add a name. Only you will see it on your profile.");
			return;
		}
		if (!username.trim()) {
			toast.error("Choose a username your partner can see.");
			return;
		}
		if (!sex) {
			toast.error("Choose a gender.");
			return;
		}
		setBusy(true);
		try {
			await saveProfile({ data: {
				role: role ?? "submissive",
				displayName: name.trim(),
				username: username.trim(),
				age: ageNum,
				sex,
				avatarData: photos[0] ?? null,
				experience,
				setupDone: false
			} });
			const next = await getMe();
			setPairing(next);
			setStep(2);
			onDone(next);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not save profile.");
		} finally {
			setBusy(false);
		}
	}
	async function saveRole() {
		if (!role) {
			toast.error("Choose Dominant, Submissive, or Switch.");
			return;
		}
		rememberRole(role);
		setBusy(true);
		try {
			await saveProfile({ data: {
				role,
				roleStyle,
				experience,
				setupDone: false
			} });
			setPairing(await getMe());
			setStep(5);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not save your role.");
		} finally {
			setBusy(false);
		}
	}
	async function finish(mode, nextMe) {
		setBusy(true);
		try {
			if (mode === "companion") await saveCompanion({ data: {
				...DEFAULT_COMPANION,
				name: companionName.trim() || DEFAULT_COMPANION.name,
				role: companionRole,
				neediness: companionNeediness
			} });
			await saveProfile({ data: {
				playMode: mode,
				setupDone: true
			} });
			onDone(nextMe ?? await getMe());
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not finish setup.");
		} finally {
			setBusy(false);
		}
	}
	async function pair() {
		if (!code.trim()) return;
		setBusy(true);
		try {
			await finish("pair", await connectPartner({ data: { code: code.trim() } }));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not connect.");
			setBusy(false);
		}
	}
	function skipBdsmQuiz() {
		markQuizSkipped("bdsm");
		markQuizSkipped("love");
		setStep(4);
	}
	function skipLoveQuiz() {
		markQuizSkipped("love");
		setStep(4);
	}
	const suggestedRole = suggestedRoleFromSections(bdsmHint ?? []);
	const suggestedArch = bdsmHint?.[0]?.rows.find((row) => ![
		"dominant",
		"submissive",
		"switch",
		"dominance",
		"submission"
	].includes(row.key) && row.pct > 0)?.label ?? "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-lg space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.22em] text-primary",
				children: "Enter Sanctum"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl font-medium",
				children: STEPS[step - 1]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex gap-1.5",
				children: STEPS.map((label, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: cn("h-1.5 flex-1 rounded-full", i < step ? "bg-primary" : "bg-secondary"),
					title: label
				}, label))
			}),
			step === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Your name stays on your profile only. Your partner sees your username. Sanctum is for adults 18 and over."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Name" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: name,
								onChange: (e) => setName(e.target.value),
								placeholder: "Only you see this",
								maxLength: 80
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Hidden from everyone else, including a partner."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Username" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: username,
							onChange: (e) => setUsername(e.target.value.replace(/[^A-Za-z0-9._-]/g, "").slice(0, 32)),
							placeholder: "What they will see",
							maxLength: 32
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Age" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 18,
								max: 99,
								value: age,
								onChange: (e) => setAge(e.target.value),
								placeholder: "18+"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Gender" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: sex,
								onChange: (e) => setSex(e.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Choose…"
								}), SEX_OPTIONS.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: opt.value,
									children: opt.label
								}, opt.value))]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoField, {
						photos,
						onChange: setPhotos,
						max: 1,
						label: "Profile photo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						onClick: () => void saveBasics(),
						disabled: busy,
						children: busy ? "Saving…" : "Continue"
					})
				]
			}) : null,
			step === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					!bdsmPick ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BdsmTestChooser, {
						onPick: setBdsmPick,
						answers,
						meId: pairing?.profile?.userId ?? profile?.userId
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiscoveryQuizRun, {
						quiz: bdsmPick === "quick" ? BDSM_QUICK_QUIZ : BDSM_FULL_QUIZ,
						answers,
						meId: pairing?.profile?.userId ?? profile?.userId,
						startOnMount: true,
						onExit: () => setBdsmPick(null),
						onSaved: (row) => setAnswers((prev) => [row, ...prev.filter((item) => item.topic !== row.topic)]),
						onFinished: (sections) => {
							setBdsmHint(sections);
							const roleKey = suggestedRoleFromSections(sections);
							if (roleKey) setRole(roleKey);
							setStep(3);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-xs text-muted-foreground",
						children: "You can take these later in Talk."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						className: "w-full",
						onClick: skipBdsmQuiz,
						children: "Skip quizzes"
					})
				]
			}) : null,
			step === 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiscoveryQuizRun, {
						quiz: LOVE_QUIZ,
						answers,
						meId: pairing?.profile?.userId ?? profile?.userId,
						startOnMount: true,
						onSaved: (row) => setAnswers((prev) => [row, ...prev.filter((item) => item.topic !== row.topic)]),
						onFinished: () => setStep(4)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-xs text-muted-foreground",
						children: "You can take this later in Talk."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						className: "w-full",
						onClick: skipLoveQuiz,
						children: "Skip this quiz"
					})
				]
			}) : null,
			step === 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							suggestedRole ? "The quiz suggested a shape. You still choose." : "Choose how you sit in the dynamic.",
							" ",
							"You can change this later on Profiles. Experience opens the matching chapter in The Playbook."
						]
					}),
					suggestedRole ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							"Quiz leaned ",
							suggestedRole,
							suggestedArch ? ` · ${suggestedArch.replace(/-/g, " ")}` : "",
							"."
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleCard, {
								title: "Dominant",
								copy: "Hold the dynamic.",
								selected: role === "dominant",
								onClick: () => {
									setRole("dominant");
									setRoleStyle("");
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleCard, {
								title: "Submissive",
								copy: "Offer the dynamic.",
								selected: role === "submissive",
								onClick: () => {
									setRole("submissive");
									setRoleStyle("");
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleCard, {
								title: "Switch",
								copy: "Either seat.",
								selected: role === "switch",
								onClick: () => {
									setRole("switch");
									setRoleStyle("");
								}
							})
						]
					}),
					role ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleStyleField, {
						role,
						value: roleStyle,
						onChange: setRoleStyle
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Experience in this role" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: experience,
								onChange: (e) => setExperience(e.target.value),
								children: EXPERIENCE_LEVELS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item.value,
									children: item.label
								}, item.value))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: EXPERIENCE_LEVELS.find((item) => item.value === experience)?.hint
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						onClick: () => void saveRole(),
						disabled: busy || !role,
						children: busy ? "Saving…" : "Continue"
					})
				]
			}) : null,
			step === 5 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Three ways in. You can connect a human later from Profiles even if you start alone."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 rounded-xl border border-border bg-card p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
								children: "Connect to a partner"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-3xl tracking-[0.28em]",
								children: pairing?.profile?.pairingCode ?? profile?.pairingCode
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Their code" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: code,
									onChange: (e) => setCode(e.target.value.toUpperCase()),
									placeholder: "ABC123",
									maxLength: 12,
									className: "tracking-[0.2em]"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "w-full",
								onClick: () => void pair(),
								disabled: busy || !code.trim(),
								children: "Connect"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 rounded-xl border border-border bg-card p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl",
								children: "Use the companion as a partner"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "Shape an adult AI to play with. You can still pair a human later."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Their name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: companionName,
									onChange: (e) => setCompanionName(e.target.value),
									maxLength: 40
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Their role" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: companionRole,
									onChange: (e) => setCompanionRole(e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "dominant",
											children: "Dominant"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "submissive",
											children: "Submissive"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "switch",
											children: "Switch"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedinessField, {
								value: companionNeediness,
								onChange: setCompanionNeediness
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "w-full",
								variant: "outline",
								onClick: () => void finish("companion"),
								disabled: busy,
								children: "Play with the companion"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						variant: "outline",
						onClick: () => void finish("solo"),
						disabled: busy,
						children: "Use as a solo player"
					})
				]
			}) : null
		]
	});
}
function RoleCard({ title, copy, selected, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("rounded-xl border p-3 text-left transition-colors", selected ? "border-primary bg-primary/10" : "border-border bg-card hover:border-primary/40"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-lg leading-tight",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-[11px] leading-relaxed text-muted-foreground",
			children: copy
		})]
	});
}
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	const { data, isPending } = authClient.useSession();
	const user = data?.user;
	return {
		user: user ? {
			id: user.id,
			displayName: user.name ?? null,
			primaryEmail: user.email ?? null,
			profileImageUrl: user.image ?? null,
			isDevFallback: false
		} : null,
		isPending
	};
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
//#endregion
export { saveCompanion as $, getCompanion as A, listEntries as B, deleteEntry as C, dropCompanionMemory as D, disconnectPartner as E, getPoints as F, listTalkAnswers as G, listMessages as H, listArchived as I, recordAppOpen as J, pingLocation as K, listCategories as L, getHouseHistory as M, getLocationBoard as N, generateCompanionPortrait as O, getMe as P, reorderEntries as Q, listCompanionMemories as R, deleteCategory as S, deletePrivatePhoto as T, listPrivatePhotos as U, listJournalComments as V, listRecentEvents as W, removePartner as X, rememberRole as Y, reorderCategories as Z, buyEntry as _, updateEntry as _t, Onboarding as a, saveVacation as at, createEntry as b, PhotoSourceButtons as c, sendMessage as ct, Select as d, setUrgency as dt, saveHouseSettings as et, VideoStrip as f, stageFiles as ft, adjustPoints as g, updateCategory as gt, addPrivatePhoto as h, toggleEntry as ht, NeedinessField as i, saveUserOptions as it, getDashboard as j, getBondSync as k, PhotoStrip as l, setEarnedCount as lt, addJournalComment as m, tickCompanion as mt, Lightbox as n, saveProfile as nt, PendingMediaTray as o, seedStarter as ot, addCategory as p, switchPartner as pt, playWithCompanion as q, MediaField as r, saveTalkAnswer as rt, PhotoField as s, sendCompanionMessage as st, DiscoveryQuizzes as t, savePlay as tt, RoleStyleField as u, setLocationSharing as ut, clearCompanionMessages as v, useCurrentUser as vt, deleteJournalComment as w, deleteAccount as x, connectPartner as y, useCurrentUserState as yt, listCompanionMessages as z };
