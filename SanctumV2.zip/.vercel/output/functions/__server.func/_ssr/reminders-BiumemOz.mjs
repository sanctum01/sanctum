import { D as usesCountdown, a as countdownLabel, d as isDueToday, x as remainingSeconds } from "./sort-CKxFQEP9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reminders-BiumemOz.js
var WEEKDAYS = [
	"Sun",
	"Mon",
	"Tue",
	"Wed",
	"Thu",
	"Fri",
	"Sat"
];
function parseHm(value) {
	const match = /^(\d{1,2}):(\d{2})$/.exec(value.trim());
	if (!match) return null;
	const h = Number(match[1]);
	const m = Number(match[2]);
	if (h < 0 || h > 23 || m < 0 || m > 59) return null;
	return {
		h,
		m
	};
}
function reminderOf(entry, now = /* @__PURE__ */ new Date()) {
	if (entry.kind !== "task" && entry.kind !== "rabbit") return null;
	if (entry.status === "archived" || entry.effectiveStatus === "archived") return null;
	if (entry.meta.reminderEnabled !== "1") return null;
	const parsed = parseHm(entry.meta.reminderTime ?? "");
	if (!parsed) return null;
	if (entry.effectiveStatus === "done") return null;
	if (!isDueToday(entry, now)) return null;
	const minutes = parsed.h * 60 + parsed.m;
	const nowMinutes = now.getHours() * 60 + now.getMinutes();
	const overdue = nowMinutes >= minutes;
	const upcoming = !overdue && minutes - nowMinutes <= 90;
	return {
		entry,
		time: `${String(parsed.h).padStart(2, "0")}:${String(parsed.m).padStart(2, "0")}`,
		minutes,
		overdue,
		upcoming,
		weekdayLabel: entry.weekday != null ? WEEKDAYS[entry.weekday] ?? null : null,
		mode: "clock"
	};
}
function countdownReminder(entry, now = /* @__PURE__ */ new Date()) {
	if (!usesCountdown(entry.kind, entry.cadence)) return null;
	const left = remainingSeconds(entry, now);
	if (left == null) return null;
	const label = countdownLabel(entry, now);
	if (!label) return null;
	return {
		entry,
		time: label,
		minutes: Math.floor(left / 60),
		overdue: left < 0,
		upcoming: left >= 0 && left <= 5400,
		weekdayLabel: null,
		mode: entry.kind === "task" || entry.kind === "challenge" || entry.kind === "punishment" ? "ends" : "starts"
	};
}
function sortReminders(items) {
	return [...items].sort((a, b) => a.minutes - b.minutes);
}
function reminderStorageKey(entryId, now = /* @__PURE__ */ new Date()) {
	return `sanctum-reminded-${entryId}-${now.toISOString().slice(0, 10)}`;
}
//#endregion
export { sortReminders as i, reminderOf as n, reminderStorageKey as r, countdownReminder as t };
