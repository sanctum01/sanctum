import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { m as canMutate, o as KINDS, r as DEFAULT_PLAY } from "./format-Dsk7inZY.mjs";
import { i as cn, n as Input, r as Label, t as Button } from "./input-CkY6TqOo.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { B as listEntries, P as getMe, tt as savePlay } from "./use-current-user-nzqgiI2T.mjs";
import { a as DialogDescription, g as subscribeMe, i as DialogContent, o as DialogHeader, r as Dialog, s as DialogTitle, t as AppShell, v as useLiveReload } from "./badge-CRftROn_.mjs";
import { a as KindPage, d as parseLineList } from "./kind-page-GHqW5OYA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/games-BOnXhStB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function GamesPlay() {
	const [me, setMe] = (0, import_react.useState)(null);
	const [catalog, setCatalog] = (0, import_react.useState)([]);
	const [editing, setEditing] = (0, import_react.useState)(null);
	async function load() {
		try {
			const [mine, shelf] = await Promise.all([getMe(), listEntries({ data: { kind: "catalog" } })]);
			setMe(mine);
			setCatalog(shelf);
		} catch {}
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	(0, import_react.useEffect)(() => subscribeMe(setMe), []);
	useLiveReload(load);
	const play = me?.house.play ?? DEFAULT_PLAY;
	const canEditGames = canMutate(me, "game");
	async function persist(next) {
		try {
			const updated = await savePlay({ data: { play: {
				...play,
				...next
			} } });
			setMe(updated);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not save the game.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.2em] text-primary",
					children: "Play"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-4xl font-medium",
					children: "Games"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm text-muted-foreground",
					children: "Edit the built-in games the same way you write a new one — title, rules, cards, prompts, and catalogue pieces. Then add games you can buy with points."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 lg:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wheel, {
						play,
						catalog,
						onEdit: canEditGames ? () => setEditing("wheel") : void 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Draw, {
						play,
						catalog,
						onEdit: canEditGames ? () => setEditing("draw") : void 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dice, {
						play,
						catalog,
						onEdit: canEditGames ? () => setEditing("dice") : void 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, {
						play,
						onEdit: canEditGames ? () => setEditing("timer") : void 0
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Your games"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 mt-1 text-sm text-muted-foreground",
					children: "Add cards and prompts, then mark catalogue items as a prop, a card, or a prompt. Draw to randomise. Set a points cost to let the Submissive buy a game."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindPage, {
					kind: "game",
					hideHeader: true
				})
			] }),
			editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuiltinEditor, {
				kind: editing,
				play,
				catalog,
				open: true,
				onOpenChange: (open) => {
					if (!open) setEditing(null);
				},
				onSave: (next) => {
					persist(next);
					setEditing(null);
				}
			}) : null
		]
	});
}
function catalogTitles(ids, catalog) {
	return ids.map((id) => catalog.find((item) => String(item.id) === id)?.title).filter((item) => Boolean(item));
}
function Wheel({ play, catalog, onEdit }) {
	const [angle, setAngle] = (0, import_react.useState)(0);
	const [spinning, setSpinning] = (0, import_react.useState)(false);
	const [result, setResult] = (0, import_react.useState)(null);
	const labels = [
		...play.wheelSlices,
		...play.wheelPrompts,
		...catalogTitles(play.wheelCatalogIds, catalog)
	].filter(Boolean);
	const slices = labels.length ? labels : ["Add slices first"];
	const slice = 360 / slices.length;
	function spin() {
		if (spinning || !labels.length) return;
		setSpinning(true);
		const index = Math.floor(Math.random() * labels.length);
		const next = 2160 + (360 - index * slice - slice / 2);
		setAngle(next);
		window.setTimeout(() => {
			setResult(labels[index] ?? null);
			setSpinning(false);
		}, 2400);
	}
	const gradient = slices.map((_, i) => {
		return `${i % 2 === 0 ? "var(--color-raised)" : "var(--color-primary)"} ${i * slice}deg ${(i + 1) * slice}deg`;
	}).join(", ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PlayShell, {
		title: play.wheelTitle,
		copy: play.wheelBody || "Spin for a beat of the evening.",
		onEdit,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto size-52",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-full rounded-full border border-border shadow-inner",
						style: {
							background: `conic-gradient(${gradient})`,
							transform: `rotate(${angle}deg)`,
							transition: spinning ? "transform 2.3s cubic-bezier(0.22, 1, 0.36, 1)" : "none"
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-1/2 left-1/2 size-8 -translate-x-1/2 -translate-y-1/2 rounded-full bg-background" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-1 left-1/2 h-6 w-0 -translate-x-1/2 border-x-8 border-b-[14px] border-x-transparent border-b-primary" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 min-h-6 text-center font-display text-xl",
				children: result ?? " "
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-3 w-full",
				onClick: spin,
				disabled: spinning || !labels.length,
				children: spinning ? "Spinning…" : "Spin"
			})
		]
	});
}
function Draw({ play, catalog, onEdit }) {
	const [card, setCard] = (0, import_react.useState)(null);
	const [flipped, setFlipped] = (0, import_react.useState)(false);
	const extras = [...play.drawPrompts.map((line) => {
		const [title, ...rest] = line.split("—");
		return {
			title: (title ?? "Prompt").trim(),
			body: rest.join("—").trim()
		};
	}), ...catalogTitles(play.drawCatalogIds, catalog).map((title) => ({
		title,
		body: "From the catalogue"
	}))];
	function draw() {
		const deck = [...play.drawCards, ...extras];
		if (!deck.length) setCard({
			title: "Empty deck",
			body: "Edit this game to add cards, prompts, or catalogue pieces."
		});
		else setCard(deck[Math.floor(Math.random() * deck.length)] ?? null);
		setFlipped(false);
		requestAnimationFrame(() => setFlipped(true));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PlayShell, {
		title: play.drawTitle,
		copy: play.drawBody || "Draw a card from your deck.",
		onEdit,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid min-h-40 place-items-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("w-full rounded-lg border border-border bg-secondary p-4 text-center transition-transform duration-300", flipped ? "scale-100 opacity-100" : "scale-95 opacity-80"),
				children: card ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl",
					children: card.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: card.body
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "The deck is face down."
				})
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mt-3 w-full",
			onClick: draw,
			children: "Draw"
		})]
	});
}
function Dice({ play, catalog, onEdit }) {
	const [value, setValue] = (0, import_react.useState)(null);
	const [rolling, setRolling] = (0, import_react.useState)(false);
	const faces = (0, import_react.useMemo)(() => [
		1,
		2,
		3,
		4,
		5,
		6
	], []);
	const extras = [...play.dicePrompts, ...catalogTitles(play.diceCatalogIds, catalog)].filter(Boolean);
	const meaning = extras.length ? [...extras, ...play.diceActs].slice(0, 6) : [...play.diceActs];
	function roll() {
		if (rolling) return;
		setRolling(true);
		let ticks = 0;
		const id = window.setInterval(() => {
			setValue(faces[Math.floor(Math.random() * 6)] ?? 1);
			ticks += 1;
			if (ticks > 10) {
				window.clearInterval(id);
				setRolling(false);
			}
		}, 80);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PlayShell, {
		title: play.diceTitle,
		copy: play.diceBody || "Six acts. Edit each face.",
		onEdit,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid place-items-center py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid size-20 place-items-center rounded-xl border border-border bg-secondary font-display text-4xl",
				children: value ?? "—"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 min-h-10 text-center text-sm text-muted-foreground",
				children: value ? meaning[value - 1] : "Roll when you are ready."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "w-full",
			onClick: roll,
			disabled: rolling,
			children: rolling ? "Rolling…" : "Roll"
		})]
	});
}
function Timer({ play, onEdit }) {
	const [hours, setHours] = (0, import_react.useState)(0);
	const [minutes, setMinutes] = (0, import_react.useState)(1);
	const [seconds, setSeconds] = (0, import_react.useState)(0);
	const configured = Math.max(1, hours * 3600 + minutes * 60 + seconds);
	const [left, setLeft] = (0, import_react.useState)(null);
	const [paused, setPaused] = (0, import_react.useState)(false);
	const leftRef = (0, import_react.useRef)(0);
	const tickRef = (0, import_react.useRef)(null);
	function clearTick() {
		if (tickRef.current) {
			window.clearInterval(tickRef.current);
			tickRef.current = null;
		}
	}
	(0, import_react.useEffect)(() => () => clearTick(), []);
	function startFrom(total) {
		clearTick();
		leftRef.current = total;
		setLeft(total);
		setPaused(false);
		const started = Date.now();
		const origin = total;
		tickRef.current = window.setInterval(() => {
			const remain = Math.max(0, origin - Math.floor((Date.now() - started) / 1e3));
			leftRef.current = remain;
			setLeft(remain);
			if (remain <= 0) clearTick();
		}, 250);
	}
	function pause() {
		if (left == null || left <= 0) return;
		clearTick();
		setPaused(true);
	}
	function resume() {
		if (left == null || left <= 0) return;
		startFrom(left);
	}
	function stop() {
		clearTick();
		setLeft(0);
		setPaused(false);
	}
	function reset() {
		clearTick();
		setLeft(null);
		setPaused(false);
	}
	const running = left != null && left > 0 && !paused;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PlayShell, {
		title: play.timerTitle || "Timer",
		copy: play.timerBody || "A timed kneel, present, or silence.",
		onEdit,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap items-center justify-center gap-2 py-2",
				children: [
					30,
					60,
					120,
					300,
					600,
					3600
				].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setHours(Math.floor(n / 3600));
						setMinutes(Math.floor(n % 3600 / 60));
						setSeconds(n % 60);
						reset();
					},
					className: cn("h-9 rounded-full px-3 text-sm", configured === n ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
					children: n < 60 ? `${n}s` : n < 3600 ? `${n / 60}m` : `${n / 3600}h`
				}, n))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs text-muted-foreground",
						children: ["Hours", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 0,
							max: 12,
							value: hours,
							onChange: (e) => {
								setHours(Math.max(0, Math.min(12, Number(e.target.value) || 0)));
								reset();
							}
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs text-muted-foreground",
						children: ["Minutes", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 0,
							max: 59,
							value: minutes,
							onChange: (e) => {
								setMinutes(Math.max(0, Math.min(59, Number(e.target.value) || 0)));
								reset();
							}
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs text-muted-foreground",
						children: ["Seconds", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 0,
							max: 59,
							value: seconds,
							onChange: (e) => {
								setSeconds(Math.max(0, Math.min(59, Number(e.target.value) || 0)));
								reset();
							}
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-4 text-center font-display text-5xl tabular-nums",
				children: formatClock(left == null ? configured : left)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => running ? pause() : paused ? resume() : startFrom(configured),
						children: running ? "Pause" : paused ? "Resume" : left === 0 ? "Again" : "Start"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: stop,
						disabled: left == null,
						children: "Stop"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						className: "col-span-2",
						onClick: reset,
						children: "Reset"
					})
				]
			})
		]
	});
}
function formatClock(total) {
	const h = Math.floor(total / 3600);
	const m = Math.floor(total % 3600 / 60);
	const s = total % 60;
	return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
function PlayShell({ title, copy, onEdit, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-card p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: copy
			})] }), onEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "outline",
				onClick: onEdit,
				children: "Edit"
			}) : null]
		}), children]
	});
}
function BuiltinEditor({ kind, play, catalog, open, onOpenChange, onSave }) {
	const labels = {
		wheel: {
			title: "The wheel",
			hint: "Cards become slices. Prompts and catalogue pieces join the spin."
		},
		draw: {
			title: "Draw a command",
			hint: "One card per line: Title — the command."
		},
		dice: {
			title: "Dice of service",
			hint: "Six acts, one per line. Catalogue pieces can replace a face."
		},
		timer: {
			title: "Timer",
			hint: "Name it and write when you use it."
		}
	}[kind];
	const [title, setTitle] = (0, import_react.useState)(kind === "wheel" ? play.wheelTitle : kind === "draw" ? play.drawTitle : kind === "dice" ? play.diceTitle : play.timerTitle);
	const [body, setBody] = (0, import_react.useState)(kind === "wheel" ? play.wheelBody : kind === "draw" ? play.drawBody : kind === "dice" ? play.diceBody : play.timerBody);
	const [cards, setCards] = (0, import_react.useState)(kind === "wheel" ? play.wheelSlices.join("\n") : kind === "draw" ? play.drawCards.map((item) => item.body ? `${item.title} — ${item.body}` : item.title).join("\n") : kind === "dice" ? play.diceActs.join("\n") : "");
	const [prompts, setPrompts] = (0, import_react.useState)(kind === "wheel" ? play.wheelPrompts.join("\n") : kind === "draw" ? play.drawPrompts.join("\n") : play.dicePrompts.join("\n"));
	const [catalogIds, setCatalogIds] = (0, import_react.useState)(kind === "wheel" ? play.wheelCatalogIds : kind === "draw" ? play.drawCatalogIds : play.diceCatalogIds);
	const groups = (KINDS.catalog.categories ?? []).map((group) => ({
		...group,
		items: catalog.filter((item) => item.category === group.value)
	})).filter((group) => group.items.length > 0);
	function save() {
		const cardLines = parseLineList(cards);
		const promptLines = parseLineList(prompts);
		if (kind === "wheel") onSave({
			wheelTitle: title.trim() || DEFAULT_PLAY.wheelTitle,
			wheelBody: body,
			wheelSlices: cardLines.slice(0, 24),
			wheelPrompts: promptLines,
			wheelCatalogIds: catalogIds
		});
		else if (kind === "draw") onSave({
			drawTitle: title.trim() || DEFAULT_PLAY.drawTitle,
			drawBody: body,
			drawCards: cardLines.slice(0, 40).map((line) => {
				const [left, ...rest] = line.split("—");
				return {
					title: (left ?? "Card").trim() || "Card",
					body: rest.join("—").trim()
				};
			}),
			drawPrompts: promptLines,
			drawCatalogIds: catalogIds
		});
		else if (kind === "dice") {
			const acts = [...cardLines, ...DEFAULT_PLAY.diceActs].slice(0, 6);
			onSave({
				diceTitle: title.trim() || DEFAULT_PLAY.diceTitle,
				diceBody: body,
				diceActs: acts,
				dicePrompts: promptLines,
				diceCatalogIds: catalogIds
			});
		} else onSave({
			timerTitle: title.trim() || DEFAULT_PLAY.timerTitle,
			timerBody: body
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[90dvh] overflow-y-auto sm:max-w-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Edit ", labels.title] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: labels.hint })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Title" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: title,
							onChange: (e) => setTitle(e.target.value),
							maxLength: 80
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Rules" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: body,
							onChange: (e) => setBody(e.target.value),
							className: "min-h-24 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
						})]
					}),
					kind !== "timer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: kind === "dice" ? "Acts" : "Cards" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: cards,
								onChange: (e) => setCards(e.target.value),
								className: "min-h-28 w-full rounded-md border border-input bg-background px-3 py-2 text-sm",
								placeholder: "One per line"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Prompts" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: prompts,
								onChange: (e) => setPrompts(e.target.value),
								className: "min-h-20 w-full rounded-md border border-input bg-background px-3 py-2 text-sm",
								placeholder: "Optional. One per line."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "From the catalogue" }),
								catalog.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: "The catalogue is empty."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "max-h-48 space-y-2 overflow-y-auto",
									children: groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mb-1 text-[11px] uppercase tracking-[0.14em] text-muted-foreground",
										children: group.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-1",
										children: group.items.map((item) => {
											const id = String(item.id);
											const on = catalogIds.includes(id);
											return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setCatalogIds((prev) => on ? prev.filter((value) => value !== id) : [...prev, id]),
												className: cn("rounded-full border px-3 py-1.5 text-xs", on ? "border-primary bg-primary/10" : "border-border text-muted-foreground"),
												children: item.title
											}, item.id);
										})
									})] }, group.value))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										"Selected pieces join the ",
										kind === "wheel" ? "wheel" : kind === "draw" ? "deck" : "dice",
										" when you play."
									]
								})
							]
						})
					] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						onClick: save,
						children: "Save"
					})
				]
			})]
		})
	});
}
function Games() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GamesPlay, {}) });
}
//#endregion
export { Games as component };
