import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { J as styleLabel } from "./video-DfU4zp6z.mjs";
import { A as greeting, C as fillSelectOptions, D as formatWhen, G as roleLabel, b as dutiesPaused, f as canEditEntry, o as KINDS, x as editDeniedCopy } from "./format-Dsk7inZY.mjs";
import { E as urgencyOf, m as outcomeMessage, w as sortNamed } from "./sort-CKxFQEP9.mjs";
import { i as sortReminders, n as reminderOf, r as reminderStorageKey, t as countdownReminder } from "./reminders-BiumemOz.mjs";
import { i as cn, n as Input, t as Button } from "./input-CkY6TqOo.mjs";
import { X as ChevronDown, b as Plus, nt as Bell, q as ChevronUp, w as Minus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as deleteEntry, F as getPoints, P as getMe, Q as reorderEntries, _t as updateEntry, dt as setUrgency, g as adjustPoints, ht as toggleEntry, j as getDashboard, ot as seedStarter } from "./use-current-user-nzqgiI2T.mjs";
import { g as subscribeMe, p as RichText, t as AppShell, v as useLiveReload } from "./badge-CRftROn_.mjs";
import { l as UrgencyControl, n as EmptyState, r as EntryForm, s as PdfStrip } from "./kind-page-GHqW5OYA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DbLUYLyw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PointsBoardCard({ me, board, onChange }) {
	const profile = me.profile;
	const [reason, setReason] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("5");
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (!profile) return null;
	async function move(userId, sign) {
		const n = Math.trunc(Number(amount));
		if (!Number.isFinite(n) || n === 0) {
			toast.error("Enter a point amount.");
			return;
		}
		setBusy(true);
		try {
			onChange(await adjustPoints({ data: {
				userId,
				delta: sign * Math.abs(n),
				reason: reason.trim() || void 0
			} }));
			setReason("");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not adjust points.");
		} finally {
			setBusy(false);
		}
	}
	const submissive = profile.role === "submissive" ? {
		id: profile.userId,
		name: profile.displayName || "You",
		score: board.mine
	} : me.partner?.role === "submissive" ? {
		id: me.partner.userId,
		name: me.partner.displayName || "Partner",
		score: board.partner ?? 0
	} : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "home-points",
		className: "rounded-xl border border-border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-baseline justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Points"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.14em] text-muted-foreground",
					children: submissive ? `${submissive.name}'s total` : "Connect a Submissive to keep a total"
				})]
			}),
			submissive ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-secondary/70 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.14em] text-muted-foreground",
						children: profile.role === "submissive" ? "Your total" : submissive.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-5xl tabular-nums",
						children: submissive.score
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							disabled: busy,
							onClick: () => void move(submissive.id, 1),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							disabled: busy,
							onClick: () => void move(submissive.id, -1),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {}), "Remove"]
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Points are kept as a single total for the Submissive, visible to both of you once you connect."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-2 sm:grid-cols-[5.5rem_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					inputMode: "numeric",
					value: amount,
					onChange: (e) => setAmount(e.target.value),
					"aria-label": "Point amount"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: reason,
					onChange: (e) => setReason(e.target.value),
					placeholder: "Reason (optional)",
					maxLength: 160
				})]
			}),
			board.ledger.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 space-y-1.5 text-sm",
				children: board.ledger.slice(0, 6).map((event) => {
					const who = event.userId === profile.userId ? profile.displayName || "You" : me.partner?.userId === event.userId ? me.partner.displayName || "Partner" : "Bond";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-baseline justify-between gap-3 text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 truncate",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: event.delta >= 0 ? "text-foreground" : "text-primary",
									children: [event.delta >= 0 ? "+" : "", event.delta]
								}),
								" ",
								who,
								event.reason ? ` · ${event.reason}` : ""
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-[11px]",
							children: formatWhen(event.createdAt)
						})]
					}, event.id);
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted-foreground",
				children: "No points moved yet. Completing a task can award them, or add some by hand."
			})
		]
	});
}
function HomeView() {
	const [me, setMe] = (0, import_react.useState)(null);
	const [dash, setDash] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [editing, setEditing] = (0, import_react.useState)(void 0);
	const [composeCadence, setComposeCadence] = (0, import_react.useState)("daily");
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const load = (0, import_react.useCallback)(async () => {
		try {
			const [mine, dashboard] = await Promise.all([getMe(), getDashboard()]);
			setMe(mine);
			setDash(dashboard);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not load Sanctum.");
		} finally {
			setLoading(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		load();
	}, [load]);
	(0, import_react.useEffect)(() => subscribeMe(setMe), []);
	useLiveReload(load);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 3e4);
		return () => window.clearInterval(id);
	}, []);
	const allTasks = (0, import_react.useMemo)(() => {
		if (!dash) return [];
		const seen = /* @__PURE__ */ new Set();
		const out = [];
		for (const item of [
			...dash.daily,
			...dash.weekly,
			...dash.once,
			...dash.habits,
			...dash.custom ?? [],
			...dash.training,
			...dash.timed ?? []
		]) {
			if (seen.has(item.id)) continue;
			seen.add(item.id);
			out.push(item);
		}
		return out;
	}, [dash]);
	const reminders = (0, import_react.useMemo)(() => {
		if (dutiesPaused(me?.house)) return [];
		const clock = allTasks.map((item) => reminderOf(item, now)).filter((item) => item != null);
		const counts = allTasks.map((item) => countdownReminder(item, now)).filter((item) => item != null);
		return sortReminders([...clock, ...counts]);
	}, [
		allTasks,
		now,
		me?.house
	]);
	(0, import_react.useEffect)(() => {
		for (const item of reminders) {
			if (!item.overdue) continue;
			const key = reminderStorageKey(item.entry.id, now);
			if (typeof window === "undefined") continue;
			if (window.localStorage.getItem(key)) continue;
			window.localStorage.setItem(key, "1");
			toast.message(`Reminder · ${item.entry.title}`, { description: `Due at ${item.time}` });
			if ("Notification" in window && Notification.permission === "granted") try {
				new Notification(item.entry.title, { body: `Due at ${item.time}` });
			} catch {}
		}
	}, [reminders, now]);
	async function toggle(entry) {
		if (dutiesPaused(me?.house)) {
			toast.message("Vacation is on. Resume it to complete duties.");
			return;
		}
		try {
			const updated = await toggleEntry({ data: {
				id: entry.id,
				done: entry.effectiveStatus !== "done"
			} });
			patchTask(updated);
			await refreshPoints();
			announceOutcome(entry, updated);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not update.");
		}
	}
	async function skip(entry) {
		if (dutiesPaused(me?.house)) {
			toast.message("Vacation is on. Resume it to complete duties.");
			return;
		}
		if (entry.kind !== "task") return;
		try {
			const updated = await updateEntry({ data: {
				id: entry.id,
				kind: "task",
				status: "skipped"
			} });
			patchTask(updated);
			await refreshPoints();
			announceOutcome(entry, updated);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not skip.");
		}
	}
	function openExisting(entry) {
		setComposeCadence(entry.cadence === "habit" ? "habit" : entry.cadence || "daily");
		setEditing(entry);
	}
	async function saveBody(entry, html) {
		if (!canEditEntry(me, entry)) {
			toast.message(editDeniedCopy(me, entry));
			return;
		}
		try {
			patchTask(await updateEntry({ data: {
				id: entry.id,
				kind: entry.kind,
				body: html
			} }));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not update.");
		}
	}
	async function archive(entry) {
		if (!canEditEntry(me, entry)) {
			toast.message(editDeniedCopy(me, entry));
			return;
		}
		try {
			const next = entry.status === "archived" ? "open" : "archived";
			await updateEntry({ data: {
				id: entry.id,
				kind: entry.kind,
				status: next
			} });
			toast.success(next === "archived" ? "Archived." : "Restored.");
			await load();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not archive.");
		}
	}
	async function remove(entry) {
		if (!canEditEntry(me, entry)) {
			toast.message(editDeniedCopy(me, entry));
			return;
		}
		if (typeof window !== "undefined" && !window.confirm(`Delete “${entry.title}”? This cannot be undone.`)) return;
		try {
			await deleteEntry({ data: { id: entry.id } });
			toast.success("Deleted.");
			await load();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not delete.");
		}
	}
	async function refreshPoints() {
		try {
			const board = await getPoints();
			setDash((prev) => prev ? {
				...prev,
				points: board
			} : prev);
		} catch {}
	}
	function patchTask(updated) {
		setDash((prev) => {
			if (!prev) return prev;
			const patch = (list) => list.map((item) => item.id === updated.id ? updated : item);
			return {
				...prev,
				daily: patch(prev.daily),
				weekly: patch(prev.weekly),
				once: patch(prev.once),
				habits: patch(prev.habits),
				custom: patch(prev.custom ?? []),
				training: patch(prev.training)
			};
		});
	}
	async function seed() {
		try {
			if ((await seedStarter()).created === 0) toast.message("Entries are already in place.");
			else toast.success("A starter protocol is in place.");
			await load();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not seed.");
		}
	}
	async function changeUrgency(entry, value) {
		try {
			patchTask(await setUrgency({ data: {
				id: entry.id,
				urgency: value
			} }));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not set importance.");
		}
	}
	if (loading || !dash || !me?.profile) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 animate-pulse rounded-xl bg-card" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-xl bg-card" })]
	});
	const profile = me.profile;
	const empty = Object.values(dash.counts).every((n) => n === 0);
	const dailyDone = dash.daily.filter((t) => t.effectiveStatus === "done").length;
	const weeklyDone = dash.weekly.filter((t) => t.effectiveStatus === "done").length;
	const names = {};
	names[profile.userId] = profile.displayName || "Me";
	if (me.partner) names[me.partner.userId] = me.partner.displayName || "Partner";
	names.both = "Both";
	const typeName = styleLabel(profile.role, profile.roleStyle);
	const partnerType = me.partner ? styleLabel(me.partner.role, me.partner.roleStyle) : "";
	const dailyItems = sortNamed(me.options.hideCompleted ? dash.daily.filter((item) => item.effectiveStatus !== "done") : dash.daily);
	const weeklyItems = sortNamed(me.options.hideCompleted ? dash.weekly.filter((item) => item.effectiveStatus !== "done") : dash.weekly);
	const onceItems = sortNamed(me.options.hideCompleted ? dash.once.filter((item) => item.effectiveStatus !== "done") : dash.once);
	const habitItems = sortNamed(me.options.hideCompleted ? dash.habits.filter((item) => item.effectiveStatus !== "done") : dash.habits);
	const customItems = sortNamed(me.options.hideCompleted ? (dash.custom ?? []).filter((item) => item.effectiveStatus !== "done") : dash.custom ?? []);
	const trainingItems = sortNamed(me.options.hideCompleted ? dash.training.filter((item) => item.effectiveStatus !== "done") : dash.training);
	async function moveList(list, entry, dir) {
		const ids = list.map((item) => item.id);
		const index = ids.indexOf(entry.id);
		const next = index + dir;
		if (index < 0 || next < 0 || next >= ids.length) return;
		const swapped = [...ids];
		[swapped[index], swapped[next]] = [swapped[next], swapped[index]];
		try {
			await reorderEntries({ data: { ids: swapped } });
			await load();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not reorder.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-medium uppercase tracking-[0.2em] text-primary",
						children: [
							greeting(),
							" · ",
							typeName ? `${typeName} · ` : "",
							roleLabel(profile.role)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-4xl font-medium sm:text-5xl",
						children: profile.displayName || "Unnamed"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: me.partner ? `Bound to ${me.partner.displayName || "your partner"}, ${partnerType ? `${partnerType.toLowerCase()} ` : ""}${roleLabel(me.partner.role).toLowerCase()}.` : profile.playMode === "companion" ? "Playing with the companion. These pages are only this house." : "Solo. These pages are only yours. The companion can talk, but cannot change them."
					})
				] }), empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => void seed(),
					children: "Load sample protocol"
				}) : null]
			}),
			me.options.showReminders && !dutiesPaused(me.house) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-border bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "flex items-center gap-2 font-display text-2xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5 text-primary" }), "Reminders"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-xs text-muted-foreground",
						onClick: () => {
							if ("Notification" in window && Notification.permission === "default") Notification.requestPermission();
						},
						children: typeof Notification !== "undefined" && Notification.permission === "granted" ? "Alerts on" : "Enable alerts"
					})]
				}), reminders.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: reminders.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3 rounded-lg bg-secondary/70 px-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-medium",
								children: item.entry.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									item.time,
									item.weekdayLabel ? ` · ${item.weekdayLabel}` : "",
									item.mode === "ends" ? " · until it ends" : item.mode === "starts" ? " · until it starts" : "",
									item.entry.kind === "rabbit" ? " · training" : item.entry.cadence === "habit" ? " · habit" : ` · ${item.entry.kind}`,
									item.entry.kind === "task" && urgencyOf(item.entry.meta) !== "normal" ? ` · ${urgencyOf(item.entry.meta)}` : "",
									item.overdue ? " · overdue" : item.upcoming ? " · soon" : ""
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => void toggle(item.entry),
								children: "Done"
							}), item.entry.kind === "task" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => void skip(item.entry),
								children: "Skip"
							}) : null]
						})]
					}, `${item.entry.id}:${item.mode}`))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "No timed reminders yet. Add a clock time on a task, or days/hours/minutes on a task, challenge, punishment, reward, scene, roleplay, or game."
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskColumn, {
					title: "Daily",
					kicker: dutiesPaused(me.house) ? "Paused" : `${dailyDone}/${dash.daily.length} complete`,
					items: dailyItems,
					empty: "No daily tasks yet. Add them from the Tasks category.",
					names,
					paused: dutiesPaused(me.house),
					me,
					onToggle: (entry) => void toggle(entry),
					onSkip: (entry) => void skip(entry),
					onBody: (entry, html) => void saveBody(entry, html),
					onOpen: (entry) => openExisting(entry),
					onArchive: (entry) => void archive(entry),
					onDelete: (entry) => void remove(entry),
					onMove: (entry, dir) => void moveList(dailyItems, entry, dir),
					onUrgency: (entry, value) => void changeUrgency(entry, value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskColumn, {
					title: "Weekly",
					kicker: dutiesPaused(me.house) ? "Paused" : `${weeklyDone}/${dash.weekly.length} complete`,
					items: weeklyItems,
					empty: "No weekly tasks yet.",
					names,
					paused: dutiesPaused(me.house),
					me,
					onToggle: (entry) => void toggle(entry),
					onSkip: (entry) => void skip(entry),
					onBody: (entry, html) => void saveBody(entry, html),
					onOpen: (entry) => openExisting(entry),
					onArchive: (entry) => void archive(entry),
					onDelete: (entry) => void remove(entry),
					onMove: (entry, dir) => void moveList(weeklyItems, entry, dir),
					onUrgency: (entry, value) => void changeUrgency(entry, value)
				})]
			}),
			habitItems.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Habits"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.14em] text-muted-foreground",
						children: dutiesPaused(me.house) ? "Paused" : `${dash.habits.filter((t) => t.effectiveStatus === "done").length}/${dash.habits.length} complete`
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: habitItems.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, {
						entry: item,
						names,
						paused: dutiesPaused(me.house),
						canEdit: canEditEntry(me, item),
						onToggle: () => void toggle(item),
						onSkip: () => void skip(item),
						onBody: canEditEntry(me, item) ? (html) => void saveBody(item, html) : void 0,
						onOpen: () => openExisting(item),
						onArchive: () => void archive(item),
						onDelete: () => void remove(item),
						onMoveUp: index === 0 ? void 0 : () => void moveList(habitItems, item, -1),
						onMoveDown: index === habitItems.length - 1 ? void 0 : () => void moveList(habitItems, item, 1),
						onUrgency: (value) => void changeUrgency(item, value)
					}, item.id))
				})]
			}) : null,
			customItems.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Custom days"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: customItems.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, {
						entry: item,
						names,
						paused: dutiesPaused(me.house),
						canEdit: canEditEntry(me, item),
						onToggle: () => void toggle(item),
						onSkip: () => void skip(item),
						onBody: canEditEntry(me, item) ? (html) => void saveBody(item, html) : void 0,
						onOpen: () => openExisting(item),
						onArchive: () => void archive(item),
						onDelete: () => void remove(item),
						onMoveUp: index === 0 ? void 0 : () => void moveList(customItems, item, -1),
						onMoveDown: index === customItems.length - 1 ? void 0 : () => void moveList(customItems, item, 1),
						onUrgency: (value) => void changeUrgency(item, value)
					}, item.id))
				})]
			}) : null,
			onceItems.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "One-time"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: onceItems.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, {
						entry: item,
						names,
						paused: dutiesPaused(me.house),
						canEdit: canEditEntry(me, item),
						onToggle: () => void toggle(item),
						onSkip: () => void skip(item),
						onBody: canEditEntry(me, item) ? (html) => void saveBody(item, html) : void 0,
						onOpen: () => openExisting(item),
						onArchive: () => void archive(item),
						onDelete: () => void remove(item),
						onMoveUp: index === 0 ? void 0 : () => void moveList(onceItems, item, -1),
						onMoveDown: index === onceItems.length - 1 ? void 0 : () => void moveList(onceItems, item, 1),
						onUrgency: (value) => void changeUrgency(item, value)
					}, item.id))
				})]
			}) : null,
			trainingItems.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Training"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: trainingItems.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, {
						entry: item,
						names,
						paused: dutiesPaused(me.house),
						canEdit: canEditEntry(me, item),
						onToggle: () => void toggle(item),
						onSkip: () => void 0,
						onBody: canEditEntry(me, item) ? (html) => void saveBody(item, html) : void 0,
						onOpen: () => openExisting(item),
						onArchive: () => void archive(item),
						onDelete: () => void remove(item),
						onMoveUp: index === 0 ? void 0 : () => void moveList(trainingItems, item, -1),
						onMoveDown: index === trainingItems.length - 1 ? void 0 : () => void moveList(trainingItems, item, 1)
					}, item.id))
				})]
			}) : null,
			dash.archived?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Archived"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: dash.archived.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, {
						entry: item,
						names,
						archivedMode: true,
						canEdit: canEditEntry(me, item),
						onToggle: () => void 0,
						onSkip: () => void 0,
						onOpen: () => openExisting(item),
						onArchive: () => void archive(item),
						onDelete: () => void remove(item)
					}, item.id))
				})]
			}) : null,
			empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "Sanctum is quiet",
				body: "Load a sample protocol, or start writing tasks, training, punishments, and rewards yourselves.",
				action: "Load sample protocol",
				onAction: () => void seed()
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PointsBoardCard, {
				me,
				board: dash.points,
				onChange: (board) => setDash((prev) => prev ? {
					...prev,
					points: board
				} : prev)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntryForm, {
				config: fillSelectOptions(KINDS.task),
				entry: editing ?? void 0,
				open: editing !== void 0,
				defaultCadence: composeCadence,
				addLabel: composeCadence === "habit" ? "New habit" : "New task",
				readOnly: Boolean(editing && !canEditEntry(me, editing)),
				onOpenChange: (open) => {
					if (!open) setEditing(void 0);
				},
				onSaved: () => void load()
			})
		]
	});
}
function announceOutcome(previous, next) {
	const note = outcomeMessage(previous, next);
	if (!note) return;
	if (note.tone === "success") toast.success(note.text);
	else toast.message(note.text);
}
function TaskColumn({ title, kicker, items, empty, names, paused, me, onToggle, onSkip, onBody, onOpen, onArchive, onDelete, onMove, onUrgency }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-card p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-baseline justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.14em] text-muted-foreground",
				children: kicker
			})]
		}), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-6 text-sm text-muted-foreground",
			children: empty
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: items.map((item, index) => {
				const editable = canEditEntry(me, item);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, {
					entry: item,
					names,
					paused,
					canEdit: editable,
					onToggle: () => onToggle(item),
					onSkip: () => onSkip(item),
					onBody: editable ? (html) => onBody(item, html) : void 0,
					onOpen: () => onOpen(item),
					onArchive: () => onArchive(item),
					onDelete: () => onDelete(item),
					onMoveUp: index === 0 ? void 0 : () => onMove?.(item, -1),
					onMoveDown: index === items.length - 1 ? void 0 : () => onMove?.(item, 1),
					onUrgency: editable && onUrgency ? (value) => onUrgency(item, value) : void 0
				}, item.id);
			})
		})]
	});
}
function TaskRow({ entry, names, paused, archivedMode, canEdit, onToggle, onSkip, onBody, onOpen, onArchive, onDelete, onMoveUp, onMoveDown, onUrgency }) {
	const done = entry.effectiveStatus === "done";
	const skipped = entry.status === "skipped" && !done;
	const assignee = entry.assignedTo === "both" ? "Both" : entry.assignedTo ? names[entry.assignedTo] ?? null : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-3 rounded-lg bg-secondary/60 p-3",
		children: [archivedMode ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onToggle,
			disabled: paused,
			className: cn("mt-0.5 size-6 shrink-0 rounded-full border", done ? "border-primary bg-primary" : "border-input", paused && "opacity-40"),
			"aria-label": paused ? "Paused" : done ? "Reopen" : "Mark done"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onOpen,
					className: "block w-full text-left",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("text-sm font-medium", done && "text-muted-foreground line-through"),
						children: entry.title
					})
				}),
				entry.body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, {
					html: entry.body,
					clamp: !onBody,
					className: "mt-0.5 text-xs",
					onChange: onBody
				}) : null,
				entry.pdfs?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PdfStrip, {
					pdfs: entry.pdfs,
					className: "mt-2"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs uppercase tracking-[0.12em] text-muted-foreground",
					children: [
						assignee ? `For ${assignee}` : null,
						entry.meta.points ? ` · ${entry.meta.points} pts` : "",
						entry.kind === "task" && urgencyOf(entry.meta) !== "normal" ? ` · ${urgencyOf(entry.meta)}` : "",
						entry.meta.reminderEnabled === "1" && entry.meta.reminderTime ? ` · ${entry.meta.reminderTime}` : "",
						skipped ? " · skipped" : "",
						paused ? " · paused" : "",
						archivedMode ? " · archived" : ""
					]
				}),
				onUrgency ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UrgencyControl, {
						value: urgencyOf(entry.meta),
						onChange: onUrgency
					})
				}) : null,
				entry.meta.catalogTitles ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: ["Using ", entry.meta.catalogTitles]
				}) : null,
				entry.meta.rewardTitles || entry.meta.punishmentTitles ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: [
						entry.meta.rewardTitles ? `Earns ${entry.meta.rewardTitles}` : "",
						entry.meta.rewardTitles && entry.meta.punishmentTitles ? " · " : "",
						entry.meta.punishmentTitles ? `Skip: ${entry.meta.punishmentTitles}` : ""
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 flex flex-wrap gap-3",
					children: [!archivedMode && !done && !skipped && !paused && entry.kind === "task" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-9 text-xs text-muted-foreground",
						onClick: onSkip,
						children: "Skip"
					}) : null, canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						onMoveUp || onMoveDown ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "grid size-9 place-items-center text-muted-foreground disabled:opacity-30",
								onClick: onMoveUp,
								disabled: !onMoveUp,
								"aria-label": "Move up",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "grid size-9 place-items-center text-muted-foreground disabled:opacity-30",
								onClick: onMoveDown,
								disabled: !onMoveDown,
								"aria-label": "Move down",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4" })
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-9 text-xs text-muted-foreground",
							onClick: onOpen,
							children: "Edit"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-9 text-xs text-muted-foreground",
							onClick: onArchive,
							children: archivedMode ? "Restore" : "Archive"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-9 text-xs text-muted-foreground",
							onClick: onDelete,
							children: "Delete"
						})
					] }) : null]
				})
			]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeView, {}) });
}
//#endregion
export { Home as component };
