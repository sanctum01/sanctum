import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { B as parseExperience, R as meetsExperience, X as tagLabel, k as experienceLabel, t as ALL_KINK_OPTIONS, w as coupleExperience } from "./video-DfU4zp6z.mjs";
import { w as sortNamed } from "./sort-CKxFQEP9.mjs";
import { i as cn, t as Button } from "./input-CkY6TqOo.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { G as listTalkAnswers, L as listCategories, P as getMe, rt as saveTalkAnswer, t as DiscoveryQuizzes } from "./use-current-user-nzqgiI2T.mjs";
import { _ as useAutoSave, f as RichEditor, m as SaveHint, p as RichText, t as AppShell, v as useLiveReload } from "./badge-CRftROn_.mjs";
import { a as KindPage, c as STARTER_KINKS, f as todaysCard, i as KINK_RATINGS, o as MoreInfoButton, t as CategoryManager, u as dayKey } from "./kind-page-GHqW5OYA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/talk-C2CYdQ6v.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function body(title, description, easy, hard, extreme) {
	return {
		title,
		description,
		easy,
		hard,
		extreme
	};
}
function slugId(kind, title) {
	return `${kind}:${title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 48)}`;
}
function entry(kind, kinks, min, dominant, submissive) {
	return {
		id: slugId(kind, dominant.title),
		kind,
		kinks,
		min,
		dominant,
		submissive
	};
}
var WEEKLY_PROMPTS = [
	entry("communication", [
		"protocol",
		"verbal",
		"training",
		"power-exchange"
	], "curious", body("Say one instruction. They do it once", "Pick one short instruction they can actually do in this room. Say it once, in a calm voice. Do not repeat it. Do not add a second one. They do it. You say thank you, or you say that was good, and you use their name. If they did not hear you, that is on you — say it again once, then stop. After: water. Write the instruction in Journal if you want to use it again.", "One instruction. Sit down. They sit. Thank you. Name. Drink water.", "One instruction that uses their body: kneel on a cushion, or put your hands on your thighs. They do it. You thank them. They stand when you say so.", "One instruction, then 2 minutes of holding it. You do not fill the quiet with extra words. Then their name, and they may move."), body("Hear one instruction. Do it once", "They say one short instruction. You do it. You do not have to guess a second one. After: water, your name.", "Sit when they say sit. Hear thank you. Drink water.", "Kneel or hands on thighs if that is what they asked. Stand when they say so.", "Hold it for 2 minutes. You may ask, in ordinary words, if you did not hear.")),
	entry("communication", [
		"praise",
		"verbal",
		"service"
	], "curious", body("Three true praises before they sleep", "Before bed, say 3 true sentences about how they were today. Be specific. Do not use empty lines like you are amazing. Do not turn praise into a new task. If the words start to sound like shame, make them smaller, or stop. After: they only have to hear them. The words can live in a message they can read tomorrow.", "3 lines, one night. They may say thank you or stop. Stop means stop.", "3 nights this week. Same rule. No extra tasks attached.", "Every night this week. Sunday ask which line actually landed. Keep those. Stop the ones that felt like acting."), body("Three true praises you have to take before sleep", "You hear 3 true lines. You may say stop. The message can stay for morning.", "One night. Thank you, or stop.", "Three nights. You may ask for paper if a low mood steals spoken words.", "Every night. Say on Sunday which line helped.")),
	entry("communication", [
		"verbal",
		"humiliation",
		"degradation"
	], "seasoned", body("Dirty talk from a page you wrote", "While clothed, write 5 words or short lines they want to hear. Only those words. Do not make up new mean words in the heat. Read the list once. Stop. Then say the opposite kind sentences, as true. If either of you laughs from discomfort, it is over. Do not do this in public. Write a kind morning note now.", "Read the 5 lines. Stop. Write the 5 kind opposites in the same notebook.", "One line, repeated. Then its opposite. Morning note already drafted.", "The full list, still once, still with the repair the same night. Do not add spanking or bondage the same night."), body("Dirty talk from a page you helped write", "Only the page you helped write. You can stop it. After: the opposite sentences. A morning note.", "The 5 lines once. Then the kind opposites.", "One line, then its opposite. You may stop after the first.", "The full list, still once. You may keep it on paper and not run it.")),
	entry("communication", [
		"verbal",
		"degradation",
		"orgasm-control",
		"denial"
	], "practiced", body("Tease them with words while you edge them", "Use your hand or a toy they already know. Bring them close to orgasm, then stop. While you do that, use playful mean words from a list you wrote while clothed — teasing, not new insults. Examples they asked for: greedy, patient, not yet. Ask for a number from 1 to 10. 8 means you take your hand away. After: water, a towel, their name, and a clear yes or no about coming later. If the words land as real shame, stop the words. Keep the care.", "2 minutes on, 1 minute off, 3 times. One teasing line from the list each stop. Then offer: come now, wait, or be held.", "Same 3 rounds. They keep their hands still. You may repeat one line. They may still ask you to stop the words.", "A longer hold at about 7. Keep the list. Then the planned yes or no. Do not add new mean words because they looked close."), body("Hear the tease while they edge you", "They touch you. They stop. They use words from a list you helped write. You say numbers. 8 means stop. After: water, towel, a clear yes or no about later.", "3 rounds. One teasing line each stop. Then say honestly: come now, wait, or be held.", "Hands still. You may still ask them to stop the words.", "A longer wait. You may ask for the kind sentences instead of the tease.")),
	entry("communication", [
		"protocol",
		"ownership",
		"verbal"
	], "curious", body("A name they asked for, used for 10 minutes", "Pick a name they already said yes to: Sir, Ma'am, a pet name, or their real name said with care. Use it for 10 minutes at home. When the timer rings, go back to ordinary names unless they ask to keep it. Do not use a name they did not pick. After: their legal name, water.", "5 minutes at the table. The name, then their legal name. Drink.", "10 minutes. The name while they sit or kneel. Then legal name and tea.", "An evening at home. The name inside. Legal name if anyone else can hear, including through a wall."), body("A name you asked for, used for 10 minutes", "They use a name you already said yes to. You get your legal name back. After: water.", "5 minutes. Then your legal name.", "10 minutes. Then tea and your name.", "An evening at home. You may ask for your legal name at any time.")),
	entry("communication", [
		"verbal",
		"protocol",
		"power-exchange"
	], "curious", body("You tell them what you will do. Then you do it", "Before you touch them, say the next step in plain words. Then do only that. Then tell the next step. They can say no to a step. No means you skip it, not that the night is over unless they want it over. After: say you are done. Their name. Water.", "3 steps. Clothes stay on. Name each one. Then done.", "5 steps. They may say skip. You skip. Then their name.", "A longer map you named while clothed. Still one step at a time. Still no extra surprise."), body("They tell you what they will do. Then they do it", "You hear the next step. You may say no. After: you are done, your name, water.", "3 steps. Clothes on. You may skip any step.", "5 steps. Skip still works.", "A longer map. You may stop the whole map with ordinary words.")),
	entry("public", [
		"exhibitionism",
		"orgasm-control",
		"sensation-play"
	], "practiced", body("A remote toy on low, a short shop", "They wear a small vibrator under ordinary clothes. You hold the remote. Use a toy they have already worn. Agree a stop word by text. Keep it on the lowest setting. A shop or a walk, 40 minutes or less. If they cannot walk easily, you find a bathroom or you go home. Do not show off to people on the street. Strangers are not in the scene. After: toy out, wash, water, sit.", "A 10-minute walk around the block on low. Then home. Out. Water.", "A short known shop, 20 minutes. One text that says the stop word means off now. You do not raise it in the aisle.", "40 minutes max. Still low. If their face looks like panic, not heat, it is over and you go home. Praise the abort."), body("A remote toy they hold, a short shop you take", "You wear it. They hold the remote. Stop word by text. Low only. Strangers are not in the scene. After: out, wash, water.", "10-minute walk. Then home.", "A short known shop. Text stop if you need it off.", "40 minutes max. You do not have to finish the shop.")),
	entry("public", [
		"protocol",
		"power-exchange",
		"voyeurism"
	], "curious", body("A look across the table that means I have you", "Agree one look. It means I have you. Use it once in a cafe, a park, or at dinner out. Nobody else should be able to read it. Do not add a second signal this week. After: a short text on the way home that says the look landed, or that it felt silly. Silly is allowed.", "Practise the look at home for 1 minute. Then use it once at a table you already sit at.", "Use it once on a real outing. Then tea as people.", "Use it twice this week, same look. If they miss it, you do not punish the miss. You try again or you drop it."), body("A look across the table that means they have you", "One look you both know. Nobody else should read it. After: a text that says it landed, or that it felt silly.", "Practise at home. Then once at a table you already sit at.", "Once on a real outing. Then tea.", "Twice this week. Missing it is not a fail.")),
	entry("public", [
		"exhibitionism",
		"ownership",
		"protocol"
	], "curious", body("A secret item under clothes on a short walk", "You choose one item they already own: underwear, a bracelet, a plug they have already worn. They wear it under normal clothes on a short walk you already take. They can take it out in a bathroom. After: home, item off, their name. Do not ask them to flash anyone. Do not take photos in public.", "A bracelet or a pair of underwear. 15-minute walk. Off at home.", "Underwear you chose. A half-hour known walk. Off at home. One check-in text.", "A plug they have already worn, a short walk, bathroom access the whole time. Out the moment they say so, including in ordinary words."), body("A secret item they chose, on a short walk you take", "One item you already own, under normal clothes. You can take it out. After: home, off, your name. No photos in public.", "A bracelet or underwear. 15-minute walk. Off at home.", "Underwear they chose. A known walk. One text. Off at home.", "A plug you have already worn, only if you still want it. You can take it out in a bathroom. That is care.")),
	entry("public", [
		"exhibitionism",
		"orgasm-control",
		"denial"
	], "practiced", body("One bathroom stall. One touch. Then back to you", "In a place with a lockable stall (cafe, shop, cinema). They go in. They touch their genitals once, through clothes or under, for no more than 60 seconds. They do not come. They come back to the table. You do not follow them in. You do not involve other people. After: home, water, a clear yes or no about coming later. If the stall feels unsafe, skip it and do the 60 seconds at home. Skipping is the skill.", "Practise the 60 seconds at home first. Then, if it still feels good, once in a stall you know. Back to the table. No coming.", "Once on a real outing. 60 seconds. Back. A kind look. Home.", "Twice this week, still 60 seconds, still no coming in the stall. A planned yes later so the week is not only waiting."), body("One bathroom stall. One touch. Then back to them", "Lock. 60 seconds. You do not come. You go back. If it feels unsafe, you skip it and do it at home. That is care.", "Practise at home. Then once in a stall you know, if you still want it.", "Once on a real outing. Back to the table.", "Twice this week. You still get a planned yes later.")),
	entry("public", [
		"verbal",
		"orgasm-control",
		"exhibitionism"
	], "curious", body("A text that heats them up while they are out", "They are at work, on a bus, or in a shop. You send 1 to 3 short texts that are dirty enough to heat them up, clean enough that a stranger glancing at a phone would not know. No photos of genitals. They may reply later. After: a kind closing text so they are not left hanging. Do not stack 20 messages.", "One text. One kind close an hour later.", "Three texts across an afternoon. A close before they sleep.", "A whole outing. Still 3 texts max. A planned yes or a planned wait when they get home. Do not make them reply at work."), body("A text that heats you up while you are out", "Short. Safe to glance at. You do not have to reply at work. You get a kind close so you are not left hanging.", "One text. One kind close.", "Three texts. A close before sleep.", "A whole outing. You may ask them to stop. That is a complete answer.")),
	entry("public", [
		"ownership",
		"protocol",
		"marking"
	], "curious", body("A hand on the small of their back in a queue", "In a real queue — shop, cinema, station — put your hand on the small of their back. Ordinary. Claimed. Nobody else should clock it as a scene. Take the hand away if they shift away. After: a squeeze of the hand when you are back in private. That is the close.", "Practise at home, 10 seconds. Then once in a real queue.", "Once on an outing you already planned. Then the private squeeze.", "Each time you queue together this week. If they shift away, the hand comes off. That is the rule working."), body("A hand on the small of your back in a queue", "Ordinary. Claimed. You may shift away. The hand should come off. After: a squeeze in private.", "Practise at home. Then once in a real queue.", "Once on a planned outing. Then the private squeeze.", "Each queue this week. Shifting away is allowed.")),
	entry("scene", [
		"protocol",
		"service",
		"power-exchange"
	], "curious", body("You wash them. They stay still", "A shower or a bath you both fit, at home. You wash them. They keep their hands on the wall or on their thighs unless they need to be safe. Agree a time: 10 minutes is enough. Water temperature they can stand. After: towel, their name, a robe, water to drink. Do not add sex unless that was the plan. Stopping if they are cold is the skill.", "10 minutes. Back and hair. They stay still. Towel. Name.", "15 minutes. Whole body they offered. They may speak. Then robe and a drink.", "20 minutes. Still. Then you dry them. Sit. 10 minutes of quiet. Do not rush the next thing."), body("They wash you. You stay still", "You keep still unless you need to be safe. You may say the water is too hot. After: towel, your name, a drink.", "10 minutes. Back and hair. Then towel and your name.", "15 minutes. Body you offered. You may speak. Then a robe.", "20 minutes. Then quiet sitting. You may ask that this be the whole scene.")),
	entry("scene", [
		"spanking",
		"impact-play",
		"sadomasochism"
	], "practiced", body("Over-the-knee spanking is the whole scene", "At home. The spanking is the scene, not a warm-up for sex. Clothes on first. Hand only. Agree the number while clothed. Count out loud. Check between sets. Landing is longer than the spanking: sit them up, water, a blanket, a hand on their back, their name. Do not add a paddle unless that was the plan.", "Clothes on. 10, check, 10. Sit up. Water. Blanket. 10 quiet minutes.", "Underwear if they asked. Same written number. Last touches are a hand. Then 15 minutes of landing.", "Bare if they asked. Two sets, still the written number. Marks that show at work need a separate yes. Landing is 20 minutes."), body("Over-the-knee spanking is the whole scene — you take it", "You get a landing longer than the spanking. After: sit up, water, blanket, your name.", "Clothes on. 10, check, 10. Then 10 quiet minutes.", "Underwear if you asked. Then 15 minutes of landing.", "Bare if you asked. Say if you sit at work tomorrow. You still get the long landing.")),
	entry("scene", [
		"denial",
		"power-exchange",
		"orgasm-control"
	], "curious", body("Kissing they cannot start", "At home. You kiss them. They do not start the kiss. They may kiss back when you say so. Set a timer: 10 minutes. If they start, you pause, smile, and begin again, or you stop. Stopping is allowed. After: they may kiss you freely, or you hold them without kissing. Say which. Water.", "5 minutes. Forehead and mouth. They wait. Then they may kiss you back. Drink water.", "10 minutes. You start every kiss. Then 5 minutes where they may start. Then names.", "15 minutes. No sex after unless that was the plan. Being not allowed to start can be the whole heat."), body("Kissing you cannot start", "They start. You wait. You may kiss back when they say so. After: free kissing or a hold. Water.", "5 minutes. Then you may kiss them back.", "10 minutes of waiting. Then 5 minutes you may start.", "15 minutes. You may ask that this stay the whole scene.")),
	entry("scene", [
		"protocol",
		"ownership",
		"exhibitionism"
	], "curious", body("A bench: they sit close. You decide when they may touch", "In a park or on a quiet street, sit on a public bench. They sit close. Ordinary clothes. You decide when they may put a hand on your leg. Nobody else is in the scene. No toys. No kissing that would make a stranger uncomfortable. 10 minutes. After: walk home or to the car as people, then a private squeeze.", "5 minutes. Close. No extra touch. Then a private squeeze.", "10 minutes. One allowed hand on a leg when you say so. Then you walk.", "20 minutes. Still ordinary. If the bench gets busy, you leave. Leaving is the scene going well."), body("A bench: you sit close. They decide when you may touch", "Public bench. Ordinary. You wait. You may put a hand on a leg when they say so. After: a private squeeze.", "5 minutes. Close. Then a private squeeze.", "10 minutes. One allowed hand when they say so.", "20 minutes. If it gets busy, you leave. That is care.")),
	entry("scene", ["cnc", "breath-play"], "established", body("Want, fear, out — write it, do not run it", "You do not run CNC (pretend force) or breath play (hands or toys on the throat or airway) tonight. You write it. Wanting is not consent for tonight. One notebook. Three columns: want, fear, out. Include who would know where you are, what sober and fed looks like, the tap, the aftercare, what never happens. Sleep on it. If it is still a yes in the morning, it goes on a calendar, not into the next hour. Closing the notebook is aftercare.", "Want / fear / out. Tea. Notebook closed. No scene. That is the whole prompt.", "A fuller page: aftercare, a trusted third who would know you are planning (not doing), what never happens. Still no scene. Still sleep.", "Read it in the morning. Calendar only after sleep — or the page scares you, and that is a complete answer. Do not write this on a train."), body("Want, fear, out — you write, you do not have to be brave tonight", "You write. You do not run it tonight. Closing the notebook is aftercare.", "Want / fear / out. Tea. Closed. No scene.", "A fuller page. Still no scene. Still sleep.", "Morning read. You may refuse the calendar. That is a complete answer.")),
	entry("roleplay", [
		"roleplay",
		"protocol",
		"verbal"
	], "curious", body("Late to work — you are the boss", "At home. You pretend they are late. You are the boss. A kitchen timer is the meeting. 3 to 8 minutes. Pick a tone first: kind, firm, or exacting — not all three. They may speak. When the timer rings, you are yourselves. Names. Water. Silly is allowed. Do not trap this at a real workplace.", "3 minutes at the table. One late line. One boss line. Timer. Names. Laugh if you need to.", "5 minutes. They stand. You sit. Then names and tea.", "8 minutes, a little more heat, still a timer, still names back. No touching until a word you picked in advance."), body("Late to work — they are the boss", "You are late. They are the boss. A timer. Then your name back. Silly is allowed.", "3 minutes. Then names.", "5 minutes. You stand. Then tea.", "8 minutes. You may stop the scene with ordinary words.")),
	entry("roleplay", [
		"roleplay",
		"service",
		"objectification"
	], "curious", body("You hired them for two hours", "At home. They are hired help for two hours. Write 3 jobs on a card: pour water, fold a throw, stand and wait. You thank or you correct once. Bathroom and water in an adult voice. When the timer ends, the card goes away and you say their real name. After: sofa, food, a check on whether it felt like play or like being used up. Repair the second.", "20 minutes. 1 job. Thank you. Name. Drink.", "1 hour. 3 jobs on a card. Then the card away and their name.", "2 hours. Still 3 jobs. If they use the adult voice, you answer the adult. Card in a drawer on time."), body("They hired you for two hours", "You do the jobs on the card. You get your name back. Adult voice always works. After: sofa, food.", "20 minutes. 1 job. Then your name.", "1 hour. 3 jobs. Then the card away.", "2 hours. You may use the adult voice. You should get the adult back.")),
	entry("roleplay", [
		"roleplay",
		"training",
		"protocol"
	], "curious", body("Homework check", "At home. They bring you one thing they did: a task ticked, a journal line, a photo of a made bed. You sit. They stand or kneel. You look. You say one true good thing. You may ask one question. Then tea. Pass or fail only with affection. End on what passed.", "Stand, one item, one kind sentence, tea. That is the whole scene.", "Kneel if they want. Two items. One question. Then tea as people.", "A fuller check of the week. Still end on what passed. Still tea. Do not invent a new standard in the middle."), body("Homework check — you bring the work", "You bring one thing. You hear what passed. You get tea.", "One item. One kind sentence. Tea.", "Two items. One question. Then tea as yourself.", "The week. You still get what passed, not a list of sins, unless you asked.")),
	entry("roleplay", [
		"pet-play",
		"roleplay",
		"ownership"
	], "curious", body("A pet coming home from a walk", "At home. They come in. They sit on a cushion. You take off a collar or a necklace. You give water. You say a pet name if they asked for one. 10 minutes. Then their real name and the sofa. No outdoor leads. No cages. If they laugh from discomfort, the pet is over and the person is held.", "5 minutes. Cushion. Water. Real name. Snack.", "10 minutes. Jewellery on, then off with their name. Three allowed asks.", "20 minutes in the house only. Pet names inside. Legal name if anyone else can hear."), body("You come home as a pet", "Cushion. Water. A name that comes back. After: sofa, your name.", "5 minutes. Then your name and a snack.", "10 minutes. Jewellery off with your name. Three asks.", "20 minutes. You may use the adult voice.")),
	entry("roleplay", [
		"roleplay",
		"power-exchange",
		"protocol"
	], "curious", body("Inspection at the door", "At home, or at the door after a short outing. They stand. You look: clothes, posture, eyes. You say one true thing you see. You may adjust a collar, a necklace, or a stray hair. 2 minutes. Then their name and the rest of the evening. Do not inspect genitals at a real door. Do not do this if a neighbour can see.", "2 minutes in the hallway, door closed. One true thing. Name. Drink.", "After a real short outing. Stand. Look. One true thing. Then tea.", "Each homecoming this week if you are both in. Skip if someone else is there. Skipping is care."), body("Inspection at the door — you stand", "You stand. They look. You hear one true thing. You get your name back. Not at a door a neighbour can see.", "2 minutes, door closed. Then your name.", "After a short outing. Then tea.", "Each homecoming this week if you are both in. You may skip if someone else is there.")),
	entry("roleplay", [
		"roleplay",
		"verbal",
		"service"
	], "curious", body("Waiter and diner at your own table", "At home. They serve a simple thing you already have: water, toast, tea. You stay in the diner seat. They stay in the waiter role until a timer rings, 10 minutes. Thank them in role, then use their real name. Silly is allowed. After: you both eat as yourselves.", "10 minutes. Water poured. Thank you. Names. Eat.", "20 minutes. A small plate. Then names and the rest of the meal as people.", "A whole simple meal. Still a timer for the role. Names back before dessert. Do not add humiliation unless that is on a written list."), body("Waiter at your own table — you serve", "You serve. They sit. You get your name back. Then you both eat as yourselves.", "10 minutes. Water. Then your name.", "20 minutes. A small plate. Then names.", "A whole simple meal. You may ask for your name back before dessert.")),
	entry("task", ["service", "exhibitionism"], "curious", body("A photo of the bed made by a time you set", "They make the bed. They send a photo of the bed, not of their body, by a time you set. You reply the same day with one true good sentence. Do not ask for a second photo because the first was easy. Do not critique the angle. Delete if they ask later, including at 2 a.m.", "One photo by 10am. One true sentence back.", "Three mornings this week. Answer each one the same day.", "Every morning this week. Sunday you decide if it lives. Praise the boring. That is the kink."), body("A photo of the bed you made, by a time they set", "A photo of the bed, not of your body. You get one true sentence back. You may ask for it to be deleted.", "One photo by 10am.", "Three mornings. You get an answer each day.", "Every morning this week. You may ask to stop on Sunday.")),
	entry("task", [
		"protocol",
		"training",
		"service"
	], "curious", body("Sixty seconds of kneeling before dinner", "Before dinner, they kneel on a cushion for 60 seconds. You set a timer. You may put a hand on their shoulder. You say their name. They stand. You eat. Write it in Tasks. If work or body makes it impossible, they tell you, and you thank the telling. Do not add a second ritual mid-week.", "Practise once, not at dinner. 60 seconds. Name. Stand. Log it.", "Once a day, three days this week, before a meal you already eat together.", "Each dinner you share this week. Sunday: keep, change, or stop. Stopping is a skill."), body("Sixty seconds of kneeling before dinner — you hold it", "Cushion. 60 seconds. Your name. Stand. Eat. A miss you report is not a fail.", "Practise once. Log it.", "Three meals this week.", "Each shared dinner. You may ask to stop on Sunday.")),
	entry("task", [
		"orgasm-control",
		"denial",
		"chastity",
		"protocol"
	], "practiced", body("Permission to come, written in Journal", "For this week, they write in Journal when they want to come, whether they asked, what you said, and how they felt after. You answer the same day. No maybe overnight. This is not a week of automatic no. Put one planned yes on the calendar so the week is not only waiting. Sunday you read it like weather, not like evidence.", "One note: time, ask, answer, after. If no, add one kind thing they may have instead.", "Three days of notes. One planned yes. Ordinary language only.", "The whole week. Sunday read as people first. If the waiting was lonely, shorten the next week."), body("Permission to come — you write the ask in Journal", "Asking is the task. You get an answer the same day. The log is weather, not evidence.", "One note. If no, you get one kind thing instead.", "Three days. A planned yes on the calendar.", "The week. Say on Sunday if the waiting was hot or just lonely.")),
	entry("task", [
		"ownership",
		"protocol",
		"exhibitionism"
	], "curious", body("Wear the item you chose, at home, until a time", "You choose one item they already own: a collar, a necklace, a bracelet, or a pair of underwear. They wear it at home until a time you name. You take it off with their real name. A collar is not a contract. They may take it off if family walks in. That is care.", "20 minutes. Sit. On. Off with their name. Water.", "The evening at home. Off before sleep. Check if they go quiet when it goes on — like, freeze, or want. Those are different.", "A day at home. On in the morning. Off at a time you named. Two items if you can: a day piece and a play piece, two rules."), body("Wear the item they chose, at home, until a time", "One item you already own. Off with your real name. You may take it off if family walks in.", "20 minutes. Off with your name.", "The evening. Off before sleep. You may ask what it means again.", "A day at home. You may take it off at the door. That is care, not a fail.")),
	entry("task", [
		"protocol",
		"service",
		"training"
	], "curious", body("One check-in at a named time", "Pick a time this week. They send a short message at that time: here, green or yellow, and one true line about the day. You reply the same day. Do not turn a late check-in into a punishment on the spot. Write it in Tasks. After the week: keep, move the time, or stop.", "One check-in. One true reply.", "Three days, same time. Reply each day.", "Each day this week. Sunday decide if the time was kind. A miss they report is not a fail."), body("One check-in at a named time you keep", "A short message: here, green or yellow, one true line. You get a reply. A miss you report is not a fail.", "One check-in. You get a reply.", "Three days. Same time.", "Each day this week. You may ask to move the time.")),
	entry("task", [
		"impact-play",
		"spanking",
		"sadomasochism"
	], "practiced", body("Twenty spanks on a calendar slot", "Put a 20-minute window on the calendar this week. Hand or a paddle you already know. Clothes on first. Count 20. They may lower the number on the day. They may not raise it because the afternoon was bad. Warm up, count, check, hand to close. Log it in Training, not Punishments, unless punishment is the flavour you named. A cancelled homework with honesty still counts.", "Calendar the window. Run 20 with clothes on. Hand to close. Stop if the day turned.", "Ask about tomorrow's clothes before you start. Two sets of 10 only if both still want it.", "A slightly fuller count, still scheduled, still cancellable. Do not do this as a surprise. Homework, not ambush."), body("Twenty spanks you help put on the calendar", "You may lower the number on the day. You get a hand at the end. Cancelling with honesty still counts.", "Clothes on. 20. A hand to close.", "Say if you sit at work tomorrow. Two sets only if you still mean it.", "A fuller count, still scheduled. You may cancel without it becoming a story about you.")),
	entry("game", [
		"protocol",
		"training",
		"verbal"
	], "curious", body("Yes, No, Ask — 10 minutes", "A kitchen timer. For 10 minutes they may only say yes, no, or ask. Ask means they need a bathroom, water, a stop, or a repeat. You ask simple questions they can answer with those words. This trains a Dominant to ask clearly, and a submissive to stay in a small language without going mute. If they use a full sentence because they need to, that is a win, not a fail. After: free speech, their name, water.", "5 minutes. Easy questions. Then free speech and names.", "10 minutes. You thank every ask. Then tea as people.", "15 minutes. If they freeze, you stop the game and hold the person. Freezing is data."), body("Yes, No, Ask — you hold the small language", "You may say yes, no, or ask. Ask always works. A full sentence because you need it is a win. After: free speech, your name, water.", "5 minutes. Then your words back.", "10 minutes. Ask is always allowed.", "15 minutes. You may break into full sentences. That is care.")),
	entry("game", [
		"training",
		"protocol",
		"power-exchange"
	], "curious", body("Repeat the instruction, then do it", "You say one short instruction. They say it back in their own words. Then they do it. If the repeat is wrong, you say it again, once, more clearly. This trains you to be clear, and them to listen without guessing. Three rounds. After: thank you, names, a drink. Do not add a trick instruction.", "3 easy rounds: sit, stand, drink water. Thank you.", "5 rounds. One of them may use their body (kneel, hands on thighs). Then names.", "8 rounds. If they miss, you own the miss as the speaker first. Then try one more, or stop."), body("Repeat the instruction, then do it — you are the ears", "You hear it. You say it back. You do it. Guessing is not the game. After: thank you, your name, a drink.", "3 easy rounds. Then thank you.", "5 rounds. You may ask for a repeat.", "8 rounds. A miss can be their wording, not your failure.")),
	entry("game", ["protocol", "power-exchange"], "curious", body("Red, yellow, green — a practice drill", "No scene. You are practising the words. You name a fake next step (a kiss, a smack, a toy). They say green (yes), yellow (slower / ask more), or red (stop). You obey the colour, even though nothing was going to happen. Do this 5 times. After: praise the reds. A red in practice is the whole point. Then tea.", "5 fake steps. Praise every colour, especially red. Tea.", "10 fake steps, mixed easy and spicy. Still no real scene. Still praise the reds.", "Do the drill, then run one real tiny green step you already planned — or stop on a yellow and call that a complete night."), body("Red, yellow, green — you practise the words", "Fake steps. You say the colour. They obey it. A red is a win. After: tea.", "5 fake steps. Your red is praised.", "10 fake steps. Still no real scene.", "The drill, then one tiny real green — or a yellow that ends the night. Both count.")),
	entry("game", [
		"protocol",
		"training",
		"pet-play"
	], "curious", body("Posture for 30 seconds, then talk", "They take a posture they already know: kneeling on a cushion, standing with hands behind, or sitting with a straight back. 30 seconds. You watch. Then they come out of it, and you both say one true thing: what the posture did in the head. This trains staying, and trains you to notice, not only to command. After: shake the body out. Water.", "Once. 30 seconds. One true sentence each. Water.", "Three times this week. Same posture. Compare the three sentences.", "Once a day, three days. If the body cannot kneel, pick a chair posture. Changing the posture is skill, not a fail."), body("Posture for 30 seconds, then you talk", "A posture you already know. 30 seconds. Then one true thing about what it did in your head. After: shake out, water.", "Once. Then one true sentence.", "Three times this week. Compare the sentences.", "Three days. You may pick a chair if kneeling hurts.")),
	entry("game", [
		"protocol",
		"training",
		"praise"
	], "curious", body("Three small wins on a card", "Write 3 tiny role wins on a card, for the week. Dominant examples: one clear instruction, one true praise, one on-time close. Submissive examples: one kneel, one honest yellow, one task ticked. Tick them when they happen. At the end of the week, read the ticks out loud and say thank you. Misses stay on the card as weather, not as a trial.", "Write 3 wins. Tick 1 this week. Read it out. Thank you.", "Tick all 3. Sunday read. Thank you both.", "Keep the same 3 next week if they helped, or write 3 new ones. Retiring a win is also a win."), body("Three small wins on a card you help write", "Tiny, possible, ticked. Sunday you hear thank you. A miss is weather.", "Write 3. Tick 1. Hear thank you.", "Tick all 3. Sunday read.", "Keep or change them next week. You may retire one.")),
	entry("game", [
		"power-exchange",
		"brat-dynamic",
		"protocol"
	], "curious", body("Who is in charge for 10 minutes", "A timer. For 10 minutes, one of you is clearly in charge. The other practises following, including a brat who still has to follow the clock. When it rings, you swap, or you stop. Say the swap out loud. This trains both seats without trapping anyone in one. After: names, a drink, one sentence about which seat was harder.", "10 minutes. One seat. Then names and a drink.", "10 minutes each. A spoken swap. Then both sentences.", "20 minutes in one seat, only if you both still want it. A brat testing the clock is still under the clock — or the game ends, and that is allowed."), body("Who is in charge for 10 minutes — you practise both", "A timer. Follow, or lead, then swap. After: your name, a drink, which seat was harder.", "10 minutes. Then your name.", "10 minutes each. A spoken swap.", "20 minutes in one seat only if you still want it. You may end the game.")),
	entry("training", [
		"training",
		"protocol",
		"power-exchange"
	], "curious", body("Kneeling clock — add it to Training", "A short exercise to train staying. They kneel on a cushion. You set a timer they can see. When it rings, you say their name and they stand. Log it in Training so you can run it again this week. If the body cannot kneel, use a chair with a straight back. Changing the posture is skill, not a fail. After: shake the legs out, water.", "30 seconds. Name. Stand. Log it in Training.", "60 seconds, once a day, three days this week. Same cushion. Log each one.", "2 minutes, three days. If they need to come up early, they say so. Thank the telling. Log the real time."), body("Kneeling clock — you hold it, they log it", "Cushion. Timer you can see. Your name, then you stand. A chair is allowed. After: shake out, water.", "30 seconds. Then your name. They log it.", "60 seconds, three days. Same cushion.", "2 minutes, three days. You may come up early. That still gets logged.")),
	entry("training", [
		"training",
		"protocol",
		"service"
	], "curious", body("Position names — present, kneel, stand", "Teach 3 names: present (hands on thighs, eyes down or on you — they pick), kneel (cushion), stand. You say the name once. They take the shape. You wait 10 seconds. Next name. Three rounds. This trains listening, not guessing. Log it in Training. After: their name, a drink, shake the body out.", "One round of the 3 names. Slow. Thank you. Log it.", "Three rounds. Same 3 names. If they miss, you say the name again, once, more clearly.", "Five rounds, or a 5-minute drill. No trick names. End on stand, then tea."), body("Position names — you take the shape they named", "Present, kneel, stand. You hear the name. You take the shape. Guessing is not the drill. After: your name, a drink.", "One round of 3. Then thank you.", "Three rounds. You may ask for the name again.", "Five rounds. End on stand. Tea.")),
	entry("training", [
		"training",
		"protocol",
		"bondage"
	], "curious", body("Hands still on their thighs", "No rope. They sit or kneel. Hands on their own thighs until the timer ends. If they move, you put the hand back once, kindly, or you stop. Stopping is allowed. Log the time they actually held in Training. After: they may move, their name, water.", "2 minutes on the sofa. Log it.", "5 minutes, three days this week. Log each hold.", "10 minutes, twice this week. Ordinary words if they need to move. Log the real time."), body("Hands still on your thighs", "No rope. Hands on your thighs until the timer. You may say you need to move. After: your name, water.", "2 minutes. Then you may move.", "5 minutes, three days.", "10 minutes, twice. Ordinary words if you need to move.")),
	entry("training", [
		"training",
		"orgasm-control",
		"denial"
	], "practiced", body("Edge count — stop at 8", "Your hand or a toy they already know. They say a number from 1 to 10. 8 means you stop. Do 3 stops. Log it in Training: how many stops, whether they came after. This trains them to speak, and you to listen. After: water, a towel, a clear yes or no about coming.", "3 stops. Clothes on. Then the planned yes or no. Log it.", "5 stops. Hands still if they can. They may still speak. Log it.", "A longer hold at 7 after the stops, then the planned yes or no. Log the real numbers, not the heroic ones."), body("Edge count — you say 8, they stop", "You say the number. 8 means they stop. After: water, towel, a clear yes or no.", "3 stops. Then the planned yes or no.", "5 stops. You may still speak.", "A longer hold at 7. Log the real numbers.")),
	entry("training", [
		"training",
		"service",
		"protocol"
	], "curious", body("Fetch and present", "You name one object in the room: a glass of water, a cushion, a toy they already use. They fetch it. They present it on open hands. You take it. You say thank you and their name. Three fetches. Log it in Training. After: they sit as a person. Do not add a fourth because the third was pretty.", "1 fetch. Water. Thank you. Name. Log it.", "3 fetches. Same rule. Then they sit.", "5 fetches, still in the house. If they use the adult voice, you answer the adult. Then sit."), body("Fetch and present — you bring it", "You hear the object. You bring it on open hands. You get thank you and your name. After: you sit as a person.", "1 fetch. Water. Then you sit.", "3 fetches. Then you sit.", "5 fetches. Adult voice always works.")),
	entry("training", [
		"training",
		"protocol",
		"verbal"
	], "curious", body("Honorific for one meal", "For one meal at home, they use a name they already said yes to: Sir, Ma'am, or another they picked. You use their name back with care. When the plates are down, legal names. Log it in Training: which meal, which name, how it felt. Do not use a name they did not pick. After: tea as people.", "5 minutes of the name at the table. Then legal names. Log it.", "One full meal. Legal names if anyone else can hear. Log it.", "Three meals this week. Sunday ask if the name still fits. Retiring it is also training."), body("Honorific for one meal — you keep the name", "A name you already said yes to, for one meal. You get your legal name back. After: tea as yourself.", "5 minutes. Then your legal name.", "One full meal. You may ask for your legal name.", "Three meals. Sunday you may retire the name.")),
	entry("reward", [
		"orgasm-control",
		"praise",
		"sensation-play"
	], "curious", body("They pick the orgasm — add it to Rewards", "A reward you can add in Rewards. When they cash it, they pick: your hand, their hand, a toy they already like, or being held with no orgasm. You run the one they picked. Do not swap it for a harder thing because you are in the mood. After: water, a towel, their name. Put it in Rewards with a point cost you both like.", "Add it. When they cash it: 10 unhurried minutes of what they picked. Then their name.", "Add it. When they cash it: they also pick the room and the music. You still run only what they named.", "Add it. When they cash it: a longer night of what they picked, still with a clock, still with a stop. Morning tea is part of the reward."), body("You pick the orgasm — they add it to Rewards", "When you cash it, you pick. They run the one you named. After: water, towel, your name.", "10 unhurried minutes of what you picked.", "You also pick the room and the music.", "A longer night, still with a clock and a stop. Morning tea is part of it.")),
	entry("reward", [
		"service",
		"praise",
		"protocol"
	], "curious", body("A bath they do not have to run", "Add this to Rewards. When they cash it, you run the water, check the heat with your hand, put a towel ready, and stay or step out — they pick. You do not turn it into a scene unless they ask. After: a robe, a drink, their name. The reward is being looked after, not performing.", "Add it. Cash: 15 minutes, you handle the water and the towel. Then their name.", "Add it. Cash: you wash their hair if they want. Then a robe and a drink.", "Add it. Cash: bath, hair, a quiet sit after. No extra tasks hiding in the aftercare."), body("A bath you do not have to run", "When you cash it, they handle the water. You do not have to perform. After: a robe, a drink, your name.", "15 minutes. Water and towel. Then your name.", "Hair washed if you want. Then a robe.", "Bath, hair, a quiet sit. You may ask that this stay aftercare, not a scene.")),
	entry("reward", [
		"roleplay",
		"power-exchange",
		"ownership"
	], "curious", body("A scene from a list of 3 they wrote", "Add this to Rewards. They write 3 scenes they actually want, while calm. When they cash it, they pick one. You run that one. You do not pick a fourth. Easy, hard, and extreme are how long and how full — not a bait-and-switch. After: their name, water, a check on whether it was the scene they meant.", "Add it. Cash: 15 minutes of the one they pick. Then names.", "Add it. Cash: 30 minutes of the one they pick. Then aftercare they named on the card.", "Add it. Cash: the fuller night of the one they pick, still with a clock and a stop. Morning note already drafted."), body("A scene from a list of 3 you wrote", "You write 3. You pick 1 when you cash it. They run that one. After: your name, water.", "15 minutes of the one you pick.", "30 minutes, plus the aftercare you named.", "The fuller night, still with a clock. You may still stop it.")),
	entry("reward", [
		"protocol",
		"power-exchange",
		"ownership"
	], "curious", body("A free evening — no protocol", "Add this to Rewards. When they cash it, names go back to ordinary, kneeling is off, honorifics are off, unless they ask for one small thing. You do not sulk. You do not sneak a rule back in. After: in the morning you both say whether you missed the structure or enjoyed the air. Both answers are allowed.", "Add it. Cash: 1 hour as people. Then you may put one small rule back, if they want it.", "Add it. Cash: a whole evening. Phones, food, a show. No extra ritual.", "Add it. Cash: a full day off protocol. A collar, if they wear one, comes off with their real name. On again only if they ask."), body("A free evening — you cash the off-switch", "When you cash it, you are a person. Rules stay off unless you ask. After: say in the morning if you missed them.", "1 hour as yourself.", "A whole evening. No extra ritual.", "A full day. You decide if anything goes back on.")),
	entry("reward", [
		"sensation-play",
		"orgasm-control",
		"praise"
	], "curious", body("The toy they have been asking for", "Add this to Rewards. When they cash it, you use the toy they have been wanting, the way they like, for a time you both named while calm. You do not swap it for a 'better' toy. After: wash, water, their name. Put the toy's name on the Rewards card so nobody 'forgets'.", "Add it. Cash: 10 minutes of that toy, their pace. Then wash and their name.", "Add it. Cash: 20 minutes. They may ask you to slow down. You slow down.", "Add it. Cash: a longer session, still the named toy, still a clock. A second toy only if they ask."), body("The toy you have been asking for", "When you cash it, you get that toy, that way, that time. After: wash, water, your name.", "10 minutes, your pace.", "20 minutes. You may ask them to slow down.", "Longer, still the named toy. A second toy only if you ask.")),
	entry("reward", ["service", "praise"], "curious", body("You serve them breakfast", "Add this to Rewards. When they cash it, you make a simple breakfast they already eat. They stay in bed or on the sofa. You bring it. You sit. This is not a humiliation meal unless that is on a written list. After: plates in the sink can wait. Their name. A normal morning.", "Add it. Cash: tea or coffee in bed. Then their name.", "Add it. Cash: a simple plate plus a drink. You sit with them.", "Add it. Cash: breakfast, then 20 minutes of doing the small chores so they do not have to. Still a thank you, not a speech."), body("They serve you breakfast", "When you cash it, they bring a simple breakfast. You do not have to perform. After: your name. A normal morning.", "Tea or coffee in bed. Then your name.", "A simple plate plus a drink. They sit with you.", "Breakfast, then 20 minutes where they take the small chores. You may still get up if you want to.")),
	entry("punishment", [
		"protocol",
		"training",
		"power-exchange"
	], "curious", body("Corner time — add it to Punishments", "A punishment you can add in Punishments. Not a surprise. They stand or sit facing a wall, in the house, for a time you both named while calm. You stay in the room. They can speak. A red ends it. After: their name, a hand on their back, water. Put the minutes on the card. Do not add extra minutes because you are still annoyed.", "Add it. Run: 2 minutes. Then name, hand, water.", "Add it. Run: 5 minutes. You stay. Then name and water.", "Add it. Run: 10 minutes, only if they have done 5 and the card still says 10. Same aftercare. No extra task stacked on after."), body("Corner time — they add it, you take it", "A time you agreed while calm. You can speak. A red ends it. After: your name, a hand, water.", "2 minutes. Then your name.", "5 minutes. They stay in the room.", "10 minutes only if you have done 5. You may still red.")),
	entry("punishment", [
		"protocol",
		"training",
		"verbal"
	], "curious", body("Written lines — add it to Punishments", "Add this to Punishments. They write a short true line, by hand, a set number of times. The line is about the miss, not about their worth. Example: I will say yellow when I need to. Not: I am bad. You read them. You say thank you. After: the page goes in a drawer, or you tear it up together if they want it gone. Do not hang it on a fridge a guest can see.", "Add it. Run: 5 lines. You read. Thank you. Drawer or tear.", "Add it. Run: 10 lines. Same rule. Then tea as people.", "Add it. Run: 20 lines, only if 10 still felt like repair, not like shame. If it shames, you stop and hold the person."), body("Written lines — you write the true one", "A short true line about the miss, not about your worth. After: they read, they thank you, drawer or tear.", "5 lines. Then tea.", "10 lines. Then tea as yourself.", "20 only if 10 still felt like repair. You may stop if it shames.")),
	entry("punishment", [
		"spanking",
		"impact-play",
		"sadomasochism"
	], "practiced", body("Counted hand spanking — add it to Punishments", "Add this to Punishments with a number you both wrote while calm. Clothes on first. Hand only unless the card names a paddle you already know. They may lower the number on the day. They may not raise it because the afternoon was bad. Count out loud. After: sit them up, water, a hand on their back, their name. This is homework, not a blow-up.", "Add it. Run: 10, clothes on. Sit up. Water. Name.", "Add it. Run: the number on the card, underwear if they asked. Hand to close.", "Add it. Run: still the card number, bare only if the card says so. Marks that show at work need a separate yes. Landing is longer than the spanking."), body("Counted hand spanking — you take the number on the card", "You may lower it on the day. You get a hand at the end. After: sit up, water, your name.", "10, clothes on. Then sit up.", "The card number. Underwear if you asked.", "Bare only if the card says so. You still get the long landing.")),
	entry("punishment", [
		"orgasm-control",
		"denial",
		"chastity"
	], "practiced", body("No toy tonight — add it to Punishments", "Add this to Punishments. When it is cashed, toys stay in the drawer for the evening. Hands, kissing, and being held are still allowed unless the card says otherwise. You do not add a sneer. After: a kind close so they are not left as a problem. Put one planned yes on the calendar so this does not become a week of only no.", "Add it. Run: one evening. Hands and holding still yes. Kind close.", "Add it. Run: two evenings this week, not stacked on a bad day. A planned yes still on the week.", "Add it. Run: 24 hours. Still a planned yes after. If the wait turns lonely, shorten it."), body("No toy tonight — you take the drawer rule", "Toys away. Hands and holding still allowed unless the card says no. You still get a kind close.", "One evening. Then a kind close.", "Two evenings, not on a piled-up day. A planned yes still exists.", "24 hours. Say if the wait is lonely. They should shorten it.")),
	entry("punishment", [
		"protocol",
		"training",
		"service"
	], "curious", body("Extra kneel before the next meal", "Add this to Punishments. One extra kneel, on a cushion, before the next meal you already eat together. Timer they can see. You say their name. They stand. You eat. Do not stack a second extra. After: ordinary meal. Log it so it does not happen twice for the same miss.", "Add it. Run: 30 seconds. Name. Stand. Eat.", "Add it. Run: 60 seconds. Then the meal as people.", "Add it. Run: 2 minutes, only if 60 seconds still felt like repair. Then eat. No speech about the miss at the table."), body("Extra kneel before the next meal — you hold it", "One extra. Cushion. Timer. Your name. Stand. Eat. It does not happen twice for the same miss.", "30 seconds. Then eat.", "60 seconds. Then the meal as yourself.", "2 minutes only if 60 still felt like repair. No speech about the miss at the table.")),
	entry("punishment", [
		"protocol",
		"ownership",
		"power-exchange"
	], "curious", body("A 24-hour pause on one named privilege", "Add this to Punishments. Name one small privilege while calm: choosing the show, a pet name, a toy, a late bedtime. When it is cashed, that one thing pauses for 24 hours. Everything else stays. You do not add a second pause because you are still mad. After: the privilege comes back out loud, with their name. Put the privilege's name on the card.", "Add it. Run: 24 hours off one small thing. Then it comes back with their name.", "Add it. Run: the same, plus one check-in at the halfway point: still fair?", "Add it. Run: 48 hours only if they have done 24 and the card says 48. If it starts to feel like exile, you end it early and say so."), body("A 24-hour pause on one privilege you named", "One named thing. Everything else stays. It comes back out loud, with your name.", "24 hours. Then it comes back.", "24 hours, plus a halfway check: still fair?", "48 hours only if the card says so. You may ask to end it early.")),
	entry("kink", ["bondage", "rope"], "curious", body("Wrists wrapped, a bow they can undo", "A scarf or a soft rope they already know. Wrists in front. A bow they can undo with their teeth or a free finger. You stay in the room. Timer they can see. Scissors in reach. After: undo, rub wrists, water, say they could have left. This is the bondage on your profile, kept small.", "5 minutes. Bow they can undo. Then off. Rub wrists.", "15 minutes. Check halfway that fingers are warm and pink, not blue.", "30 minutes. Same bow. Still a timer. No gag and no ankles at the same time tonight."), body("Wrists wrapped, a bow you can undo", "You can undo it. You can leave. Staying is the scene. After: wrists rubbed, water.", "5 minutes. Then off.", "15 minutes. Say if fingers tingle.", "30 minutes. You may refuse a gag or ankles tonight.")),
	entry("kink", [
		"spanking",
		"impact-play",
		"sadomasochism"
	], "practiced", body("A counted spanking, clothes on first", "The spanking and impact on your profile, run as a small set. Clothes on first. Hand, or a paddle you already know. Number written while calm. Count out loud. They may lower it. After: sit up, water, a hand on their back, look at the skin. Do not add a second tool.", "Clothes on. 10, check, 10. Sit up. Water.", "Underwear if they asked. Same written number. Hand to close.", "Bare if they asked. Marks that show at work need a separate yes. Landing is 15 minutes."), body("A counted spanking you take, clothes on first", "You may lower the number. You get a hand at the end. After: sit up, water.", "Clothes on. 10, check, 10.", "Underwear if you asked. Same number.", "Bare if you asked. Say if you sit at work tomorrow.")),
	entry("kink", [
		"protocol",
		"power-exchange",
		"ownership"
	], "curious", body("One house rule on a card", "The protocol and power exchange on your profile, as one rule. Written. Small enough for a real life. Examples: phone on the table at dinner, water before coffee, ask before you come to bed. Run it for one evening. Thank more than you catch. Then take the card down. Ask if it lives.", "Write the rule. Run it for 1 hour. Release on time. Tea.", "One evening. Catch once, kindly, or not at all. Then the card away.", "Keep it for the week if you both liked it. Ending a rule is also protocol."), body("One house rule on a card you can keep", "One rule you can live inside. A miss you report is not a fail. The card comes down.", "1 hour. Then tea as yourself.", "One evening. Then the card away.", "A week if you want it. You may also retire it.")),
	entry("kink", ["service"], "curious", body("They serve one small thing, then they sit", "The service on your profile, kept to one act: pour water, fold a throw, bring a towel. They do it. You thank them. They sit as a person. Do not stack a second job because the first was easy. After: drink together.", "One job. Thank you. Sit. Drink.", "Three small jobs on a card. Then the card away and they sit.", "A 30-minute window of small jobs you already need done. Then they sit, and you do not add more."), body("You serve one small thing, then you sit", "One act. You get thank you. You sit as a person. After: drink together.", "One job. Then you sit.", "Three small jobs. Then you sit.", "30 minutes of jobs you already need. Then you sit. You may use the adult voice.")),
	entry("kink", ["pet-play", "ownership"], "curious", body("A cushion, a bowl of water, a name that comes back", "The pet play on your profile. They sit on a cushion. You offer water. A pet name only if they asked for one. 10 minutes in the house. Then their real name and the sofa. No outdoor leads. No cages. If they laugh from discomfort, the pet is over and the person is held.", "5 minutes. Cushion. Water. Real name. Snack.", "10 minutes. Jewellery on, then off with their name.", "20 minutes in the house only. Legal name if anyone else can hear."), body("You sit on a cushion. Your name comes back", "Water. A pet name only if you asked. Then your real name and the sofa.", "5 minutes. Then your name and a snack.", "10 minutes. Then your name.", "20 minutes. You may use the adult voice.")),
	entry("kink", ["praise", "verbal"], "curious", body("Three true praises, spoken", "The praise and verbal play on your profile. Say 3 true sentences about how they were today. Be specific. Do not turn praise into a new task. If it starts to sound like shame, make it smaller, or stop. After: they only have to hear it. The words can live in a message.", "3 lines, one night. Stop means stop.", "3 nights this week. No extra tasks attached.", "Every night this week. Sunday keep the lines that landed."), body("Three true praises you have to take", "You hear 3 true lines. You may say stop. The message can stay.", "One night. Thank you, or stop.", "Three nights.", "Every night. Say on Sunday which line helped.")),
	entry("kink", [
		"humiliation",
		"degradation",
		"verbal"
	], "seasoned", body("Playful mean words from a page, then kindness", "The humiliation and degradation on your profile, kept on a page. While clothed, write 5 lines they want. Only those. Read once. Stop. Then the opposite kind sentences, as true. If anyone laughs from discomfort, it is over. Do not do this in public. Morning note already drafted.", "The 5 lines once. Then the 5 kind opposites.", "One line, repeated, then its opposite. Morning note drafted.", "The full list, still once, still with repair the same night. No spanking stacked on."), body("Playful mean words from a page you helped write", "Only the page. You can stop it. After: the opposite sentences.", "The 5 lines once. Then kindness.", "One line, then its opposite. You may stop after the first.", "The full list, still once. You may keep it on paper and not run it.")),
	entry("kink", [
		"orgasm-control",
		"denial",
		"chastity"
	], "practiced", body("They ask before they come", "The orgasm control, denial, or chastity on your profile, as a week rule. They ask before they come. You answer the same day. Yes, not yet, or tomorrow. If the answer is no, you still owe warmth. Put one planned yes on the calendar so the week is not only waiting. Sunday read it like weather, not like evidence.", "One evening. They ask once. You answer. If no, a kind text and a show you know.", "Three days. One planned yes. Ordinary language only.", "The whole week. One planned yes. Sunday decide if it lives."), body("You ask before you come", "Asking is the kink. You get an answer the same day. Warmth is still owed if the answer is no.", "One evening. Ask once.", "Three days. A planned yes on the calendar.", "The week. Say on Sunday if the waiting was hot or just lonely.")),
	entry("kink", ["exhibitionism", "voyeurism"], "curious", body("They show you, in the house, on purpose", "The exhibitionism or voyeurism on your profile, with no strangers. They take off as much as they want. You look. You do not touch until they say so, or you do not touch at all — they pick. 10 minutes. No photos unless that is a second yes. After: clothes, their name, a drink.", "Clothes half off. You look for 2 minutes. Then their name.", "They pick what comes off. You look. Touch only if they say. Then clothes and a drink.", "A longer look, still in the house. A mirror if they want to see themselves being seen. Still no photos unless they asked."), body("You show them, in the house, on purpose", "You pick what comes off. They look. Touch only if you say. After: clothes, your name, a drink.", "Clothes half off. 2 minutes. Then your name.", "You pick. They look. You say if they may touch.", "A longer look. A mirror if you want it. You may refuse photos.")),
	entry("kink", ["roleplay"], "curious", body("Ten minutes in a role you already named", "The roleplay on your profile. Pick a role you have already talked about. A timer. 10 minutes. When it rings, legal names. Silly is allowed. After: water, a sentence about whether the role still fits.", "5 minutes. One line each. Timer. Names.", "10 minutes. Then names and tea.", "20 minutes, still a timer, still names back. No extra kink stacked on unless it was in the plan."), body("Ten minutes in a role you already named — you enter it", "A role you have already talked about. A timer. Then your legal name.", "5 minutes. Then your name.", "10 minutes. Then tea.", "20 minutes. You may stop with ordinary words.")),
	entry("kink", ["primal"], "practiced", body("A short chase in the house", "The primal play on your profile. At home. You count down from 5. They run to another room. You follow. You catch them with arms, not with pain, unless impact is also on the card. 3 minutes. Then hold, breath, their name. No stairs. No glass. No outdoor chase.", "One countdown. One catch. Hold. Name. Water.", "Three short chases. Same house rules. Then a long hold.", "A 10-minute hunt, still in the house, still a stop word. After: blanket, water, names. If anyone is actually scared, it is over."), body("A short chase in the house — you run, you get caught", "Home only. Arms, not pain, unless you asked. After: hold, breath, your name.", "One countdown. One catch. Hold.", "Three short chases. Then a long hold.", "A 10-minute hunt. You may stop with ordinary words. Scared means over.")),
	entry("kink", ["sensation-play", "temperature-play"], "curious", body("Warm hands, then a cool spoon", "The sensation or temperature play on your profile. Warm oil or warm hands, then the back of a metal spoon run under cold water. On skin they offered. Ask after each pass: more, less, or somewhere else. No boiling. No spoon on nipples or genitals unless they asked while calm. After: towel, blanket, a warm drink.", "Clothes on. Shoulders. 5 minutes. Stop at the first enough.", "One area at a time, clothes as they like. End with a towel.", "A longer map they named in advance. This can be the whole night. You do not have to have sex after."), body("Warm hands, then a cool spoon on you", "On skin you offered. Say more, less, or somewhere else. After: towel, blanket, a warm drink.", "Clothes on. Shoulders. 5 minutes.", "One area at a time. End with a towel.", "A longer map you named. You do not have to have sex after.")),
	entry("kink", ["sensory-deprivation"], "practiced", body("A blindfold they can take off", "The sensory deprivation on your profile. A sleep mask or a scarf they can pull down. You stay talking so they know where you are. Timer they agreed. After: light back, their name, water, sit. Do not add a gag the first time. Do not leave the room.", "2 minutes. They can pull it down. Then name and water.", "5 minutes. You keep talking. Then light, name, sit.", "10 minutes only if they have done 5. Still able to take it off. Still you in the room."), body("A blindfold you can take off", "You can pull it down. They stay. After: light, your name, water.", "2 minutes. Then your name.", "5 minutes. They keep talking.", "10 minutes only if you have done 5. You may take it off early.")),
	entry("kink", ["brat-dynamic"], "curious", body("One poke, then they take the answer", "The brat dynamic on your profile. They get one poke: a sass, a delay, a grin. You answer once, clearly — a look, a number, a hold. Then the poke is over and the evening continues. This trains a brat to poke on purpose, and a tamer to answer without a spiral. After: names, a drink, a laugh if there is one.", "One poke. One answer. Drink.", "Three pokes this week, not stacked in one hour. Each one gets one answer.", "A named brat window of 10 minutes, then they drop it on the timer. If they cannot drop it, you pause the dynamic and hold the person."), body("One poke, then you take the answer", "One poke on purpose. You take the one answer. Then the evening continues.", "One poke. One answer. Drink.", "Three pokes this week. Not stacked.", "A 10-minute window, then you drop it. You may ask to pause the dynamic.")),
	entry("kink", ["marking"], "practiced", body("A hickey they asked for, where they said", "The marking on your profile. A suck-mark on a place they named. Agree if it may show tomorrow. Do not break the skin. After: look together, ice or nothing. Photo only with a yes they still mean.", "One small mark. Sit and look. Ordinary evening.", "A place they can cover. Ask about tomorrow before you start.", "A place they want to see in the mirror. Still one mark. Do not add another because the first looked pretty."), body("A hickey you asked for, where you said", "You name the place. You name whether it may show. After: look, then ordinary evening or ice.", "One small mark. Look. Ordinary evening.", "A place you can cover. Say if you work tomorrow.", "A place you want to see. You may ask that one is enough.")),
	entry("kink", ["objectification"], "practiced", body("A furniture minute — they hold still, then they are a person", "The objectification on your profile, with a clock. They kneel or sit as a table or a footrest for a time you both named — no weight that hurts. You do not pile things that will fall. When the timer rings, you say their name first, then thank you. After: they sit as a person, water, a check on whether it felt hot or just unused. Repair the second.", "1 minute. Then their name, thank you, sit.", "5 minutes. You stay in the room. Then name and water.", "10 minutes, only if 5 still felt like play. If they go quiet in a way that is not heat, you end it and hold the person."), body("A furniture minute — you hold still, then you are a person", "A clock. Your name comes back first. After: sit as yourself, water.", "1 minute. Then your name.", "5 minutes. They stay. Then water.", "10 minutes only if 5 still felt like play. You may end it.")),
	entry("kink", ["cnc", "breath-play"], "established", body("Want, fear, out — write the edge, do not run it", "The CNC or breath play on your profile. You do not run it tonight. You write it. Wanting is not consent for tonight. Three columns: want, fear, out. Sleep on it. Closing the notebook is aftercare. If it is still a yes in the morning, it goes on a calendar, not into the next hour.", "Want / fear / out. Tea. Closed. No scene.", "A fuller page: aftercare, what never happens, who would know you are planning (not doing). Still no scene.", "Morning read. Calendar only after sleep — or the page scares you, and that is a complete answer."), body("Want, fear, out — you write the edge, you do not have to be brave tonight", "You write. You do not run it tonight. Closing the notebook is aftercare.", "Want / fear / out. Tea. Closed.", "A fuller page. Still no scene. Still sleep.", "Morning read. You may refuse the calendar."))
];
function seat(role) {
	if (role === "dominant") return "You are doing this alone. You still set the timer and the stop.";
	if (role === "submissive") return "You are doing this alone. Keep the rule you wrote when you were calm.";
	return "You are doing this alone. You hold both seats. Say out loud who is in charge before you start.";
}
var SOLO = {
	"communication:say-one-instruction-they-do-it-once": {
		titles: {
			dominant: "Say one instruction. Then you do it",
			submissive: "Write one instruction. Then you do it once",
			switch: "One instruction — you say it, you do it"
		},
		description: "Write one short instruction you can actually do in this room. Say it out loud once. Do it. Say thank you to yourself, and your name. After: water. Journal the instruction if you want it again.",
		easy: "One instruction. Sit down. Thank you. Name. Water.",
		hard: "One body instruction: kneel, or hands on thighs. Hold it. Stand when the timer says so.",
		extreme: "One instruction, then 2 minutes of holding it. Do not fill the quiet. Then your name, and you may move."
	},
	"communication:three-true-praises-before-they-sleep": {
		titles: {
			dominant: "Three true praises you write and then have to take",
			submissive: "Three true praises you wrote when kind, read at night",
			switch: "Three true lines before sleep. Stop if they turn to shame"
		},
		description: "Write 3 true sentences about how you were today. Be specific. Read them. Stop if they turn to shame. The page stays.",
		easy: "3 lines, one night. You may say stop.",
		hard: "3 nights this week. No extra tasks attached.",
		extreme: "Every night this week. Sunday keep the lines that landed."
	},
	"communication:dirty-talk-from-a-page-you-wrote": {
		titles: {
			dominant: "Dirty talk from a page, then the kind opposites",
			submissive: "Dirty talk from a page you wrote calm, then repair",
			switch: "A list, once, then kindness in the same notebook"
		},
		description: "While clothed, write 5 words you want to hear. Read them once. Stop. Write the opposite kind sentences. Do not make up new mean words in the heat. A kind note for the morning, written now.",
		easy: "Read the 5 lines. Write the 5 kind opposites.",
		hard: "One line, repeated. Then its opposite. Morning note drafted.",
		extreme: "The full list, still once, still with repair the same night. If the page scares you in the morning, that is a complete answer."
	},
	"communication:tease-them-with-words-while-you-edge-them": {
		titles: {
			dominant: "Tease yourself with words you wrote, while you edge",
			submissive: "Hear the tease you wrote, while you edge, then stop",
			switch: "A list, a hand, a stop at 8"
		},
		description: "Your hand or a toy you already know. Close to orgasm, then stop. Use playful mean words from a list you wrote while clothed. 8 on a 1-to-10 scale means you take your hand away. After: water, towel, a clear yes or no about coming later.",
		easy: "3 rounds: 2 minutes on, 1 off. One teasing line each stop. Then come, wait, or be held (blanket, tea).",
		hard: "Same rounds. Other hand still. You may still stop the words.",
		extreme: "A longer hold at 7. Keep the list. Then the planned yes or no. Do not add new mean words."
	},
	"communication:a-name-they-asked-for-used-for-10-minutes": {
		titles: {
			dominant: "A name you chose, used for 10 minutes, then your legal name",
			submissive: "A name you asked for, used for 10 minutes, then yours back",
			switch: "A name for 10 minutes. Then the one on your ID"
		},
		description: "Pick a name you already said yes to. Use it for 10 minutes at home — out loud, in Journal, or in a voice note. When the timer rings, go back to your legal name. After: water.",
		easy: "5 minutes. The name, then your legal name. Drink.",
		hard: "10 minutes while you sit or kneel. Then tea and your legal name.",
		extreme: "An evening at home. The name inside. Legal name if anyone else can hear."
	},
	"communication:you-tell-them-what-you-will-do-then-you-do-it": {
		titles: {
			dominant: "You tell yourself the next step. Then you do only that",
			submissive: "You hear the next step you wrote. Then you do only that",
			switch: "Name the step. Do the step. Name the next"
		},
		description: "Before you touch yourself, say the next step in plain words. Then do only that. You can say no to a step. After: say you are done. Your name. Water.",
		easy: "3 steps. Clothes stay on. Then done.",
		hard: "5 steps. Skip is allowed. Then your name.",
		extreme: "A longer map you named while clothed. Still one step at a time. Still no extra surprise."
	},
	"public:a-remote-toy-on-low-a-short-shop": {
		titles: {
			dominant: "A remote toy on low, a short walk you run",
			submissive: "A remote toy on low, a short walk under a rule you wrote",
			switch: "Wear it. Hold the remote. Keep it low. Come home"
		},
		description: "Wear a small vibrator under ordinary clothes. You hold the remote. A walk or a known shop, 40 minutes or less. Lowest setting. If you cannot walk easily, go home. Strangers are not in the scene. After: out, wash, water, sit.",
		easy: "A 10-minute walk around the block on low. Then home. Out. Water.",
		hard: "A short known shop, 20 minutes. Stop means off now. Do not raise it in the aisle.",
		extreme: "40 minutes max. Still low. If your face feels like panic, not heat, go home. Praise the abort."
	},
	"public:a-look-across-the-table-that-means-i-have-you": {
		titles: {
			dominant: "A look in a window that means I have you",
			submissive: "A look you give yourself in a window, then a text home",
			switch: "One look, in public, that only you know"
		},
		description: "Agree one look with yourself. Use it once in a cafe window, a shop glass, or a park. Nobody else should read it. After: a note that says the look landed, or that it felt silly. Silly is allowed.",
		easy: "Practise at home for 1 minute. Then once at a table you already sit at.",
		hard: "Once on a real outing. Then tea as a person.",
		extreme: "Twice this week, same look. Missing it is not a fail."
	},
	"public:a-secret-item-under-clothes-on-a-short-walk": {
		titles: {
			dominant: "A secret item you chose, on a short walk",
			submissive: "A secret item you chose when calm, on a short walk",
			switch: "One item, under clothes, a known walk, off at home"
		},
		description: "One item you already own, under normal clothes, on a short walk you already take. You can take it out in a bathroom. After: home, off, your name. No photos in public.",
		easy: "A bracelet or underwear. 15-minute walk. Off at home.",
		hard: "Underwear you chose. A half-hour known walk. One check-in to Journal. Off at home.",
		extreme: "A plug you have already worn, a short walk, bathroom access the whole time. Out the moment you say so."
	},
	"public:one-bathroom-stall-one-touch-then-back-to-you": {
		titles: {
			dominant: "One stall. One touch. Then back to the table",
			submissive: "One stall. One touch. Then you go back. You do not come",
			switch: "60 seconds, a lock, then you return"
		},
		description: "A lockable stall. Touch your genitals once, 60 seconds max. Do not come. Go back to the table. If the stall feels unsafe, skip it and do the 60 seconds at home. Skipping is the skill. After: home, water, a clear yes or no about coming later.",
		easy: "Practise 60 seconds at home first. Then once in a stall you know, if it still feels good.",
		hard: "Once on a real outing. Back to the table. Home.",
		extreme: "Twice this week, still 60 seconds, still no coming in the stall. A planned yes later."
	},
	"public:a-text-that-heats-them-up-while-they-are-out": {
		titles: {
			dominant: "A note you send yourself while you are out",
			submissive: "A note you wrote when calm, opened while you are out",
			switch: "One dirty-enough, safe-to-glance note. Then a kind close"
		},
		description: "While you are out, open 1 to 3 short notes you wrote at home. Dirty enough to heat you up, clean enough that a stranger glancing would not know. No genital photos. After: a kind closing line so you are not left hanging.",
		easy: "One note. One kind close an hour later.",
		hard: "Three notes across an afternoon. A close before you sleep.",
		extreme: "A whole outing. Still 3 notes max. A planned yes or wait when you get home."
	},
	"public:a-hand-on-the-small-of-their-back-in-a-queue": {
		titles: {
			dominant: "A hand on your own back in a queue — a private claim",
			submissive: "A private claim in a queue you already stand in",
			switch: "Ordinary. Claimed. Then a squeeze at home"
		},
		description: "In a real queue, rest your own hand at the small of your back for 10 seconds, or wear a bracelet there as the stand-in. Ordinary. After: a squeeze of your own hand when you are home. That is the close.",
		easy: "Practise at home, 10 seconds. Then once in a real queue.",
		hard: "Once on an outing you already planned. Then the private squeeze.",
		extreme: "Each time you queue this week. If it feels silly, that is allowed. The close still happens."
	},
	"scene:you-wash-them-they-stay-still": {
		titles: {
			dominant: "You wash yourself. You stay still. You keep the clock",
			submissive: "A shower. Still. Then a towel and your name",
			switch: "Wash, still, towel, name"
		},
		description: "A shower. Wash slowly. Hands on the wall unless you need to be safe. 10 minutes is enough. After: towel, your name, a drink. Do not add sex unless that was the plan. Stop if you are cold.",
		easy: "10 minutes. Back and hair. Towel. Name.",
		hard: "15 minutes. Body you offered. Then a robe and a drink.",
		extreme: "20 minutes. Dry off. Sit. 10 minutes of quiet. Do not rush the next thing."
	},
	"scene:over-the-knee-spanking-is-the-whole-scene": {
		titles: {
			dominant: "Over a pillow, a count, a landing longer than the spanking",
			submissive: "Over a pillow, a count you wrote, a landing you actually take",
			switch: "Spanking as the scene, not a warm-up"
		},
		description: "The spanking is the scene, not a warm-up for sex. Clothes on first. Hand only. Count you wrote while clothed. Landing is longer than the spanking: sit up, water, blanket, your name.",
		easy: "Clothes on. 10, check, 10. Sit up. 10 quiet minutes.",
		hard: "Underwear if you asked while calm. Then 15 minutes of landing.",
		extreme: "Bare if you asked while calm. Marks that show need a yes you wrote first. Landing is 20 minutes."
	},
	"scene:kissing-they-cannot-start": {
		titles: {
			dominant: "Kissing you start on a timer, then you let yourself start",
			submissive: "Kissing you do not start until the timer says so",
			switch: "A kiss rule, a timer, then free"
		},
		description: "For a set time, you do not start a kiss (including a kiss to your own hand or a photo, if that is the stand-in). When the timer ends, you may. After: water, your name.",
		easy: "5 minutes of waiting. Then you may.",
		hard: "10 minutes of waiting. Then 5 minutes free.",
		extreme: "15 minutes. No sex after unless that was the plan."
	},
	"scene:a-bench-they-sit-close-you-decide-when-they-may-": {
		titles: {
			dominant: "A bench. You sit. You decide when a hand may rest",
			submissive: "A bench. You sit close. You wait for the allowed touch",
			switch: "A public bench, ordinary clothes, one allowed hand"
		},
		description: "A public bench. Ordinary clothes. 10 minutes. You decide when a hand may rest on your own leg. No toys. No kissing that would make a stranger uncomfortable. After: walk as a person, then a private squeeze at home. If the bench gets busy, you leave.",
		easy: "5 minutes. Close. No extra touch. Then a private squeeze at home.",
		hard: "10 minutes. One allowed hand when you say so. Then you walk.",
		extreme: "20 minutes. Still ordinary. Busy bench means you leave. Leaving is the scene going well."
	},
	"scene:want-fear-out-write-it-do-not-run-it": {
		titles: {
			dominant: "Want, fear, out — you do not run it tonight",
			submissive: "Want, fear, out — you do not have to be brave tonight",
			switch: "Three columns. The notebook closing is aftercare"
		},
		description: "You do not run CNC (pretend force) or breath play (hands or toys on the throat or airway) tonight. You write it. Wanting is not consent for tonight. Sleep on it. Closing the notebook is aftercare.",
		easy: "Want / fear / out. Tea. Closed. No scene.",
		hard: "A fuller page: aftercare, what never happens, who would know you are planning (not doing). Still no scene.",
		extreme: "Read it in the morning. Calendar only after sleep — or the page scares you. Do not write this on a train."
	},
	"roleplay:late-to-work-you-are-the-boss": {
		titles: {
			dominant: "Late to work — you play both parts, then you say your name",
			submissive: "Late to work — you hear the boss, then your name",
			switch: "A 3-minute late meeting with yourself, then tea"
		},
		description: "A timer is the meeting. Play both parts in a voice note or in Journal. 3 to 8 minutes. When it rings, you are yourself. Silly is allowed. Do not take this to a real workplace.",
		easy: "3 minutes. One late line. One boss line. Then your name.",
		hard: "5 minutes. Then tea as a person.",
		extreme: "8 minutes, a little more heat, still a timer, still your name."
	},
	"roleplay:you-hired-them-for-two-hours": {
		titles: {
			dominant: "You hired yourself for two hours. The card goes away on time",
			submissive: "Hired for two hours. Jobs on a card. Your name back",
			switch: "A card of jobs — you do them, you inspect them, you sit"
		},
		description: "Write 3 jobs: pour water, fold a throw, stand and wait. Do them. Thank or correct once. When the timer ends, the card goes away and you say your name. After: sofa, food.",
		easy: "20 minutes. 1 job. Thank you. Name. Drink.",
		hard: "1 hour. 3 jobs. Then the card away.",
		extreme: "2 hours. Still 3 jobs. Adult voice always works. Card in a drawer on time."
	},
	"roleplay:homework-check": {
		titles: {
			dominant: "Homework check — you inspect, you end on what passed",
			submissive: "Homework check — you present, you hear what passed",
			switch: "One item, a note, tea"
		},
		description: "Bring one thing you did. Look. Say one true good thing. Write it. Tea. End on what passed.",
		easy: "One item. One kind sentence. Tea.",
		hard: "Two items. One question. Then tea as a person.",
		extreme: "The week. Still end on what passed. Do not invent a new standard in the middle."
	},
	"roleplay:a-pet-coming-home-from-a-walk": {
		titles: {
			dominant: "A pet coming home — you own the clock and you keep the creature",
			submissive: "You come home as a pet. Your name comes back",
			switch: "Cushion, water, a name that returns"
		},
		description: "Sit on a cushion. Take off a necklace. Drink water. Pet name only if you asked for it. Then your real name and the sofa. No outdoor leads. No cages.",
		easy: "5 minutes. Cushion. Water. Real name. Snack.",
		hard: "10 minutes. Jewellery on, then off with your name. Three asks.",
		extreme: "20 minutes in the house only. If you laugh from discomfort, the pet is over."
	},
	"roleplay:inspection-at-the-door": {
		titles: {
			dominant: "Inspection at the door — you look, you name one true thing",
			submissive: "Inspection at the door — you stand, you hear one true thing",
			switch: "Stand. Look. One true thing. Name. Drink"
		},
		description: "At home, door closed. Stand. Look in a mirror or at your clothes. Say one true thing you see. 2 minutes. Then your name. Do not inspect genitals at a real door a neighbour can see.",
		easy: "2 minutes in the hallway, door closed. One true thing. Name. Drink.",
		hard: "After a real short outing. Stand. Look. One true thing. Then tea.",
		extreme: "Each homecoming this week if you are alone. Skip if someone else is there."
	},
	"roleplay:waiter-and-diner-at-your-own-table": {
		titles: {
			dominant: "Waiter and diner at your own table — you sit, you serve, you eat",
			submissive: "Waiter at your own table — you serve, then you eat as yourself",
			switch: "Pour, serve, timer, names, eat"
		},
		description: "Serve a simple thing you already have. Stay in role until a timer rings. Then your real name. Silly is allowed. After: eat as yourself.",
		easy: "10 minutes. Water poured. Thank you. Name. Eat.",
		hard: "20 minutes. A small plate. Then names and the rest of the meal as a person.",
		extreme: "A whole simple meal. Names back before dessert. Do not add humiliation unless that is on a written list."
	},
	"task:a-photo-of-the-bed-made-by-a-time-you-set": {
		titles: {
			dominant: "A photo of the bed you made, by a time you set",
			submissive: "A photo of the bed, logged, by the time you wrote",
			switch: "Make the bed. Show it. One true sentence"
		},
		description: "Make the bed. Take a photo of the bed, not of your body, by a time you set. Reply to yourself with one true good sentence. Delete if your stomach flips later.",
		easy: "One photo by 10am. One true sentence.",
		hard: "Three mornings this week.",
		extreme: "Every morning this week. Sunday decide if it lives. Praise the boring."
	},
	"task:sixty-seconds-of-kneeling-before-dinner": {
		titles: {
			dominant: "Sixty seconds of kneeling you will not skip without a note",
			submissive: "Sixty seconds of kneeling before dinner you already eat",
			switch: "A cushion, a minute, then you eat"
		},
		description: "Before dinner, kneel on a cushion for 60 seconds. Timer. Your name. Stand. Eat. Write it in Tasks. If the body makes it impossible, write that. That is also the task.",
		easy: "Practise once. 60 seconds. Log it.",
		hard: "Three meals this week.",
		extreme: "Each dinner this week. Sunday: keep, change, or stop."
	},
	"task:permission-to-come-written-in-journal": {
		titles: {
			dominant: "Permission to come — you ask, you answer, you write it down",
			submissive: "Permission to come — asking is the task",
			switch: "Want, ask, answer, after — weather, not evidence"
		},
		description: "Write when you want to come, the answer you gave yourself while clothed, and how you felt after. Answer the same day. One planned yes so the week is not only waiting. Sunday read it like weather, not like evidence.",
		easy: "One note. If no, add one kind thing you may have instead.",
		hard: "Three days. One planned yes. Ordinary language only.",
		extreme: "The whole week. Sunday read as a person first. If the waiting was lonely, shorten the next week."
	},
	"task:wear-the-item-you-chose-at-home-until-a-time": {
		titles: {
			dominant: "Wear the item you chose, at home, until the time you named",
			submissive: "Wear the item, at home, until the time you wrote",
			switch: "On, a clock, off with your name"
		},
		description: "One item you already own. Wear it at home until a time you name. Take it off with your real name. You may take it off if family walks in.",
		easy: "20 minutes. Off with your name. Water.",
		hard: "The evening at home. Off before sleep.",
		extreme: "A day at home. On in the morning. Off at a time you named."
	},
	"task:one-check-in-at-a-named-time": {
		titles: {
			dominant: "One check-in at a named time you will actually keep",
			submissive: "One check-in at a named time — here, a colour, one true line",
			switch: "A clock, a line, a reply to yourself"
		},
		description: "Pick a time. Write: here, green or yellow, and one true line about the day. Reply to it the same day. A miss you report is not a fail.",
		easy: "One check-in. One true reply.",
		hard: "Three days, same time. Reply each day.",
		extreme: "Each day this week. Sunday decide if the time was kind."
	},
	"task:twenty-spanks-on-a-calendar-slot": {
		titles: {
			dominant: "Twenty spanks on a calendar slot you will not raise",
			submissive: "Twenty spanks you put on the calendar and may lower",
			switch: "A count written calm, run on a calendar, closed with a hand"
		},
		description: "Put a 20-minute window on the calendar. Hand or a paddle you already know. Clothes on first. You may lower the number on the day. You may not raise it. Hand to close. A cancelled homework with honesty still counts.",
		easy: "Clothes on. 20. Hand to close. Stop if the day turned.",
		hard: "Ask about tomorrow's clothes. Two sets of 10 only if you still want it.",
		extreme: "A slightly fuller count, still scheduled, still cancellable. Homework, not ambush."
	},
	"game:yes-no-ask-10-minutes": {
		titles: {
			dominant: "Yes, No, Ask — you ask the questions and you answer them",
			submissive: "Yes, No, Ask — you hold the small language",
			switch: "A timer, three words, then free speech"
		},
		description: "A timer. For 10 minutes you may only say yes, no, or ask, even in a voice note to yourself. Ask means bathroom, water, stop, or a repeat. A full sentence because you need it is a win. After: free speech, your name, water.",
		easy: "5 minutes. Easy questions in Journal. Then free speech and your name.",
		hard: "10 minutes. Thank every ask. Then tea.",
		extreme: "15 minutes. If you freeze, stop the game and hold yourself. Freezing is data."
	},
	"game:repeat-the-instruction-then-do-it": {
		titles: {
			dominant: "Write the instruction. Say it. Repeat it. Do it",
			submissive: "Hear the instruction you wrote. Repeat it. Do it",
			switch: "Say it, say it back, do it, thank you"
		},
		description: "Write one short instruction. Say it. Say it back in your own words. Then do it. Three rounds. No trick instructions. After: thank you, your name, a drink.",
		easy: "3 easy rounds: sit, stand, drink water. Thank you.",
		hard: "5 rounds. One may use your body (kneel, hands on thighs). Then your name.",
		extreme: "8 rounds. If you miss, own the miss as the speaker first. Then one more, or stop."
	},
	"game:red-yellow-green-a-practice-drill": {
		titles: {
			dominant: "Red, yellow, green — you name fake steps and you obey the colour",
			submissive: "Red, yellow, green — you practise the words",
			switch: "Fake steps. Real colours. Tea"
		},
		description: "No scene. Name a fake next step. Say green, yellow, or red. Obey the colour. Do this 5 times. Praise the reds. A red in practice is the whole point. Then tea.",
		easy: "5 fake steps. Praise every colour, especially red. Tea.",
		hard: "10 fake steps, mixed easy and spicy. Still no real scene.",
		extreme: "The drill, then one tiny real green you already planned — or stop on a yellow and call that a complete night."
	},
	"game:posture-for-30-seconds-then-talk": {
		titles: {
			dominant: "Posture for 30 seconds, then you notice what it did",
			submissive: "Posture for 30 seconds, then one true thing",
			switch: "Stay. Come out. Say what it did in the head"
		},
		description: "A posture you already know: kneeling, hands behind, or a straight back in a chair. 30 seconds. Then one true thing about what it did in the head. After: shake the body out. Water.",
		easy: "Once. 30 seconds. One true sentence. Water.",
		hard: "Three times this week. Same posture. Compare the sentences.",
		extreme: "Once a day, three days. If the body cannot kneel, pick a chair. That is skill, not a fail."
	},
	"game:three-small-wins-on-a-card": {
		titles: {
			dominant: "Three small role wins you will actually tick",
			submissive: "Three small wins on a card you can keep",
			switch: "Tiny, possible, ticked. Sunday you read them out"
		},
		description: "Write 3 tiny role wins for the week. Tick them when they happen. At the end of the week, read the ticks out loud and say thank you. Misses stay as weather, not as a trial.",
		easy: "Write 3. Tick 1 this week. Read it out. Thank you.",
		hard: "Tick all 3. Sunday read. Thank you.",
		extreme: "Keep the same 3 next week if they helped, or write 3 new ones. Retiring a win is also a win."
	},
	"game:who-is-in-charge-for-10-minutes": {
		titles: {
			dominant: "Who is in charge for 10 minutes — you practise both seats",
			submissive: "Who is in charge for 10 minutes — you follow, then you say",
			switch: "A timer, a seat, a spoken swap"
		},
		description: "A timer. For 10 minutes, name who is in charge — even if both seats are you. Follow the clock. When it rings, swap or stop. Say the swap out loud. After: your name, a drink, one sentence about which seat was harder.",
		easy: "10 minutes. One seat. Then your name and a drink.",
		hard: "10 minutes each. A spoken swap. Then both sentences.",
		extreme: "20 minutes in one seat, only if you still want it. Ending the game is allowed."
	},
	"training:kneeling-clock-add-it-to-training": {
		titles: {
			dominant: "Kneeling clock — you set it, you hold it, you log it",
			submissive: "Kneeling clock — you hold it, you log it in Training",
			switch: "A cushion, a timer, a log in Training"
		},
		description: "Kneel on a cushion. Timer you can see. When it rings, say your name and stand. Log it in Training. A chair with a straight back is allowed. After: shake the legs out, water.",
		easy: "30 seconds. Name. Stand. Log it.",
		hard: "60 seconds, three days this week. Log each one.",
		extreme: "2 minutes, three days. If you come up early, log the real time. Thank the telling."
	},
	"training:position-names-present-kneel-stand": {
		titles: {
			dominant: "Position names — you say them, you take them, you log it",
			submissive: "Position names — you take the shape you wrote",
			switch: "Present, kneel, stand — say, take, thank"
		},
		description: "Write 3 names: present, kneel, stand. Say the name once. Take the shape. Wait 10 seconds. Next name. Log it in Training. After: your name, a drink, shake out.",
		easy: "One round of the 3 names. Thank you. Log it.",
		hard: "Three rounds. If you miss, say the name again, once, more clearly.",
		extreme: "Five rounds, or a 5-minute drill. End on stand, then tea."
	},
	"training:hands-still-on-their-thighs": {
		titles: {
			dominant: "Hands still on your thighs — you keep the clock",
			submissive: "Hands still on your thighs — the timer you wrote",
			switch: "Hands on thighs until the timer. Then your name"
		},
		description: "No rope. Hands on your thighs until the timer ends. If you need to move, say so and move. Log the real time in Training. After: your name, water.",
		easy: "2 minutes on the sofa. Log it.",
		hard: "5 minutes, three days. Log each hold.",
		extreme: "10 minutes, twice. Ordinary words if you need to move."
	},
	"training:edge-count-stop-at-8": {
		titles: {
			dominant: "Edge count — you stop at 8, you log the real numbers",
			submissive: "Edge count — you say 8, you stop, you log it",
			switch: "A number, a stop, a log in Training"
		},
		description: "Your hand or a toy you already know. 8 on a 1-to-10 scale means stop. Do 3 stops. Log it in Training. After: water, towel, a clear yes or no about coming.",
		easy: "3 stops. Then the planned yes or no. Log it.",
		hard: "5 stops. Other hand still if you can. Log it.",
		extreme: "A longer hold at 7 after the stops, then the planned yes or no. Log the real numbers."
	},
	"training:fetch-and-present": {
		titles: {
			dominant: "Fetch and present — you name it, you bring it, you thank you",
			submissive: "Fetch and present — you bring it on open hands",
			switch: "Name, fetch, present, thank you, sit"
		},
		description: "Name one object. Fetch it. Present it on open hands. Say thank you and your name. Log it in Training. After: sit as a person.",
		easy: "1 fetch. Water. Thank you. Name. Log it.",
		hard: "3 fetches. Then sit.",
		extreme: "5 fetches, still in the house. Adult voice always works. Then sit."
	},
	"training:honorific-for-one-meal": {
		titles: {
			dominant: "Honorific for one meal — you keep it, then your legal name",
			submissive: "Honorific for one meal — a name you asked for",
			switch: "One meal, one name, then the one on your ID"
		},
		description: "For one meal at home, use a name you already said yes to. When the plates are down, legal name. Log it in Training. After: tea as a person.",
		easy: "5 minutes of the name. Then legal name. Log it.",
		hard: "One full meal. Legal name if anyone else can hear.",
		extreme: "Three meals this week. Sunday ask if the name still fits."
	},
	"reward:they-pick-the-orgasm-add-it-to-rewards": {
		titles: {
			dominant: "You pick the orgasm — add it to Rewards and cash it",
			submissive: "You pick the orgasm — add it to Rewards, then take it",
			switch: "Add it. Cash it. Run the one you named"
		},
		description: "Add this to Rewards. When you cash it, pick: your hand, a toy you already like, or being held with no orgasm. Run only that. After: water, towel, your name.",
		easy: "Add it. Cash: 10 unhurried minutes of what you picked.",
		hard: "Add it. Cash: you also pick the room and the music.",
		extreme: "Add it. Cash: a longer night, still with a clock and a stop. Morning tea is part of it."
	},
	"reward:a-bath-they-do-not-have-to-run": {
		titles: {
			dominant: "A bath you actually run for yourself, logged as a Reward",
			submissive: "A bath you do not have to earn — add it, cash it",
			switch: "Water, towel, robe — add it to Rewards"
		},
		description: "Add this to Rewards. When you cash it, run the water, check the heat, put a towel ready. Do not turn it into a scene unless you asked. After: a robe, a drink, your name.",
		easy: "Add it. Cash: 15 minutes. Water and towel. Then your name.",
		hard: "Add it. Cash: wash your hair slowly. Then a robe and a drink.",
		extreme: "Add it. Cash: bath, hair, a quiet sit after. No extra tasks hiding in the aftercare."
	},
	"reward:a-scene-from-a-list-of-3-they-wrote": {
		titles: {
			dominant: "A scene from a list of 3 — you write, you pick, you run",
			submissive: "A scene from a list of 3 you wrote, then you take it",
			switch: "Three wants. Cash one. Run that one"
		},
		description: "Add this to Rewards. Write 3 scenes you actually want, while calm. When you cash it, pick one. Run that one. After: your name, water.",
		easy: "Add it. Cash: 15 minutes of the one you pick.",
		hard: "Add it. Cash: 30 minutes, plus the aftercare you named on the card.",
		extreme: "Add it. Cash: the fuller night, still with a clock. Morning note drafted."
	},
	"reward:a-free-evening-no-protocol": {
		titles: {
			dominant: "A free evening — you cash the off-switch",
			submissive: "A free evening — no protocol, on purpose",
			switch: "Names off. Kneeling off. A show. Morning you say if you missed it"
		},
		description: "Add this to Rewards. When you cash it, names go ordinary, kneeling is off, honorifics are off. Do not sneak a rule back in. After: in the morning, say whether you missed the structure or enjoyed the air.",
		easy: "Add it. Cash: 1 hour as a person.",
		hard: "Add it. Cash: a whole evening. Phones, food, a show.",
		extreme: "Add it. Cash: a full day. A collar, if you wear one, comes off with your real name."
	},
	"reward:the-toy-they-have-been-asking-for": {
		titles: {
			dominant: "The toy you have been saving — add it, cash it, use it",
			submissive: "The toy you have been asking for — add it and take it",
			switch: "Named toy, named time, wash after"
		},
		description: "Add this to Rewards. When you cash it, use the toy you have been wanting, the way you like, for a time you named while calm. After: wash, water, your name.",
		easy: "Add it. Cash: 10 minutes, your pace.",
		hard: "Add it. Cash: 20 minutes. You may slow down.",
		extreme: "Add it. Cash: longer, still the named toy. A second toy only if you ask."
	},
	"reward:you-serve-them-breakfast": {
		titles: {
			dominant: "Breakfast you actually sit down to — add it as a Reward",
			submissive: "Breakfast you do not have to perform for",
			switch: "A simple plate, a drink, your name, a normal morning"
		},
		description: "Add this to Rewards. When you cash it, make a simple breakfast you already eat. Sit. This is not a humiliation meal unless that is on a written list. After: your name. A normal morning.",
		easy: "Add it. Cash: tea or coffee, sitting down. Then your name.",
		hard: "Add it. Cash: a simple plate plus a drink. You sit.",
		extreme: "Add it. Cash: breakfast, then 20 minutes where the small chores wait."
	},
	"punishment:corner-time-add-it-to-punishments": {
		titles: {
			dominant: "Corner time — add it, run the minutes on the card",
			submissive: "Corner time — you take the minutes you agreed",
			switch: "A wall, a timer, a name, a hand, water"
		},
		description: "Add this to Punishments. Stand or sit facing a wall, in the house, for a time you named while calm. You can speak. A red ends it. After: your name, a hand on your back, water. Do not add extra minutes because you are still annoyed.",
		easy: "Add it. Run: 2 minutes. Then name, hand, water.",
		hard: "Add it. Run: 5 minutes. Then name and water.",
		extreme: "Add it. Run: 10 minutes only if you have done 5. No extra task stacked on after."
	},
	"punishment:written-lines-add-it-to-punishments": {
		titles: {
			dominant: "Written lines — a true miss, not a worth wound",
			submissive: "Written lines — you write the true one",
			switch: "A short line, a set number, drawer or tear"
		},
		description: "Add this to Punishments. Write a short true line about a miss, not about your worth. Read them. Thank you. Drawer, or tear them up if you want them gone.",
		easy: "Add it. Run: 5 lines. Thank you. Drawer or tear.",
		hard: "Add it. Run: 10 lines. Then tea as a person.",
		extreme: "Add it. Run: 20 only if 10 still felt like repair. If it shames, stop and hold yourself."
	},
	"punishment:counted-hand-spanking-add-it-to-punishments": {
		titles: {
			dominant: "Counted hand spanking — the number on the card, not the mood",
			submissive: "Counted hand spanking — you take the card number",
			switch: "Clothes on first. Count. Sit up. Water"
		},
		description: "Add this to Punishments with a number you wrote while calm. Clothes on first. Hand only unless the card names a paddle you already know. You may lower the number on the day. After: sit up, water, a hand, your name.",
		easy: "Add it. Run: 10, clothes on. Sit up. Water.",
		hard: "Add it. Run: the card number, underwear if you asked. Hand to close.",
		extreme: "Add it. Run: still the card number. Bare only if the card says so. Landing is longer than the spanking."
	},
	"punishment:no-toy-tonight-add-it-to-punishments": {
		titles: {
			dominant: "No toy tonight — the drawer rule you wrote",
			submissive: "No toy tonight — hands and holding still allowed",
			switch: "Toys away. A kind close. A planned yes still exists"
		},
		description: "Add this to Punishments. Toys stay in the drawer. Hands, kissing, and being held are still allowed unless the card says otherwise. After: a kind close. Put one planned yes on the calendar.",
		easy: "Add it. Run: one evening. Kind close.",
		hard: "Add it. Run: two evenings, not stacked on a bad day. A planned yes still on the week.",
		extreme: "Add it. Run: 24 hours. If the wait turns lonely, shorten it."
	},
	"punishment:extra-kneel-before-the-next-meal": {
		titles: {
			dominant: "Extra kneel before the next meal — once, then you eat",
			submissive: "Extra kneel — you hold it, then you eat",
			switch: "One extra. Timer. Name. Stand. Ordinary meal"
		},
		description: "Add this to Punishments. One extra kneel, on a cushion, before the next meal. Timer. Your name. Stand. Eat. Do not stack a second extra.",
		easy: "Add it. Run: 30 seconds. Name. Stand. Eat.",
		hard: "Add it. Run: 60 seconds. Then the meal as a person.",
		extreme: "Add it. Run: 2 minutes only if 60 still felt like repair. No speech about the miss at the table."
	},
	"punishment:a-24-hour-pause-on-one-named-privilege": {
		titles: {
			dominant: "A 24-hour pause on one privilege you named",
			submissive: "A 24-hour pause — one thing, everything else stays",
			switch: "One named thing off. It comes back out loud"
		},
		description: "Add this to Punishments. Name one small privilege while calm. Pause that one thing for 24 hours. Everything else stays. After: it comes back out loud, with your name.",
		easy: "Add it. Run: 24 hours off one small thing. Then it comes back.",
		hard: "Add it. Run: the same, plus a halfway check: still fair?",
		extreme: "Add it. Run: 48 hours only if the card says 48. If it feels like exile, end it early and say so."
	},
	"kink:wrists-wrapped-a-bow-they-can-undo": {
		titles: {
			dominant: "Wrists wrapped, a bow you can undo",
			submissive: "Wrists wrapped. You stay because you chose to",
			switch: "A scarf, a bow, a timer, wrists rubbed"
		},
		description: "A scarf or soft rope. Wrists in front. A bow you can undo. Timer. Scissors in reach. After: undo, rub wrists, water, a sentence that you could have left.",
		easy: "5 minutes. Then off. Rub wrists.",
		hard: "15 minutes. Check halfway that fingers are warm and pink.",
		extreme: "30 minutes. Same bow. No gag and no ankles at the same time tonight."
	},
	"kink:a-counted-spanking-clothes-on-first": {
		titles: {
			dominant: "A counted spanking, clothes on first, a landing after",
			submissive: "A counted spanking you take, clothes on first",
			switch: "A number written calm. Count. Sit up. Water"
		},
		description: "Clothes on first. Hand, or a paddle you already know. Number written while calm. You may lower it. After: sit up, water, a hand on your back, look at the skin.",
		easy: "Clothes on. 10, check, 10. Sit up. Water.",
		hard: "Underwear if you asked while calm. Same number. Hand to close.",
		extreme: "Bare if you asked. Marks that show need a yes you wrote first. Landing is 15 minutes."
	},
	"kink:one-house-rule-on-a-card": {
		titles: {
			dominant: "One house rule you write and actually keep",
			submissive: "One house rule you can keep without a witness",
			switch: "One rule. A card. Down at the end"
		},
		description: "One rule. Written. Small enough for a real life. Run it, then take the card down. Ask if it lives.",
		easy: "Write the rule. 1 hour. Release on time. Tea.",
		hard: "One evening. Catch once, kindly, or not at all.",
		extreme: "Keep it a week if you liked it. Ending a rule is also protocol."
	},
	"kink:they-serve-one-small-thing-then-they-sit": {
		titles: {
			dominant: "Serve one small thing, then sit as a person",
			submissive: "Serve one small thing, then you sit",
			switch: "One job. Thank you. Sit. Drink"
		},
		description: "One act: pour water, fold a throw, bring a towel. Do it. Thank you. Sit as a person. After: drink.",
		easy: "One job. Thank you. Sit. Drink.",
		hard: "Three small jobs on a card. Then the card away and you sit.",
		extreme: "A 30-minute window of jobs you already need. Then you sit. Do not add more."
	},
	"kink:a-cushion-a-bowl-of-water-a-name-that-comes-back": {
		titles: {
			dominant: "A cushion, water, a name that returns",
			submissive: "You sit on a cushion. Your name comes back",
			switch: "Pet for 10 minutes. Then the sofa and your name"
		},
		description: "Sit on a cushion. Drink water. Pet name only if you asked. Then your real name and the sofa. No outdoor leads. No cages.",
		easy: "5 minutes. Cushion. Water. Real name. Snack.",
		hard: "10 minutes. Jewellery on, then off with your name.",
		extreme: "20 minutes in the house only. If you laugh from discomfort, the pet is over."
	},
	"kink:three-true-praises-spoken": {
		titles: {
			dominant: "Three true praises you write and then take",
			submissive: "Three true praises you have to take",
			switch: "Three true lines. Stop if they turn to shame"
		},
		description: "Say or write 3 true sentences about how you were today. Be specific. Stop if it turns to shame. The words can stay.",
		easy: "3 lines, one night. Stop means stop.",
		hard: "3 nights this week. No extra tasks attached.",
		extreme: "Every night this week. Sunday keep the lines that landed."
	},
	"kink:playful-mean-words-from-a-page-then-kindness": {
		titles: {
			dominant: "Playful mean words from a page, then kindness",
			submissive: "Playful mean words you wrote calm, then repair",
			switch: "A list, once, then the opposite sentences"
		},
		description: "While clothed, write 5 lines. Read once. Stop. Write the opposite kind sentences. Morning note already drafted.",
		easy: "The 5 lines once. Then the 5 kind opposites.",
		hard: "One line, repeated, then its opposite.",
		extreme: "The full list, still once, still with repair the same night."
	},
	"kink:they-ask-before-they-come": {
		titles: {
			dominant: "Ask before you come — you ask, you answer, you write it",
			submissive: "Ask before you come — asking is the kink",
			switch: "Want, ask, answer, after — weather, not evidence"
		},
		description: "Ask before you come. Answer the same day. If no, you still owe yourself warmth. One planned yes so the week is not only waiting.",
		easy: "One evening. Ask once. If no, a mug and a show you know.",
		hard: "Three days. One planned yes.",
		extreme: "The whole week. Sunday decide if it lives."
	},
	"kink:they-show-you-in-the-house-on-purpose": {
		titles: {
			dominant: "You show, in the house, on purpose",
			submissive: "You show, in the house, and you say if there is touch",
			switch: "A look you asked for. Clothes after. A drink"
		},
		description: "Take off as much as you want. Look — a mirror counts. Touch only if you say so. 10 minutes. No photos unless that is a second yes. After: clothes, your name, a drink.",
		easy: "Clothes half off. Look for 2 minutes. Then your name.",
		hard: "You pick what comes off. Touch only if you say. Then clothes and a drink.",
		extreme: "A longer look. A mirror if you want. Still no photos unless you asked."
	},
	"kink:ten-minutes-in-a-role-you-already-named": {
		titles: {
			dominant: "Ten minutes in a role you already named, then your name",
			submissive: "Ten minutes in a role, then your legal name",
			switch: "A timer. A role. Then tea"
		},
		description: "Pick a role you have already talked about. A timer. When it rings, legal name. Silly is allowed. After: water, a sentence about whether the role still fits.",
		easy: "5 minutes. One line. Timer. Name.",
		hard: "10 minutes. Then names and tea.",
		extreme: "20 minutes, still a timer, still your name back."
	},
	"kink:a-short-chase-in-the-house": {
		titles: {
			dominant: "A short chase in the house — you count, you catch, you hold",
			submissive: "A short chase — you run, you get caught, you get held",
			switch: "Countdown, catch, hold, breath, your name"
		},
		description: "At home. Count down from 5. Run to another room. Catch with arms, not with pain, unless impact is also on your list. Then hold, breath, your name. No stairs. No glass. No outdoor chase.",
		easy: "One countdown. One catch. Hold. Name. Water.",
		hard: "Three short chases. Then a long hold.",
		extreme: "A 10-minute hunt, still in the house. If you are actually scared, it is over."
	},
	"kink:warm-hands-then-a-cool-spoon": {
		titles: {
			dominant: "Warm hands, then a cool spoon, at a pace you run",
			submissive: "Warm hands, then a cool spoon you give yourself",
			switch: "Warm, cool, ask, towel, a warm drink"
		},
		description: "Warm oil or warm hands, then a metal spoon run under cold water, on skin you offered. Stop at enough. After: towel, blanket, a warm drink.",
		easy: "Clothes on. Shoulders. 5 minutes.",
		hard: "One area at a time. End with a towel.",
		extreme: "A longer map you named. You do not have to have sex after."
	},
	"kink:a-blindfold-they-can-take-off": {
		titles: {
			dominant: "A blindfold you can take off, a voice you keep",
			submissive: "A blindfold you can take off",
			switch: "Mask on, timer, voice, light, your name"
		},
		description: "A sleep mask or a scarf you can pull down. Keep talking, or keep a podcast on so the quiet is not too big. After: light, your name, water, sit. Do not add a gag the first time.",
		easy: "2 minutes. You can pull it down. Then name and water.",
		hard: "5 minutes. Keep a voice in the room. Then light, name, sit.",
		extreme: "10 minutes only if you have done 5. Still able to take it off."
	},
	"kink:one-poke-then-they-take-the-answer": {
		titles: {
			dominant: "One poke, one answer, then the evening continues",
			submissive: "One poke, then you take the answer",
			switch: "Sass on purpose. One answer. A drink"
		},
		description: "One poke: a sass, a delay, a grin — even in a journal line. One clear answer. Then the poke is over. After: your name, a drink, a laugh if there is one.",
		easy: "One poke. One answer. Drink.",
		hard: "Three pokes this week, not stacked in one hour.",
		extreme: "A named brat window of 10 minutes, then you drop it on the timer."
	},
	"kink:a-hickey-they-asked-for-where-they-said": {
		titles: {
			dominant: "A hickey you asked for, where you said",
			submissive: "A hickey you asked for, where you said it could live",
			switch: "One mark. Look. Ordinary evening or ice"
		},
		description: "A suck-mark on a place you named. Agree if it may show tomorrow. Do not break the skin. After: look, ice or nothing.",
		easy: "One small mark. Sit and look. Ordinary evening.",
		hard: "A place you can cover. Ask about tomorrow before you start.",
		extreme: "A place you want to see in the mirror. Still one mark."
	},
	"kink:a-furniture-minute-they-hold-still-then-they-are": {
		titles: {
			dominant: "A furniture minute — you hold still, then you are a person",
			submissive: "A furniture minute — then your name first",
			switch: "A clock, still, your name, water"
		},
		description: "Kneel or sit as a table or a footrest for a time you named — no weight that hurts. When the timer rings, say your name first, then thank you. After: sit as a person, water.",
		easy: "1 minute. Then your name, thank you, sit.",
		hard: "5 minutes. Then name and water.",
		extreme: "10 minutes only if 5 still felt like play. If you go quiet in a way that is not heat, end it."
	},
	"kink:want-fear-out-write-the-edge-do-not-run-it": {
		titles: {
			dominant: "Want, fear, out — you do not run it tonight",
			submissive: "Want, fear, out — you do not have to be brave tonight",
			switch: "Three columns. The notebook closing is aftercare"
		},
		description: "You do not run CNC or breath play tonight. You write it. Wanting is not consent for tonight. Sleep on it. Closing the notebook is aftercare.",
		easy: "Want / fear / out. Tea. Closed. No scene.",
		hard: "A fuller page. Still no scene. Still sleep.",
		extreme: "Morning read. Calendar only after sleep — or the page scares you."
	}
};
function fallback(prompt) {
	const kind = prompt.kind;
	const baseTitle = prompt.dominant.title.replace(/\s+they\b/gi, " you").replace(/\s+them\b/gi, " yourself");
	return {
		titles: {
			dominant: baseTitle,
			submissive: baseTitle,
			switch: baseTitle
		},
		description: `You do this week's ${kind} alone. Write the rule while calm. Keep a timer. Keep a stop. Aftercare is food, water, and three sentences in Journal.`,
		easy: prompt.dominant.easy,
		hard: prompt.dominant.hard,
		extreme: prompt.dominant.extreme
	};
}
function soloBody(prompt, role) {
	const spec = SOLO[prompt.id] ?? fallback(prompt);
	return {
		title: spec.titles[role],
		description: `${seat(role)} ${spec.description}`,
		easy: spec.easy,
		hard: spec.hard,
		extreme: spec.extreme
	};
}
var WEEK_KINDS = [
	"communication",
	"public",
	"scene",
	"roleplay",
	"task",
	"game",
	"training",
	"reward",
	"punishment",
	"kink"
];
function mulberry32(seed) {
	return () => {
		let t = seed += 1831565813;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function talkWeekKey(date = /* @__PURE__ */ new Date()) {
	const daysFromMonday = (date.getUTCDay() + 6) % 7;
	const monday = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate() - daysFromMonday, 0, 1, 0, 0));
	if (date.getTime() < monday.getTime()) monday.setUTCDate(monday.getUTCDate() - 7);
	return monday.toISOString().slice(0, 10);
}
function seededPick(items, seed, count) {
	if (!items.length) return [];
	const rand = mulberry32([...seed].reduce((h, ch) => Math.imul(h ^ ch.charCodeAt(0), 16777619), 2166136261) >>> 0);
	const pool = [...items];
	const out = [];
	while (pool.length && out.length < count) {
		const i = Math.floor(rand() * pool.length);
		out.push(pool.splice(i, 1)[0]);
	}
	return out;
}
var WEEKLY_QUIZZES = [
	{
		id: "love",
		title: "Love languages",
		blurb: "How care actually lands — in and out of dynamic.",
		questions: [
			{
				prompt: "I feel most loved when you…",
				options: [
					{
						value: "words",
						label: "Tell me, specifically, what I did well"
					},
					{
						value: "time",
						label: "Give me undivided time with no phones"
					},
					{
						value: "touch",
						label: "Reach for me without it having to become a scene"
					},
					{
						value: "acts",
						label: "Do the unglamorous thing I asked for last week"
					},
					{
						value: "gifts",
						label: "Leave something small that says you thought of me"
					}
				]
			},
			{
				prompt: "When I am dropping, the language I need first is…",
				options: [
					{
						value: "words",
						label: "Words — I am safe, I did well, you are here"
					},
					{
						value: "touch",
						label: "Quiet touch and a blanket"
					},
					{
						value: "acts",
						label: "Water, food, the lights down"
					},
					{
						value: "time",
						label: "You staying, even if we say nothing"
					}
				]
			},
			{
				prompt: "A public way you can love me without anyone else clocking it…",
				options: [
					{
						value: "glance",
						label: "A look we already agreed means 'I have you'"
					},
					{
						value: "text",
						label: "A short message in the ordinary day"
					},
					{
						value: "errand",
						label: "Handling something so I don't have to"
					},
					{
						value: "none",
						label: "Keep it private. Public is not for us."
					}
				]
			},
			{
				prompt: "The love language I fake because I think I should…",
				min: "curious",
				options: [
					{
						value: "gifts",
						label: "Gifts — I smile and feel nothing"
					},
					{
						value: "words",
						label: "Praise that sounds like a script"
					},
					{
						value: "touch",
						label: "Touch I don't actually want yet"
					},
					{
						value: "acts",
						label: "Service I resent later"
					}
				]
			},
			{
				prompt: "In protocol, love looks like…",
				min: "practiced",
				options: [
					{
						value: "precision",
						label: "Exactness. You meant what you asked."
					},
					{
						value: "warmth",
						label: "Warmth inside the rule, not instead of it"
					},
					{
						value: "release",
						label: "Being allowed to stop performing"
					},
					{
						value: "demand",
						label: "Being asked for more because you trust I can"
					}
				]
			},
			{
				prompt: "The unsexy act that is actually my love language in a 24/7 stretch…",
				min: "seasoned",
				options: [
					{
						value: "calendar",
						label: "Keeping the calendar so I don't have to hold it"
					},
					{
						value: "food",
						label: "Feeding me when I forget"
					},
					{
						value: "sleep",
						label: "Protecting sleep and drop days"
					},
					{
						value: "repair",
						label: "Coming back after a rupture without theatre"
					}
				]
			},
			{
				prompt: "Edge-play aftercare as a love language should include…",
				min: "established",
				options: [
					{
						value: "medical",
						label: "Practical body care, not just cuddles"
					},
					{
						value: "debrief",
						label: "A real debrief, even if it is ugly"
					},
					{
						value: "space",
						label: "Space first, then a scheduled check-in"
					},
					{
						value: "claim",
						label: "Being claimed again, so I know I still belong"
					}
				]
			}
		]
	},
	{
		id: "kink",
		title: "Kink",
		blurb: "Taste, appetite, and the difference between a picture and a practice.",
		questions: [
			{
				prompt: "Right now my kink appetite is…",
				options: [
					{
						value: "soft",
						label: "Soft — protocol, voice, being held in a role"
					},
					{
						value: "sensation",
						label: "Sensation — I want to feel something"
					},
					{
						value: "head",
						label: "Headspace more than pain or toys"
					},
					{
						value: "mixed",
						label: "A mix, but I need to name it each time"
					}
				]
			},
			{
				prompt: "The kink I want named out loud this week is…",
				options: [
					{
						value: "restraint",
						label: "Restraint / being held still"
					},
					{
						value: "impact",
						label: "Impact"
					},
					{
						value: "service",
						label: "Service"
					},
					{
						value: "control",
						label: "Control of orgasm, time, or permission"
					},
					{
						value: "none",
						label: "None — I want vanilla closeness"
					}
				]
			},
			{
				prompt: "A hard limit I need restated, even if you already know…",
				options: [
					{
						value: "body",
						label: "Something about my body"
					},
					{
						value: "words",
						label: "Words or names"
					},
					{
						value: "people",
						label: "Other people, even in fantasy"
					},
					{
						value: "record",
						label: "Photos, video, or anything kept"
					},
					{
						value: "none",
						label: "Nothing new — my list is current"
					}
				]
			},
			{
				prompt: "I want intensity to trend…",
				min: "curious",
				options: [
					{
						value: "down",
						label: "Down. More aftercare than edge."
					},
					{
						value: "even",
						label: "Where we already are"
					},
					{
						value: "up",
						label: "Up, slowly, with a plan"
					},
					{
						value: "spike",
						label: "One planned spike, then rest"
					}
				]
			},
			{
				prompt: "Marks, bruises, or evidence should be…",
				min: "practiced",
				options: [
					{
						value: "none",
						label: "None this season"
					},
					{
						value: "hidden",
						label: "Fine if hidden"
					},
					{
						value: "kept",
						label: "I want to keep them a few days"
					},
					{
						value: "shown",
						label: "I want them seen by you, not the world"
					}
				]
			},
			{
				prompt: "The kink I perform because I think you want it…",
				min: "seasoned",
				options: [
					{
						value: "pain",
						label: "Pain I don't actually crave"
					},
					{
						value: "degrade",
						label: "Degradation that misses me"
					},
					{
						value: "service",
						label: "Service that has gone empty"
					},
					{
						value: "none",
						label: "I am not performing. I will say if I am."
					}
				]
			},
			{
				prompt: "Edge play this week is…",
				min: "established",
				options: [
					{
						value: "off",
						label: "Off the table"
					},
					{
						value: "talk",
						label: "Talk only — no running it"
					},
					{
						value: "negotiated",
						label: "Negotiated, with a written aftercare plan"
					},
					{
						value: "trusted",
						label: "Inside our standing yes, with safewords live"
					}
				]
			}
		]
	},
	{
		id: "roleplay",
		title: "Roleplay",
		blurb: "Who you become, and how you get back.",
		questions: [
			{
				prompt: "I slip into a role best when…",
				options: [
					{
						value: "clothes",
						label: "Clothes or a collar change first"
					},
					{
						value: "voice",
						label: "Your voice changes"
					},
					{
						value: "name",
						label: "You use a name that isn't the daily one"
					},
					{
						value: "place",
						label: "We leave the ordinary room, even a little"
					}
				]
			},
			{
				prompt: "A role I want to try or return to…",
				options: [
					{
						value: "service",
						label: "Service — staff, attendant, kept"
					},
					{
						value: "stranger",
						label: "Strangers who shouldn't"
					},
					{
						value: "owner",
						label: "Owner and belonging"
					},
					{
						value: "teacher",
						label: "Teacher / coach / inspector"
					},
					{
						value: "none",
						label: "I don't want a role. I want us."
					}
				]
			},
			{
				prompt: "When the role slips, please…",
				options: [
					{
						value: "catch",
						label: "Catch me back in, gently"
					},
					{
						value: "ask",
						label: "Ask if I want in or out"
					},
					{
						value: "drop",
						label: "Let it become us without comment"
					},
					{
						value: "stop",
						label: "Stop the scene and check"
					}
				]
			},
			{
				prompt: "Words that belong only in the role…",
				min: "curious",
				options: [
					{
						value: "titles",
						label: "Titles"
					},
					{
						value: "cruel",
						label: "Cruel or filthy lines"
					},
					{
						value: "story",
						label: "The backstory we invented"
					},
					{
						value: "none",
						label: "No special vocabulary"
					}
				]
			},
			{
				prompt: "How long should a role last?",
				min: "practiced",
				options: [
					{
						value: "scene",
						label: "The scene, then a clear out"
					},
					{
						value: "evening",
						label: "The evening, with a safeword out"
					},
					{
						value: "thread",
						label: "A message thread across days"
					},
					{
						value: "rare",
						label: "Rare, and fully planned"
					}
				]
			},
			{
				prompt: "A role that is too close to real life is…",
				min: "seasoned",
				options: [
					{
						value: "work",
						label: "Work / rank / actual jobs"
					},
					{
						value: "family",
						label: "Family-shaped stories"
					},
					{
						value: "ex",
						label: "Anyone who actually existed"
					},
					{
						value: "ok",
						label: "Fine if we name the difference first"
					}
				]
			},
			{
				prompt: "CNC or resistance-in-role this week is…",
				min: "established",
				options: [
					{
						value: "no",
						label: "No"
					},
					{
						value: "light",
						label: "Light struggle, lots of checking"
					},
					{
						value: "scripted",
						label: "Scripted, with a written out"
					},
					{
						value: "standing",
						label: "Inside our standing negotiation only"
					}
				]
			}
		]
	},
	{
		id: "scenes",
		title: "Scenes",
		blurb: "How a night is built, run, and closed.",
		questions: [
			{
				prompt: "The next scene should start with…",
				options: [
					{
						value: "talk",
						label: "A talk and a drink of water"
					},
					{
						value: "protocol",
						label: "Protocol — present, wait, be arranged"
					},
					{
						value: "warm",
						label: "Warm-up that could still turn vanilla"
					},
					{
						value: "in",
						label: "In media res. We already negotiated."
					}
				]
			},
			{
				prompt: "Who names the night?",
				options: [
					{
						value: "dom",
						label: "The Dominant"
					},
					{
						value: "sub",
						label: "The submissive may ask"
					},
					{
						value: "either",
						label: "Either, without ceremony"
					},
					{
						value: "calendar",
						label: "It goes on a calendar"
					}
				]
			},
			{
				prompt: "I want the arc to be…",
				options: [
					{
						value: "slow",
						label: "Slow, with lots of checking"
					},
					{
						value: "peak",
						label: "A clear peak and a long come-down"
					},
					{
						value: "service",
						label: "Service-shaped, not climax-shaped"
					},
					{
						value: "short",
						label: "Short. I don't have a long runway."
					}
				]
			},
			{
				prompt: "Toys in the next scene…",
				min: "curious",
				options: [
					{
						value: "none",
						label: "None. Hands and voice."
					},
					{
						value: "one",
						label: "One chosen piece"
					},
					{
						value: "kit",
						label: "A small kit we lay out together"
					},
					{
						value: "surprise",
						label: "Surprise from a negotiated list"
					}
				]
			},
			{
				prompt: "If I safeword, the scene…",
				min: "practiced",
				options: [
					{
						value: "ends",
						label: "Ends. Aftercare starts."
					},
					{
						value: "pause",
						label: "Pauses. We may resume if I say so."
					},
					{
						value: "down",
						label: "Drops two gears, does not end unless I ask"
					},
					{
						value: "script",
						label: "Follows the written plan, not improvisation"
					}
				]
			},
			{
				prompt: "A scene I want logged (photos, notes) is…",
				min: "seasoned",
				options: [
					{
						value: "never",
						label: "Never"
					},
					{
						value: "notes",
						label: "Notes only, in Journal"
					},
					{
						value: "still",
						label: "Stills we both agree to keep"
					},
					{
						value: "full",
						label: "A full record, private to the bond"
					}
				]
			},
			{
				prompt: "Risk-aware edge this week needs…",
				min: "established",
				options: [
					{
						value: "off",
						label: "It is off"
					},
					{
						value: "sober",
						label: "Sober, slept, eaten"
					},
					{
						value: "third",
						label: "A check-in person or a time-cap"
					},
					{
						value: "kit",
						label: "Kit, first aid, and a written out"
					}
				]
			}
		]
	},
	{
		id: "aftercare",
		title: "Aftercare",
		blurb: "What happens when the scene ends — and the next morning.",
		questions: [
			{
				prompt: "Right after, I most need…",
				options: [
					{
						value: "touch",
						label: "Quiet touch and a blanket"
					},
					{
						value: "words",
						label: "Words — what happened, that I did well"
					},
					{
						value: "space",
						label: "A little space, then check-in"
					},
					{
						value: "practical",
						label: "Water, food, and the lights down"
					}
				]
			},
			{
				prompt: "The next morning I want…",
				options: [
					{
						value: "message",
						label: "A short message, no pressure"
					},
					{
						value: "debrief",
						label: "A proper debrief"
					},
					{
						value: "normal",
						label: "Ordinary day unless I ask"
					},
					{
						value: "plan",
						label: "Already planning the next one"
					}
				]
			},
			{
				prompt: "If I drop later, please…",
				options: [
					{
						value: "stay",
						label: "Stay close and slow everything down"
					},
					{
						value: "call",
						label: "Call, even if it is late"
					},
					{
						value: "list",
						label: "Use the written list, not improvisation"
					},
					{
						value: "ask",
						label: "Ask me what I need rather than guessing"
					}
				]
			},
			{
				prompt: "Aftercare I do not want…",
				min: "curious",
				options: [
					{
						value: "sex",
						label: "Sex as a closer"
					},
					{
						value: "jokes",
						label: "Jokes about what just happened"
					},
					{
						value: "crowd",
						label: "Other people around"
					},
					{
						value: "analysis",
						label: "A post-mortem while I am still in it"
					}
				]
			},
			{
				prompt: "Food, sugar, salt, protein — my body wants…",
				min: "practiced",
				options: [
					{
						value: "sweet",
						label: "Something sweet"
					},
					{
						value: "savoury",
						label: "Something savoury and grounding"
					},
					{
						value: "water",
						label: "Water and time, not food yet"
					},
					{
						value: "later",
						label: "A real meal an hour later"
					}
				]
			},
			{
				prompt: "After a heavy night, protocol the next day should…",
				min: "seasoned",
				options: [
					{
						value: "off",
						label: "Be off"
					},
					{
						value: "soft",
						label: "Go soft — titles optional"
					},
					{
						value: "same",
						label: "Stay, because structure helps me"
					},
					{
						value: "check",
						label: "Be decided in the morning, not assumed"
					}
				]
			},
			{
				prompt: "After edge play, the non-negotiable is…",
				min: "established",
				options: [
					{
						value: "sleep",
						label: "Sleep in the same place"
					},
					{
						value: "24h",
						label: "A 24-hour check-in, calendar'd"
					},
					{
						value: "body",
						label: "Looking at the body together, honestly"
					},
					{
						value: "offswitch",
						label: "An off-switch phrase that ends all protocol"
					}
				]
			}
		]
	},
	{
		id: "relationship",
		title: "Relationship",
		blurb: "The bond outside the scene.",
		questions: [
			{
				prompt: "This week I most need us to be…",
				options: [
					{
						value: "partners",
						label: "Partners first, dynamic second"
					},
					{
						value: "dynamic",
						label: "In dynamic. I miss the shape of it."
					},
					{
						value: "friends",
						label: "Friends who laugh"
					},
					{
						value: "quiet",
						label: "Quiet. Less processing, more sitting."
					}
				]
			},
			{
				prompt: "A conversation we keep postponing is about…",
				options: [
					{
						value: "time",
						label: "Time and how we spend it"
					},
					{
						value: "sex",
						label: "Sex and how often"
					},
					{
						value: "future",
						label: "The future we have not named"
					},
					{
						value: "hurt",
						label: "Something that still hurts"
					},
					{
						value: "none",
						label: "Nothing. We are current."
					}
				]
			},
			{
				prompt: "When we miss each other, I want…",
				options: [
					{
						value: "repair",
						label: "A repair the same day"
					},
					{
						value: "sleep",
						label: "Sleep, then talk"
					},
					{
						value: "write",
						label: "It written, so I can reread"
					},
					{
						value: "touch",
						label: "Touch first, words later"
					}
				]
			},
			{
				prompt: "Jealousy, if it is here…",
				min: "curious",
				options: [
					{
						value: "none",
						label: "It is not here"
					},
					{
						value: "name",
						label: "Name it without solving it"
					},
					{
						value: "rule",
						label: "We need a clearer rule"
					},
					{
						value: "reassurance",
						label: "I need reassurance, not a lecture"
					}
				]
			},
			{
				prompt: "Money, chores, admin in a power exchange should…",
				min: "practiced",
				options: [
					{
						value: "equal",
						label: "Stay equal and boring"
					},
					{
						value: "service",
						label: "Be service, if it is chosen"
					},
					{
						value: "split",
						label: "Be split on purpose, in writing"
					},
					{
						value: "talk",
						label: "Be talked about before it becomes kink"
					}
				]
			},
			{
				prompt: "How open is this bond to other people?",
				min: "seasoned",
				options: [
					{
						value: "closed",
						label: "Closed. Us only."
					},
					{
						value: "social",
						label: "Social, not sexual"
					},
					{
						value: "play",
						label: "Play with others, negotiated each time"
					},
					{
						value: "unset",
						label: "We have not actually decided"
					}
				]
			},
			{
				prompt: "A rupture at this depth is repaired by…",
				min: "established",
				options: [
					{
						value: "time",
						label: "Time and no scenes until we say"
					},
					{
						value: "third",
						label: "A third — therapist, friend, or text"
					},
					{
						value: "contract",
						label: "Rewriting the contract in the light"
					},
					{
						value: "body",
						label: "Careful, non-sexual body closeness first"
					}
				]
			}
		]
	},
	{
		id: "communication",
		title: "Communication",
		blurb: "How we speak when it is not a scene.",
		questions: [
			{
				prompt: "When I go quiet, assume…",
				options: [
					{
						value: "processing",
						label: "I am processing — wait"
					},
					{
						value: "check",
						label: "Check in once"
					},
					{
						value: "green",
						label: "I am fine unless I safeword"
					},
					{
						value: "yellow",
						label: "Treat silence as yellow"
					}
				]
			},
			{
				prompt: "Correction lands best when it is…",
				options: [
					{
						value: "firm",
						label: "Firm and brief"
					},
					{
						value: "warm",
						label: "Warm, then clear"
					},
					{
						value: "written",
						label: "Written, so I can reread it"
					},
					{
						value: "private",
						label: "Always private"
					}
				]
			},
			{
				prompt: "I want more of this in our ordinary talk…",
				options: [
					{
						value: "ask",
						label: "Questions, not conclusions"
					},
					{
						value: "praise",
						label: "Praise that is specific"
					},
					{
						value: "want",
						label: "Want, said plainly"
					},
					{
						value: "apology",
						label: "Clean apologies"
					}
				]
			},
			{
				prompt: "During a fight, titles and protocol should…",
				min: "curious",
				options: [
					{
						value: "off",
						label: "Come off until we repair"
					},
					{
						value: "on",
						label: "Stay — they keep me from spinning"
					},
					{
						value: "pause",
						label: "Pause if either of us asks"
					},
					{
						value: "never",
						label: "Never mix. Fights are vanilla."
					}
				]
			},
			{
				prompt: "The check-in cadence I actually want…",
				min: "practiced",
				options: [
					{
						value: "daily",
						label: "A daily line, even a short one"
					},
					{
						value: "weekly",
						label: "A weekly sit-down"
					},
					{
						value: "after",
						label: "Only after scenes"
					},
					{
						value: "asneeded",
						label: "As needed — don't schedule my feelings"
					}
				]
			},
			{
				prompt: "A word I want retired from how we speak…",
				min: "seasoned",
				options: [
					{
						value: "joke",
						label: "A joke that isn't funny anymore"
					},
					{
						value: "title",
						label: "A title that has gone sour"
					},
					{
						value: "always",
						label: "'Always' and 'never'"
					},
					{
						value: "none",
						label: "None. Our language is clean."
					}
				]
			},
			{
				prompt: "After a heavy negotiation, we should…",
				min: "established",
				options: [
					{
						value: "write",
						label: "Write it down the same night"
					},
					{
						value: "sleep",
						label: "Sleep on it before anything runs"
					},
					{
						value: "cool",
						label: "Have a cool-off safeword for the contract itself"
					},
					{
						value: "third",
						label: "Have someone else hold a copy"
					}
				]
			}
		]
	}
];
function switchBody(dominant, submissive) {
	return {
		title: `${dominant.title.replace(/\s+—.*$/, "")} / ${submissive.title.replace(/\s+—.*$/, "")}`,
		description: "You are switching. Name who leads before anything starts — a coin, a look, or a plain 'I have you tonight.' Pick Easy, Hard, or Extreme together. The lead runs it. The follow can still say yellow. Swap on purpose, or stop. Aftercare belongs to whoever went deepest.",
		easy: `Lead: ${dominant.easy} Follow: ${submissive.easy}`,
		hard: `Lead: ${dominant.hard} Follow: ${submissive.hard}`,
		extreme: `Lead: ${dominant.extreme} Follow: ${submissive.extreme}`
	};
}
function resolvePrompt(prompt, role, kinks, solo = false) {
	const body = solo ? soloBody(prompt, role) : role === "dominant" ? prompt.dominant : role === "submissive" ? prompt.submissive : switchBody(prompt.dominant, prompt.submissive);
	const wanted = new Set(kinks.map((item) => item.toLowerCase()));
	const matchedKinks = prompt.kinks.filter((item) => wanted.has(item.toLowerCase()));
	return {
		...body,
		id: prompt.id,
		kind: prompt.kind,
		kinks: prompt.kinks,
		matchedKinks,
		min: prompt.min,
		role,
		solo
	};
}
function promptScore(prompt, kinks) {
	if (!kinks.length || !prompt.kinks.length) return 1;
	const wanted = new Set(kinks.map((item) => item.toLowerCase()));
	const hits = prompt.kinks.filter((item) => wanted.has(item.toLowerCase())).length;
	return hits > 0 ? 10 + hits : 0;
}
function weeklyQuizzesFor(level, seed) {
	const experience = parseExperience(level);
	return WEEKLY_QUIZZES.map((pack) => {
		const pool = pack.questions.filter((q) => meetsExperience(q.min ?? "curious", experience));
		const questions = seededPick(pool.length ? pool : pack.questions, `${seed}:${pack.id}`, 4);
		return {
			id: pack.id,
			title: pack.title,
			blurb: pack.blurb,
			questions
		};
	});
}
function weeklyTryPrompts(level, seed, role = "switch", kinks = [], solo = false) {
	const experience = parseExperience(level);
	const kinkKey = [...new Set(kinks.map((item) => item.toLowerCase()))].sort().join(",");
	return WEEK_KINDS.map((kind) => {
		const all = WEEKLY_PROMPTS.filter((item) => item.kind === kind);
		const leveled = all.filter((item) => meetsExperience(item.min ?? "curious", experience));
		const scored = (leveled.length ? leveled : all).map((item) => ({
			item,
			score: promptScore(item, kinks)
		}));
		const matched = scored.filter((row) => row.score > 0);
		const pool = matched.length ? matched : scored;
		const max = Math.max(...pool.map((row) => row.score), 0);
		return resolvePrompt(seededPick(pool.filter((row) => row.score === max).map((row) => row.item), `${seed}:${kind}:${kinkKey}`, 1)[0] ?? all[0], role, kinks, solo);
	});
}
function weeklySeed(bondId, week = talkWeekKey()) {
	return `${bondId}:${week}`;
}
function coupleLevel(a, b) {
	return coupleExperience(a, b);
}
function formatTalkWeek(week = talkWeekKey()) {
	const [y, m, d] = week.split("-").map(Number);
	return new Date(Date.UTC(y ?? 2026, (m ?? 1) - 1, d ?? 1, 0, 1, 0)).toLocaleDateString("en-GB", {
		day: "numeric",
		month: "long",
		timeZone: "UTC"
	});
}
var WEEK_KIND_LABEL = {
	communication: "Communication",
	public: "Public play",
	scene: "Scene",
	roleplay: "Roleplay",
	task: "Task",
	game: "Game",
	training: "Training",
	reward: "Rewards",
	punishment: "Punishment",
	kink: "Kink"
};
function TalkView() {
	const [me, setMe] = (0, import_react.useState)(null);
	const [answers, setAnswers] = (0, import_react.useState)([]);
	const [tab, setTab] = (0, import_react.useState)("today");
	const [cats, setCats] = (0, import_react.useState)([]);
	const [manage, setManage] = (0, import_react.useState)(false);
	const load = (0, import_react.useCallback)(async () => {
		try {
			const [mine, rows, categories] = await Promise.all([
				getMe(),
				listTalkAnswers(),
				listCategories({ data: { kind: "talk" } })
			]);
			setMe(mine);
			setAnswers(rows);
			setCats(categories);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not load talk.");
		}
	}, []);
	(0, import_react.useEffect)(() => {
		load();
	}, [load]);
	useLiveReload(load);
	function answersFor(topic) {
		return answers.filter((item) => item.topic === topic);
	}
	function remember(saved) {
		setAnswers((prev) => {
			return [saved, ...prev.filter((item) => !(item.topic === saved.topic && item.userId === saved.userId))];
		});
	}
	async function save(topic, body, rating, visibility) {
		try {
			remember(await saveTalkAnswer({ data: {
				topic,
				body,
				rating,
				visibility
			} }));
			return true;
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not save.");
			return false;
		}
	}
	const parentCats = (0, import_react.useMemo)(() => sortNamed(cats.filter((item) => !item.parentSlug && !item.archived)), [cats]);
	const tabs = (0, import_react.useMemo)(() => {
		return [
			{
				id: "today",
				label: "Today",
				pane: "today"
			},
			{
				id: "week",
				label: "This week",
				pane: "week"
			},
			...parentCats.filter((item) => item.slug !== "question" && item.slug !== "quiz" && item.slug !== "week").map((item) => ({
				id: item.slug,
				label: item.name,
				pane: item.slug === "kink" ? "kinks" : "entries"
			})),
			{
				id: "quizzes",
				label: "Quizzes",
				pane: "quizzes"
			}
		];
	}, [parentCats]);
	const active = tabs.some((item) => item.id === tab) ? tab : "today";
	const activePane = tabs.find((item) => item.id === active)?.pane ?? "today";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.2em] text-primary",
					children: "The table"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-4xl font-medium",
					children: "Talk"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setManage(true),
					children: "Categories"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "-mt-4 max-w-xl text-sm text-muted-foreground",
				children: "One shared card each day, a weekly try-or-pass, quizzes that follow your experience, kink inventories, fantasies, and issues. On a relevant prompt, More info opens the matching Education and Activities notes."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: tabs.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab(item.id),
					className: cn("h-10 rounded-full px-4 text-sm", active === item.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
					children: item.label
				}, item.id))
			}),
			activePane === "today" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DailyQuestion, {
				me,
				answers: answersFor(`daily:${dayKey()}`),
				onRemember: remember
			}) : null,
			activePane === "week" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThisWeekBoard, {
				me,
				answers,
				onSave: save
			}) : null,
			activePane === "kinks" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KinkBoard, {
				me,
				answers,
				onSave: save
			}) : null,
			activePane === "quizzes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizBoard, {
				me,
				answers,
				onSave: save,
				onQuizSaved: (row) => setAnswers((prev) => {
					return [row, ...prev.filter((item) => !(item.topic === row.topic && item.userId === row.userId))];
				})
			}) : null,
			activePane === "entries" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindPage, {
				kind: "talk",
				hideHeader: true,
				initialFilter: active
			}, active) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryManager, {
				kind: "talk",
				open: manage,
				cats,
				onClose: () => setManage(false),
				onChange: setCats
			})
		]
	});
}
function DailyQuestion({ me, answers, onRemember }) {
	const card = todaysCard();
	const topic = `daily:${card.date}`;
	const mine = answers.find((a) => a.userId === me?.profile?.userId);
	const theirs = answers.find((a) => a.userId === me?.partner?.userId);
	const [text, setText] = (0, import_react.useState)(mine?.body ?? "");
	const dirty = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (dirty.current) return;
		setText(mine?.body ?? "");
	}, [mine?.body]);
	const saveStatus = useAutoSave(text, async () => {
		onRemember(await saveTalkAnswer({ data: {
			topic,
			body: text
		} }));
	}, {
		delay: 600,
		resetKey: topic
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-xl rounded-[28px] border border-ivory/15 bg-ivory px-8 py-10 text-ink shadow-soft",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 text-[11px] font-medium uppercase tracking-[0.22em] text-oxblood",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Today's card" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						card.number,
						" / ",
						card.total
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-6 font-display text-3xl font-medium leading-tight text-ink sm:text-4xl",
					children: card.prompt
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-sm text-ink/60",
					children: "Same prompt for both of you today. Answers stay between you."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoreInfoButton, {
						text: card.prompt,
						tone: "onIvory"
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border border-border bg-card p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichEditor, {
					value: text,
					onChange: (value) => {
						dirty.current = true;
						setText(value);
					},
					placeholder: "Your answer — private to the two of you."
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveHint, { status: saveStatus })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnswerCard, {
						label: "You",
						body: text || mine?.body
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnswerCard, {
						label: me?.partner?.displayName || "Partner",
						body: theirs?.body,
						empty: me?.partner ? "Waiting for them." : "Connect a partner to see both sides."
					})]
				})
			]
		})]
	});
}
function weekContext(me) {
	const week = talkWeekKey();
	return {
		week,
		level: coupleLevel(me?.profile?.experience, me?.partner?.experience),
		seed: weeklySeed(me?.profile?.bondId || me?.profile?.userId || "solo", week),
		role: me?.profile?.role ?? "switch",
		kinks: [.../* @__PURE__ */ new Set([...me?.profile?.kinks ?? [], ...me?.partner?.kinks ?? []])],
		solo: !me?.partner
	};
}
function ThisWeekBoard({ me, answers, onSave }) {
	const { week, level, seed, role, kinks, solo } = weekContext(me);
	const prompts = (0, import_react.useMemo)(() => weeklyTryPrompts(level, seed, role, kinks, solo), [
		level,
		seed,
		role,
		kinks,
		solo
	]);
	const partner = me?.partner ?? null;
	const partnerName = partner?.displayName || partner?.username || "Partner";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm text-muted-foreground",
			children: [
				"Ten prompts for the week of ",
				formatTalkWeek(week),
				" — communication, public play, a scene, a roleplay, a task, a game, training, a reward, a punishment, and a kink from your profile. Written in your ",
				role,
				" voice, at ",
				experienceLabel(level).toLowerCase(),
				" experience",
				kinks.length ? `, using the kinks on your profile${partner?.kinks?.length ? " and theirs" : ""}` : "",
				".",
				" ",
				"Each prompt tells you what to do. Easy, Hard, and Extreme are three versions of the same idea — pick one. Press Try if you will do it this week, or Pass if you will not. They change every Monday.",
				kinks.length ? "" : " Add kinks on your profile to pull these closer to your tastes.",
				solo ? " Written for you alone — every one can be finished without a partner in the room." : partner ? ` You both see the same ten, each in your own role. ${partnerName} can see whether you choose Try or Pass.` : ""
			]
		}), prompts.map((prompt) => {
			const topic = `weektry:${week}:${prompt.kind}`;
			const mine = answers.find((a) => a.topic === topic && a.userId === me?.profile?.userId);
			const theirs = answers.find((a) => a.topic === topic && a.userId === partner?.userId);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-border bg-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-medium uppercase tracking-[0.18em] text-primary",
							children: WEEK_KIND_LABEL[prompt.kind]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoreInfoButton, {
							weekKind: prompt.kind,
							text: `${prompt.title} ${prompt.description}`,
							texts: [
								prompt.easy,
								prompt.hard,
								prompt.extreme
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-2xl",
						children: prompt.title
					}),
					prompt.matchedKinks.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: ["Drawn from ", prompt.matchedKinks.map((item) => tagLabel(item, ALL_KINK_OPTIONS)).join(", ")]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted-foreground",
						children: prompt.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelCard, {
						level: "Easy",
						text: prompt.easy
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelCard, {
						level: "Hard",
						text: prompt.hard
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelCard, {
						level: "Extreme",
						text: prompt.extreme
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: ["try", "pass"].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => void onSave(topic, prompt.title, value, "shared"),
							className: cn("h-10 rounded-full px-4 text-sm", mine?.rating === value ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
							children: value === "try" ? "Try" : "Pass"
						}, value))
					}),
					partner ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TryPassCard, {
							label: "You",
							rating: mine?.rating,
							empty: "Not chosen yet."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TryPassCard, {
							label: partnerName,
							rating: theirs?.rating,
							empty: "Waiting for them."
						})]
					}) : null
				]
			}, prompt.kind);
		})]
	});
}
function LevelCard({ level, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 rounded-lg bg-secondary/70 px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.16em] text-primary",
			children: level
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1.5 text-sm leading-relaxed",
			children: text
		})]
	});
}
function KinkBoard({ me, answers, onSave }) {
	const [custom, setCustom] = (0, import_react.useState)("");
	const extras = (0, import_react.useMemo)(() => {
		const known = new Set(STARTER_KINKS.map((k) => k.slug));
		const found = /* @__PURE__ */ new Map();
		for (const row of answers) {
			if (!row.topic.startsWith("kink:")) continue;
			const slug = row.topic.slice(5);
			if (!known.has(slug)) found.set(slug, row.body || slug);
		}
		return [...found.entries()].map(([slug, label]) => ({
			slug,
			label
		}));
	}, [answers]);
	const list = [...STARTER_KINKS, ...extras];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Mark each yes, maybe, curious, no, or hard limit. Both profiles show on the same row."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: list.map((kink) => {
					const topic = `kink:${kink.slug}`;
					const mine = answers.find((a) => a.topic === topic && a.userId === me?.profile?.userId);
					const theirs = answers.find((a) => a.topic === topic && a.userId === me?.partner?.userId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border bg-card p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: kink.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-end gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoreInfoButton, {
									kinkSlug: kink.slug,
									text: kink.label
								}), theirs?.rating ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										me?.partner?.displayName || "Partner",
										":",
										" ",
										KINK_RATINGS.find((r) => r.value === theirs.rating)?.label ?? theirs.rating
									]
								}) : null]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex flex-wrap gap-1",
							children: KINK_RATINGS.map((rating) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => void onSave(topic, kink.label, rating.value),
								className: cn("h-8 rounded-full px-2.5 text-xs", mine?.rating === rating.value ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
								children: rating.label
							}, rating.value))
						})]
					}, kink.slug);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					if (!custom.trim()) return;
					onSave(`kink:${custom.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 40)}`, custom.trim(), "curious");
					setCustom("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: custom,
					onChange: (e) => setCustom(e.target.value),
					placeholder: "Add a kink",
					className: "h-11 flex-1 rounded-md border border-input bg-secondary px-3 text-sm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Add"
				})]
			})
		]
	});
}
function QuizBoard({ me, answers, onSave, onQuizSaved }) {
	const { week, level, seed } = weekContext(me);
	const quizzes = (0, import_react.useMemo)(() => weeklyQuizzesFor(level, seed), [level, seed]);
	const [open, setOpen] = (0, import_react.useState)(quizzes[0]?.id ?? "love");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Always-on discovery. Take the BDSM test (25-question Quick Quiz or 125-question Full Profile) and love languages. Share the scores with your partner, or keep them private. Individual answers stay with you."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiscoveryQuizzes, {
				answers,
				meId: me?.profile?.userId,
				partnerId: me?.partner?.userId,
				partnerName: me?.partner?.username || me?.partner?.displayName || "Partner",
				onSaved: onQuizSaved
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"Weekly packs — love languages, kink, roleplay, scenes, aftercare, relationship, and communication — four questions each, drawn for ",
					experienceLabel(level).toLowerCase(),
					" experience. New set every Monday at 00:01 UTC (week of ",
					formatTalkWeek(week),
					")."
				]
			}), quizzes.map((quiz) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-border bg-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "w-full text-left",
						onClick: () => setOpen(open === quiz.id ? null : quiz.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap items-start justify-between gap-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl",
								children: quiz.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: quiz.blurb
							})] })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoreInfoButton, {
							quizId: quiz.id,
							text: `${quiz.title} ${quiz.blurb}`,
							texts: quiz.questions.map((item) => item.prompt)
						})
					}),
					open === quiz.id ? quiz.questions.map((q, qi) => {
						const topic = `weekquiz:${week}:${quiz.id}:${qi}`;
						const mine = answers.find((a) => a.topic === topic && a.userId === me?.profile?.userId);
						const theirs = answers.find((a) => a.topic === topic && a.userId === me?.partner?.userId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 border-t border-border pt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium",
										children: q.prompt
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoreInfoButton, {
										quizId: quiz.id,
										text: q.prompt
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 grid gap-1",
									children: q.options.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => void onSave(topic, opt.label, opt.value),
										className: cn("rounded-md border px-3 py-2 text-left text-sm", mine?.rating === opt.value ? "border-primary bg-primary/10" : "border-border"),
										children: opt.label
									}, opt.value))
								}),
								theirs?.body ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-xs text-muted-foreground",
									children: [
										me?.partner?.displayName || "Partner",
										" chose: ",
										theirs.body
									]
								}) : null
							]
						}, topic);
					}) : null
				]
			}, quiz.id))]
		})]
	});
}
function TryPassCard({ label, rating, empty }) {
	const chosen = rating === "try" ? "Try" : rating === "pass" ? "Pass" : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-secondary p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-[0.14em] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("mt-2 text-sm", chosen ? "font-medium" : "text-muted-foreground"),
			children: chosen ?? empty
		})]
	});
}
function AnswerCard({ label, body, empty = "Not answered yet." }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-secondary p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-[0.14em] text-muted-foreground",
			children: label
		}), body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, {
			html: body,
			className: "mt-2"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm",
			children: empty
		})]
	});
}
function Talk() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TalkView, {}) });
}
//#endregion
export { Talk as component };
