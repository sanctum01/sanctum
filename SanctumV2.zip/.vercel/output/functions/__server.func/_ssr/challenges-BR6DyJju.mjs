import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { m as canMutate } from "./format-Dsk7inZY.mjs";
import { i as cn, t as Button } from "./input-CkY6TqOo.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { B as listEntries, P as getMe, b as createEntry, ht as toggleEntry } from "./use-current-user-nzqgiI2T.mjs";
import { n as Badge, t as AppShell, v as useLiveReload } from "./badge-CRftROn_.mjs";
import { a as KindPage } from "./kind-page-GHqW5OYA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/challenges-BR6DyJju.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SHARED = [
	"Name one need out loud before noon.",
	"Hold eye contact for a full minute.",
	"Write three lines about yesterday's dynamic.",
	"Practice the safeword and aftercare check together.",
	"Do one act of service without being asked.",
	"Photograph something that belongs to the dynamic.",
	"Sit in protocol posture for five minutes.",
	"Send one voice note of praise or thanks.",
	"Review one limit and confirm it still holds.",
	"Choose a word of the day and use it on purpose.",
	"Stretch and check in with your body before play.",
	"Read last week's journal page and mark one growth.",
	"Leave a note your partner will find later.",
	"Practice a cue or command until it is clean.",
	"Drink water and pause before any scene talk."
];
var DOMINANT = [
	"Set one clear expectation for tonight.",
	"Give specific praise for something they did well.",
	"Check their calendar and adjust one duty if needed.",
	"Hold a five-minute inspection or posture check.",
	"Write a short protocol they can keep.",
	"Name a reward that is actually available.",
	"Ask what would make them feel chosen today.",
	"Correct one small thing with care, not heat.",
	"Plan aftercare before you plan intensity.",
	"Let them hear that you are proud, in detail."
];
var SUBMISSIVE = [
	"Offer a report of how you slept and how you feel.",
	"Complete one open duty before you ask for play.",
	"Practice kneeling or waiting posture for three minutes.",
	"Ask for what you need in one clean sentence.",
	"Tidy one thing that belongs to service.",
	"Wear or carry a reminder of your role today.",
	"Thank them for a specific instruction.",
	"Journal a drop or a high without editing it pretty.",
	"Ask permission for one small pleasure.",
	"Repeat a rule back in your own words."
];
function challengesFor(role, monthKey) {
	const extra = role === "dominant" ? DOMINANT : role === "submissive" ? SUBMISSIVE : [...DOMINANT, ...SUBMISSIVE];
	const pool = [...SHARED, ...extra];
	const seed = monthKey.split("").reduce((n, ch) => n + ch.charCodeAt(0), role === "dominant" ? 11 : role === "switch" ? 19 : 29);
	const days = daysInMonth(monthKey);
	const out = [];
	for (let day = 1; day <= days; day += 1) {
		const index = (seed * 17 + day * 13) % pool.length;
		out.push({
			day,
			title: pool[index] ?? SHARED[0]
		});
	}
	return out;
}
function monthKey(date = /* @__PURE__ */ new Date()) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}
function daysInMonth(key) {
	const [y, m] = key.split("-").map(Number);
	return new Date(y, m, 0).getDate();
}
function monthLabel(key) {
	const [y, m] = key.split("-").map(Number);
	return new Intl.DateTimeFormat(void 0, {
		month: "long",
		year: "numeric"
	}).format(new Date(y, m - 1, 1));
}
function ChallengesView() {
	const [me, setMe] = (0, import_react.useState)(null);
	const [rows, setRows] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const month = monthKey();
	const load = (0, import_react.useCallback)(async () => {
		const [mine, list] = await Promise.all([getMe(), listEntries({ data: { kind: "challenge" } })]);
		setMe(mine);
		const mineMonth = list.filter((item) => item.meta.month === month);
		setRows(mineMonth);
		return {
			mine,
			list: mineMonth
		};
	}, [month]);
	(0, import_react.useEffect)(() => {
		load().catch((err) => {
			toast.error(err instanceof Error ? err.message : "Could not load challenges.");
		});
	}, [load]);
	useLiveReload(load);
	async function seed() {
		if (!me?.profile) return;
		setBusy(true);
		try {
			const items = challengesFor(me.profile.role, month);
			for (const item of items) await createEntry({ data: {
				kind: "challenge",
				title: `Day ${item.day} · ${item.title}`,
				body: item.title,
				cadence: "daily",
				status: "open",
				meta: {
					month,
					day: String(item.day)
				}
			} });
			toast.success("This month's challenges are ready.");
			await load();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not set the month.");
		} finally {
			setBusy(false);
		}
	}
	async function toggle(entry) {
		try {
			const updated = await toggleEntry({ data: {
				id: entry.id,
				done: entry.effectiveStatus !== "done"
			} });
			setRows((prev) => prev.map((item) => item.id === updated.id ? updated : item));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not update.");
		}
	}
	const today = (/* @__PURE__ */ new Date()).getDate();
	const done = rows.filter((item) => item.effectiveStatus === "done").length;
	const todayRow = rows.find((item) => Number(item.meta.day) === today);
	const allowed = canMutate(me, "challenge");
	const ordered = (0, import_react.useMemo)(() => [...rows].sort((a, b) => Number(a.meta.day ?? 0) - Number(b.meta.day ?? 0)), [rows]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.2em] text-primary",
						children: "The month"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-4xl font-medium",
						children: "Challenges"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 max-w-xl text-sm text-muted-foreground",
						children: [
							"Daily practice for ",
							monthLabel(month),
							", plus challenges you assign each other."
						]
					})
				] }), rows.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: [
					done,
					"/",
					rows.length,
					" kept"
				] }) : allowed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void seed(),
					disabled: busy,
					children: busy ? "Setting…" : "Set this month"
				}) : null]
			}),
			todayRow ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-border bg-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
						children: ["Today · Day ", today]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-2xl",
						children: todayRow.body || todayRow.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						variant: todayRow.effectiveStatus === "done" ? "secondary" : "default",
						onClick: () => void toggle(todayRow),
						children: todayRow.effectiveStatus === "done" ? "Done — reopen" : "Mark done"
					})
				]
			}) : null,
			ordered.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "space-y-2",
				children: ordered.map((item) => {
					const day = Number(item.meta.day ?? 0);
					const isToday = day === today;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void toggle(item),
						className: cn("flex w-full items-start gap-3 rounded-xl border px-4 py-3 text-left", item.effectiveStatus === "done" ? "border-border bg-secondary/50 text-muted-foreground" : isToday ? "border-primary bg-primary/10" : "border-border bg-card"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-8 shrink-0 font-display text-xl tabular-nums",
								children: day
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 text-sm",
								children: item.body || item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs uppercase tracking-[0.12em] text-muted-foreground",
								children: item.effectiveStatus === "done" ? "Kept" : isToday ? "Today" : "Open"
							})
						]
					}) }, item.id);
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-border bg-card px-4 py-8 text-center text-sm text-muted-foreground",
				children: "Set the month for a daily practice, or assign a challenge to your partner below."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Assigned"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: me?.partner ? `Give ${me.partner.displayName || "your partner"} — or both of you — a challenge to keep.` : "Connect a partner to assign challenges to each other. You can still write one for yourself."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindPage, {
					kind: "challenge",
					hideHeader: true,
					entryFilter: (entry) => !entry.meta.month
				})]
			})
		]
	});
}
function Challenges() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChallengesView, {}) });
}
//#endregion
export { Challenges as component };
