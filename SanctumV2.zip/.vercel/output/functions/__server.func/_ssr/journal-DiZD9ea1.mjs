import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { C as fillSelectOptions, D as formatWhen, M as intensityMarks, N as isArchivedEntry, o as KINDS } from "./format-Dsk7inZY.mjs";
import { i as cn, t as Button } from "./input-CkY6TqOo.mjs";
import { A as Lock, b as Plus, rt as Archive, s as Trash2 } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { B as listEntries, C as deleteEntry, P as getMe, V as listJournalComments, _t as updateEntry, c as PhotoSourceButtons, ft as stageFiles, l as PhotoStrip, m as addJournalComment, n as Lightbox, o as PendingMediaTray, w as deleteJournalComment } from "./use-current-user-nzqgiI2T.mjs";
import { f as RichEditor, n as Badge, p as RichText, t as AppShell, v as useLiveReload } from "./badge-CRftROn_.mjs";
import { n as EmptyState, r as EntryForm, s as PdfStrip } from "./kind-page-GHqW5OYA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/journal-DiZD9ea1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CONFIG = fillSelectOptions(KINDS.journal);
function JournalView() {
	const [entries, setEntries] = (0, import_react.useState)([]);
	const [comments, setComments] = (0, import_react.useState)([]);
	const [me, setMe] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [editing, setEditing] = (0, import_react.useState)(void 0);
	const [lightbox, setLightbox] = (0, import_react.useState)(null);
	const load = (0, import_react.useCallback)(async () => {
		try {
			const [rows, notes, mine] = await Promise.all([
				listEntries({ data: { kind: "journal" } }),
				listJournalComments(),
				getMe()
			]);
			setEntries(rows);
			setComments(notes);
			setMe(mine);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not load the journal.");
		} finally {
			setLoading(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		load();
	}, [load]);
	useLiveReload(load);
	const visible = (0, import_react.useMemo)(() => {
		return entries.filter((item) => {
			const archived = isArchivedEntry(item);
			if (filter === "archived") return archived;
			if (archived) return false;
			const vis = item.meta.visibility === "private" ? "private" : "shared";
			if (filter === "all") return true;
			return vis === filter;
		});
	}, [entries, filter]);
	const names = {};
	if (me?.profile) names[me.profile.userId] = me.profile.displayName || "Me";
	if (me?.partner) names[me.partner.userId] = me.partner.displayName || "Partner";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.2em] text-primary",
						children: CONFIG.kicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-4xl font-medium",
						children: CONFIG.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-sm text-muted-foreground",
						children: CONFIG.blurb
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setEditing(null),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), CONFIG.addLabel]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: [
					"all",
					"shared",
					"private",
					"archived"
				].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(value),
					className: cn("h-9 rounded-full px-3 text-sm capitalize", filter === value ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
					children: value
				}, value))
			}),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: [0, 1].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-xl bg-card" }, i))
			}) : visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: CONFIG.emptyTitle,
				body: CONFIG.emptyBody,
				action: CONFIG.addLabel,
				onAction: () => setEditing(null)
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-4",
				children: visible.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JournalCard, {
					entry,
					comments: comments.filter((item) => item.entryId === entry.id),
					names,
					me,
					onOpen: () => setEditing(entry),
					onPhoto: setLightbox,
					onComments: setComments,
					onBody: (html) => {
						updateEntry({ data: {
							id: entry.id,
							kind: "journal",
							body: html
						} }).then((updated) => {
							setEntries((prev) => prev.map((item) => item.id === updated.id ? updated : item));
						}).catch((err) => toast.error(err instanceof Error ? err.message : "Could not update."));
					},
					onArchive: () => {
						const next = entry.status === "archived" ? "open" : "archived";
						updateEntry({ data: {
							id: entry.id,
							kind: "journal",
							status: next
						} }).then((updated) => {
							setEntries((prev) => prev.map((item) => item.id === updated.id ? updated : item));
						}).catch((err) => toast.error(err instanceof Error ? err.message : "Could not archive."));
					},
					onDelete: () => {
						if (typeof window !== "undefined" && !window.confirm(`Delete “${entry.title}”? This cannot be undone.`)) return;
						deleteEntry({ data: { id: entry.id } }).then(() => setEntries((prev) => prev.filter((item) => item.id !== entry.id))).catch((err) => toast.error(err instanceof Error ? err.message : "Could not delete."));
					}
				}, entry.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntryForm, {
				config: CONFIG,
				entry: editing ?? void 0,
				open: editing !== void 0,
				onOpenChange: (open) => {
					if (!open) setEditing(void 0);
				},
				onSaved: (entry, removed) => {
					setEntries((prev) => {
						if (removed) return prev.filter((item) => item.id !== entry.id);
						return prev.some((item) => item.id === entry.id) ? prev.map((item) => item.id === entry.id ? entry : item) : [entry, ...prev];
					});
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbox, {
				src: lightbox,
				onClose: () => setLightbox(null)
			})
		]
	});
}
function JournalCard({ entry, comments, names, me, onOpen, onPhoto, onComments, onBody, onArchive, onDelete }) {
	const shared = entry.meta.visibility !== "private";
	const [body, setBody] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const author = names[entry.createdBy] ?? "Someone";
	const canComment = shared && Boolean(me?.profile);
	async function send() {
		const media = pending[0];
		if (!body.trim() && !media) return;
		setBusy(true);
		try {
			const created = await addJournalComment({ data: {
				entryId: entry.id,
				body: body.trim(),
				photoData: media?.data ?? null
			} });
			onComments((prev) => [...prev, created]);
			setBody("");
			setPending([]);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not comment.");
		} finally {
			setBusy(false);
		}
	}
	async function remove(id) {
		try {
			await deleteJournalComment({ data: { id } });
			onComments((prev) => prev.filter((item) => item.id !== id));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not delete.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "overflow-hidden rounded-xl border border-border bg-card",
		children: [
			entry.photos[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "block w-full",
				onClick: () => onPhoto(entry.photos[0]),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: entry.photos[0],
					alt: "",
					className: "h-52 w-full object-cover"
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onOpen,
							className: "text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl font-medium leading-snug",
								children: entry.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs uppercase tracking-[0.14em] text-muted-foreground",
								children: [author, entry.meta.mood ? ` · ${entry.meta.mood}` : ""]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: shared ? "default" : "muted",
							children: shared ? "Shared" : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3" }), "Private"]
							})
						})]
					}),
					entry.body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, {
						html: entry.body,
						onChange: onBody
					}) : null,
					entry.intensity ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-1",
						"aria-label": `Charge ${entry.intensity}`,
						children: intensityMarks(entry.intensity).map((on, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2 rounded-full", on ? "bg-primary" : "bg-border") }, i))
					}) : null,
					entry.photos.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoStrip, {
						photos: entry.photos.slice(1),
						onOpen: onPhoto
					}) : null,
					entry.pdfs?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PdfStrip, { pdfs: entry.pdfs }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: formatWhen(entry.createdAt)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: onOpen,
									children: "Edit"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: onArchive,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { className: "size-3.5" }), entry.status === "archived" ? "Restore" : "Archive"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: onDelete,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), "Delete"]
								})
							]
						})]
					})
				]
			}),
			shared ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs uppercase tracking-[0.14em] text-muted-foreground",
						children: ["Comments ", comments.length ? `· ${comments.length}` : ""]
					}),
					comments.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-3",
						children: comments.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-lg bg-secondary/70 p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs uppercase tracking-[0.12em] text-muted-foreground",
										children: names[item.authorId] ?? "Partner"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] text-muted-foreground",
										children: formatWhen(item.createdAt)
									})]
								}),
								item.body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, {
									html: item.body,
									className: "mt-1"
								}) : null,
								item.photoData ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "mt-2 block",
									onClick: () => onPhoto(item.photoData),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: item.photoData,
										alt: "",
										className: "h-28 rounded-md object-cover"
									})
								}) : null,
								item.authorId === me?.profile?.userId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "mt-2 text-xs text-muted-foreground",
									onClick: () => void remove(item.id),
									children: "Remove"
								}) : null
							]
						}, item.id))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: me?.partner ? "No comments yet. Your partner can answer this page." : "No comments yet. Write one, or connect a partner to share the page."
					}),
					canComment ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichEditor, {
								value: body,
								onChange: setBody,
								placeholder: "A comment on this page",
								compact: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoSourceButtons, {
								onFiles: async (files) => {
									try {
										const staged = await stageFiles(files, {
											allowImage: true,
											max: 1
										});
										if (!staged.length) {
											toast.error("Choose a photo from your gallery.");
											return;
										}
										setPending(staged.slice(0, 1));
									} catch (err) {
										toast.error(err instanceof Error ? err.message : "Could not attach that photo.");
									}
								},
								busy
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendingMediaTray, {
								items: pending,
								onRemove: () => setPending([]),
								onCommit: () => void send(),
								onDiscard: () => setPending([]),
								commitLabel: "Send",
								busy
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								size: "sm",
								onClick: () => void send(),
								disabled: busy || !body.trim() && !pending.length,
								children: busy ? "Sending…" : "Send"
							})
						]
					}) : null
				]
			}) : null
		]
	});
}
function Journal() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JournalView, {}) });
}
//#endregion
export { Journal as component };
