import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as authClient } from "./client-CVqXY6bk.mjs";
import { n as Input, r as Label, t as Button } from "./input-CkY6TqOo.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reset-password-uJ_DV9z1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TOKEN_KEY = "sanctum-reset-token";
function readHeldToken() {
	if (typeof window === "undefined") return "";
	const fromQuery = new URLSearchParams(window.location.search).get("token") ?? "";
	if (fromQuery) {
		try {
			window.sessionStorage.setItem(TOKEN_KEY, fromQuery);
		} catch {}
		return fromQuery;
	}
	try {
		return window.sessionStorage.getItem(TOKEN_KEY) ?? "";
	} catch {
		return "";
	}
}
function ResetPassword() {
	const [token, setToken] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [ready, setReady] = (0, import_react.useState)(false);
	const [password, setPassword] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setToken(readHeldToken());
		setError(new URLSearchParams(window.location.search).get("error") ?? "");
		setReady(true);
	}, []);
	const invalid = Boolean(error) || !token;
	async function submit(event) {
		event.preventDefault();
		if (!token) {
			toast.error("This reset link is missing its key. Ask for a new one.");
			return;
		}
		if (password !== confirm) {
			toast.error("The two passwords do not match.");
			return;
		}
		setBusy(true);
		try {
			const { error: resetError } = await authClient.$fetch("/reset-password", {
				method: "POST",
				body: {
					newPassword: password,
					token
				}
			});
			if (resetError) throw new Error(resetError.message ?? "Could not reset the password.");
			try {
				window.sessionStorage.removeItem(TOKEN_KEY);
			} catch {}
			setDone(true);
			toast.success("Password updated. Sign in with the new one.");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not reset the password.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "relative min-h-dvh overflow-hidden bg-background vignette chamber-grid",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh w-full max-w-md flex-col px-5 py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl tracking-tight",
					children: "Sanctum"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-8 font-display text-4xl",
					children: "Choose a new password"
				}),
				!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: "Opening the reset link…"
				}) : done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: "Your door is locked with the new password. Sign in to continue."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						children: "Sign in"
					})
				})] }) : invalid ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: "This reset link is invalid or has expired. Ask for a new one from the sign-in page."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						children: "Back to sign in"
					})
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: "Pick a new password for this door. At least 8 characters."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-6 space-y-3",
					onSubmit: (e) => void submit(e),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "block space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "new-password",
								children: "New password"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "new-password",
								type: "password",
								required: true,
								minLength: 8,
								autoComplete: "new-password",
								value: password,
								onChange: (e) => setPassword(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "block space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "confirm-password",
								children: "Confirm password"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "confirm-password",
								type: "password",
								required: true,
								minLength: 8,
								autoComplete: "new-password",
								value: confirm,
								onChange: (e) => setConfirm(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							className: "w-full",
							disabled: busy || false,
							children: busy ? "Please wait…" : "Save password"
						})
					]
				})] })
			]
		})
	});
}
//#endregion
export { ResetPassword as component };
