import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as AppShell } from "./badge-CRftROn_.mjs";
import { a as KindPage } from "./kind-page-GHqW5OYA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tasks-C8AkQmWk.js
var import_jsx_runtime = require_jsx_runtime();
function Tasks() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindPage, {
		kind: "task",
		defaultCadence: "daily",
		entryFilter: (entry) => entry.cadence !== "habit",
		blurb: "Daily, weekly, custom-day, and one-off assignments — either of you can write them.",
		emptyBody: "Set the first daily, weekly, or custom assignment."
	}) });
}
//#endregion
export { Tasks as component };
