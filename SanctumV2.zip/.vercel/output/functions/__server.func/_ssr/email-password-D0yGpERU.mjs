import { r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/email-password-D0yGpERU.js
var email_password_D0yGpERU_exports = /* @__PURE__ */ __exportAll({
	n: () => sendResetPassword,
	t: () => email_password_exports
});
var email_password_exports = /* @__PURE__ */ __exportAll$1({
	emailAndPasswordEnabled: () => true,
	sendResetPassword: () => sendResetPassword,
	takePreviewResetUrl: () => takePreviewResetUrl
});
var previewResetRef = globalThis;
function previewResetLinks() {
	previewResetRef.__sanctumPreviewResetLinks__ ??= /* @__PURE__ */ new Map();
	return previewResetRef.__sanctumPreviewResetLinks__;
}
function takePreviewResetUrl(email) {
	const key = email.trim().toLowerCase();
	const url = previewResetLinks().get(key) ?? null;
	if (url) previewResetLinks().delete(key);
	return url;
}
function stashPreviewResetUrl(email, url) {
	previewResetLinks().set(email.trim().toLowerCase(), url);
}
function escapeHtml(value) {
	const amp = ["&", "amp;"].join("");
	const lt = ["&", "lt;"].join("");
	const gt = ["&", "gt;"].join("");
	const quot = ["&", "quot;"].join("");
	return value.replace(/[&<>"']/g, (char) => {
		if (char === "&") return amp;
		if (char === "<") return lt;
		if (char === ">") return gt;
		if (char === "\"") return quot;
		return "&#39;";
	});
}
function resetEmailCopy(name, url) {
	const who = name.trim() || "there";
	const safeWho = escapeHtml(who);
	const safeUrl = escapeHtml(url);
	return {
		subject: "Reset your Sanctum password",
		text: [
			`Hi ${who},`,
			"",
			"Someone asked to reset the Sanctum password for this email.",
			"Use this link to choose a new one. It expires in one hour.",
			"",
			url,
			"",
			"If you did not ask for this, you can ignore the email — your password stays the same."
		].join("\n"),
		html: [
			"<!doctype html>",
			"<html>",
			"  <body style=\"font-family: Georgia, serif; background:#0c0a0b; color:#f3ece6; padding:32px;\">",
			"    <div style=\"max-width:480px;margin:0 auto;background:#1c1718;border:1px solid rgba(243,236,230,0.12);padding:28px;\">",
			"      <p style=\"letter-spacing:0.2em;text-transform:uppercase;font-size:11px;color:#c4b4a8;margin:0 0 16px;\">Sanctum</p>",
			"      <h1 style=\"font-size:28px;margin:0 0 12px;\">Reset your password</h1>",
			`      <p style="line-height:1.5;color:#d7cbc2;">Hi ${safeWho}. Someone asked to reset the Sanctum password for this email. The link below expires in one hour.</p>`,
			`      <p style="margin:24px 0;"><a href="${safeUrl}" style="display:inline-block;background:#c4a484;color:#1c1718;text-decoration:none;padding:12px 18px;">Choose a new password</a></p>`,
			`      <p style="font-size:13px;color:#c4b4a8;line-height:1.5;">If the button does not work, paste this into your browser:<br/>${safeUrl}</p>`,
			"      <p style=\"font-size:13px;color:#c4b4a8;\">If you did not ask for this, ignore the email. Your password stays the same.</p>",
			"    </div>",
			"  </body>",
			"</html>"
		].join("\n")
	};
}
function parseFrom(raw) {
	const match = raw.match(/^(.*)<([^>]+)>$/);
	if (!match) return {
		email: raw,
		name: "Sanctum"
	};
	return {
		name: match[1].trim().replace(/^"|"$/g, "") || "Sanctum",
		email: match[2].trim()
	};
}
async function sendResetEmail(to, name, url) {
	const { subject, text, html } = resetEmailCopy(name, url);
	const from = parseFrom(process.env.EMAIL_FROM?.trim() || "Sanctum <noreply@mail.sanctum.app>");
	const resend = process.env.RESEND_API_KEY?.trim();
	if (resend) {
		const res = await fetch("https://api.resend.com/emails", {
			method: "POST",
			headers: {
				Authorization: `Bearer ${resend}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				from: `${from.name} <${from.email}>`,
				to,
				subject,
				html,
				text
			})
		});
		if (!res.ok) console.error("[reset-password] Resend failed", await res.text());
		return;
	}
	const sendgrid = process.env.SENDGRID_API_KEY?.trim();
	if (sendgrid) {
		const res = await fetch("https://api.sendgrid.com/v3/mail/send", {
			method: "POST",
			headers: {
				Authorization: `Bearer ${sendgrid}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				personalizations: [{ to: [{ email: to }] }],
				from: {
					email: from.email,
					name: from.name
				},
				subject,
				content: [{
					type: "text/plain",
					value: text
				}, {
					type: "text/html",
					value: html
				}]
			})
		});
		if (!res.ok) console.error("[reset-password] SendGrid failed", await res.text());
	}
}
async function sendResetPassword(data, _request) {
	let appUrl = data.url;
	try {
		appUrl = `${new URL(data.url).origin}/reset-password?token=${encodeURIComponent(data.token)}`;
	} catch {
		appUrl = data.url;
	}
	stashPreviewResetUrl(data.user.email, appUrl);
	try {
		await sendResetEmail(data.user.email, data.user.name || "there", appUrl);
	} catch (error) {
		console.error("[reset-password] send failed", error);
	}
}
//#endregion
export { sendResetPassword as n, email_password_D0yGpERU_exports as t };
