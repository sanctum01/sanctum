//#region node_modules/.nitro/vite/services/ssr/assets/sort-CKxFQEP9.js
var PDF_META_KEY = "_pdfs";
function isPdfFile(file) {
	if (file.type === "application/pdf") return true;
	return /\.pdf$/i.test(file.name);
}
function parsePdfs(raw) {
	if (!raw) return [];
	try {
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return [];
		return parsed.filter((item) => Boolean(item && typeof item === "object" && typeof item.name === "string" && typeof item.data === "string" && item.data.startsWith("data:"))).slice(0, 3).map((item) => ({
			name: item.name.replace(/[^\w.\- ()]+/g, "").slice(0, 80) || "document.pdf",
			data: item.data
		}));
	} catch {
		return [];
	}
}
function encodePdfs(list) {
	return JSON.stringify(list.slice(0, 3).map((item) => ({
		name: item.name.slice(0, 80),
		data: item.data
	})));
}
function applyPdfs(meta, pdfs) {
	const next = { ...meta };
	if (!pdfs.length) delete next[PDF_META_KEY];
	else next[PDF_META_KEY] = encodePdfs(pdfs);
	return next;
}
function readAsDataUrl(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => {
			if (typeof reader.result === "string") resolve(reader.result);
			else reject(/* @__PURE__ */ new Error("Could not read that PDF."));
		};
		reader.onerror = () => reject(/* @__PURE__ */ new Error("Could not read that PDF."));
		reader.readAsDataURL(file);
	});
}
async function readPdfFile(file) {
	if (!isPdfFile(file)) throw new Error("Choose a PDF file.");
	if (file.size > 2e6) throw new Error("Each PDF needs to be under 2 MB.");
	const data = await readAsDataUrl(file);
	if (!data.startsWith("data:")) throw new Error("Could not read that PDF.");
	return {
		name: `${(file.name.replace(/\.pdf$/i, "").trim() || "document").slice(0, 72)}.pdf`,
		data
	};
}
var SHOP_KINDS = [
	"reward",
	"scene",
	"roleplay",
	"game"
];
var COUNTED_KINDS = [
	"punishment",
	"reward",
	"scene",
	"roleplay",
	"game"
];
function isShopKind(kind) {
	return SHOP_KINDS.includes(kind);
}
function isCountedKind(kind) {
	return COUNTED_KINDS.includes(kind);
}
function countWord(kind) {
	if (kind === "punishment") return "earned";
	if (kind === "reward") return "given";
	if (kind === "scene") return "run";
	if (kind === "roleplay") return "played";
	if (kind === "game") return "played";
	return "times";
}
function parseIdList(raw) {
	if (!raw) return [];
	return raw.split(/[, ]+/).map((value) => Number(value.trim())).filter((n) => Number.isInteger(n) && n > 0);
}
function parsePoints(raw) {
	if (raw == null || raw === "") return null;
	const n = Number(raw);
	if (!Number.isFinite(n)) return null;
	return Math.trunc(n);
}
function shopCost(meta) {
	const n = parsePoints(meta?.cost);
	if (n == null || n <= 0) return null;
	return n;
}
function isBought(meta) {
	return Boolean(meta?.boughtBy);
}
function earnedCountOf(meta) {
	const n = Number(meta?.earnedCount);
	if (!Number.isFinite(n) || n < 0) return 0;
	return Math.trunc(n);
}
function shopBuyLabel(kind, cost) {
	if (kind === "scene") return `Book · ${cost} pts`;
	if (kind === "game") return `Play · ${cost} pts`;
	return `Buy · ${cost} pts`;
}
function stakesModeOf(meta) {
	const mode = meta.stakesMode;
	if (mode === "points" || mode === "items" || mode === "punishments" || mode === "both" || mode === "none") return mode;
	const hasPoints = parsePoints(meta.points) != null || parsePoints(meta.skipPoints) != null;
	const hasRewards = parseIdList(meta.rewardIds).length > 0;
	const hasPunishments = parseIdList(meta.punishmentIds).length > 0;
	if (hasPoints && (hasRewards || hasPunishments)) return "both";
	if (hasPoints) return "points";
	if (hasRewards && hasPunishments) return "both";
	if (hasRewards) return "items";
	if (hasPunishments) return "punishments";
	return "none";
}
function usesPoints(mode) {
	return mode === "points" || mode === "both";
}
function usesRewards(mode) {
	return mode === "items" || mode === "both";
}
function usesPunishments(mode) {
	return mode === "punishments" || mode === "both";
}
function outcomeMessage(previous, next) {
	const wasDone = previous.effectiveStatus === "done";
	const nowDone = next.effectiveStatus === "done";
	if (!wasDone && nowDone) {
		const pts = parsePoints(next.meta.points);
		const bits = [];
		if (pts) bits.push(`${pts > 0 ? "+" : ""}${pts} points`);
		if (next.meta.rewardTitles) bits.push(`reward: ${next.meta.rewardTitles}`);
		if (bits.length) return {
			tone: "success",
			text: bits.join(" · ")
		};
		return null;
	}
	if (previous.status !== "skipped" && next.status === "skipped") {
		const pts = parsePoints(next.meta.skipPoints);
		const bits = [];
		if (pts) bits.push(`${pts > 0 ? "+" : ""}${pts} points`);
		if (next.meta.punishmentTitles) bits.push(`punishment: ${next.meta.punishmentTitles}`);
		if (bits.length) return {
			tone: "message",
			text: bits.join(" · ")
		};
	}
	return null;
}
var COUNTDOWN_KINDS = [
	"task",
	"challenge",
	"punishment",
	"reward",
	"roleplay",
	"game",
	"scene"
];
function usesCountdown(kind, cadence) {
	if (kind === "task" && cadence === "habit") return false;
	return COUNTDOWN_KINDS.includes(kind);
}
function countdownMode(kind) {
	if (kind === "task" || kind === "challenge" || kind === "punishment") return "ends";
	if (kind === "reward" || kind === "roleplay" || kind === "game" || kind === "scene") return "starts";
	return null;
}
function parseCountdown(meta) {
	const days = clampInt(meta.countdownDays, 0, 365);
	const hours = clampInt(meta.countdownHours, 0, 23);
	const minutes = clampInt(meta.countdownMinutes, 0, 59);
	return {
		days,
		hours,
		minutes,
		total: days * 86400 + hours * 3600 + minutes * 60
	};
}
function countdownAnchor(entry) {
	return entry.meta.countdownAnchor || entry.createdAt;
}
function remainingSeconds(entry, now = /* @__PURE__ */ new Date()) {
	if (!usesCountdown(entry.kind, entry.cadence)) return null;
	if (entry.status === "archived" || entry.effectiveStatus === "archived") return null;
	if (entry.effectiveStatus === "done" || entry.status === "done") return null;
	const { total } = parseCountdown(entry.meta);
	if (total <= 0) return null;
	const start = new Date(countdownAnchor(entry)).getTime();
	if (!Number.isFinite(start)) return null;
	return Math.floor((start + total * 1e3 - now.getTime()) / 1e3);
}
function formatCountdown(seconds) {
	const overdue = seconds < 0;
	const abs = Math.abs(seconds);
	const days = Math.floor(abs / 86400);
	const hours = Math.floor(abs % 86400 / 3600);
	const minutes = Math.floor(abs % 3600 / 60);
	const secs = abs % 60;
	const clock = days > 0 ? `${days}d ${hours}h ${String(minutes).padStart(2, "0")}m` : hours > 0 ? `${hours}h ${String(minutes).padStart(2, "0")}m` : `${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
	return overdue ? `Overdue ${clock}` : clock;
}
function countdownLabel(entry, now = /* @__PURE__ */ new Date()) {
	const left = remainingSeconds(entry, now);
	if (left == null) return null;
	const mode = countdownMode(entry.kind);
	const clock = formatCountdown(left);
	if (left < 0) return mode === "starts" ? `Should have started · ${clock}` : clock;
	return mode === "starts" ? `Starts in ${clock}` : `Ends in ${clock}`;
}
function clampInt(raw, min, max) {
	const n = Number(raw);
	if (!Number.isFinite(n)) return 0;
	return Math.min(max, Math.max(min, Math.trunc(n)));
}
function byTitle(a, b) {
	const left = (a.title ?? a.name ?? "").trim();
	const right = (b.title ?? b.name ?? "").trim();
	return left.localeCompare(right, void 0, { sensitivity: "base" });
}
function sortOrderOf(item) {
	if (typeof item.sortOrder === "number" && Number.isFinite(item.sortOrder) && item.sortOrder !== 0) return item.sortOrder;
	const raw = item.meta?.sortOrder;
	const n = raw ? Number(raw) : 0;
	return Number.isFinite(n) ? n : 0;
}
function sortNamed(items) {
	return [...items].sort((a, b) => {
		const ao = sortOrderOf(a);
		const bo = sortOrderOf(b);
		if (ao !== bo) return ao - bo;
		return byTitle(a, b);
	});
}
function parseCustomDays(raw) {
	if (!raw) return [];
	return raw.split(/[, ]+/).map((value) => Number(value.trim())).filter((n) => Number.isInteger(n) && n >= 0 && n <= 6);
}
function encodeCustomDays(days) {
	return [...new Set(days)].sort((a, b) => a - b).join(",");
}
function isDueToday(entry, now = /* @__PURE__ */ new Date()) {
	const cadence = entry.cadence ?? "";
	if (cadence === "weekly") return entry.weekday == null || entry.weekday === now.getDay();
	if (cadence === "custom") {
		const days = parseCustomDays(entry.meta?.customDays);
		if (!days.length) return true;
		return days.includes(now.getDay());
	}
	return true;
}
var URGENCY = [
	{
		value: "low",
		label: "Low"
	},
	{
		value: "normal",
		label: "Normal"
	},
	{
		value: "high",
		label: "High"
	},
	{
		value: "urgent",
		label: "Urgent"
	}
];
function urgencyOf(meta) {
	const value = meta?.urgency;
	if (value === "low" || value === "high" || value === "urgent") return value;
	return "normal";
}
//#endregion
export { usesRewards as A, shopCost as C, usesCountdown as D, urgencyOf as E, usesPoints as O, shopBuyLabel as S, stakesModeOf as T, parseIdList as _, countdownLabel as a, readPdfFile as b, encodeCustomDays as c, isDueToday as d, isPdfFile as f, parseCustomDays as g, parseCountdown as h, countWord as i, usesPunishments as k, isBought as l, outcomeMessage as m, URGENCY as n, countdownMode as o, isShopKind as p, applyPdfs as r, earnedCountOf as s, PDF_META_KEY as t, isCountedKind as u, parsePdfs as v, sortNamed as w, remainingSeconds as x, parsePoints as y };
