import { c as SEX_OPTIONS, o as EXPERIENCE_LEVELS } from "./video-DfU4zp6z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-Dsk7inZY.js
function pack(slug, label, starts, ends) {
	if (starts.length * ends.length < 500) throw new Error(`${slug} needs at least 500 combinations (has ${starts.length * ends.length})`);
	return {
		slug,
		label,
		starts: starts.slice(0, 25),
		ends: ends.slice(0, 20)
	};
}
var IDEA_CATEGORIES = [
	pack("scenes", "Scenes", [
		"They smirk in the doorway instead of kneeling. You wait. The scene starts when the smirk drops.",
		"A doorway kneel until you are acknowledged.",
		"A brat window of five minutes on the living-room floor, then you take the night back with one quiet instruction.",
		"They wait in present while you finish a drink.",
		"They try to undress you as a loophole. You thank them, then they stay dressed until you say.",
		"A timed hold at the foot of the bed.",
		"Kitchen counter: they sass the instruction. You repeat it once, slower, then they move.",
		"Shower first. Scene starts when the towel is taken from them.",
		"You let them brat through the inspection, then stillness is the catch — not a speech.",
		"Blindfold optional. Safeword is not.",
		"Collar on. They test the honorific with a smirk. You do not argue. You wait until the title is real.",
		"Begin with protocol: title, posture, eyes.",
		"A weekday scene: they poke, you stay bored, then you run the catch you already wrote.",
		"Weekend morning. No clocks except the one you set.",
		"They try to pick the duration to top from below. You thank the information, then you pick.",
		"You choose the toy. They choose the duration.",
		"A scene about voice: their brat mouth, your unmoved one. The gear can wait.",
		"A scene about voice, not gear.",
		"Against the wall after a brat push. You make it simple: hands, breath, colour, then they kneel.",
		"Against the wall, then down to the floor.",
		"On a blanket you can wash. Plan for a mess.",
		"Collar on as the threshold. Collar off as the close.",
		"A photograph at the start and at the end, if they want it kept.",
		"Music on, lyrics off — instrumental only.",
		"The companion chair is for aftercare, not for watching them struggle."
	], [
		"Warm-up is a hand, not a toy. Close with water and a true sentence.",
		"The peak is one instruction obeyed slowly. Aftercare on the sofa.",
		"If they brat the beat, you repeat the instruction once. Then they move, or you run the catch you already wrote.",
		"Check colour twice. End on purpose, not because you got tired.",
		"If they go quiet, that is data. Ask for a colour before you add intensity.",
		"Keep one hand on them whenever they cannot see you.",
		"Stay calmer than the smirk. Praise the kneel that ended it louder than the poke.",
		"Marks only where clothes will cover tomorrow.",
		"No new kinks tonight — only what is already on the yes list.",
		"Finish with the same honorific you started with.",
		"After the brat, they drink water before they speak in ordinary voice. Taming includes the landing.",
		"You put every toy away. They watch. That is part of the close.",
		"A blanket, a snack, and who sleeps where — say it before you start.",
		"If yellow is called, the scene becomes aftercare without argument.",
		"Debrief the catch, not the person. One keep, one tweak, one never.",
		"The last five minutes are stillness and breath, not a second peak.",
		"Kiss the place you were harshest.",
		"Thank them for the trust, not for the performance.",
		"Write one line in the journal before phones come back.",
		"If either of you is hungry or angry, this idea waits for another night."
	]),
	pack("roleplay", "Roleplay", [
		"Inspector and a brat who will not stay on the mark. Clipboard optional. Your patience is not.",
		"Hotel corridor strangers who already have a room key.",
		"A job interview they try to run. You ask the questions. They answer.",
		"Doctor's office only if you both like medical play — otherwise pick a different room.",
		"Bodyguard and a principal who pokes the rules. You move them. You do not debate them.",
		"A stolen hour in a borrowed office after hours.",
		"Librarian and the brat who will not stop talking. Quiet is the scene you run.",
		"Librarian and the person who will not stop talking.",
		"A fitting room they turn into sass. You keep the plot you both wrote. The shop is still your bedroom.",
		"A fitting room with a lock, and a shop that is actually your bedroom.",
		"Butler and guest. They brat the service. You stay the one who runs the evening — no swap.",
		"Rivals who lost a bet and have to share a room.",
		"The inspector returns. They try to lower the standard with a grin. You do not.",
		"A voice on a phone while they wait on the bed.",
		"Teacher and adult student only as costume — no school, no minors. You run the lesson; they brat, you still teach.",
		"Two people who met in a bar in 1998 and never got the room.",
		"The valet told to stay. They take a step. You point at the mark.",
		"Teacher and adult student only as costume — no school, no minors, no scripts that pretend otherwise.",
		"Confession booth of two chairs. They confess the brat. You name the penance you already wrote.",
		"The valet who is told to stay.",
		"A wedding-night scene for people who already live together.",
		"The mechanic who finds something that needs 'adjusting.'",
		"A confession booth you built out of two chairs.",
		"Strangers with a list they wrote last week.",
		"The person who hired help. You are the help who is actually running them."
	], [
		"Stay in character until yellow, then you are partners immediately.",
		"Costumes come off for aftercare. The role does not get a vote on water.",
		"If the plot wants a loophole, the plot loses. You stay the one who runs them.",
		"Write three lines of script and leave the rest to the room.",
		"Honorifics belong to the scene. Names belong to the landing.",
		"No 'surprise' kinks smuggled in as plot twists.",
		"If they brat in character, you can laugh. Then you decide whether the scene continues. You do not hand them the plot.",
		"If they laugh, you can laugh. Then decide whether the scene continues.",
		"Keep the interrogation questions on paper so you do not invent cruelty live.",
		"End by taking the costume off together, not by slamming back into ordinary without a bridge.",
		"If they cannot find the character, drop it and be yourselves. That is still a scene you run.",
		"If one of you cannot find the character, drop it and be yourselves. That is still a scene.",
		"You stay the one who runs the plot. They stay the one who is run. Yellow still wins.",
		"Debrief: which beat was hot, which was camp, which never again.",
		"A time cap so the bit — and the brat — do not eat the night.",
		"A time cap so the bit does not eat the night.",
		"They may break character to say a colour. You will hear it.",
		"Put keepers into the Roleplay page the same night.",
		"Kiss them as themselves before you sleep.",
		"If the role needs a cruel line, you wrote it on a calm day, not in heat."
	]),
	pack("exhibitionism", "Exhibitionism", [
		"A plug under clothes on a known walk. They try to make it a show. You shorten the loop. Strangers are not in this.",
		"A coded word in a café that means “sit up straighter.”",
		"Remote toy on low in a bookshop. They pull a face for you. You look at a spine, unmoved. Public people are not in the scene.",
		"A hotel lobby. The scene is your voice in their ear, nothing visible.",
		"Dinner out. They test who speaks first to the waiter. Your rule stands. No scene for the room.",
		"A car park at night, engine off, windows up, doors locked.",
		"A long drive. They sass a town. You skip the next command and take the brat home. The peak waits for a door.",
		"A long drive. One command per town you pass.",
		"A picnic far from paths. Clothes stay on. If they brat visibly, you pack up. Implication, not a show.",
		"A picnic blanket far from paths. Clothes stay on.",
		"A garden at a party. Five minutes. If the smirk is for anyone else, you both go back in. The catch waits for a lock.",
		"A garden at a party. Five minutes, then you both go back in.",
		"Shopping: they try to choose to get a rise. You decide. Ordinary errands as taming, not as theatre.",
		"A museum bench. A whisper, then silence until the next room.",
		"Earpiece in another aisle. They whisper a loophole. You say the coded word once. Then silence.",
		"A balcony that does not overlook neighbours.",
		"Public transport only if you can get off. They brat, you get off at the next stop. No peak there.",
		"A late walk with a plug and a time cap.",
		"A restaurant bathroom is not a catch unless it locks. If they poke for a scene, you pay and you leave.",
		"A restaurant bathroom is not a scene unless it locks and you can leave fast.",
		"A coded tap under the table: green, yellow, out.",
		"They kneel to tie a shoe. You let the moment be only that.",
		"A photograph of their collar at home, sent while they sit in a waiting room.",
		"Overnight bag with one toy for the hotel, nothing used in the corridor.",
		"A park at dusk, empty enough. Hands, breath, then you walk on."
	], [
		"Nobody who did not consent is part of this. If a stranger appears, the scene dies instantly.",
		"Toys stay silent. If it buzzes loud, it comes out in a bathroom, not a performance.",
		"Clothes stay on. Exhibitionism is implication, not a show, and not a brat performance for anyone who did not consent.",
		"You both have an exit sentence: “We're heading back.” Use it without shame.",
		"Intoxication and exhibitionism do not share a night.",
		"If they freeze, you get them private before you talk about it.",
		"The aftercare happens at home, not on the pavement. If they poked in public, the catch waits for a door.",
		"Keep intensity two steps below what you would do behind a door.",
		"Agree the rooms it may be on: street, shop, car — and the rooms it may not.",
		"A plug needs a bathroom plan and a time cap.",
		"If staff or a stranger looks twice, you are done. Warmth, not a joke at their expense, not a brat encore.",
		"If staff or a stranger looks twice, you are done. Warmth, not a joke at their expense.",
		"Debrief: thrilling, too close, never again, again please.",
		"The honorific is in your head until you are home, unless you agreed a quiet one.",
		"Legal and venue rules beat the fantasy and the smirk. Always.",
		"Legal and venue rules beat the fantasy. Always.",
		"They may call yellow in ordinary words. You will hear ordinary words.",
		"Do not involve neighbours, colleagues, or family even as a joke.",
		"The peak waits for a door that locks.",
		"Write the rule in Notes so “public” never means “unwilling audience.”"
	]),
	pack("voyeurism", "Voyeurism", [
		"They try to look away. You wait. The scene is them watching you stroke yourself.",
		"You sit in the chair and touch yourself. They kneel, hands on thighs, and watch. They may not touch until you say.",
		"They brat for a turn. You keep your cock in your own hand. Watching is the instruction.",
		"You edge yourself with the toy they wanted. They watch from the mark. They do not get it unless you say.",
		"You come where they can see it. They stay still. Aftercare is a towel and a true sentence, not a joke.",
		"They undress on your count while you sit and watch. A smirk that hides a breast restarts the count.",
		"You tell them to touch themselves the way they like. You do not help. If they rush as a brat, they start over slower.",
		"They present on the bed. You stay in the chair. The brat who crawls to you gets sent back to the mark.",
		"A mirror behind them. You watch their face, not only the act. Hiding the face as a poke gets a check.",
		"They follow a written list of acts while you drink. Sass about the list is a redo, not a debate.",
		"You tell them to hold still after they come, so you can watch the drop. A joke instead of stillness is a wait.",
		"They strip, then they wait, then they touch, all on your words. A loophole in the wait sends them back to dressed.",
		"Chair opposite. They ride a toy you are not holding. They brat for your hands. Your hands stay on the chair.",
		"Lights on. They masturbate how they actually do it when you are not in the room. You watch. You do not coach unless they ask.",
		"They stand in the doorway and undress item by item. You do not leave the chair.",
		"A timed five minutes of them touching themselves. You watch the clock and their face.",
		"They kneel and use their mouth on a toy while you watch from the bed. Pace you set with a word.",
		"You put a pillow under their hips and tell them to work. You stay dressed. Watching is the heat.",
		"They come once where you can see, then they ask if there is another. You decide.",
		"A video they record for you in another room, then they bring the phone. You watch it together. Delete if they want.",
		"They wear what you chose and walk the length of the room. You watch. You do not touch.",
		"Shower with the door open. They wash how you told them. You lean on the frame. Footing is safe. You do not crowd.",
		"They read the filthy sentence out loud, then they do it, while you watch without helping.",
		"On their back, feet toward you, so you can see. Your instruction is slow. Their job is to stay visible.",
		"After they finish, they stay arranged so you can look. Then a blanket. Then water."
	], [
		"Door locked. Curtains closed. Nobody who did not consent is in this.",
		"If they look away as yellow, that is a colour. You stop or you change. You do not mock it.",
		"If they brat the watching — hiding, rushing, crawling off the mark — you repeat the instruction once. Then they do it, or you run the catch you wrote.",
		"You do not stack a second audience. Screenshots of this are an audience.",
		"Keep a hand or a word available. Watching is not abandoning.",
		"If they freeze, you drop the watching and become a partner. Ask.",
		"Stay calmer than the smirk. The temperature of the room is yours.",
		"Aftercare: water, a blanket, ordinary voice. Being seen can drop people.",
		"Time-box. An hour of being watched is a lot. Minutes are a scene.",
		"No neighbours, windows that face people, or hallway risk. A window fantasy is not a street.",
		"Debrief the catch, not the person. One keep, one tweak, one never.",
		"If this is them watching you, they still get a colour. They may look away. That is not a brat unless they named it as one.",
		"If this is you watching them, you do not coach every breath. Watching includes letting them do it.",
		"Toys stay body-safe. You put them away. They watch that too, or you do.",
		"Praise the stay-visible, or the stay-watching, louder than the poke.",
		"Intoxication and a watching scene do not share a night if anyone might miss a colour.",
		"Write which arrangement they could actually hold. Catalogue it.",
		"Kiss them after. Being watched is intimacy, not a test they can fail at love.",
		"The peak waits for a door that locks.",
		"If either of you is hungry or angry, this idea waits for another night."
	]),
	pack("praise", "Praise", [
		"Tell them exactly how well they stopped the brat — the kneel, not the smirk — in plain words.",
		"Name the thing they did that was hard, not only the thing that was pretty.",
		"Praise in the honorific after a catch, then the same praise in their ordinary name, so the brat is not the only story.",
		"Praise in the honorific, then the same praise in their ordinary name.",
		"You describe their in-bounds sass as skill, then you praise the stop louder.",
		"You describe their obedience as skill, not as luck.",
		"Praise the ask they made instead of the poke they wanted.",
		"Praise the ask they made, not only the yes they gave.",
		"A public-to-you compliment after a brat night: said in front of no one else.",
		"A public-to-you compliment: said in front of no one else, written like it could be.",
		"Praise a limit they named in the middle of a push. That is courage, not a spoiler.",
		"Praise a limit they named. That is courage, not a spoiler.",
		"You thank them for the brat that stayed in bounds, then for the quiet that was not a freeze.",
		"You thank them for the brat that stayed in bounds.",
		"A note in a private pocket: you saw the spark, and you saw them let you catch it.",
		"A note in their pocket for a workday, filthy only if the pocket is private.",
		"A ritual after every brat scene: one praise they cannot argue with, about the person, not the performance.",
		"Say what you are proud of in them outside the dynamic, then bring it into the room.",
		"Praise them in position after the catch, then again when they are up, so taming ends in being seen.",
		"Describe their mouth, their patience, their eyes — pick one and be precise.",
		"Praise them while they are still in position, then again after they are up.",
		"A toast at dinner that only the two of you can hear.",
		"Write the praise in Notes so lust does not get to be the only historian.",
		"Tell them they were easy to hold. Mean it.",
		"The last word of the night is their name, said like a keep."
	], [
		"No sarcasm hiding in the compliment. If you cannot be kind, wait.",
		"Do not praise a freeze as 'good and quiet.' Ask if they were with you.",
		"Specific beats generic. Good girl/boy/pet only after the specific — including after a catch.",
		"If praise is a kink, still mean it. Empty praise trains them to distrust you.",
		"They may cry. That is not a problem to solve with a joke.",
		"Do not add a 'but' tonight.",
		"Do not add a but tonight. A brat night still gets the compliment clean.",
		"Praise is not a prelude you rush to get to the 'real' scene. It can be the scene.",
		"If they deflect, repeat once, then hold them. Do not argue them into receiving.",
		"Match volume to the person: some want a speech, some want a whisper.",
		"Never praise them for enduring a catch they did not agree. Taming is not a blank cheque.",
		"If humiliation is also on the menu, keep praise and humiliation in different beats.",
		"The body hears tone. Soften your face.",
		"Aftercare can be more praise. It does not have to become analysis.",
		"If humiliation was also on the menu, keep praise and humiliation in different beats, especially after a smirk.",
		"Write what landed. Retire what felt like a performance review.",
		"Say it while you are still touching them, or it can feel like a debrief.",
		"Do not compare them to a previous partner, even as a 'you are better.'",
		"Let them praise you back if they want. Dominance is not a compliment deficit.",
		"Close with water and the same sentence you would want said to you."
	]),
	pack("humiliation", "Humiliation", [
		"A small fact they offered as a button, used once after a smirk — kindly-mean, then you stop.",
		"They describe what they want in plain, embarrassing words while you listen.",
		"You name their brat out loud as if it were minutes from a meeting, then you make them ask without the grin.",
		"You name their arousal out loud as if it were minutes from a meeting.",
		"They thank you for a denial they asked for, without turning the thanks into another poke.",
		"They ask for the thing they are ashamed of wanting. You make them use the crude word.",
		"They hold a toy they want and explain the loophole. Then they thank you for the no.",
		"A petty title for the evening, retired at collar-off.",
		"A mirror. They watch themselves take the catch. You do not add garnish they did not circle.",
		"A photo of their face after they said the hard sentence — only if they want it kept.",
		"They introduce themselves with the brat-need, not the job title. You still run the room.",
		"They hold a toy they want and explain why they have not earned it yet.",
		"They confess a want you already knew, without the wink. You pretend it is news, then you hold them.",
		"The 'wrong' honorific on purpose, then the right one as a mercy.",
		"You make them choose between two humiliations they both circled yes. The brat does not get a third invented in heat.",
		"A slow undress with notes, not with laughter at a body.",
		"They say please until it is real — not theatrical. Then you answer.",
		"A timer: sixty seconds of honest filth, then you hold them.",
		"After they come, they have to say what they are, once, without the smirk, then they get water.",
		"A posture that is a little ridiculous, held because they asked to be seen.",
		"They say 'please' until it is real, then you answer.",
		"A line they hate and love, used only as the peak, not as wallpaper.",
		"You describe how obvious they are, and you sound fond.",
		"They keep their clothes on while they ask to be used. The asking is the scene.",
		"After they come, they have to say what they are, once, then they get water."
	], [
		"Only humiliations on the yes list. Character, work, family, and old wounds stay off unless they were named.",
		"Mean is a flavour. Contempt is a poison. If your face goes cold for real, you stop.",
		"Mean is a flavour. Contempt is a poison. If your face goes cold for real at a brat, you stop.",
		"A humiliation safeword can be the same colour words. Hear ordinary language too.",
		"Do not improvise a new shame in anger. Anger is not erotic humiliation.",
		"Body-shaming that was not requested is just cruelty. Full stop.",
		"Do not improvise a new shame because they poked. Anger is not erotic humiliation.",
		"If they go small and far away, you drop the bit and become a partner.",
		"Retire a line that still stings the next day. Hot in the room is not the same as keepable.",
		"Do not stack humiliation with a hard limit 'as a joke.'",
		"If they go small and far away, you drop the bit and become a partner. That is not them winning.",
		"Never use money, food, sleep, or the relationship as the humiliation.",
		"If they laugh, check whether it is joy or a flinch with teeth.",
		"Write the exact sentences that are allowed. Lust has a bad memory.",
		"They get to ask for it to be meaner or softer. That is not topping from below. That is consent, even from a brat.",
		"No involving colleagues, exes, or family even as fiction they did not pick.",
		"A time cap. Humiliation that runs all evening becomes a mood disorder.",
		"If they need to be disgusting, keep it about want, not about worth.",
		"Debrief the next day: still hot, too sharp, never again.",
		"Kiss the place you were unkind, and mean the kiss."
	]),
	pack("punishments", "Punishments", [
		"A corner they already know, for a count you both wrote, after a loophole they thought was cute.",
		"Lines: the rule, in their handwriting, until it is neat.",
		"Loss of a privilege you actually control — not affection, not food — because the brat left the window.",
		"An early bedtime that is boring, not a kidnapping.",
		"A position held while you read, colour checks, because they tried to run the catch.",
		"They fetch the toy they earned and wait.",
		"Extra protocol for twenty-four hours after an in-bounds brat: title, kneel, ask. Then it is over.",
		"Extra protocol for twenty-four hours: title, kneel, ask.",
		"They serve water in silence after a mouthy streak, then they may speak.",
		"They serve tea or water in silence, then they may speak.",
		"Writing the loophole they used, and the patch, into Notes. That is the catch. You do not freelance a new cruelty.",
		"Writing the loophole they used, and the patch, into Notes.",
		"No toys for a set number of days after they pushed a named line. Hands are still allowed. You still want them.",
		"No toys for a set number of days. Hands are still allowed.",
		"They choose the catch from two you offer. You still run it. The brat does not write a third in the moment.",
		"A task from the bank completed before they get the evening they wanted.",
		"They lose the brat window until the weekend. They do not lose being wanted. You say both.",
		"They choose the catch from two you offer. You still run it.",
		"The catch happens the same day as the push. Delayed vengeance is not taming.",
		"They lose the brat window for the week. They do not lose being wanted.",
		"A photo of the lines, if they want it in the album as proof they were caught.",
		"Quiet dinner. You speak; they answer when invited.",
		"They make the bed to your standard, then they may get in it.",
		"A short, dull lecture of the actual rule. Then you drop it. No circling.",
		"The catch happens the same day. Delayed vengeance is not discipline."
	], [
		"Anger is not a method. If you are actually angry, pause the dynamic.",
		"The catch must be on the list. Inventing a new cruelty in heat is a fight, not a punishment.",
		"The catch must be on the list. Inventing a new cruelty because they smirked is a fight, not taming.",
		"A brat who safewords has not 'gotten out of it.' They have used the tool. Thank them.",
		"Match the catch to the push. Playful loophole, playful catch. Real harm, real stop — not a paddling.",
		"Follow through once. Then it is over. Do not store it for later.",
		"A brat who safewords has not gotten out of it. They have used the tool. Thank them, then hold them.",
		"Write the catalogue of catches in Punishments so you do not freelance.",
		"Pain as punishment is optional and specific. Many pairs do better with boredom.",
		"Do not punish a freeze, a drop, or a missed orgasm. Those are bodies.",
		"Follow through once. Then it is over. Do not store a brat for later.",
		"If the rule was unclear, the repair is a better rule, not a scene.",
		"Count out loud. They should know when it ends.",
		"Marks only where you both agreed they may show.",
		"If the rule was unclear, the repair is a better rule, not a scene you throw at the spark.",
		"Do not stack three punishments because one did not 'feel like enough.'",
		"They may ask for the catch. Wanting to be caught is not a crime.",
		"If you cannot be steady, you do not run the catch tonight.",
		"Put the date in the journal. Patterns beat grudges.",
		"Close with water and a sentence that they are still yours to hold."
	]),
	pack("rewards", "Rewards", [
		"The slow undress they asked for, given after they let you catch them — no clock, no snatch-back.",
		"A bath you run, and you stay in the room.",
		"They pick the toy as the prize. You use it the way they like. The brat does not get to move the posts mid-scene.",
		"A morning in bed with no protocol until they ask for it.",
		"Praise written on paper they can keep, naming the stop as well as the spark.",
		"The scene they circled in Ideas, run without moving the goalposts.",
		"A collar-on hour that is only affection after a brat night, with the rules they actually enjoy.",
		"You cook. They do not serve.",
		"Orgasm first as the reward they earned by coming to the mark, not by winning an argument.",
		"Orgasm first, conversation later — if that is what they earned.",
		"They get a brat window you set, and you play, delighted — then you take the night back on time.",
		"They get to brat in a window you set, and you play, delighted.",
		"The hotel room with the lock, for the scene they were patient for, including the minutes they did not poke.",
		"You read to them. They do not have to be useful.",
		"Points spent on a reward from the board after a catch they took without a tantrum. Mark it bought. Give it generously.",
		"A photograph they asked to have taken, then the choice to keep or delete.",
		"You say the filthy thing they like, without making them brat to earn the vocabulary.",
		"A long, boring, reliable ritual that means they are safe.",
		"Sleep where they want, after a night you tamed. You adjust. The reward is rest, not a second test.",
		"They come as many times as the body will, without a lesson attached.",
		"Breakfast in the bed they were told they could stay in.",
		"You say the filthy thing they like, without making them earn the vocabulary.",
		"A day of service inverted: you fetch, they rest.",
		"The good towel, the good lube, the time they actually needed.",
		"Sleep where they want. You adjust."
	], [
		"A reward is not a trap. Do not snatch it back to 'teach.'",
		"If they bought it with points, mark it bought and be generous in how you give it.",
		"A reward is not a trap. Do not snatch it back to teach a brat. That is how people stop bringing you the fun.",
		"Rest can be the reward. Do not add a scene they have to perform to receive rest.",
		"If they crash after, that is drop. Aftercare, not a pop quiz on gratitude.",
		"Write what actually landed. Fancy gifts they did not want are clutter.",
		"Rest can be the reward after a catch. Do not add a scene they have to perform to receive rest.",
		"Do not make them grovel for something you already decided to give. That is a different kink.",
		"If humiliation is their reward, still hold them after. Mean gifts need soft landings.",
		"Time-box so the treat does not become an obligation to be 'on.'",
		"If humiliation is their reward, still hold them after. Mean gifts need soft landings, especially after a poke.",
		"If the body cannot take the prize tonight, commute it. Mercy is still a gift.",
		"Put keepers into Rewards so you are not inventing on a tired Thursday.",
		"They may say the reward was wrong. Believe them. Try again.",
		"Do not reward a freeze or a fawn. Reward a choice — including the choice to stop bratting.",
		"Share food, water, warmth. Then the filthy part, if any.",
		"A reward should still fit the yes list. 'Surprise' that blows a limit is not generous.",
		"Let them enjoy it without performing thanks on a timer.",
		"They still get a colour, even when the reward is filthy. Receiving is not a place to lose the off-switch.",
		"Close with the same honorific or the same name you started with — they should know they arrived."
	]),
	pack("tasks", "Tasks", [
		"Make the bed to the standard in Notes after a brat morning. Photo optional. No moving the goal.",
		"A water bottle finished before noon, marked in Tasks.",
		"Kneel for three minutes after the door closes, even if the smirk is still on. Timer visible.",
		"Write tomorrow's yes/maybe/no in three lines and send it.",
		"Wear the agreed underwear. Report when it goes on. A loophole in the report is a new task, written, not a fight.",
		"A plug for a commute they already said was safe, time-capped, bathroom plan.",
		"Prepare the toy they asked for: clean, charged, on the towel. Sass about it does not delay the done.",
		"Prepare the toy they asked for: clean, charged, on the towel.",
		"A journal line after they poke: one want, one limit, one gratitude. You read it. You do not grade the spark.",
		"Cook the simple meal. Serve it without a speech.",
		"Lay out the clothes for the evening they already chose. They do not get to re-choose as a brat.",
		"Stretch the hips and the wrists. Send 'done,' not a video unless they like that.",
		"A no-touch morning if that is a known game, with a clock and a yellow. Bratting the clock is a colour, not a loophole.",
		"A no-touch morning, if that is a known game, with a clock and a way to call yellow.",
		"Tidy the play drawer. Photograph the labelled shelf. Cute delay is not done.",
		"Tidy the play drawer. Photograph the labelled shelf.",
		"Answer the Talk card in writing before dinner. A clever dodge is a rewrite, not a win.",
		"Answer the Talk card in writing before dinner.",
		"They pick one task from three you offer. You still want it done. The brat does not invent a fourth.",
		"Learn the new rope cuff on a chair leg, not on a person, until it is boring.",
		"Ice cube on the inner wrist for thirty seconds, then words about sensation.",
		"A gratitude text that is specific, not a performance of being owned.",
		"Charge the estim, check the pads, put shears where they belong.",
		"They pick one task from three you offer. You still want it done.",
		"Lights out at the time you both wrote. Phones on the dresser."
	], [
		"A task they cannot actually do is not dominance. It is a setup.",
		"Work, sleep, and health beat the assignment. Commute it without a lecture.",
		"A task they cannot actually do is not dominance. It is a setup. Brats will find that out loud. Believe them.",
		"Mark it done. Unmarked tasks become a fog of failure.",
		"No moving the goal after they have started.",
		"A missed task is data: too much, unclear, or a brat. Read it before you punish.",
		"No moving the goal after they have started, even if they sassed you at breakfast.",
		"Keep tasks short enough for a weekday. Heroic lists are how people quit.",
		"If the task is erotic, it still needs a colour and a stop.",
		"Write new ones in Tasks, not in a midnight text wall.",
		"A miss is data: too much, unclear, or a spark. Read it before you run a catch.",
		"You assign. They mark it done. You do not stack a second lap because you are restless.",
		"Do not assign something that injures. Soreness from play is negotiated; injury is a stop.",
		"A task during vacation is optional. Rest is not slacking.",
		"If the task is erotic, it still needs a colour and a stop. A smirk is not a colour.",
		"Put the why in the body of the task so it does not feel like busywork.",
		"One consequence, written. Not a mystery box.",
		"If they finish early, they are done. Do not invent a second lap.",
		"Debrief weekly: which assignments still serve.",
		"Close the day with 'enough,' even if the list is not empty."
	]),
	pack("commands", "Commands", [
		"Kneel. Eyes down. Wait. If they smirk, you wait longer. Then the next word.",
		"Hands behind. Chest up. Breathe where I can see it.",
		"Strip to what you agreed. Fold it. Present. A loophole in the fold is a redo, not a debate.",
		"Open your mouth. Stay. I will tell you when.",
		"Walk to the wall. Palms flat. Do not turn around. You do not chase a look they try to steal.",
		"Say the title. Then the ask. Then wait.",
		"Hold this position until the timer, not until they perform struggle as a brat.",
		"Look at me. Now look away. Now look at me.",
		"On the bed. On their back. Still. Mouthy gets a quieter room, not a louder you.",
		"Fetch the toy we named. Both hands. Kneel when you return.",
		"Quiet. They may make sound when you say. Sass is sound. You said quiet.",
		"Count for me. Start over if you lose the number.",
		"Ask permission to come. Use the crude word. A joke instead of the word means wait.",
		"Tell me your colour. Now.",
		"Drink. Then thank you. Then wait. The thank-you is not a place to sneak a poke.",
		"Put your forehead on my knee. Stay through the next sentence.",
		"Repeat after you. Then do it. If they ad-lib, you start the line again, bored.",
		"Repeat after me. Then do it.",
		"Come here. Slower than that. The brat speed is a test. You do not match it.",
		"Come here. Slower than that.",
		"Sit on your heels. Palms up. That is all.",
		"Say what you want in one sentence. Then I decide.",
		"Hold still while I inspect. You may tremble. You may not hide.",
		"Kiss where I point. Then wait.",
		"When I snap, you freeze. When I tap, you move."
	], [
		"One command at a time. Stacked orders are how people fail on purpose.",
		"If they cannot hear you, you are too far or too quiet. Move.",
		"A command they physically cannot do is a trap. Change it. A brat failing a trap is not a brat.",
		"Colour checks are commands too. Use them.",
		"Practise these in the Activities drill before you use them in a peak.",
		"Do not bark because you are stressed about work. They can tell.",
		"If they brat the command, run the catch you wrote, or laugh and repeat once. Do not invent a third option in heat.",
		"If they brat the command, run the catch you wrote, or laugh and repeat once.",
		"Safewords beat the script. A 'no' in ordinary voice beats the script.",
		"Write the short list of standing commands in Notes so you do not invent a dialect every night.",
		"Never command something off the yes list to see whether the smirk holds.",
		"Give them time to move. Bodies are not code.",
		"If you forget a command you started, you apologise inside the dynamic or you drop it. Do not pretend.",
		"Aftercare voice is not a command voice. Change it on purpose.",
		"If they freeze, you stop commanding and you start asking. Freeze is not sass.",
		"A nod can be the command if you both trained it. Confirm once.",
		"If they freeze, you stop commanding and you start asking.",
		"Count is mercy. Open-ended 'until I am bored' is not, unless they asked for that cruelty.",
		"Put keepers into the journal: which words made them land.",
		"Close with a release word you both know, so their nervous system can stand down."
	]),
	pack("training", "Training", [
		"Install one greeting this week: title, kneel, wait. A brat greeting is a redo, not a new religion.",
		"A posture they can hold for two minutes, then four, then they are done.",
		"The honorific in ordinary rooms, only when you are both home. They do not get to drop it as a joke.",
		"Presenting a toy on open palms until it is boring.",
		"A colour check ritual at the start of every scene, even the tiny brat ones.",
		"Ask permission for the one thing they always forget to ask.",
		"A journal habit: one line after play, including after a catch, before phones.",
		"Edging on a schedule they can keep, not a martyrdom.",
		"Orgasm on a cue, with stimulation, same word for two weeks. Bargaining the word is off the drill.",
		"A service task done the same way each morning until the body knows it.",
		"Wait in present while you finish a paragraph. If they poke, you restart the wait. Release is the point.",
		"The inspection order: face, hands, back, the rest. Same order every time.",
		"A brat window with a clock, so the spark has a pen. When it ends, you take the night back.",
		"Silence until spoken to, for a scene, not for a relationship.",
		"Silence until spoken to, for a scene, not for a relationship. They may colour. They may not fill the air with sass.",
		"Walking at your shoulder in private, dropped at the door.",
		"Walking at your shoulder in private, dropped at the door. A step ahead is a mark to return to, not a fight.",
		"One protocol off for the weekend so you both remember it is chosen.",
		"They practise asking for aftercare in words after a brat night, not in a collapse they dress up as sass.",
		"They practise asking for aftercare in words, not in collapse.",
		"You practise giving a command without heat. They practise taking it.",
		"A map of their body, updated when the map moves.",
		"No-touch as a trained skill, with a time cap and a yellow.",
		"They learn to fold the scene clothes. You learn to put the toys away.",
		"A month of the same landing: water, blanket, one true sentence."
	], [
		"One protocol at a time. A new religion every night is how people go numb.",
		"Training is not a personality transplant. Keep the person.",
		"One protocol at a time. A new religion every night — or after every brat — is how people go numb.",
		"Praise the boring repetition. That is where the skill lives.",
		"Do not train self-hate. A missed kneel is a miss, not a character defect.",
		"Write the curriculum in Training so both of you can see the path.",
		"If they fail a drill, the drill was too much, unclear, or they were playing. Adjust. Do not pile on.",
		"A trained cue still loses to a safeword.",
		"The Dominant is in training too: steadiness, timing, reading.",
		"If the ritual starts to feel like a test they can fail at love, you stop it and talk.",
		"A trained cue still loses to a safeword, including a safeword in the middle of a poke.",
		"Put dates on what you installed. Patterns beat memory.",
		"Do not add pain to a protocol that was about grace unless they asked.",
		"Let them be clumsy. Clumsy is the middle of learning.",
		"If the ritual starts to feel like a test they can fail at love, you stop it and talk. That is taming too.",
		"If they are ill, training is cancelled. Care is not a loophole.",
		"Ask what they want to be good at. Train that, not your forum taste.",
		"Drop a protocol that no longer serves. Loyalty to a dead rule is theatre.",
		"Aftercare after drills. Nervous systems do not know it was 'only practice.'",
		"Close the week with what is now easy. That is the point of training."
	]),
	pack("temperature-play", "Temperature play", [
		"An ice cube along the inner thigh after a smirk, then your mouth on the same path. You stay unhurried.",
		"A mug of warm (not hot) water held to the hip while they stay still.",
		"Ice on a nipple they like, warmth on the other, then swap. They do not get to pick the next as a loophole.",
		"A cold stainless toy from the fridge, wiped, then slow.",
		"A shower that shifts warm to cool on a count. They brat the count, you hold the tap, you do not chase.",
		"Ice in your mouth, then a kiss they did not brace for — on a yes list place.",
		"A frozen wand through a cloth, seconds at a time. They sass for more. You stay on seconds.",
		"Wax only if you have low-temp wax and unshaven or well-oiled skin. Test on yourself.",
		"Ice at the small of the back while they present. If the presenting is a joke, you wait until it is not.",
		"Warm lube in a bowl of water, then cold lube, and they tell you which.",
		"Breath, then ice, then breath on the same square. Their clever mouth does not rush your metronome.",
		"A metal plug chilled briefly, not freezer-burned, lots of lube.",
		"They hold ice in their palm while you edge them. When it hurts, they say yellow — not a brat word for stop.",
		"A warm pack on sore hips after a hold, as the landing, not the peak.",
		"A teaspoon of ice water down the sternum after they poke. Towel ready. You do not pour a second as revenge.",
		"A teaspoon of ice water down the sternum, towel ready.",
		"The cube traces the line you will later kiss. They stay still. Movement as sass restarts the line.",
		"A glass toy run under cold, then under warm, then into a slow scene.",
		"They choose ice or warmth for the last five minutes. Choosing is not a place to brat the whole scene back open.",
		"The cube traces the line you will later kiss.",
		"Warm oil on the back, then a single ice line down the spine — not the neck.",
		"A cold coin (clean) on the inner thigh, then your palm.",
		"They choose ice or warmth for the last five minutes.",
		"Temperature as a metronome: cold means still, warm means they may move.",
		"End with skin at ordinary temperature and a blanket."
	], [
		"No burns. If it is too hot for the inside of your wrist, it is too hot for them.",
		"Ice can burn too. Cloth, time caps, and watching the skin.",
		"No burns. If it is too hot for the inside of your wrist, it is too hot for them, smirk or not.",
		"Never pour boiling water, never use a heat gun, never use a freezer-burned toy inside.",
		"Metal and glass hold temperature longer than you think. Start milder.",
		"Colour on the skin that stays white or angry is a stop, not a trophy.",
		"Wax: low-temp, no eyes, no mucous membranes, no broken skin. A dare does not change the physics.",
		"Towels. Drips on electronics and on floors that become rinks are not hot.",
		"Do not combine serious cold with bondage that traps the ice in place.",
		"Aftercare is warmth, lotion if the skin asks, and a look at marks.",
		"Colour on the skin that stays white or angry is a stop, not a trophy you collect because they poked.",
		"If they laugh and flinch, that can be joy. If they go silent, ask.",
		"Write which contrast they loved. Retire what only looked dramatic.",
		"No temperature play on the neck in a way that could shock the baroreflex. Be boring and safe.",
		"Do not combine serious cold with bondage that traps the ice in place, and do not add that as a catch.",
		"A burn is a first-aid problem. Run cool water. Do not put butter on it. Do not keep playing.",
		"Keep nails and jewellery from scraping skin that is busy feeling temperature.",
		"If they have a heart condition or Raynaud's, this may be a never. Believe that.",
		"The scene ends at ordinary skin. Do not send them to sleep shivering or overheated.",
		"Kiss the places you painted with cold. Mean it."
	]),
	pack("sensory-deprivation", "Sensory deprivation", [
		"A soft blindfold, your hand on their sternum. They brat in the dark. You do not add a gag to win.",
		"Earplugs, not a total bind. They can still hear a colour if they shout.",
		"Blindfold plus your mouth as the only map. If they guess as a poke, you laugh, then you slow down.",
		"A dark room they know, no new furniture, a clear path to the door.",
		"Headphones with a playlist they set. Your tap is the safeword too. Sass is not the tap.",
		"Sight gone, hands free, so they can tap.",
		"Sight gone, hands bound loosely, a bell in the fingers. The bell is yellow. Shaking it as a brat is a talk after, not a pile-on.",
		"A hood only if it is made for this, airway clear, time-capped, never if they have a cold.",
		"They wear the blindfold while you describe what you will not do. They do not get to dare you into doing it.",
		"A slow undress they can only feel.",
		"You stop making sound for a count, then you speak their name. Filling the quiet with sass restarts the count.",
		"You stop making sound for a count, then you speak their name.",
		"One sense taken, one sense given: blind, but more of your voice. You stay calmer than their spark.",
		"One sense taken, one sense given: blind, but more voice.",
		"They guess which toy by feel. Wrong guesses are laughter, not a catch, unless they asked for that game.",
		"They guess which toy by feel. Wrong guesses are laughter, not punishment, unless they asked.",
		"Earplugs plus a hand squeeze: one green, two yellow, three stop. A squeeze as a joke is still a squeeze. You honour it.",
		"Earplugs plus a hand squeeze code: one squeeze green, two yellow, three stop.",
		"A clock they cannot see. You can. You end on time even if they brat for one more minute of dark.",
		"A quiet, boring deprivation: sit, blind, breathe, your palm on them.",
		"They keep the blindfold on for aftercare if they want the dark. Ask.",
		"A scene where the only surprise is kindness they cannot brace for.",
		"No talking from them unless a colour. You still check in out loud.",
		"A clock they cannot see. You can. You end on time.",
		"Lights on before you leave the room for any reason. Do not leave them."
	], [
		"Keep a hand or a word on them. Isolation plus dark is how people panic.",
		"Blind plus gag plus binds is stacked risk. Cut one if they go quiet.",
		"Keep a hand or a word on them. Isolation plus dark is how people panic, including brats who asked for it.",
		"A tap, a bell, or a drop-able object is a safeword when their mouth is busy.",
		"If they have trauma around dark, this may be a never. That is allowed.",
		"Ear damage is not a kink. Volume stays in their control.",
		"Never leave a deprived person alone. Not to 'let them think about the smirk.' Not for a second.",
		"Tell them before you touch with something cold or sharp, unless they asked for the startle and you have a tap.",
		"Panic is a stop. Untie, light, name, water. Do not 'ride it out.'",
		"Time-box. Long deprivation becomes a medical event.",
		"Panic is a stop. Untie, light, name, water. Do not ride it out as taming.",
		"Do not stack this with breath play. Ever, tonight.",
		"If they dissociate, senses back on, ordinary language, blanket.",
		"Write which sense they can lose and which they must keep.",
		"Do not stack this with breath play. Ever, tonight. A brat dare does not write that stack.",
		"Check circulation if anything is bound. Deprivation is not an excuse to skip.",
		"The first time is shorter than the fantasy.",
		"They may want the blindfold off to come. That is not a failure of the scene.",
		"Debrief: thrilling, too far, never the hood, again the dark.",
		"End by giving the sense back slowly, then holding them in ordinary light."
	]),
	pack("masochism", "Masochism", [
		"An ache they asked to keep, after a smirk: a clamp on a count, then off, then your mouth. You do not add a count because they poked.",
		"The good kind of sting on the thighs, warm-up first.",
		"They tell you where the want lives today. A brat mis-map to get more is a colour check, then you stay in the country they named.",
		"A slow, heavy press, not a showy strike.",
		"Nails on the back they offered, not a carving, not a punishment for sass unless that pairing was named.",
		"A bite they chose, where clothes will cover.",
		"A clamp only if that is a known yes, seconds, then blood returns. They do not brat you into longer.",
		"A clamp on the labia or the scrotum only if that is a known yes, seconds, then blood returns.",
		"The thud they like more than the sting. Ask which. They do not get to switch mid-stroke as a loophole.",
		"A ache in a hold: thighs, arms, a stretch, a shake, then rest.",
		"They ask for a little more in words. You give a little more, then you check. A moan is not a brat tax.",
		"A scratch they can look at tomorrow and still want.",
		"The toy they fear a little and want a lot, used below the story. You do not let a dare write the scene.",
		"They ask for 'a little more' in words. You give a little more, then you check.",
		"A ritual: they present the place, you ask, they say yes, you begin. A joke yes is a wait.",
		"The toy they fear a little and want a lot, used below the story they tell about it.",
		"Pain only while they can still make a joke. When the joke dies, you check — that is not a brat to catch, that is a body.",
		"A ritual: they present the place, you ask, they say yes, you begin.",
		"The last impact is the kindest. Then you stop being the one who hurts them, even if they poke for one more.",
		"A bruise they requested, on a calendar that has no beach, no family photos, no work shorts.",
		"The masochism is in the wait: knowing it is coming, not in the surprise.",
		"They keep their hands on you so they can tap.",
		"A mix of hurt and filthy praise, if that is their pairing.",
		"The last impact is the kindest. Then you stop being the one who hurts them.",
		"They get to say the pain was perfect. Believe them. Write it down."
	], [
		"Warm up. Cold muscle tears. Hot muscle talks.",
		"Stay off kidneys, spine, throat, joints, and anything that already hurts for a medical reason.",
		"Stay off kidneys, spine, throat, joints, and anything that already hurts. A brat map is not a medical licence.",
		"A masochist can still have a limit. 'They like pain' is not a blank cheque.",
		"If they go quiet and far, that is not 'in the zone' until they tell you it is. Ask.",
		"Blood, breath, and head are different sports. Do not wander there because the thighs went well.",
		"A masochist can still have a limit. They like pain is not a blank cheque, and not a catch.",
		"Aftercare is extra. Endorphins lie, then they drop.",
		"Do not add a new implement in the last five minutes.",
		"If they have a clotting issue, are on blood thinners, or bruise alarmingly, this is a clinician conversation or a never.",
		"If they go quiet and far, that is not in the zone until they tell you it is. Ask. Do not assume the smirk went to subspace.",
		"Kiss the place you were harshest. That is part of the masochism for many of you.",
		"Write which ache they want to keep. Retire what only looked fierce.",
		"A safeword during pain can come out ugly. Hear it.",
		"Do not add a new implement in the last five minutes, and do not add one because they poked.",
		"Hydrate. Pain plus dehydration is a faint.",
		"The Dominant is responsible for the anatomy. Want does not make a kidney a good target.",
		"If they ask to stop, you are proud of them. Do not sulk.",
		"Check the skin the next day. Pride in a bruise is optional. Infection is not a vibe.",
		"Close with ordinary tenderness so the nervous system knows the hunt is over."
	]),
	pack("sadism", "Sadism", [
		"You take your time choosing the place. They brat the wait. You do not speed up. The wait is yours.",
		"A precise, small cruelty they asked for, delivered without a grin getting away from you.",
		"You describe what you will do, then you do less, and they still shake. A dare for more is information. You still do less.",
		"The sadism is in the patience: a slow clamp, a slow count, a slow no.",
		"You make them ask for the thing that will sting, without a smirk riding the ask.",
		"A look that is fond and unkind in the proportion they like.",
		"You stop at the first pretty mark and make them thank you for the rest they will not get yet. Thanks is not a loophole.",
		"The implement stays in sight while you talk about something else.",
		"You give them a choice between two known hurts. You still enjoy the choosing. They do not add a third in heat.",
		"A quiet 'good' when they flinch the way you like.",
		"You hold their face and do not let them hide the feeling, including the brat that is trying to hide it.",
		"The mean thing is a sentence. The kind thing is a hand. You keep both in the room.",
		"You edge the pain the way some people edge an orgasm. They do not get to rush your tempo with sass.",
		"They may not rush you. Your tempo is the sadism.",
		"A single, perfect strike they will remember, then you refuse to chase it. Poking for a storm loses the storm.",
		"You make the aftercare look like mercy you decided, because you did.",
		"You make the aftercare look like mercy you decided, because you did — especially after a brat night.",
		"A notebook: you record what made them gasp. That hunger is yours to study.",
		"You stop while you still want more. Leftover hunger is part of the gift. They do not brat it out of you.",
		"The sadism ends when you say. They do not have to earn the end.",
		"You kiss them with the same mouth that was unkind.",
		"A scene about your enjoyment, named, so they are not mind-reading a monster.",
		"You take a photograph of the mark only if they want the evidence of what you did together.",
		"You stop while you still want more. That leftover is part of the gift.",
		"You thank them for letting you be this. Mean it."
	], [
		"Sadism without a way out is just harm. Keep the off-switch in the other hand.",
		"If you feel real contempt, you stop. The role is not a place to put your actual hate.",
		"Sadism without a way out is just harm. Keep the off-switch in the other hand, especially when they brat.",
		"Stay on the yes list. 'But I was in the headspace' is not a defence.",
		"Watch them more than you watch your own pleasure. The art is the reading.",
		"Aftercare is not optional because you 'came down fine.' Check them.",
		"If you feel real contempt at the spark, you stop. The role is not a place to put your actual hate.",
		"If they brat, that is a different game unless you both glued the games together on a calm day.",
		"Marks, work, family, and tomorrow's body are logistics. Plan them.",
		"A sadist can still be sweet in the kitchen. That is not a leak. That is the point.",
		"Do not use this to settle a fight. Fights are for ordinary language. Brats are not fights until they are.",
		"Write the cruel sentences that are allowed. Improvised poetry goes wrong.",
		"If they cry the 'wrong' cry, you drop the role and ask.",
		"Never target a real wound — body or story — unless they handed it to you as a button, in writing.",
		"No surprise implements, no surprise audiences, no surprise recording — not as a clever catch.",
		"They should know they can stop you. Remind them once at the start.",
		"Hydrate them. Hydrate you. Mean people faint too.",
		"Debrief: what you liked, what you regret, what you will not do again. Your ethics are part of the kink.",
		"If you need this every time to feel like a Dominant, talk about that out of scene.",
		"Close by being unmistakably safe. The monster puts the teeth away on purpose."
	]),
	pack("bondage", "Bondage", [
		"Wrists in cuffs they can still leave, after a push. Clipped to a belt, not to your mood.",
		"Ankles together with a strap, hands free, on the bed they know.",
		"Ankles together with a strap, hands free, so they can tap. Sass is not a reason to add a gag.",
		"Hands to the headboard with a quick-release clip.",
		"Hands to the headboard with a quick-release clip. They brat the still. You do not tighten for the smirk.",
		"Cuffs and a spreader they have used before. New geometry waits.",
		"Cuffs and a spreader they have used before. New geometry is not a catch. New geometry waits.",
		"A single column on each wrist, then you clip the columns together.",
		"A single column on each wrist, then you clip the columns together. They can still colour. They cannot fidget the brat into a worse tie.",
		"A futomomo only if they can still feel their feet. Time-cap.",
		"Hands behind, standing, your arm around them so they cannot fall. You do not leave a bound brat to 'think about it.'",
		"A collar that is not a hangman's loop. Two fingers of slack. Never to a moving line.",
		"Bind them on their side so breath is easy. A struggle that is play gets a check. A struggle that is panic gets out.",
		"A decorative chest harness that does not do rib-crushing.",
		"They hold a rope themselves as the bind, and they may drop it. Dropping it as a brat is still a drop. You honour it, then you talk.",
		"Cuffed to a chair that will not tip, feet flat.",
		"A quick cuff-and-kiss, then off, so the body learns it is safe even after a mouthy hour.",
		"Ankles to the corners, knees bent, no splits they do not have.",
		"They are bound; you are not. You do not leave the room. A brat does not earn unsupervised rope.",
		"Mummied in a sheet, mouth free, your hand on the outside.",
		"They are bound; you are not. You do not leave the room.",
		"A strappado fantasy kept on the bed, not on a hook.",
		"One wrist bound to your wrist. The bondage is togetherness.",
		"A leather sleepsack only with a way out you can work in the dark.",
		"Untie as slowly as you tied, unless they need out now — then shears."
	], [
		"Never leave a bound person alone. Not for a second. Shears or a cutter in reach.",
		"Two fingers of space. Colour and numbness are an immediate untie, not a toughness test.",
		"Never leave a bound person alone. Not for a second. Shears in reach. A brat does not earn unsupervised rope.",
		"If they cannot feel a hand or a foot, they come out. Tingling that does not fade in moments comes out.",
		"Do not suspend without training, a backup, and a spotter. Floor bondage is already a scene.",
		"Bonds go on a body that can still breathe. Chest compression is a medical problem.",
		"No rope or strap on the neck as a load-bearing line. A dare does not change anatomy.",
		"A gag plus bondage means a tap or a drop-able bell. Always.",
		"Joints at a natural angle. Pretzel is for photos, and photos can wait.",
		"If they panic, they come out first, talk second.",
		"Intoxication and bondage do not share a night, including a brat night with drinks.",
		"Time-box. 'All night' is a slogan. Bodies swell.",
		"Write which holds they loved. Catalogue the hardware that actually fits.",
		"Aftercare includes rubbing blood back, water, and not rushing them to be useful.",
		"If they panic, they come out first, talk second. Panic is not a loophole. It is a stop.",
		"If they have nerve issues, old injuries, or clotting problems, this is a careful yes or a never.",
		"The cutter is not a mood-killer. It is how you get to do this again.",
		"Keys for locks live on you, not across the room.",
		"Debrief circulation, sleep, and whether they want less next time. Believe less.",
		"Close with them free, held, and sure they could have gotten out because you would have gotten them out."
	]),
	pack("cock-worship", "Cock worship", [
		"They greet it the way you both wrote: a kiss, a title, a wait. A smirk instead of the title means you wait longer.",
		"A slow undress of you, then they stay dressed until you say.",
		"On their knees, hands behind, mouth only, pace you set. They do not get to rush you as a brat.",
		"They look up when they can; they look down when you say.",
		"A wash first. The worship starts on clean skin. Sass about the wash is not a skip.",
		"They describe what they want to do, then they ask, then they do it.",
		"You sit. They come to you. If they dawdle as a poke, you point at the mark. You do not fetch them.",
		"A time-capped throat scene they have practised. Air is scheduled.",
		"They use hands the way they use a prayer: specific, not frantic. Frantic as a brat is a still command.",
		"You rest a palm on their head without steering until they ask to be steered.",
		"They thank it and they thank you, as two different sentences, without a joke that dodges the thanks.",
		"A mirror so they can see the devotion if that is their kink.",
		"Soft cock worship counts. Especially then. A brat comment about it is a stop and a kindness, not a dare to prove.",
		"They keep it in their mouth while you talk about the day, then you come back to the room.",
		"A rule: no teeth unless you asked. A scrape as sass is a pause, not a punishment stacked in heat.",
		"They finish with their face where you want it, then they wait for the next kindness.",
		"A service evening: they may not rush you to a peak. The brat clock is not your clock.",
		"A service evening: they may not rush you to a peak.",
		"After you finish, they stay until you lift their chin. Leaving early as a poke is a return to the kneel.",
		"You stay still and make them do the work. That is the scene.",
		"They ask to swallow, or to not. You already know the answer because you asked last week.",
		"A collar on, mouth open, patience as the offering.",
		"They kiss down the thighs first. The cock is not the only altar.",
		"After you finish, they stay until you lift their chin.",
		"They get to be proud of the worship. Say so."
	], [
		"If they choke, you stop, they cough, you wait. No 'one more try' in the same breath.",
		"Write what pace they loved.",
		"If they choke, you stop, they cough, you wait. No one more try in the same breath, smirk or not.",
		"Clean bodies, cut nails, no surprises with teeth or toys at the back of the throat.",
		"They may want to be used. They may want to adore. Ask which night this is.",
		"If you cannot finish, the worship was still complete. Say so.",
		"They may want to be used. They may want to adore. Ask which night this is. A brat mix-up needs a question.",
		"Air is not optional. A tap on your thigh is a safeword.",
		"No holding the head down unless that was a named yes, and still they can tap.",
		"Jaw, neck, and knees need breaks. Worship that wrecks them is sloppy.",
		"Air is not optional. A tap on your thigh is a safeword. Honour it even if you think they were poking.",
		"Aftercare can be water, a spit-or-swallow towel, and no jokes about 'mess.'",
		"Do not compare their mouth to anyone else's.",
		"STI status is part of this scene. Barriers are allowed and not a mood-killer.",
		"No holding the head down unless that was a named yes, and still they can tap. A brat night is not a reason to forget.",
		"A soft cock is not a failure of the ritual. Adjust the story.",
		"Time-box if they are on their knees. Floors are hard.",
		"Put keepers in Notes: the pace, the words, the after.",
		"They get praise for the devotion, not only for the finish.",
		"Kiss them on the mouth after if they want that closeness. Ask."
	]),
	pack("double-penetration", "Double penetration (toys)", [
		"Your cock in the cunt, a slim flared plug in the ass — they brat for thicker. You stay slim. Named, lubed, no heroics.",
		"Your cock in the ass, a slim dildo filling the cunt. Pillow under the hips.",
		"Side-lying: your cock in the cunt, a slim plug in the ass. They try to rush depth as a loophole. They control with a hip only when you say.",
		"Your cock in their mouth while a slim toy occupies the cunt — they tap if they need air.",
		"A plug they already wear, then your cock in the empty hole they asked for. Asking with a smirk means you wait for ordinary words.",
		"They ride your cock; you hold a slim toy still in the other hole.",
		"Your cock in the cunt, a remote plug in the ass. They sass for more buzz. You tease without a third arm, and without chasing the brat.",
		"Your mouth on their clit, a slim toy filling the cunt — you pace both.",
		"Two of your fingers in the cunt, a slim plug in the ass — a training night. They do not brat you into thicker.",
		"Warm-up is your fingers, one hole at a time, until your cock and a slim toy can share them without a brace.",
		"They look in a mirror if they want to see your cock and the toy. Hiding their face as a poke gets a check, not a harder fuck.",
		"Your mouth on the hole that is shy tonight; a slim toy occupies the greedy one.",
		"The toy enters the second hole on an exhale, your cock already home. A flinch dressed as sass is still a flinch. You wait.",
		"You go still with your cock in; the toy stays seated — or you go slow. They pick.",
		"Your cock in their mouth, a slim plug they already wear — two fills, one of them you. They tap if they need air. A gag-joke is not a tap.",
		"Your fingers in their ass, a slim vibrator in the cunt, your mouth on their neck so they hear you.",
		"Four of your fingers as the first fill, a slim toy as the second, once they ask in words — not in a dare.",
		"Your mouth working their cunt while you fuck them with a slim toy in the ass.",
		"Double as a reward they bought with points: your cock, one toy, they name the holes. They do not add a third as a brat tax.",
		"Your cock out first, then the toy, slowly, then a palm over the body.",
		"Double as a reward they bought with points: your cock, one toy, they name the holes.",
		"A timer: five minutes of your cock plus a toy, then rest, then decide if there is a second set.",
		"You hold their hip with one hand and the toy with the other, your cock doing the slow work.",
		"Your mouth on theirs, your cock in one hole, a slim toy in the other — you breathe for both of you.",
		"Aftercare starts when your cock and the toy are both out, with a bathroom plan without shame."
	], [
		"Lots of lube, more than pride wants. Reapply.",
		"Nails short. Anything anal needs a flared base. Your cock does not count as the flare.",
		"Never move from ass to vagina or mouth without a condom change or a wash. A brat rush does not skip the wash.",
		"Sharp pain is a stop. Burn that eases may be stretch. They tell you which.",
		"Go smaller than the internet. Your cock plus a slim toy is already a lot.",
		"If they have an existing tear, haemorrhoids flare, or an infection, this waits.",
		"Breath together. Bearing down gently can help the toy enter next to you. Pushing past a wince because they dared you does not.",
		"A safeword while full may come out as a tap. Watch the hand.",
		"Do not add a third thing tonight. Greed is how people bleed.",
		"Aftercare: water, a pad if they want, no “jokes” about looseness. Ever.",
		"Do not add a third thing tonight. Greed — theirs or yours — is how people bleed.",
		"If a harness frees a hand, straps should not bite hips for the sake of a photo.",
		"If they dissociate, you out, toy out, name, blanket.",
		"Write which toy actually fitted with you. Catalogue it.",
		"If they dissociate, you out, toy out, name, blanket. Do not read it as a brat going quiet.",
		"Warm-up time is longer than the peak. Budget for that.",
		"You plus one toy, two holes. Stacking two toys in one hole as well as yourself is a different scene. Stay here tonight.",
		"Keep a towel. Keep the lube uncapped. Fumbles kill mood more than planning does.",
		"They may laugh when it is awkward. Awkward is allowed. Then adjust.",
		"Kiss them like the fullness was intimacy, because it was."
	]),
	pack("triple-penetration", "Triple penetration (toys)", [
		"Your cock in the cunt, a slim plug in the ass, a slim toy they suck — named, slim, slow. They brat for bigger. You stay slim.",
		"Your cock in their mouth, a slim plug in the ass, a slim dildo in the cunt. That is already a lot.",
		"They lie on their side. Your cock in the cunt, a slim plug in the ass, a slim toy at their mouth. Heroic stacking as a dare does not.",
		"A slim plug, a slim vaginal toy, and your thumb they can suck. Your hand is the third.",
		"Your cock, a plug, and a mouth toy they are allowed to drop whenever. Dropping it as a brat is still a drop. You honour it.",
		"One hole is just your fingertip. A slim toy in the second. Your cock in the third. Triple can mean “almost.” Honour almost.",
		"A scene that names your cock plus two slim toys and never actually gets to three because they poked for pride. That is still the scene.",
		"You hold still. They back onto your cock and a toy. The mouth toy is a maybe they add later.",
		"They pick which hole is the shy one tonight. Your cock takes the brave one; two slim toys wait. They do not pick all three as a smirk.",
		"Short intervals: thirty seconds of your cock and two toys, then two fills, then three, then out.",
		"Training night: a plug, your fingers, your mouth. Call it triple if you want. A brat demanding the porn version loses the night.",
		"A vibrator on the clit, your cock in the cunt, a modest plug in the ass. Say so out loud so porn does not lie.",
		"A tap on your wrist is the whole language while their mouth is on your cock and two toys fill the rest. A tap is not a loophole. Everything eases.",
		"All toys slimmer than your pride; your cock is the thickest thing in them. All lube wetter than the video.",
		"One toy out at the first yellow. Your cock stays only if they want it. You do not let a 'I was bratting' pull them back to three.",
		"You watch their feet. Your cock and two slim toys stay; curl is data. Stillness can be freeze. Ask.",
		"After two holes are happy on your cock and a toy, you ask whether the mouth wants the third. No is a complete scene, even from a brat.",
		"A pillow fortress so your cock, the plug, and the mouth toy strain nothing in a knee or a neck.",
		"The third thing is your tongue. Two slim toys do the filling. A dare for a third toy is greed. You stay kind.",
		"After two holes are happy on your cock and a toy, you ask whether the mouth wants the third. No is a complete scene.",
		"A timer on the nightstand. Your cock plus two toys is minutes, not an hour.",
		"The third thing is your tongue. Two slim toys do the filling. Sometimes that is the kindest geometry.",
		"Stop while they still want it. Your cock and the toys come out with leftover hunger rather than a tear.",
		"Toys out in reverse order, then your cock, slow, with a palm on the back.",
		"They get water before they try to make a joke about your cock and the two toys that just happened."
	], [
		"Three is optional, not a badge. Most nights you plus one toy is already plenty.",
		"Slim toys, flared anal bases, more lube, shorter time than the fantasy. Your cock is not the small one.",
		"A tap or a drop-able toy is a safeword when the mouth is busy on you. Honour it. Do not call it a loophole.",
		"Never ass to vagina or mouth without a barrier change.",
		"If they cannot breathe, everything comes out — you and the toys. Air wins.",
		"Sharp pain is a stop. “Too much” is a stop. Ego is not a third partner.",
		"If they cannot breathe, everything comes out — you and the toys. Air wins. Sass does not get a vote.",
		"If they have tears, flares, infections, or are not warmed, this waits.",
		"Write the exact toys that worked next to you, if any did.",
		"If it was too much, the aftercare sentence is “thank you for saying,” not “we almost had it.”",
		"Do not add a fourth idea tonight. Greed is how people bleed, including greedy brats you adore.",
		"Next-day bathroom check. Blood is not “fine.”",
		"No jokes about gape, looseness, or being “ruined.” Ever.",
		"If they dissociate, you out, toys out, name, blanket, ordinary voice.",
		"If they dissociate, you out, toys out, name, blanket, ordinary voice. That is taming too.",
		"Warm-up is you in one hole, then a toy in a second, then maybe a third. Never the other way.",
		"Knees, jaws, and necks fail first. Pad them.",
		"A third person is not implied. This is your body and toys, unless you both named a guest on a calm day.",
		"Aftercare includes a shower they do not have to perform as pretty.",
		"Kiss them like you did not just try to prove something. You did not. Right?"
	]),
	pack("electrostimulation", "Electrostimulation", [
		"A body-safe estim toy on the lowest setting, on a muscle, not a joint. They brat for higher. You stay lowest until the map is real.",
		"Pads on the inner thigh, pulse on a clock, your finger on the off switch.",
		"Sync the pulse to their breath: on the exhale only. They cannot sass the breath into a harder setting.",
		"Sync the pulse to their breath: on the exhale only.",
		"They hold the remote. You hold the veto. A brat turning it up is a veto, then a talk, not a dare accepted.",
		"They hold the remote. You hold the veto.",
		"Estim on the perineum through a toy made for that, seconds at a time. Seconds are not a loophole they can brat past.",
		"Estim on the perineum through a toy made for that, seconds at a time.",
		"A rhythmic pattern, then a pause, then they ask for it back in ordinary words, not in a poke.",
		"Warm skin, dry pads, good contact. Poor contact bites.",
		"Estim as a tease while they are cuffed loosely. Loose enough to tap. Sass is not a reason to tighten.",
		"Do not chase intensity. Chase the look on their face.",
		"They describe the feeling in plain words: sting, ache, buzz, no. Clever metaphors can wait. You need no.",
		"A session of five pulses, then a kiss, then decide.",
		"Off during any conversation about colour. On only when they are ready again. A brat 'I'm fine' during off stays off until you hear a real colour.",
		"Use it as a metronome for them to hold a position.",
		"A short scene so you both learn their map. They do not get a longer one by daring you.",
		"A toy they already like, now with a mild pulse, if it is rated for that.",
		"They come with a low pulse only if that is a known yes, not an experiment they brat into in the last ten seconds.",
		"A short scene so you both learn their map.",
		"After a pulse, your mouth on the same place.",
		"They come with a low pulse only if that is a known yes, not an experiment in the last ten seconds.",
		"Pads off, skin checked, lotion if it looks fussy.",
		"Write which placement was delicious and which was simply annoying.",
		"Put the toy away like it is sharp, because to a heart it can be."
	], [
		"Never across the chest, head, or neck. Never if there is a heart condition, a pacemaker, epilepsy, pregnancy, or you are not sure.",
		"Only toys sold for bodies. No TENS units unless you have been taught for erotic use, and still never across the chest.",
		"Broken skin, metal jewellery in the path, or wet floors: no. A smirk does not make it a yes.",
		"Start lower than the manual's “fun” setting. People lie in manuals too.",
		"If it feels sharp-wrong, off. Contact gel or better pads, or you end the idea.",
		"Do not combine with a metal collar or nipple jewellery in the circuit.",
		"Do not combine with a metal collar or nipple jewellery in the circuit, and do not add that as a catch.",
		"Alcohol, drugs, and estim do not share a night.",
		"Aftercare is ordinary: water, a look at the skin, a cuddle. Watch for feeling shaky.",
		"Do not use while they are standing on a wet bathroom floor.",
		"If they laugh, good. If they cannot speak, off. Do not wait to see if the laugh was a brat.",
		"Read the toy's own warnings. They beat this list if they are stricter.",
		"No estim in a pool, bath, or shower unless the toy is explicitly made and rated for that, which most are not.",
		"This is a maybe-never for many experienced people. That is allowed.",
		"Do not punish with electricity. Ever. A brat is not a circuit.",
		"Store pads so they still stick. Poor stick means hot spots.",
		"If they have nerve pain conditions, ask a clinician before you play, or skip.",
		"Write a hard no on the chest in Notes so lust cannot “forget.”",
		"A pulse should be a flavour, not a proof of love.",
		"If anything feels cardiac — chest, jaw, unusual shortness — off, and you are done with the toy tonight."
	]),
	pack("impact-play", "Impact play", [
		"A warm-up with the hand on the seat, then the toy they already know. They brat for the cane first. You warm up anyway.",
		"Thighs, not the lower back. You can both see the skin.",
		"A slow paddle, counted, with a breath between. They rush the count as a poke. You restart the count, bored.",
		"The sting they like, then the thud they like, then you ask which to keep.",
		"They present. You wait until the presenting is real, not a joke. Then you begin.",
		"A flogger on the back of the shoulders, away from the spine and the kidneys.",
		"A slap they asked for, on the face, only if face is a known yes — open hand, no rings, no ear. A smirk-ask is a wait for a real ask.",
		"A slap they asked for, on the face, only if face is a known yes — open hand, no rings, no ear.",
		"They choose the toy from two. You choose the count. They do not add a third implement as a loophole.",
		"A scene that is mostly warm-up. The 'real' set is ten. Then you stop.",
		"Impact as punctuation between instructions, not as a storm you throw because they sassed.",
		"You choose the toy. They choose the colour that means ease off.",
		"The cane only if you have practised on a pillow and on yourself. Light. Few. A brat dare does not write the cane.",
		"A over-the-lap spanking that is intimate, not theatrical, unless they want theatre.",
		"They count. If they lose the number as a brat, you pause, not pile on, unless that game was named on a calm day.",
		"A thuddy bat on the seat, then your palm to read the heat.",
		"A ritual: kiss, strike, kiss. If they brat the kiss, you wait for it. You do not skip to a harder strike.",
		"Marks as a maybe. Ask about shorts, work, and swimming tomorrow.",
		"The last set is the kindest. Then the toy goes out of reach, even if they poke for one more.",
		"You stop at the first mark that is prettier than you meant.",
		"Impact on the calves or the soles only if they asked, and lightly — lots of nerves.",
		"A hair-brush scene that stays on the seat.",
		"The last set is the kindest. Then the toy goes out of reach.",
		"They get to look at the colour in a mirror if they want the evidence.",
		"You ice or you lotion or you do neither — they pick, after you look at the skin."
	], [
		"Warm the body first. Stay off kidneys, spine, throat, joints, and the tailbone as a target.",
		"Wrapping is how thighs get hip bones. Watch your angle.",
		"If the skin splits, you are done with impact. Clean, assess, no one more, smirk or not.",
		"Face, breasts, and genitals are advanced and optional. Default is seat and thighs.",
		"A implement you have never used belongs on a pillow first.",
		"Intoxication and impact do not share a night.",
		"If they go floppy or quiet, you stop and ask. Subspace is not a guess you make from behind, and not a catch.",
		"Count, or a clock. Open-ended beating is how accidents happen.",
		"Marks only where you both agreed they may show.",
		"Aftercare is extra: drop is real. Water, sugar, blanket, your ordinary voice.",
		"Do not chase the last time's bruise. Bodies vary. A brat dare does not restore last week's canvas.",
		"If they have clotting issues, are on blood thinners, or bruise alarmingly, this is a clinician talk or a never.",
		"The toy is put away before aftercare so the nervous system can stand down.",
		"Write which implements they loved. Retire what only looked fierce.",
		"Do not mix a fight with a spanking. The spanking will not repair the fight, and it will not tame a real anger.",
		"Do not mix a fight with a spanking. The spanking will not repair the fight.",
		"Check the skin the next day. Pride is optional. Heat, stripes, and unbroken skin are data.",
		"If you are angry, you do not pick up a toy.",
		"Kiss the place you were harshest.",
		"Close with them unhit, held, and sure the hunt is over."
	]),
	pack("shibari", "Shibari", [
		"A single-column tie on each wrist, on the floor, shears in sight. They brat the still. You do not cinch for the smirk.",
		"A chest harness that is decorative, not load-bearing, two fingers of space.",
		"Futomomo on one leg, the other free, time-capped. They do not brat the cap into 'a bit longer.'",
		"Futomomo on one leg, the other free, time-capped.",
		"A TK only if you have been taught. A picture they dare you to copy is not a class. Skip it.",
		"A TK only if you have been taught. Otherwise, skip the picture you saw.",
		"A gote that stays loose enough for a hand to slide. Beauty after safety. Tightening to win a brat is how nerves die.",
		"A gote that stays loose enough for a hand to slide. Beauty after safety.",
		"A crotch rope only if they asked, with padding and a way out that does not yank. Asking as a poke still needs the padding.",
		"A crotch rope only if they asked, with padding and a way out that does not yank.",
		"A scene about the pulling-in, not about the photograph they want to brat into the internet.",
		"A scene about the pulling-in, not about the photograph.",
		"An upper-body tie plus a blanket, because bound people get cold. Sass about the blanket does not remove it.",
		"An upper-body tie plus a blanket, because bound people get cold.",
		"They tell you a story while you tie, so you keep hearing their voice. Silence as a freeze is a check, not a catch.",
		"They tell you a story while you tie, so you keep hearing their voice.",
		"A rope gag only if they have a tap and a clear nose. Maybe skip — especially on a brat night when you need to hear yellow.",
		"You untie as a scene: slow, kissed, blood returning.",
		"A self-tie they do, you check. Agency as the aesthetic. A sloppy self-tie as a loophole gets a redo, not a humiliation pile-on.",
		"Marks from rope are a maybe. Ask about short sleeves tomorrow.",
		"A self-tie they do, you check. Agency as the aesthetic.",
		"No arms-above-head for long. Nerves live there.",
		"A hip tie that presents, then you do something that is not more rope.",
		"The first time on a person is half as tight as the first time on a chair.",
		"Shears on the mat before the first wrap. Always."
	], [
		"Never leave a bound person alone. Keep shears. Nerve pain, colour change, or numbness is an immediate untie.",
		"Do not suspend. Suspension is a class, a spotter, and hardware — not a mood.",
		"Do not suspend. Suspension is a class, a spotter, and hardware — not a mood, and not a brat dare.",
		"No rope as a load on the neck. Ever.",
		"If they cannot feel a hand, they come out. Do not 'finish the pattern.'",
		"Intoxication and rope do not share a night.",
		"If they cannot feel a hand, they come out. Do not finish the pattern to win the smirk.",
		"Joints at a natural angle. Pretty that wrecks a shoulder is not pretty.",
		"Time-box. Bodies swell in rope.",
		"If they panic, shears are allowed to ruin the aesthetic. You can retie another year.",
		"If they panic, shears are allowed to ruin the aesthetic. You can retie another year. Panic is not a loophole.",
		"Aftercare is circulation, warmth, water, and not rushing them to pose for a photo.",
		"Write which harness they could breathe in. Retire what only looked like the internet.",
		"A class beats a video. A video beats guessing. Guessing is how nerves die.",
		"A class beats a video. A video beats guessing. Guessing because they dared you is how nerves die.",
		"Keys and cutters on you, not across the room.",
		"Do not add impact on a limb that is already nerve-compromised in a tie.",
		"Check in the next day about grip, tingling, and sleep. Tingling that stays is a clinician.",
		"The person is the point. The pattern is optional.",
		"Close with them free, wrapped in something warm, sure you would have cut them out."
	]),
	pack("orgasm-control", "Orgasm control", [
		"They ask. You say not yet. You mean the clock you both set. Bargaining is a brat. The clock does not move.",
		"An edge, a rest, an edge, a rest. Three, then a decision you already made.",
		"Permission as the peak: the same word every time. A joke word is not the word. They wait.",
		"A no-touch morning, time-capped, with a yellow that returns their hands.",
		"They may come when the timer ends, not when they bargain, smirk, or offer a loophole.",
		"You finish first if that is the rule tonight. They wait. Generous or not is named at the start, not as a brat tax.",
		"A ruined orgasm only if that is a known yes, not a surprise lesson for a brat. Write it. Then maybe.",
		"They wear a ring with a time cap, colour checks, and no sleeping in it.",
		"A week of ask, not a month of silence, unless they asked for the long game. You do not extend it to win a poke.",
		"A week of 'ask,' not a month of silence, unless they asked for the long game.",
		"Denial as a gift of attention, not as a sulk you throw because they sassed.",
		"Denial as a gift of attention, not as a sulk.",
		"A scene where they come quickly on purpose, because control is not always later, and not always a catch.",
		"A scene where they come quickly on purpose, because control is not always 'later.'",
		"They write how close they got, in numbers, once. A cute lie is a rewrite, not a punishment stacked in heat.",
		"They write how close they got, in numbers, once, then they put the pen down.",
		"A ruined-or-full choice they make at the start, not in the last two seconds of a brat spiral.",
		"Orgasm as a reward already on the board, marked, then given without moving the posts.",
		"They say the crude word for what they want. Then they wait. A brat paragraph is not the word.",
		"They may come as many times as the body will, and the control is that you decide when the set starts.",
		"A chastity device only if it fits, can come off, and has a hygiene plan. Otherwise skip the hardware.",
		"You say 'now' and you keep doing exactly what was working.",
		"They say the crude word for what they want. Then they wait.",
		"A night they do not come, planned, with extra aftercare for the raw feeling.",
		"A night they do, on a word, and you make a fuss of the pairing."
	], [
		"A body that comes 'too soon' is a body, not a brat, unless they are performing a loophole you both think is funny.",
		"Agree whether a slip is a giggle, a reset, or a punishment. Write it down.",
		"Ruined orgasms are a specific kink. Do not accidentally ruin one as a catch unless that was written.",
		"Chastity needs fit, hygiene, a time cap, and a key on you. Swelling, cold, or numbness comes out.",
		"SSRIs, alcohol, pain, and shame all change the map. Lower the ambition.",
		"Do not train self-hate. A miss is a miss.",
		"Do not train self-hate. A miss is a miss. A brat miss is still a body.",
		"The cue stays the same if you are also training command.",
		"If they look like they are enduring, you are not controlling an orgasm. You are ignoring a person.",
		"Public orgasm control is a fantasy that still loses to non-consenting people. Keep it private or keep it invisible.",
		"If they look like they are enduring, you are not controlling an orgasm. You are ignoring a person. Ask.",
		"Do not stack humiliation, pain, and denial on night one.",
		"They can call yellow on the game without calling yellow on you.",
		"If they ask to come because they are in pain, they come or you stop. Pain is not a lock.",
		"They can call yellow on the game without calling yellow on you. Honour it. That is not them winning the brat.",
		"A week is long. A month is a relationship conversation, not a silent test.",
		"Hydrate. Edging dehydrates patience and people.",
		"You decide when they come. They do not decide when you are done talking.",
		"End on purpose: now, or not tonight, and then hold them.",
		"Kiss them like the control was intimacy, not a scoreboard."
	]),
	pack("games", "Games", [
		"A dare jar you both filled on a calm day. You draw. They brat the draw. You reroll only if it is off the yes list.",
		"Chess or cards: loser kneels for the next round's start.",
		"A yes, and improv that stays inside the yes list. They try to yes-and a limit. You stop the game. Limits beat clever.",
		"Roll for aftercare style: quiet, talky, food, bath.",
		"The brat names three games, the tamer picks one. You pick. They do not add a fourth after they lose.",
		"The brat names three games, the tamer picks one.",
		"Hide the clothespin: last one to find it sets the next kiss. Cheating as a brat is a kiss you choose, then a talk.",
		"Hide the clothespin: last one to find it sets the next kiss.",
		"A wheel of praise only — so a brat night can end without a catch, if that is what you decide.",
		"Co-op: you both lose if anyone skips a colour check.",
		"Strip rules that stop at underwear unless the room is private and the yes is current. They do not brat the clothes off in front of a window.",
		"End the game on a win for both, even if the dice were mean.",
		"Two truths and a filthy wish. You pick which wish to run. They do not pick for you as a loophole.",
		"A card they drew last month, played tonight, so chance had time to be consented to.",
		"The wheel in Games, with slices you wrote, none that blow a limit. If it lands off the list, you reroll. Chance is not consent, and not a brat win.",
		"A Jenga tower: each brick is a known dare. It falls, you both drink water, not shots.",
		"They have to win a round to earn the scene they already wanted — or you commute it if luck is ugly. You do not use a loss to sneak a catch.",
		"A scavenger hunt of catalogue items, ending on the bed.",
		"Dice for pace: slow, slower, still. Not for punish with a never, and not for a brat tax you did not write.",
		"A board you both hate to lose at, with a table rule that the winner services the loser.",
		"Dice for pace: slow, slower, still. Not for 'punish with a never.'",
		"A memory game: they recall last scene's keepers. Right answers are kisses.",
		"You are the timer. They play against your clock for ten minutes. You still hear yellow.",
		"A 'stop-go' red-light game with freeze as the hot part, not as a trap.",
		"Make a new card together before you shuffle the old ones."
	], [
		"If the card, die, or wheel lands off the yes list, you reroll. Chance is not consent.",
		"Keep the kit in Games so you can start without a planning meeting.",
		"Alcohol makes people agree to stupid dares. Skip it. Brats plus drink is how limits get 'funny.'",
		"A game is still a scene if it gets intense. Safewords still work.",
		"Do not use a loss to sneak in a kink they have not agreed.",
		"Time-box. Games that eat the night become chores.",
		"Do not use a loss to sneak in a kink they have not agreed, and do not call that taming.",
		"If they tilt into actual upset, you stop being a games-master and become a partner.",
		"Write new cards together. Your rules beat the printed ones.",
		"If they win the round, you still run the night you wrote. Chance is not the Dominant.",
		"If they tilt into actual upset, you stop being a games-master and become a partner. Upset is not a smirk.",
		"Keep a veto token on the table so chance never feels like a trap.",
		"Aftercare after a mean game is not optional.",
		"If points bought the game, mark it bought, then be generous in how you play it.",
		"Keep a veto token on the table so chance never feels like a trap, even when they are poking the pile.",
		"A laugh that breaks the game can be the best round.",
		"Put keepers into custom cards the same night.",
		"Do not keep score across the relationship. That becomes a wound.",
		"You still own the rules. They may suggest a card. You decide if it goes in.",
		"Close with water and a sentence about what was fun, not who won."
	]),
	pack("dominant-self-improvement", "Dominant-self improvement", [
		"When they brat, you breathe twice before you speak. The second breath is the Dominant.",
		"You name the catch before the sass peaks, so you are not inventing punishment in heat.",
		"Practise looking bored while they poke. Bored is a tool. Anger is not.",
		"A brat window you set with a clock. When it ends, you take the night back in one sentence.",
		"You write three in-bounds catches this week and you use only those. No freelance cruelty.",
		"If they top from below, you thank the information, then you decide. You do not debate the crown.",
		"Keep your voice lower than theirs when they get loud. Volume is not dominance.",
		"You put them on their knees for the stop — not for your ego, for their nervous system.",
		"Learn their brat-to-drop face. When it shows, you switch from taming to holding.",
		"You do not chase a smirk with a bigger smirk. You wait. They come to the mark.",
		"After a brat night, you debrief the catch, not the person. They are not a problem to solve.",
		"Practise the release word so their spark can stand down. Taming includes the off-switch.",
		"You let a small brat live if it is play. You stop a brat that is a fight. Tell the difference out loud.",
		"Train the still hold: their forehead on your knee until the clever mouth is done.",
		"You ask, once, whether they need to brat or need to cry. Then you run the night they actually need.",
		"You put the phone down before you give a command. Split attention is not a presence.",
		"Practise one command in a calm voice until you can do it tired.",
		"Write what you will not do when you are hungry, late, or embarrassed. Then do not do it.",
		"A daily two-minute posture of your own — shoulders, breath — so the role has a body.",
		"You ask for a colour even when you are sure. Confidence includes checking.",
		"Learn three ways into subspace that are not pain: voice, still, repetitive service.",
		"You hold the landing as carefully as the peak. Aftercare is dominance too.",
		"Count to four on the exhale before you add intensity. Self-control is the kink they can feel.",
		"You apologise inside the dynamic when you fumble, then you take the night back. Fumbles are not abdication.",
		"Read their body map again this month. Guessing is not confidence."
	], [
		"Write the drill in the journal the same day, or it did not happen.",
		"If you are actually angry, pause the dynamic. Self-control is the scene.",
		"Practise this when nothing is on fire, so it is in your mouth when they poke.",
		"A colour check still wins. Confidence is not skipping it.",
		"Do not stack three improvements this week. One change you keep beats a new religion.",
		"If they safeword, you thank them. That is taming too.",
		"Debrief tomorrow: what you did with your own temper, not only what they did with theirs.",
		"Keep the catch on the list. Inventing in heat is how you become the problem.",
		"Aftercare after drills. Your nervous system does not know it was only practice.",
		"If it felt like winning, check whether they landed. Winning is not the job.",
		"Put the phone in another room for the next scene. Presence is a skill.",
		"Ask them what helps them drop. Then do that, not the forum version.",
		"Bored is allowed. Cruel is a flavour you both named. Contempt is a stop.",
		"If your voice shook, that is data. Repeat the line later. Do not fake steel.",
		"A brat is not a referendum on your dominance. Stay in your body.",
		"Sleep, food, and not drinking before a catch night. Biology is not a loophole you get.",
		"Praise yourself for the pause you took. That is the muscle.",
		"If they needed holding, you hold. Taming that cannot hold is just winning.",
		"Read one Education note on bratting or subspace this week and use one sentence from it.",
		"Close with water and a true sentence. You need the landing as much as they do."
	]),
	pack("submissive-self-improvement", "Submissive-self improvement", [
		"You brat on purpose inside the window, then you stop when the clock ends — without a bonus poke.",
		"Practise asking for the thing you were about to sass for. The ask is the skill.",
		"When you want to top from below, you kneel first, then you speak.",
		"You write three in-bounds brats and you stay inside them. New cruelty is not play.",
		"Learn your drop signs. When they show, you say yellow instead of pushing harder.",
		"You take the catch without a speech. The speech can wait for debrief.",
		"Practise the honorific when you are annoyed, not only when you are wet.",
		"A still hold: forehead, breath, mouth closed, until you are invited.",
		"You brat for connection, then you let yourself be caught. Running the catch is not your job.",
		"When they look bored, you do not escalate. You get smaller or you ask.",
		"Journal the brat: what you needed, what you did, what you will try next time.",
		"Practise going still on a single word. That word is how you stop.",
		"You drink water before the clever remark. Bodies lie; thirst looks like sass.",
		"Learn to come down: from spark, to kneel, to ordinary, without a sulk.",
		"You ask for subspace with words — voice, still, repetition — not with a war.",
		"Confidence is taking the yes list seriously, including your own nos.",
		"You fold the scene clothes. Usefulness after a brat is not grovelling. It is landing.",
		"Practise receiving praise without a joke that dodges it.",
		"When you freeze, you say so. Freeze is not a brat. Do not dress it up as one.",
		"You keep the brat out of work, family, and public people who did not consent.",
		"A colour check you offer, not only one you wait to be asked.",
		"You let them see the soft under the spark. Hiding it makes them guess, and guessing is strain.",
		"Practise the crude ask in a calm voice so you do not have to misbehave to be heard.",
		"After a catch, you do the aftercare you need: words, quiet, food. You may ask.",
		"You write one keep, one tweak, one never, after a brat night, before you rewrite history."
	], [
		"If you cannot do it this time, you say so. A missed drill is data, not a new brat.",
		"Safewords are not cheating. Using one is the job.",
		"Do not add a fourth poke after the stop. That is how play becomes a fight.",
		"Write it in the journal the same night, or the story will get funnier than it was.",
		"If they are actually angry, you drop the spark and become a partner.",
		"A colour is a complete sentence. You do not have to make it cute.",
		"Practise this when you are not already flooded, so it is in your mouth later.",
		"You are allowed to want to be caught. Wanting it is not topping from below.",
		"If the brat was a bid for care, say that in ordinary words after.",
		"Keep in-bounds. Work, family, and strangers are not your audience.",
		"Take the water. Take the blanket. Landing is part of being good at this.",
		"If you froze, tell them. Do not let them read it as sass.",
		"One change you keep beats a personality transplant they did not ask for.",
		"You may cry. That is not a failed brat. That is a body.",
		"Ask for the still, the voice, or the repetition if you want subspace. They cannot read a war.",
		"Do not punish yourself with a meaner brat tomorrow. Repair is a conversation.",
		"If the catch hurt wrong, you say so tomorrow. Keep, tweak, never.",
		"Your nos belong on the list too. Confidence includes them.",
		"Thank them for catching you when they did it well. Specific, not theatrical.",
		"Close with ordinary voice. The spark does not get the last word unless they invite it."
	])
].map((group) => ({
	value: group.slug,
	label: group.label,
	parent: "ideas"
}));
var IDEA_SLUG_ALIASES = {
	"public-play": "exhibitionism",
	voyerism: "voyeurism"
};
function resolveIdeaSlug(slug) {
	if (!slug) return "";
	return IDEA_SLUG_ALIASES[slug] ?? slug;
}
function clipIdeaTitle(text, max = 160) {
	const clean = text.replace(/\s+/g, " ").trim();
	if (clean.length <= max) return clean;
	return `${clean.slice(0, max - 1).replace(/\s+\S*$/, "").trim()}…`;
}
function p$1(text) {
	return `<p>${text}</p>`;
}
function h$1(text) {
	return `<h2>${text}</h2>`;
}
function h3(text) {
	return `<h3>${text}</h3>`;
}
function ul$1(...items) {
	return `<ul>${items.map((item) => `<li>${item}</li>`).join("")}</ul>`;
}
function ol$1(...items) {
	return `<ol>${items.map((item) => `<li>${item}</li>`).join("")}</ol>`;
}
function callout$1(text) {
	return `<blockquote><p><strong>Hold this.</strong> ${text}</p></blockquote>`;
}
function doc$1(...parts) {
	return parts.join("");
}
var NOTE_LIBRARY_CATEGORIES = [
	{
		value: "education",
		label: "Education"
	},
	{
		value: "reference",
		label: "Reference",
		parent: "education"
	},
	{
		value: "how-to",
		label: "How-to",
		parent: "education"
	},
	{
		value: "exercises",
		label: "Activities"
	},
	{
		value: "self",
		label: "Self",
		parent: "exercises"
	},
	{
		value: "partner",
		label: "Partner",
		parent: "exercises"
	},
	{
		value: "dynamic",
		label: "Dynamic",
		parent: "exercises"
	},
	{
		value: "kinks",
		label: "Kinks",
		parent: "exercises"
	},
	{
		value: "communication",
		label: "Communication",
		parent: "exercises"
	},
	{
		value: "play",
		label: "Play",
		parent: "exercises"
	},
	{
		value: "roles",
		label: "Roles",
		parent: "exercises"
	},
	{
		value: "bratting",
		label: "Bratting",
		parent: "exercises"
	},
	{
		value: "body",
		label: "Body",
		parent: "exercises"
	},
	...IDEA_CATEGORIES
];
function isLibraryNote(entry) {
	return Boolean(entry.meta?.libraryKey);
}
function plainExcerpt(html, max = 220) {
	const text = html.replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">").replace(/\s+/g, " ").trim();
	if (text.length <= max) return text;
	return `${text.slice(0, max).replace(/\s+\S*$/, "").trim()}…`;
}
var NOTES_LIBRARY = [
	{
		key: "edu-kinks",
		title: "A map of kinks",
		category: "education",
		subcategory: "reference",
		sort: 10,
		body: doc$1(p$1("Kink is a family of tastes, not a ladder. Use this as a map: names, what they tend to feel like, and what you actually need to say out loud before you try them. Nothing here is permission to skip a negotiation, a safeword, or aftercare."), callout$1("If it involves breath, blood, fire, electricity, or leaving someone bound and alone, it is edge play. Study it. Do not improvise it drunk. Have a way out that does not depend on the person in the scene keeping their nerve."), h$1("Power and protocol"), ul$1("<strong>Dominance and submission.</strong> Authority given, not stolen. Negotiate what the Dominant decides, what stays with the submissive, and what is theatre versus standing rule.", "<strong>Service.</strong> Care, errands, ritual, body service. The kink is usefulness done well — and being seen doing it.", "<strong>Ownership and protocol.</strong> Titles, collars, rules, kneeling, speech restrictions. The charge is in the structure. Write the rules down. Review them when you are not high on a scene.", "<strong>Brat and tamer.</strong> Push and catch. The brat tests the frame; the tamer holds it without collapsing into real anger. See the how-to notes."), h$1("Body and sensation"), ul$1("<strong>Impact.</strong> Hand, paddle, flogger, cane, crop. Negotiate implements, targets (avoid kidneys, spine, joints, throat), warm-up, and how you will check in. Bruises are not proof of a good scene.", "<strong>Bondage.</strong> Cuffs, rope, tape, furniture, being held. Circulation, nerves, joints, and a cutting tool in reach. Never around the neck. Never leave a bound person.", "<strong>Sensation.</strong> Ice, wax, feathers, Wartenberg, vibration, teasing. Often a gentler door into intensity.", "<strong>Temperature and wax.</strong> Low-temp toy wax only. Test on yourself first. No wax on face, genitals, or broken skin unless you both know the risk.", "<strong>Electro.</strong> Only on toys made for bodies. Never across the chest. Never if there is a heart condition, implant, or pregnancy.", "<strong>Clamps and pressure.</strong> Time-box them. Blood returning hurts more than going on. That after-sting is part of the scene — warn them."), h$1("Mind and story"), ul$1("<strong>Praise and degradation.</strong> Opposite doors into the same room: being seen. Degradation that uses a real wound is not edgy, it is careless. Make a list of words that are in, words that are out, and words that are only in-scene.", "<strong>Exhibition and voyeur.</strong> Being watched, watching, or the idea of it. Public play must not involve non-consenting people. A window fantasy is not a street.", "<strong>Primal.</strong> Chase, wrestle, bite, growl. Agree on what “fight” means, where biting is allowed, and the word that turns the animal off.", "<strong>Pet play.</strong> Handler and pet, gear, speech limits, care. It is adult roleplay between adults.", "<strong>Medical / clinical.</strong> Exam, gloves, orders, clinical voice. Real medical acts (injections, cutting) are not costume. Leave them to people trained for them.", "<strong>Fear play and CNC.</strong> Consensual non-consent is a <em>scripted</em> loss of control, negotiated when everyone can still think. It needs a safeword that always works, a non-verbal signal, aftercare, and a sober yes. It is not a loophole."), h$1("Sex, control, and the rest"), ul$1("<strong>Orgasm control and chastity.</strong> Tease, deny, schedule, cage. Hydration, skin, and a release plan if swelling or panic shows up. A key the Dominant cannot lose.", "<strong>Anal and pegging.</strong> Relax, lube, go slower than pride wants. Nails short. Stop for sharp pain. Aftercare includes a bathroom plan without shame.", "<strong>Body worship.</strong> Boots, cock, cunt, chest, feet — attention as devotion.", "<strong>Gags and silence.</strong> A gagged person needs a non-verbal safeword (drop a bell, tap twice, hold an object and release it). Never gag someone with a blocked nose or who cannot breathe easily.", "<strong>Breath play.</strong> Choking and smothering can kill with no warning and no time to safeword. Many experienced people refuse it. If you still go near it, study from qualified educators, never compress the front of the neck as a casual move, and treat “just a little” as a lie you tell yourselves."), h$1("How to use the map"), ol$1("Each of you marks: a curious yes, a maybe later, a hard no. Do it separately. Compare.", "For every curious yes, write one sentence: what you hope it feels like, and one fear.", "Pick one item. Negotiate a small version. Run it. Debrief the next day, not only in the afterglow.", "Nothing moves from no to yes because a scene went well. Nos stay nos until the person who owns them reopens them."), p$1("Want the activity version? Use <em>Explore a kink together</em> under Activities."))
	},
	{
		key: "edu-toys",
		title: "Toys and how to use them",
		category: "education",
		subcategory: "reference",
		sort: 20,
		body: doc$1(p$1("A toy is a tool. The scene is still the two of you. Buy body-safe, learn the material, and introduce one new thing at a time so you can tell what actually worked."), h$1("Materials that belong in a body"), ul$1("<strong>Platinum silicone, borosilicate glass, stainless steel.</strong> Non-porous. Wash, boil if the maker says so, and they can last years.", "<strong>ABS plastic, some hard toys.</strong> Fine if they are actually body-safe and seamless.", "<strong>TPE, jelly, “mystery rubber”, unmarked cheap toys.</strong> Porous. They hold bacteria. Do not share. Consider a condom over them, or replace them.", "<strong>Leather and fabric.</strong> For outside the body. Condition leather. Do not use a porous flogger on broken skin and then on someone else."), h$1("Lube"), ul$1("<strong>Water-based.</strong> Works with almost everything, including silicone toys and latex. Reapply. It dries.", "<strong>Silicone-based.</strong> Long-lasting. Not on silicone toys — it can melt the surface. Good for water play.", "<strong>Oil-based.</strong> Ruins latex. Messy. Some people like it for hands and external massage only.", "If it stings and it is not meant to, stop. Flavoured and warming lubes can irritate."), h$1("By type"), h3("Vibrators"), p$1("Bullets for precise spots, wands for broad and overwhelming, air-pulse for external suction, rabbits for split attention. Start low. Hold still before you chase. A wand on the perineum, over pants, or on the glans can be a lot — ask, then watch their breathing, not only their mouth."), h3("Plugs and anal toys"), p$1("A flared base is not optional. Training plugs go up in size across weeks, not one evening. Put lube on the toy and the body. Aim toward the navel, not “up.” If they bear down gently it often enters easier than pushing. Prostate / p-spot toys have a curve for a reason — let them show you the angle. Time in should have a time out. Numbness or sharp pain means out."), h3("Dildos, straps, sleeves"), p$1("Harness fit matters more than length. Start smaller than ego. Double-ended needs communication about pace. Sleeves and extenders can rub — lube both sides. Pegging: the receiver sets depth until they ask for more."), h3("Rings and constriction"), p$1("Cock rings go on a semi, sit behind the testicles if that is the design, and come off if colour, cold, or numbness shows. Never sleep in a tight ring. Metal rings need a plan if the erection will not fade (cold, time, medical help — not shame)."), h3("Clamps"), p$1("Nipples, labia, skin. Adjustable is kinder than cheap spring clips. Seconds to a few minutes for new bodies. Take them off as part of the scene; the blood-return ache is intense. No clamps on the throat, nose, or genitals until you know that body."), h3("Impact toys"), p$1("Hand first, so you learn the body. Then paddle (thud), flogger (thud or sting by fall material), crop (sting, small target), cane (sting, skilled only). Wrap around a hip or thigh is how people get hurt. Land flat. Look at the skin between strikes. White that does not pink up, or pain that feels electric down a limb, is a stop."), h3("Gags, collars, bits"), p$1("Collars: not load-bearing. Do not yank a person by the neck. Gags: start with a bit they can spit out. Have a drop-signal. Drool is normal; mock it only if that is the negotiated flavour."), h3("Remote and app toys"), p$1("Agree the rooms they may be on in. Public play cannot involve unsuspecting people. Batteries die at the worst time — have a word that means “off, now.”"), h$1("Care and sharing"), ol$1("Wash before and after. Toy cleaner or mild soap and water. Silicone and steel can often boil. Follow the maker.", "Do not share porous toys. For non-porous, wash; a condom is extra insurance between partners or holes.", "Let them dry. Store clean, separate from keys and lint.", "Inspect for tears. A nicked silicone toy is a retirement."), h$1("How to bring a toy in"), ol$1("Show it out of scene. Let them hold it. Say what you want it to do.", "Agree where it may go, for how long, and the safeword.", "Use it for a short scene. Debrief: too much, not enough, never again, again please.", "Photograph it into the Catalogue if you want it in rotation — care notes, intensity, whose body it is for."))
	},
	{
		key: "edu-restraints",
		title: "Restraints and how to use them",
		category: "education",
		subcategory: "reference",
		sort: 30,
		body: doc$1(p$1("Restraint is not the knot. It is the decision to stay, and the other person’s job to make staying survivable. Bondage that looks pretty and wrecks a nerve is a failure."), callout$1("Never leave a bound person. Never restrain the neck. Keep EMT shears or a cutter in reach — not in another room. If they are gagged, they need a non-verbal safeword you will actually see."), h$1("What you are choosing between"), ul$1("<strong>Leather or vegan cuffs.</strong> Fast, kind on skin, buckle or clip. Two-finger space. Clip to a D-ring; do not trust fashion hardware.", "<strong>Metal cuffs.</strong> Heavy psychologically. Easy to over-tighten. Padded or not at all for long holds. Know where the key is. Have a spare.", "<strong>Velcro and beginner kits.</strong> Fine for under-the-bed and first nights. They give. That is a feature.", "<strong>Rope.</strong> Slow, intimate, versatile. Also where beginners hurt people. Learn a single-column tie from a reputable teacher before you load a joint. No rope on the neck. No suspension until you are actually trained — furniture height is not “almost suspension.”", "<strong>Tape, wrap, mummification.</strong> Heat, panic, and no circulation feedback. Keep sessions short. Scissors ready. Never cover the nose.", "<strong>Spreader bars, hogties, furniture.</strong> Change the leverage on shoulders and knees. Hogties compress the chest — watch breathing. Benches and St Andrew’s crosses need padding and a way down that is not “figure it out while crying.”", "<strong>Body holding.</strong> Pins, folds, sitting on thighs. Still bondage. Still needs a word. Joints still have angles they do not like."), h$1("The checks that are not optional"), ol$1("<strong>Colour and temperature.</strong> Hands and feet should not go white, blue, or ice-cold.", "<strong>Sensation.</strong> Can they wiggle fingers and toes? Any numbness, pins and needles, or electric zing — untie that limb now. Nerves do not always warn you twice.", "<strong>Capillary refill.</strong> Press a nail bed. Colour should return in a couple of seconds.", "<strong>Breathing and talk.</strong> If they cannot take a full breath, or their words go slurry, you are done with this position.", "<strong>Time.</strong> Even a “comfortable” tie has a clock. Check every few minutes until you know that body in that tie."), h$1("How to put someone in"), ol$1("Negotiate: wrists, ankles, arms, torso? Front or back? How long? What happens if they panic?", "Empty pockets. No jewellery that will bite. Hair out of clasps.", "Cuff loosely, then snug. You should fit two fingers. Clip, then check again because people pull.", "Stay where they can see or hear you. Narrate if they like that; be quiet if they like that. Do not disappear to “get a toy” without a check-in.", "Build the scene on top of the restraint. The first scene can just be: stay, breathe, be touched, be released.", "Take them out slower than you think. Blood returns. Shake-out, water, wrap."), h$1("Panic and drops"), p$1("Some people panic in restraint even when they asked for it. That is not brat. That is a nervous system. Get them out. Do not lecture. Warmth, water, a blanket, a simple true sentence: “You are out. I am here.” Talk later."), p$1("Positional asphyxia is real: face-down, chest compressed, drunk, or hogtied. If in doubt, sit them up. If they are not breathing normally, this is no longer a scene — it is first aid."), h$1("Rope, in brief"), ul$1("Learn single-column and a reliable cuff before anything decorative.", "Keep rope off the front of the neck, and off nerves at the wrist, inner elbow, armpit, and outer knee.", "Natural fibre (jute, hemp) bites and holds; synthetics can slip and melt. Pick one and learn it.", "Never hoist a person with a tie you cannot undo under stress.", "Take a class. Videos are not a spotter."))
	},
	{
		key: "edu-train-brat",
		title: "How to train a bratty submissive",
		category: "education",
		subcategory: "how-to",
		sort: 40,
		body: doc$1(p$1("A brat is not a submissive who has failed. A brat is a submissive whose play is the test: “Will you still hold me if I push?” Training a brat is teaching them that the frame is real, the fun is welcome, and cruelty without a scene is not the game."), h$1("First, name the game"), p$1("Sit out of dynamic and write three lists together:"), ul$1("<strong>In-bounds brat.</strong> Sass, loopholes, fake innocence, slow obedience, stealing the last word.", "<strong>Out of bounds.</strong> Real insults, hitting a hard limit, public humiliation you did not agree, ignoring a red, using the Dominant’s actual wounds as a toy.", "<strong>What “caught” looks like.</strong> A look, a countdown, a position, a punishment from the list, laughter and a kiss. If they do not know what winning-at-losing feels like, they will escalate until someone is actually hurt."), h$1("The frame"), ol$1("<strong>Rules in writing.</strong> Few, clear, enforceable. “Be respectful in front of other people” is a rule. “Never sass me” is a war with a brat.", "<strong>Consequences that match.</strong> Playful push, playful catch. Mean push, real stop. Do not punish with a hard limit. Do not invent a new humiliation in anger.", "<strong>Follow through.</strong> A brat who is never caught learns that the Dominant is theatre. A brat who is always crushed learns to go quiet, not to submit.", "<strong>Praise the landing.</strong> When they finally kneel, or say it straight, mark that louder than the chase. Brats often starve for the moment they can stop performing."), h$1("How to catch without becoming the villain"), ul$1("Keep your voice even. If you are actually angry, pause the dynamic. Anger is not a taming tool.", "Name the behaviour, not the person. “That rule still stands” lands. “You are impossible” becomes a wound.", "Offer the out you both agreed: position, count, written lines, a task, loss of a privilege you actually control.", "If they safeword, they have won at safety. Thank them. Never add a punishment for the word.", "Debrief bratting the way you debrief a scene. What was hot. What was too much. What to try next time."), h$1("Training over time"), p$1("Pick one protocol to install at a time — a title, a morning check-in, a kneeling greeting. Let them brat around it. Catch them. Repeat until the ritual is easy. Then add the next. A brat who is “trained” overnight has usually just gone numb."), p$1("Give them jobs that use the brat: loophole hunting in a contract draft, choosing the next game, writing a worse version of a rule so you can both laugh and then set the real one. Use the spark. Do not try to extinguish it and keep the person."), p$1("Read <em>How to become a good brat tamer</em> if you are the one holding the frame, and the bratting activities when you want to practise rather than read."))
	},
	{
		key: "edu-brat-tamer",
		title: "How to become a good brat tamer",
		category: "education",
		subcategory: "how-to",
		sort: 50,
		body: doc$1(p$1("Taming is not breaking. A good tamer is steady, amused, and impossible to top from a tantrum. You are the wall they get to throw themselves at because the wall does not crumble and does not hit back for real."), h$1("The job"), ul$1("Hold the agreed rules when it would be easier to laugh it off or explode.", "Keep the play in the playground. When it leaves the playground, you stop being a tamer and become a partner having a fight — which you should have as partners, not as roles.", "Give the brat a worthy opponent. Cleverness on their side deserves craft on yours, not volume.", "Let them feel caught, contained, and still wanted."), h$1("Skills to build"), ol$1("<strong>A still face.</strong> Practise not taking the bait for three breaths. Then answer.", "<strong>A small menu of catches.</strong> One look, one position, one punishment, one reward for coming back in. You should be able to run them when you are tired.", "<strong>Humour without contempt.</strong> You can find them ridiculous and delicious. You may not find them worthless.", "<strong>Repair.</strong> After a hard catch, you are the one who opens the door: water, a hand, “Come here.” If you only ever win, they will stop playing.", "<strong>Self-knowledge.</strong> If bratting hits your shame, your need to be obeyed at all times, or your temper, say so. Either renegotiate the kink or get support. Do not make them pay for your unexamined pride."), h$1("What good tamers do not do"), ul$1("Do not use real-life necessities as leverage (food, sleep, work, medication, the relationship itself).", "Do not stack punishments because you lost the beat.", "Do not mock a drop or a safeword.", "Do not train by isolation or silent treatment unless that was explicitly negotiated as play, with a time cap and a check-in.", "Do not compete with them for who can be crueller. You will win, and you will lose them."), h$1("A simple tamer’s loop"), p$1("See the push. Name it. Offer the known consequence. Follow through. Receive them when they yield. Praise the yield. Reset the warmth. If you skip the last two, you are just punishing."))
	},
	{
		key: "edu-good-dom",
		title: "How to be a good Dominant",
		category: "education",
		subcategory: "how-to",
		sort: 60,
		body: doc$1(p$1("Dominance is a service with a spine. You take responsibility for the frame, the scene, and the person who handed you power. The aesthetic is optional. The responsibility is not."), h$1("The work, not the costume"), ul$1("<strong>Listen harder than you speak.</strong> Their limits, drop patterns, and ordinary day are your actual brief.", "<strong>Decide, then check.</strong> A Dominant who never decides is a roommate in leather. A Dominant who never checks is a risk.", "<strong>Be consistent.</strong> Rules you forget are not rules. If you cannot enforce it this month, take it off the list.", "<strong>Stay sober enough to run the room.</strong> If you cannot drive, you cannot run edge play.", "<strong>Repair.</strong> You will get it wrong. A good Dominant notices, owns it without collapsing, and makes the next round safer. Ego is not a sacrament."), h$1("Before you take power"), ol$1("Know your own yes, no, and need. A Dominant with unsaid needs will take them out of the submissive’s hide.", "Negotiate when you are both clothed and fed. Write it. Dates, safewords, aftercare, who can pause the dynamic.", "Learn basic first aid for the play you actually do. Know when a mark is a bruise and when it is a problem.", "Have a life. A Dominant whose only self is the role will smother the person in it."), h$1("In scene"), ul$1("Start below the fantasy. Warm the body and the trust.", "Watch breath, skin, eyes, and the way they stop using words. Topspace is real; so is missing a safeword because you were performing.", "Give instructions one at a time unless they are trained for stacks.", "End on purpose. A scene that fizzles because you got tired is a drop waiting to happen. Close it: words, water, hands, what happens next."), h$1("Out of scene"), p$1("Be someone they can bring a boring problem to. Pay attention to sleep, food, and whether the dynamic is covering for a fight you will not have. Do not hide behind “because I said so” when the question is rent, family, or a limit."), p$1("Pride in the role looks like this: they are more themselves with you, not less. They take risks you have earned. They tell you the truth. If they only ever perform for you, you are being fed, not followed."))
	},
	{
		key: "edu-good-sub",
		title: "How to be a good submissive",
		category: "education",
		subcategory: "how-to",
		sort: 70,
		body: doc$1(p$1("Submission is not disappearance. It is a skilled choice: you offer power, you keep a spine, and you tell the truth soon enough that your Dominant can actually lead."), h$1("The craft"), ul$1("<strong>Know your limits before you are high on the scene.</strong> Hard nos, soft nos, curiosities. Update them. You are allowed to grow stricter.", "<strong>Safeword without a speech.</strong> The word is a tool, not a failure. Using it is obedience to the real rule.", "<strong>Receive.</strong> Let praise land. Let a hand land. You cannot be led if you are already three steps into what you think they wanted.", "<strong>Do the boring parts.</strong> Check-ins, hydration, stretching, writing the journal page. Fantasy sits on maintenance.", "<strong>Do not make them guess.</strong> “Green, I want more of that” is gold. Suffering in silence and exploding later is not devotion, it is a trap."), h$1("Service that actually serves"), p$1("Ask what would help this week — not what looks like service in a story. Sometimes it is kneeling. Sometimes it is doing the thing they hate doing. Match the gift to the person, not to your favourite ritual."), h$1("Subspace, drop, and pride"), p$1("Subspace can make you agree to things you would not agree to in daylight. Negotiate before. Confirm after. If you drop — shame, ache, insomnia, a sudden no — say so. Drop is chemistry and meaning, not evidence you are bad at this."), p$1("Pride in the role looks like this: you can kneel without hating yourself, and stand without the dynamic collapsing. You can brat or serve according to the agreed game. You can say “that hurt wrong” and still be theirs."), h$1("What is not required"), ul$1("Pain you did not consent to.", "A personality wipe.", "Always being ready.", "Protecting their ego from your limits.", "Taking care of their aftercare instead of your own — unless that is the negotiated service, and you still get yours."))
	},
	{
		key: "edu-aftercare",
		title: "Aftercare",
		category: "education",
		subcategory: "how-to",
		sort: 75,
		body: doc$1(p$1("Aftercare is what you do on purpose once the scene, the ritual, or the high is over. It is how you land a nervous system you took up into the air. It is not a cute extra. It is part of the scene, and it starts when you close the play — not when you feel like being nice again."), callout$1("If you can run the intensity, you can run the landing. A Dominant who disappears into a shower, a phone, or sleep while they are still shaking is not “done.” They are unfinished."), h$1("What it is"), p$1("During play, bodies dump adrenaline, endorphins, oxytocin, sometimes tears, sometimes nothing obvious. Aftercare is the sequence that tells their body: you are here, you are safe, the story is over, I am still with you. It can be quiet. It can be filthy and then gentle. It can be five minutes of water and a blanket. It is whatever you both named as the way back."), ul$1("<strong>Physical.</strong> Water, sugar, a wee, warmth, a wash, arnica, clothes, food they can actually eat.", "<strong>Emotional.</strong> A voice. Praise that is specific. Permission to cry, to joke, to say nothing. Being held or being given space — they are not the same person every night.", "<strong>Practical.</strong> Toys out, ropes off, marks checked, a towel, who sleeps where, a plan for work in the morning.", "<strong>The next day.</strong> A message, a meal, a boring check-in. Drop often arrives late. Aftercare is not only the sofa."), h$1("Why it matters"), ul$1("Play without a landing teaches their body that intensity is abandonment. They will either stop going deep, or they will go deep and crash when you are not looking.", "Aftercare is how you prove the power was given, not taken. It is the receipt.", "You will miss a cue someday. Aftercare is the net under that miss.", "Shame, marks, a word that landed too well, an orgasm they did not expect — all of it needs a place to go that is not a 3am spiral.", "Your own drop is real too. Landing them does not replace landing yourself. Do both. See <em>Domspace</em>."), h$1("What it is not"), ul$1("A reward they can lose for bratting. Aftercare is not a treat. It is first aid for a state you helped create.", "An interrogation. Debrief when they can think. Not while they are still in subspace.", "Sex they did not ask for, piled on because you are still hard. Ask. “Do you want more, or do you want still?”", "A script you copy from the internet if it does not fit this person. Some people need quiet. Some need a running commentary. Some need to be left in the room with the door open and a glass of water."), h$1("How to give it"), ol$1("<strong>Close the scene out loud.</strong> A sentence they know: “Scene over. You did well. I have you.” Unbind. Ungag. Colours still work.", "<strong>Look at the body.</strong> Circulation, cuts, nausea, cold, whether they can stand. Treat what you see before you chase a mood.", "<strong>Offer, do not pile on.</strong> Water. A blanket. Your chest or a bit of space. One thing at a time. Watch which one they take.", "<strong>Keep talking if they need a voice.</strong> Simple, specific: what you liked, that they are safe, what happens next (shower, bed, food). Do not make them perform gratitude.", "<strong>Keep quiet if they need quiet.</strong> A hand on a nape can be the whole paragraph.", "<strong>Get sugar and salt in.</strong> Juice, chocolate, toast, an electrolyte. Intensity burns through people who “are not hungry.”", "<strong>Wash and mark-check together if that is your way.</strong> A shower can be aftercare. It can also be too much sensation. Ask.", "<strong>Stay reachable.</strong> If you must leave the room, say when you will be back, and be back. A brat who jokes “go on then” may still panic if you vanish.", "<strong>Write the next-day check-in before you sleep.</strong> A time, a medium, a question: “How is your head? Any marks that worry you? Anything you want off the table next time?”"), h$1("Matching the person, not the fantasy"), ul$1("<strong>The floaty one.</strong> Slow voice, warmth, do not quiz them. They may agree to anything. Do not add new play.", "<strong>The shaky one.</strong> Ground: name, date, room, water, feet on the floor.", "<strong>The one who goes sharp or mean.</strong> That can be drop wearing armour. Do not punish the landing. Offer food and a later talk.", "<strong>The brat.</strong> They may sass instead of asking to be held. Catch the sass lightly if that is your game, then give the care anyway. Do not make them earn the blanket.", "<strong>The one who wants space.</strong> Space with a tether: “I will be in the kitchen. Text if you want me.” Check at the time you said.", "<strong>Heavy pain, humiliation, or CNC.</strong> Plan aftercare before the scene. Include a re-entry sentence that takes the fiction off: who you both are, that the words were play, that they are wanted."), h$1("A small kit"), p$1("Water, a snack they actually like, a towel, a soft layer, their favourite blanket, pain relief you have already agreed is allowed, a charger, tissues, a spare pair of underwear, the aftercare note you wrote on a non-horny day. Keep it where you play. Future-you is worse at shopping."), p$1("Read <em>Subspace</em> and <em>Domspace</em> with this. Aftercare is how both of those states come home."))
	},
	{
		key: "edu-subspace",
		title: "Subspace",
		category: "education",
		subcategory: "how-to",
		sort: 76,
		body: doc$1(p$1("Subspace is a shift in their nervous system during or after play: the world narrows, words get expensive, time smears, and the Dominant's voice can feel like the only solid thing in the room. It is not a trophy. It is a state. Some nights they go there in ten minutes. Some nights they never leave the shoreline, and that is still a good scene."), callout$1("A person in subspace can look like they are saying yes to everything. Treat that as a yellow you have not heard yet. Do not add new acts, new degradation, or extra time because they went quiet and pretty."), h$1("What it is"), p$1("Bodies under intense sensation, focus, trust, or ritual dump chemicals that change pain, fear, and self-talk. For some people that feels like floating. For others it is heavy, small, animal, tearful, or blank. Service, impact, bondage, voice, orgasm control, even a long kneel can open the door. It is not always sexual. It is not always bliss. It is a trance you are responsible for because you helped build it."), h$1("How it can feel — to them"), ul$1("Warm, floaty, far away, as if the room is underwater.", "Very small, very good, very simple. Decisions feel impossible and that is the point.", "Wordless. They know they should speak and the sentence will not form.", "High pain tolerance that is a trick, not a superpower. They can be injured without the usual alarm.", "Time gone. A twenty-minute scene felt like two, or two hours felt like a breath.", "Tears without a sad story. Laughter that is not a joke. Shaking that is not cold.", "A fierce need to please, or a fierce need to be still and used, or both.", "Nothing cinematic at all — just quiet, heavy limbs, and a brain that has stepped aside. Believe them if they say they were “in it” without the porn face."), h$1("Signs to look for"), ul$1("<strong>Eyes.</strong> Soft, slow to track, glassy, or locked on you and not much else.", "<strong>Voice.</strong> Smaller, later, slurred, one-word answers, or gone. A brat's smirk going still is a sign, not a win you stack more sass on.", "<strong>Breath.</strong> Deep and even, or high and forgotten. Remind them to breathe.", "<strong>Body.</strong> Heavy, pliant, delayed flinch, less bracing than they showed in warm-up.", "<strong>Colours.</strong> They stop offering green on their own. You have to ask. If they cannot answer, you ease off or stop.", "<strong>The tell they named.</strong> A hand going slack, a particular sound, a stare. Write it in Notes. Do not guess every time.", "<strong>What is not a sign.</strong> Endurance. Faking. Freeze from fear. If the eyes go flat, the jaw locks, or they look like they are waiting for it to be over, that is not subspace. That is a stop."), h$1("How to take them there"), p$1("You cannot force subspace. You can make the conditions honest enough that their body will consider it."), ol$1("Negotiate first, while they can still think. Subspace is a terrible time to invent the scene.", "Start below the fantasy. Warm skin, warm trust, a rhythm they can predict. Surprise is for later, if they asked for it.", "Pick one door: impact with a build, bondage and stillness, service and repetition, voice and praise, a long hold. Mixing five kinks is noise.", "Be consistent. Same cue, same cadence, same hand. The nervous system drops when it knows who is driving.", "Watch more than you perform. If you are chasing a look for your own pride, you will miss the yellow.", "Use the voice they trained to. Quiet and sure lands more people than a speech.", "Give them something to do with the mind: count, hold a position, repeat a phrase, breathe on your count. Busy brains do not drop. Occupied ones sometimes do.", "Do not clock it. Asking “are you in subspace yet?” yanks them out. Ask colours. Ask breath. Ask one yes/no.", "For a brat: catch them, then settle. A brat who is still hunting cannot drop. End the game on purpose, then give the rhythm."), h$1("While they are in it"), ul$1("Stay. A body in subspace left alone can drop into panic.", "Keep stimulation inside what you already agreed. Depth is not permission.", "Check in in a way they can answer: squeeze, tap, “colour.” If you get nothing useful, you come down.", "Track time, temperature, circulation, and whether they have gone too still.", "End on purpose before they crash. Bring them back with your voice, their name, water, sitting up slowly."), h$1("Subdrop"), p$1("Subdrop is the come-down: hours or a day or three later, the chemicals leave and meaning rushes in. It can look like sadness with no story, shame, clinginess, numbness, a sudden “I am bad at this,” insomnia, a short temper, or a brat who is only actually scared. It is not proof the scene was wrong. It is proof a body did something large."), ul$1("<strong>When.</strong> Same night, next morning, or a delayed Tuesday. Heavy scenes and new intensity drop harder. So do scenes that ended without a close.", "<strong>What helps.</strong> The aftercare you already planned, food, sleep, daylight, a boring check-in, less protocol for a day if they need to be a person, more protocol if they need the frame. Ask which. Do not guess from your own drop.", "<strong>What does not help.</strong> “Cheer up.” A surprise scene to “fix” them. Silence because you feel awkward. Making them explain the chemistry as a moral essay.", "<strong>When it is more than drop.</strong> If they cannot eat, cannot work, cannot be touched, or the shame is about a real wound you used, you stop play and deal with the person. Drop is not a licence to wait it out if they are in trouble."), h$1("Aftercare this state requires"), ol$1("A spoken close. Name, time, “the scene is over.”", "Warmth, water, sugar, a slow sit-up. They may be cold and not know it.", "Do not leave them in bondage or a corner to “soak.” Soaking is a negotiated beat with you in the room.", "Re-enter who they are: partner, name, what is true outside the fiction.", "A next-day message even if they said they were fine on the sofa. Especially then.", "If drop shows: more of the same, not a new intensity. Offer a walk, a meal, a quiet evening. Keep colours available."), p$1("Read <em>Aftercare</em> for the practical kit, and <em>Domspace</em> so you do not miss your own landing while you are watching theirs."))
	},
	{
		key: "edu-domspace",
		title: "Domspace",
		category: "education",
		subcategory: "how-to",
		sort: 77,
		body: doc$1(p$1("Domspace — also called topspace — is the shift on your side of the rope. The room gets simple. Time stretches. Their breath, their skin, the next decision: that is the whole job. It can feel like a clean hunt, like tender authority, like a quiet that is louder than the impact. It is not an excuse. It is a state you have to come back from on purpose."), callout$1("If subspace makes them agree too easily, domspace can make you miss a yellow. Build checks into the scene that do not depend on you feeling like a god."), h$1("What it is"), p$1("You are running attention, risk, and another person's nervous system. When that focus locks, your own chemistry moves: adrenaline, focus, sometimes a high that is sexual, sometimes one that is not. The ego wants to call it power. The work is still care. Domspace is the flow state of doing that work well — and the tunnel vision of doing it too hard."), h$1("How it can feel"), ul$1("Sharp and quiet. Fewer thoughts. The next stroke, the next sentence, the next pause.", "Larger than your day-self. Voice drops. Hands know. The performance falls off and something plainer takes over.", "Protective and predatory in the same breath, if that is your flavour. Wanting to ruin them and wrap them.", "Time gone. You meant twenty minutes and the clock says an hour.", "A hum in the chest, a stillness in the jaw, heat, an erection that is not the point, or no sexual charge at all — only the work.", "Irritation at interruption: a phone, a giggle, a brat loop. That irritation is data. It can mean “hold the frame.” It can mean “you are getting too high to be kind.” Know which.", "After, either a clean tiredness or a crash: emptiness, guilt, restlessness, a need to be alone, a need to be held. That is drop, not proof you are a monster or a fraud."), h$1("Signs you are in it"), ul$1("You are watching them more than you are watching yourself in the fantasy.", "Instructions come out shorter. You are not narrating a novel.", "You can feel the next beat before you decide it.", "Peripheral noise falls away. This is useful until you stop hearing the kettle, the colour, or the clock.", "You do not want to stop. That is the dangerous one. Wanting to continue is not the same as it being wise.", "A brat can pull you out or push you deeper. If their sass makes you actually angry, you are leaving domspace and entering a fight. Pause."), h$1("How to get there"), ol$1("Do the unsexy work first. Negotiation, water, toys laid out, a clock you can see, aftercare kit in reach. A brain that is scrambling for lube does not drop into authority. It fusses.", "A threshold ritual: a collar, a sentence, a kneel, you washing your hands. Same door each time so your body knows the room has changed.", "Start below the peak. Warm them, and warm your own attention. Domspace arrives through doing the job, not through putting on a voice in the bathroom mirror.", "Reduce inputs. Phone out. One scene, one flavour. You cannot get into the quiet if you are also performing for an imaginary audience.", "Breathe on a count. Plant your feet. Feel your hands. Dominance is a body, not a TED talk.", "Let yourself care. Cold for show is a costume. Many people drop into domspace when they stop trying to look Dominant and start tracking the person in front of them.", "If you are tired, hungry, furious, or drunk, you will not find the good version. You will find sloppy power. Reschedule."), h$1("Signs to watch — in you, and in them"), ul$1("<strong>Green-enough.</strong> They are with you, colours work, breath is usable.", "<strong>Too far in you.</strong> You skip a colour check because you “can tell.” You add one more cane strike because the rhythm is pretty. You hate the idea of stopping. Ease off or call the close.", "<strong>Too far in them.</strong> See <em>Subspace</em>. Your job in domspace is to notice theirs.", "<strong>The miss.</strong> You feel nothing, or you feel only panic. Not every scene will give you the high. Do not punish them for a night your chemistry stayed home. Run a smaller scene well."), h$1("Coming down — Dom drop"), p$1("When the focus breaks, some Dominants feel hollow, ashamed of what they enjoyed, buzzing and unable to sleep, or suddenly small. You may want to flee the person you were just inside a scene with. That is chemistry plus meaning. It is common. It is your job to plan for it so they do not experience your drop as rejection."), ul$1("<strong>What it can look like.</strong> Guilt (“I hurt them”), numbness, a crash after the erection goes, irritability, needing silence, needing praise you feel you cannot ask for, a day of “I am not cut out for this.”", "<strong>What they may see.</strong> You going quiet, going practical, going to your phone, going sharp. Name it if you can: “I am dropping. I am here. I need a minute, then I will take care of you.”"), h$1("Aftercare when you leave domspace"), ol$1("<strong>Close them first if they still need you.</strong> Water, unbind, the spoken end, a blanket. Your drop does not get to skip their landing. If you cannot do both, say so and do the physical safety, then sit.", "<strong>Then land yourself.</strong> Water, food, a shower, clothes, the room put back. A walk. Sleep. You are an animal too.", "<strong>Ask for what you need without making them parent you mid-drop.</strong> If you need to be held, say “hold me.” If you need ten minutes alone, give them a time and a way to reach you, and do not make them guess whether they failed.", "<strong>A sentence that puts the power down.</strong> Out of role, you are partners. They should not have to keep submitting to keep you stable.", "<strong>Debrief later.</strong> What you enjoyed, what you almost missed, whether you got too high. The next day is kinder than the afterglow.", "<strong>If they offer aftercare to you.</strong> That can be service, and it can be beautiful. It is not their job to absorb your shame. Do not unload “I am a bad person” onto the body you just beat. Get a friend, a journal, or a professional for that.", "<strong>The next-day check is for both of you.</strong> “How is your head?” includes yours. If you went dark, say so before they invent a story that they were too much."), h$1("What you still owe"), p$1("Domspace is not a possession that removes the safeword. It is not a reason to skip aftercare, to stack pain, or to treat a brat's landing as a nuisance. The high is a tool. The person is the point. If the state makes you crueler than the scene you negotiated, you come down. Pride is being able to stop."), p$1("Keep <em>Aftercare</em> and <em>Subspace</em> next to this. You are landing two nervous systems. Start with theirs, then do not forget yours."))
	},
	{
		key: "edu-difficult-talk",
		title: "Open communication for difficult topics",
		category: "education",
		subcategory: "how-to",
		sort: 80,
		body: doc$1(p$1("The hard talks are the ones that keep the rest of this from turning into theatre. Sex, jealousy, a limit that moved, a scene that went wrong, money, health, “I do not want this flavour any more.” You will have them, or you will have a blow-up wearing a collar."), h$1("Set the room"), ul$1("Not in scene. Not in the last five minutes before sleep, unless someone is unsafe.", "Phones down. Sit at the same height. Water on the table.", "Time-box it (thirty to forty minutes) with permission to pause and return tomorrow. An endless talk is another way to flee.", "If you use honorifics, decide whether this talk is in-dynamic or out. Most difficult topics need out."), h$1("A script that does not start a war"), ol$1("<strong>Ask for the talk.</strong> “I need twenty minutes on something tender. Tonight or tomorrow?” Surprise ambush makes people stupid.", "<strong>One topic.</strong> Not a year of evidence. You can stack later if the first one goes well.", "<strong>Speak in first person and present tense.</strong> “I dropped after Thursday and I have been scared to kneel” is usable. “You always” is a summons to court.", "<strong>Say the need under the complaint.</strong> “I need a slower warm-up” is a request. “You do not care” is a verdict.", "<strong>The other person reflects.</strong> “What I heard is… Did I get it?” Until they have it, do not argue.", "<strong>Make one small agreement.</strong> A change you can see in seven days. Write it in Notes if it is a rule.", "<strong>Close.</strong> A hand, a sentence of appreciation for the honesty, and a real aftercare plan if the topic was a scene."), h$1("Topics that deserve this treatment"), ul$1("A limit that got brushed.", "A punishment that felt like contempt.", "Wanting more, or less, power exchange in ordinary life.", "Jealousy, other partners, time.", "Health, pain, medication, mental health weeks.", "The dynamic covering for a fight about chores, money, or respect.", "I think I am a switch. I think I am not a brat. I think I want a collar. I think I want it off."), h$1("When it is going badly"), p$1("If voices rise, call a pause. Twenty minutes apart, then back, or tomorrow. If you are using the other person’s wounds as ammunition, you are done for the day. If someone is scared, stop the topic and get to safety — physical or emotional. Repair is a different conversation from decision-making."), p$1("Use the Talk page for lighter daily questions. Use this note when the thing in your chest has a name and a cost."))
	},
	{
		key: "edu-instructions",
		title: "How to give better instructions",
		category: "education",
		subcategory: "how-to",
		sort: 90,
		body: doc$1(p$1("Bad instructions create brats by accident, drops by confusion, and Dominant frustration that looks like the submissive’s fault. A good instruction is a kindness: it can be obeyed."), h$1("The shape of an instruction that works"), ol$1("<strong>One action.</strong> “Kneel here, hands on thighs, eyes down.” Not five rituals in one breath unless they are trained for that stack.", "<strong>A place and a posture.</strong> Vague “behave” cannot be completed. Concrete “wait in present until I touch your shoulder” can.", "<strong>A finish line.</strong> Time, a count, a word you will say, or “until I release you.” Open-ended orders need extra trust and extra check-ins.", "<strong>The why, when it helps.</strong> “I want your head quieter” teaches. “Because I said so” is for when the why is already known.", "<strong>How they tell you it is done, or too much.</strong> “Say ‘set’ when you are there.” “Safeword if the knee goes.”"), h$1("Tone"), p$1("Match the scene. Protocol can be spare. Care can be warm. Degradation is a negotiated flavour, not the default setting for every order. If you only ever snap, they will not be able to hear you when you need to be gentle, and the other way around."), h$1("When they get it wrong"), ul$1("First assume the instruction was muddy, not that they are defiant.", "Repeat once, shorter. Show if you can.", "If it is brat, catch the brat — do not rewrite the order into a riddle.", "If it is capacity (pain, freeze, drop), stop stacking. Get them stable. Teach later."), h$1("Written tasks"), p$1("Same rules. Title. What good looks like. When it is due. What happens if it is done, and if it is not — if you use stakes, they belong in the task, not in a surprise. Put photos or a catalogue item on it if the body needs a picture."), p$1("Practise with the exercise <em>Instruction practice</em>. Ten minutes will show you every leak in how you speak."))
	},
	{
		key: "edu-negotiate-scene",
		title: "How to negotiate a scene",
		category: "education",
		subcategory: "how-to",
		sort: 100,
		body: doc$1(p$1("A scene is a short story you both agree to enter. Negotiation is how you keep it a story instead of an accident. Do it before anyone is naked and buzzing, and again if the plan changes."), h$1("The skeleton"), ol$1("<strong>Who is running it.</strong> Who can call yellow and red. If you switch mid-scene, say how.", "<strong>The want.</strong> Each person, one or two sentences. “I want to feel taken in hand and a bit overwhelmed, then held.”", "<strong>The flavour.</strong> Praise, degradation, protocol, primal, service, quiet, filthy talk — pick the lane.", "<strong>The acts.</strong> What may happen to which body parts, with which toys. What is off the table tonight even if it is usually on.", "<strong>Intensity and duration.</strong> A number you both understand, and a clock. You can end early. You should not run long because nobody wanted to be the one to stop.", "<strong>Safewords.</strong> Traffic lights work: green / yellow / red. Plus a non-verbal if anyone might be gagged or beyond words. What you will do on yellow (ease off, check) and on red (stop, release, aftercare).", "<strong>Aftercare.</strong> Water, food, quiet, talk, space, who sleeps where, a check-in the next day. Write it if you forget when you are floaty.", "<strong>Risks.</strong> Marks that must not show, work in the morning, medication, a sore knee, a bad week. The truth belongs here."), h$1("Traffic lights, in practice"), ul$1("<strong>Green.</strong> More of this is welcome, or stay.", "<strong>Yellow.</strong> Too much, or wrong flavour, or I need a second. Do not punish a yellow.", "<strong>Red.</strong> Scene over. Unbind. The person who called it does not owe a performance of being fine."), h$1("A small scene is still a scene"), p$1("Ten minutes of kneeling and a wand is worth this skeleton in miniature. You are teaching your future selves how to go bigger without getting lost."), p$1("After: debrief when you have eaten. What worked, what to keep, what never again, what to try next time. Put keepers in Notes or the Journal. If something went wrong, treat it as data, not as a verdict on the relationship."))
	},
	{
		key: "edu-roleplay",
		title: "How to write and run a roleplay",
		category: "education",
		subcategory: "how-to",
		sort: 110,
		body: doc$1(p$1("Roleplay is a costume for a feeling. Inspector and subject, handler and pet, stranger in a hotel, captain and crew — the plot is there to give your nervous systems a script. Keep the script light enough to hold, and the safewords real."), h$1("Build the fiction"), ol$1("<strong>The feeling, not the novel.</strong> “I want to be inspected and a little embarrassed” is a brief. A twelve-page backstory is homework nobody asked for.", "<strong>Names and address.</strong> What you call each other in the fiction. What is forbidden.", "<strong>The setting in one line.</strong> A doorway, a chair, a hotel lamp. You do not need a set. You need a threshold: a sentence that starts the play and a sentence that ends it.", "<strong>Who knows what.</strong> Are you strangers in the fiction? Is one of you in on a secret? CNC-flavoured roleplay needs extra care — the fiction of no consent is never actual no consent.", "<strong>Props from the Catalogue.</strong> One or two. A collar, a clipboard, a toy. Too many props become a fumble.", "<strong>The beat sheet.</strong> Arrival. Tension. Peak. Landing. Aftercare out of character."), h$1("Running it"), ul$1("Start with the threshold line, not with a joke about feeling silly. You can laugh after.", "If someone corpses (breaks into giggles), you can either fold it in or pause, breathe, restart from the last beat.", "Stay inside the negotiated acts. A role is not a blank cheque to try a new kink “in character.”", "End with the closing line, then a clear “scene over” so the fiction does not leak into a fight about dishes."), h$1("When roleplay hurts wrong"), p$1("If the character uses a real slur you did not agree, or a real memory, call yellow or red. Out of character, name it. Either rewrite the role or retire it. A good partner would rather lose a scene than win a wound."), p$1("There is an activity under Activities — <em>Create a roleplay</em> — that walks you through a one-page script you can keep in the Roleplay page."))
	},
	{
		key: "ex-confidence",
		title: "Confidence in your role",
		category: "exercises",
		subcategory: "self",
		sort: 10,
		body: doc$1(p$1("Time: 20 minutes, alone. Then 10 minutes with your partner if you want. You are training the feeling of occupying the role without performing a cartoon of it."), h$1("Alone"), ol$1("Stand or sit how you sit when you are actually in the role — not the Pinterest version. Notice jaw, shoulders, breath, where your eyes go.", "Say, out loud, one sentence that is true in the role. Dominant example: “I can take this slowly and still be in charge.” Submissive example: “I can kneel and still have a no.” Brat example: “I can push and still come back.”", "Write five lines: what you fear you look like in the role, and five: what you actually offer. Compare. Keep one sentence from the second list in your phone for a week.", "Do one tiny in-role act today with no audience: a posture, a journal line, laying out a toy, sending a single clear instruction or a single honest check-in."), h$1("Optional, together"), p$1("Each of you reads one fear and one offer. The other person answers only: “I believe this part.” No fixing. Stop there."), h$1("Debrief"), p$1("What felt like costume? What felt like you? Put one keeper in the Journal."))
	},
	{
		key: "ex-improve-self",
		title: "A week of becoming sharper",
		category: "exercises",
		subcategory: "self",
		sort: 20,
		body: doc$1(p$1("Time: 10 minutes a day for seven days. Pick a role you actually live, not a fantasy week you will abandon on Tuesday."), h$1("Choose one track"), ul$1("<strong>Body.</strong> Sleep, water, a stretch before play, no scene on a night you skipped food.", "<strong>Attention.</strong> One undistracted check-in a day. Phone down.", "<strong>Craft.</strong> Read one Education note, or practise one instruction, or one piece of service, slowly.", "<strong>Nerve.</strong> One true sentence a day you have been decorating instead of saying."), h$1("Each day"), ol$1("Do the small thing.", "Write one line: what you did, and how your body felt after.", "Do not add a second track until the week is done."), h$1("Day seven"), p$1("Read the seven lines to your partner, or only to yourself. Keep one habit. Drop the martyrdom. If you missed days, that is data about load, not proof you are undominant or unsubmissive."))
	},
	{
		key: "ex-know-partner",
		title: "Learn your partner",
		category: "exercises",
		subcategory: "partner",
		sort: 30,
		body: doc$1(p$1("Time: 40 minutes. You are not fixing them. You are collecting a better brief."), h$1("Setup"), p$1("Sit facing. One speaks, one writes. Then swap. No advice until both have spoken."), h$1("Ask these, slowly"), ol$1("When do you feel most taken care of by me, in or out of dynamic?", "When do you feel most missed by me?", "What does a good order (or a good offer of service) sound like in your body?", "What should I never use against you, even in play?", "How do you want me to bring you back from brat, subspace, or topspace?", "What is a small thing I could do this week that would feel like I studied you?"), h$1("Then"), p$1("Each of you picks one thing to do in the next seven days. Put it in Tasks or Habits if it should repeat. Do not pick five. Competence beats a manifesto."))
	},
	{
		key: "ex-dynamic",
		title: "Strengthen the dynamic",
		category: "exercises",
		subcategory: "dynamic",
		sort: 40,
		body: doc$1(p$1("Time: 45 minutes. Out of scene. This is a maintenance bay, not a trial."), h$1("Part one — inventory (15 min)"), p$1("Separately, write:"), ul$1("What in the dynamic is giving us life right now.", "What has gone theatrical or stale.", "What we are using the dynamic to avoid (chores, sex, a fight, loneliness).", "One ritual worth keeping. One rule worth retiring. One we might add."), h$1("Part two — compare (20 min)"), p$1("Read them aloud. No defence for the first pass. Circle overlaps. Those are your real dynamic. The rest is optional costume."), h$1("Part three — one change (10 min)"), p$1("Agree a single change for the next two weeks. Examples: a morning honorific, a Sunday negotiation, a week off punishments, a weekly scene night, a no-phone kneel. Put it in Notes under Rules or Agreements. Diary a date to review."), h$1("Close"), p$1("A small in-dynamic beat you both like — a kiss, a kneel, a hand in the hair — then ordinary evening. The point is that the frame can bend without breaking."))
	},
	{
		key: "ex-explore-kink",
		title: "Explore a kink together",
		category: "exercises",
		subcategory: "kinks",
		sort: 50,
		body: doc$1(p$1("Time: 60–90 minutes including aftercare. Pick one item from <em>A map of kinks</em> that is a curious yes for both of you. If it is a yes for only one, stop — this exercise is for shared curiosity, not persuasion."), h$1("Before"), ol$1("Each write: the fantasy in three sentences, the fear in one, the hard nos for tonight.", "Build a tiny version. Impact becomes ten warm hand spanks. Bondage becomes cuffs for five minutes. Degradation becomes one agreed phrase. CNC is not a “tiny version” for a first try — pick another door.", "Set safewords. Set aftercare. Set a clock."), h$1("During"), p$1("Run only the tiny version. The Dominant (or the person driving) checks yellow/green once at the midpoint. Nobody “just adds” a toy."), h$1("After, the same evening"), p$1("Water. The aftercare you booked. Then three words each: keep / tweak / never."), h$1("The next day"), p$1("A message or a sit-down: still yes, still no, want a slightly larger version, or file it. Put the keeper in Scenes or Notes so you do not rely on afterglow memory."))
	},
	{
		key: "ex-communication",
		title: "Communication skills lab",
		category: "exercises",
		subcategory: "communication",
		sort: 60,
		body: doc$1(p$1("Time: 25 minutes. You are drilling the muscles from <em>Open communication for difficult topics</em> on a low-stakes subject first."), h$1("Round one — reflect (8 min)"), p$1("Person A talks for two minutes about something mild (a scene they liked, a brat moment, a want). Person B may only reflect: “What I heard… What I think you need…” A corrects until it is right. Swap."), h$1("Round two — request (8 min)"), p$1("Each makes one request in the form: <em>When X, I feel Y, I need Z (a specific behaviour).</em> The other person can say yes, no, or a counter-offer. No explaining the no until the requester says they can hear it."), h$1("Round three — repair (5 min)"), p$1("Each names one moment in the last month they wish they had handled better. One sentence of ownership. One sentence of what they will try next time. No cross-examination."), h$1("Close"), p$1("Something easy and kind. If this lab surfaces a real fight, book the difficult-topics structure for another hour. Do not finish a war inside a drill."))
	},
	{
		key: "ex-instructions",
		title: "Instruction practice",
		category: "exercises",
		subcategory: "communication",
		sort: 70,
		body: doc$1(p$1("Time: 15 minutes. Dominant (or the person giving) speaks. Submissive (or the person receiving) obeys only what was actually said — no mind-reading, no helpful extras. Then swap if you switch."), h$1("The giver"), ol$1("Give three instructions, one at a time: a posture, a simple fetch or placement, a timed hold (use the Games timer if you want).", "After each, ask: “What did you hear?” If it does not match, that is your sentence, not their defiance.", "Rewrite shorter. Try again."), h$1("The receiver"), ol$1("Do exactly the instruction. If it is incomplete, you may ask one clarifying question. You may not improve it.", "If you want to brat, save it for a named brat round at the end — otherwise you will not learn the difference between a muddy order and a game."), h$1("Debrief"), p$1("Which instruction was easy to inhabit? Which one needed a picture, a demonstration, or a finish line? Steal that pattern for Tasks and Training."))
	},
	{
		key: "ex-create-scene",
		title: "Create a scene",
		category: "exercises",
		subcategory: "play",
		sort: 80,
		body: doc$1(p$1("Time: 35 minutes to design, another evening to run it. You will leave with a one-page scene you can paste into the Scenes page."), h$1("Fill this in together"), ol$1("<strong>Title.</strong>", "<strong>Feeling we want.</strong> Two words each.", "<strong>Who leads.</strong>", "<strong>Opening image.</strong> One sentence (a doorway, a command, a piece of clothing).", "<strong>Allowed acts.</strong> A short list. Be vulgar if that is accurate. Be specific about body parts and toys.", "<strong>Forbidden tonight.</strong>", "<strong>Intensity.</strong> 1–5 and what that means for you.", "<strong>Duration.</strong>", "<strong>Safewords and non-verbal.</strong>", "<strong>Aftercare.</strong> Who does what.", "<strong>Marks / work / sleep constraints.</strong>", "<strong>Closing image.</strong> How we will know it is over."), h$1("Then"), p$1("Do not run it the same hour you design it unless it is very small. Let it sit. If either of you wants a change, the change happens before anyone is in subspace."), p$1("After you run it, add a debrief line to the scene note: keep / tweak / never. Completing it in Scenes is optional; the learning is not."))
	},
	{
		key: "ex-create-roleplay",
		title: "Create a roleplay",
		category: "exercises",
		subcategory: "play",
		sort: 90,
		body: doc$1(p$1("Time: 30 minutes to write, later to play. Keep it to one page. If it needs a novel, it is not ready to be inhabited."), h$1("The page"), ol$1("<strong>Working title.</strong>", "<strong>The feeling.</strong> (Inspected, hunted, useful, adored, ruined — pick one primary.)", "<strong>Roles and names.</strong>", "<strong>Threshold line</strong> that starts the fiction.", "<strong>Setting in one line.</strong>", "<strong>Three beats.</strong> Arrival, peak, landing.", "<strong>Props.</strong> One or two from the Catalogue, or none.", "<strong>Lines that are in.</strong> A few phrases you want said.", "<strong>Lines that are out.</strong>", "<strong>Safewords stay ordinary-world words.</strong> They punch through the fiction on purpose.", "<strong>Closing line</strong> and an out-of-character “scene over.”", "<strong>Aftercare.</strong>"), h$1("Playtest"), p$1("Read it aloud once without acting. If you cringe at a line, cut it. Cringe in the living room becomes freeze in the scene. When you run it, you may improvise inside the beats. You may not add a new kink “because the character would.”"), p$1("Save the page under Roleplay. Use the wheel there if you want chance to pick the next fiction from the ones you have actually written."))
	},
	{
		key: "ex-role-voice",
		title: "Communication in your role",
		category: "exercises",
		subcategory: "roles",
		sort: 100,
		body: doc$1(p$1("Time: 20 minutes. You are finding a voice you can sustain — not a movie accent, a way of speaking that still tells the truth."), h$1("Warm-up, each of you"), p$1("Out of role, say: “I want you closer.” Then say it in role, three ways: spare, filthy, tender. Notice which one your body believes."), h$1("Drill"), ol$1("The Dominant (or lead) gives a real instruction in-role, then a check-in in-role (“Colour?” “Look at me.”).", "The submissive (or receiver) answers in-role without hiding a yellow. Practise: “Yellow — the cuff is biting” in the same voice you use for “Yes, Sir.” The role must be able to carry bad news.", "Swap one piece of praise and one piece of correction. Correction aims at the act, not the person’s worth."), h$1("Brat variant"), p$1("One sassy line that is in-bounds, one catch, one sincere landing line. If the landing line is still a joke, you are not done."), h$1("Takeaway"), p$1("Write three phrases you want as standing language — a call to position, a check-in, a close. Put them in Rules or Training so you do not invent a new dialect every Thursday."))
	},
	{
		key: "ex-deal-brat",
		title: "Deal with a bratty submissive",
		category: "exercises",
		subcategory: "bratting",
		sort: 110,
		body: doc$1(p$1("Time: 25 minutes as a drill, not a sneak attack. You both know you are practising. Real bratting during a drill is allowed only in the marked round."), h$1("Agree the sandbox"), ul$1("Two in-bounds brat moves for today (e.g. loophole, slow-walk).", "One catch (position, count, a known punishment).", "The landing (praise, touch, a simple order they will actually do).", "Safeword still works. So does “pause the game.”"), h$1("Run three loops"), ol$1("Brat pushes.", "Tamer names it, applies the catch without a speech.", "Brat yields on purpose.", "Tamer receives and warms. Reset."), h$1("Then talk"), p$1("Which catch felt like a game? Which one felt like a parent? Which yield was hot, and which was collapse? Adjust the menu. Put the keeper in Punishments or Training so you are not inventing consequences when you are already mad."), p$1("If anyone got actually angry, you left the sandbox. Repair as partners before you play again."))
	},
	{
		key: "ex-be-brat",
		title: "Be a bratty submissive (well)",
		category: "exercises",
		subcategory: "bratting",
		sort: 120,
		body: doc$1(p$1("Time: 20 minutes. Bratting is a gift if it is aimed at the game. It is a leak if it is how you say everything you are afraid to say straight."), h$1("Write, alone (8 min)"), ol$1("Three brat moves that are fun and in-bounds for your dynamic.", "Three that you use when you are actually hurt, tired, or avoiding a talk. Those need the difficult-topics script, not a smirk.", "What you want when you get caught. Be honest: the fight, the hold, the laugh, the sex, the proof they will not leave."), h$1("Share (7 min)"), p$1("Read the lists. The tamer does not argue with your want. They say whether they can offer that catch. If they cannot offer it, that is a negotiation, not a failure to “handle you.”"), h$1("Play one clean brat (5 min)"), p$1("You push on purpose, they catch as agreed, you let yourself be received. Stay for the warmth after. Leaving the moment you are caught is another push — sometimes hot, sometimes just fleeing. Name which one you are doing."), h$1("Remember"), p$1("A good brat makes the frame visible. A frightened person pretending to brat makes the frame cruel. You get to be both people on different days. Pick the tool that matches the day."))
	},
	{
		key: "edu-brat-needs",
		title: "Recognising a brat's needs",
		category: "education",
		subcategory: "how-to",
		sort: 55,
		body: doc$1(p$1("A brat is rarely asking for “more rules” in the words they use. They are asking for a need to be met inside a game. If you only hear the sass, you will miss the request. If you only hear the request, you will miss the fun."), h$1("Needs that often wear a brat face"), ul$1("<strong>To be caught.</strong> Proof the frame is real. The need is containment, not chaos.", "<strong>To be seen as clever.</strong> A loophole is a gift of attention. If you never acknowledge the craft, they will escalate the volume.", "<strong>To be wanted while difficult.</strong> “Will you still hold me if I push?” is an attachment question in costume.", "<strong>To discharge energy.</strong> Some bratting is play-hunting. They need a chase, a catch, and a landing, not a lecture.", "<strong>To test safety.</strong> After a yellow, a fight, or a drop, a small push can mean “are we still here?” Answer the need, then the game.", "<strong>To avoid a straight ask.</strong> Wanting sex, aftercare, or reassurance can come out as sass because asking felt more exposing than being a pest.", "<strong>To have an effect.</strong> If nothing they do moves you, they will find something that does. Give them a worthy effect that is still in-bounds.", "<strong>To rest from being good.</strong> A well-behaved submissive can starve for permission to be inconvenient. Scheduled brat windows feed that without wrecking Tuesday."), h$1("How to tell a need from a fight"), ol$1("Look at the body, not only the mouth. Bright eyes and a grin is often play. Flat eyes, a slammed door, or tears they will not name is often a need wearing armour — or a real conflict.", "Offer a clean ask once: “Is this play, or do you need something straight?” A brat in play will dodge and grin. A person in need will often sag with relief if you mean it.", "If the same push happens after they have been caught well, it may still be play. If it happens after they have been ignored, it is information about attention.", "Hunger, hormones, shame, and workdays change the mix. A well-fed, well-held brat is easier to read."), h$1("Meeting the need without collapsing the game"), ul$1("Catch them in the way you both wrote down, then meet the need in the landing: a hand, a specific praise, a yes to the thing they could not ask for.", "If the need is rest, commute the rest of the scene. Mercy is still dominance.", "If the need is sex, you can still make them ask. Do not make them invent a crime to get touched.", "If the need is proof, a short, boring, reliable ritual will feed them more than a theatrical punishment.", "If you cannot tell, pause the dynamic and use ordinary language. You can always restart the game after the truth is on the table."), p$1("Use the activity <em>Name the brat's need</em> when you want to practise this as a drill, not as a 2am guess."))
	},
	{
		key: "edu-why-brat",
		title: "Why they brat, and how to deal with it",
		category: "education",
		subcategory: "how-to",
		sort: 56,
		body: doc$1(p$1("Bratting is a behaviour, not a diagnosis. The same smirk can mean five different things. Your job is not to “win.” It is to read the why, stay in your role if it is play, and drop the role if it is a wound."), h$1("Common whys"), ul$1("<strong>Play.</strong> They want the chase. Deal with it as a game: named moves, named catches, named landings.", "<strong>Under-stimulation.</strong> The dynamic has gone slack. Deal with it by feeding protocol or a short scene, not by snapping.", "<strong>Over-stimulation.</strong> Too many rules, too much intensity, no rest. Deal with it by subtracting, not by adding a punishment.", "<strong>Shame.</strong> They cannot stand being seen as good, or as needy. Deal with it with precise praise and no audience.", "<strong>Fear of closeness.</strong> A push just when it got tender. Deal with it by staying, not by chasing them into a bigger fight.", "<strong>Unsaid no.</strong> They do not want tonight's plan and cannot say it. Deal with it by making “no” easy, then asking again tomorrow.", "<strong>Copied from old rooms.</strong> Bratting that used to keep them safe with someone unsafe. Deal with it slowly, maybe with help, never with humiliation of that history.", "<strong>You were sloppy.</strong> They found a hole in the frame. Deal with it by thanking the auditor, then patching the rule."), h$1("A simple read in the moment"), ol$1("Pause internally for three breaths so you do not take bait with real anger.", "Name what you see: “That was a loophole” or “That landed like a real no.”", "If it is play, run the catch you both know. Do not invent a new cruelty.", "If it is a need, ask one straight question. Then meet it or negotiate a time to meet it.", "If it is a fight, say “out of dynamic.” Have the fight as partners. Do not paddle a grievance.", "Repair. A brat who is only ever caught and never received will stop bringing you the fun, or they will stop being honest."), h$1("What not to do"), ul$1("Do not ignore them to “teach a lesson” unless a short, negotiated ignore was the catch — with a clock.", "Do not match their volume. You are the wall, not the second brat.", "Do not use the relationship, money, food, or sleep as leverage.", "Do not tell them they are “not a real submissive.” That sentence does damage you cannot scene your way out of.", "Do not skip the debrief. Play that is never talked about turns into a secret language you will misread."), p$1("Read <em>How to train a bratty submissive</em> and <em>Recognising a brat's needs</em> alongside this. Practise with <em>Decode the brat</em> under Activities."))
	},
	{
		key: "edu-partner-body",
		title: "Learning your partner's body",
		category: "education",
		subcategory: "how-to",
		sort: 120,
		body: doc$1(p$1("Porn is a map of somebody else. Your partner is a specific animal: where heat lives, where a tickle becomes a flinch, which knee complains, which words open them, which touch makes them leave the room without leaving the bed. Learning that is a practice, not a talent you either have or do not."), h$1("What you are mapping"), ul$1("<strong>Skin.</strong> Places that want pressure, places that want air, places that are simply “no.”", "<strong>Pace.</strong> How long until a touch that was nice becomes too much. How long after a peak they can stand to be touched at all.", "<strong>Sound and silence.</strong> Which noises are pleasure, which are performance, which are “get off that.”", "<strong>The week in the body.</strong> Hormones, medication, sleep, old injuries. Tuesday's yes is not Saturday's.", "<strong>The sexual map.</strong> Clit, cock, perineum, prostate, nipples, neck, inner thigh — and the boring places that are secretly the point.", "<strong>The limit map.</strong> Not only genitals. Stomach, feet, face, scars, the place they were hurt before you."), h$1("How to learn without turning them into a project"), ol$1("Ask out of bed first: “Where do you like to be started?” Write it down. Do not rely on afterglow memory.", "Give one new kind of touch at a time. If you change five variables, you will not know what worked.", "Use a colour on a body part: green / yellow / never. A full-body scan once a season beats guessing nightly.", "Watch the breath more than the porn face. A held breath is data.", "Let them show you on their own body, or on yours. Mirroring teaches faster than a lecture.", "After, one question only: “Where should I linger longer next time?”"), h$1("Notes worth keeping"), p$1("Keep a private page in Notes or the Journal: lube that does not sting, a angle that finds them, a word that shuts them down, a time of month that wants gentler. Update it as they grow. A body is not a contract you signed once."), p$1("The activity <em>Map your partner's body</em> is a 40-minute version of this you can run without turning it into homework every night."))
	},
	{
		key: "edu-edging",
		title: "How to edge your partner effectively",
		category: "education",
		subcategory: "how-to",
		sort: 130,
		body: doc$1(p$1("Edging is riding the climb and choosing not to step off. Done well, it makes the nervous system louder and the asking sweeter. Done badly, it inflames tissue, teaches them to fake, or turns a game into spite."), h$1("The mechanics"), ol$1("Warm the body before you chase the peak. Blood flow is not optional.", "Use enough lube. Dry friction makes people come from irritation, not pleasure — or refuse to come at all.", "Find their “close” tells: breath, hips, a specific noise, a foot, a look. Ask them to name one tell you may trust.", "Approach, then back off before the point of no return. The art is leaving them on the ledge, not shoving them off and pretending it was control.", "Change the variable you back off: speed, pressure, location, dirty talk. Do not only stop dead unless they like the crash.", "Rest long enough that the next climb is a climb, not a grind on a numb part.", "Water. Jaws, hips, and wrists also need breaks."), h$1("For different bodies"), ul$1("<strong>Clit and vulva.</strong> Indirect can last longer than a bullseye. Some people need a pause on the glans and a move to the shaft of the clit or the surrounding skin. Ask. Do not assume more pressure is more kind.", "<strong>Cock.</strong> A tight grip too soon finishes the night. Looser, wetter, slower as they get close. A ring only with a time cap and colour checks.", "<strong>Prostate / g-spot.</strong> Edging here can sneak up. Go slower than your pride. Sharp pain is a stop.", "<strong>Nipples, thighs, voice.</strong> Some people edge from dirty talk or from being watched. That still counts. Do not add genital touch just to make it “real.”"), h$1("Control versus cruelty"), p$1("If they asked for mean denial, you can still be precise. If they asked to be taken care of, edging is a gift of attention, not a test they can fail. A body that comes “too soon” is a body, not a brat — unless they are obviously performing a loophole you both think is funny."), ul$1("Agree whether a slip is a giggle, a reset, or a punishment. Write it down so lust does not prosecute.", "Ruined orgasms are a specific kink. Do not “accidentally” ruin one.", "Stop if they look like they are enduring. Endurance is not the same as heat.", "Aftercare for a night they did not come: they may feel raw or clingy. Plan for that, not only for the ones who float."), p$1("Practise with <em>Edging lab</em> under Activities. Keep what you learn in the body-map note."))
	},
	{
		key: "edu-orgasm-command",
		title: "Orgasm on command",
		category: "education",
		subcategory: "how-to",
		sort: 140,
		body: doc$1(p$1("Coming when they are told — with a hand, a toy, or eventually with a word — is trained pairing, not magic. Some bodies will never be fully reliable. That is not a moral failure. It is anatomy, history, medication, and luck. Train the skill. Do not train self-hate."), h$1("With stimulation"), ol$1("Pick a cue: a word, a snap, a tap. Use the same one for weeks.", "Bring them to the edge with the touch they already come from. Do not invent a new technique in week one.", "When they are truly close, give the cue and keep doing exactly what was working. The cue rides the orgasm, it does not replace the work yet.", "If they come, mark it: praise, the word “good,” a still hand. You are teaching the nervous system that the cue predicted the peak.", "If they do not, do not punish. Back off, rest, try once more or stop for the night. Shame makes orgasms hide.", "Repeat across many sessions, not one heroic evening. Pairing is boring until it is not.", "Over time, shorten the runway: less build, same cue. Only then reduce the stimulation."), h$1("Without stimulation"), p$1("This is later, and it is not guaranteed. You are asking a body to finish on memory, voice, and tension."), ol$1("Only start this after the cue already works with touch most of the time.", "Use the same cue. Add a posture or a breath pattern they already associate with being close.", "Let them clench, rock, or breathe — that is still their body helping. “Without stimulation” means without your hand or a toy, not without their own muscle.", "Some people need a fantasy spoken, or a memory of the last time. That is allowed.", "Success may look like a small orgasm, a ruined one, or a wave that is more like a shiver. Celebrate the pairing, not a porn money-shot.", "If nothing happens, they have still practised arousal on a word. End with closeness, not a scoreboard.", "Never require this in public, at work, or as a proof of ownership. A body that can do this is offering something rare. Treat it that way."), h$1("What gets in the way"), ul$1("SSRIs, alcohol, pain, being watched with contempt, needing to pee, being cold, being rushed, being told they “should have by now.”", "Switching the cue every session. Pick one.", "Punishing a miss. You will train freeze.", "Trying to stack humiliation, pain, and command-orgasm on night one."), p$1("Run <em>Orgasm on command — with stimulation</em> for a few weeks before you open the without-stimulation activity. Keep notes. Bodies change."))
	},
	{
		key: "act-body-map",
		title: "Map your partner's body",
		category: "exercises",
		subcategory: "body",
		sort: 130,
		body: doc$1(p$1("Time: 40 minutes. Phones away. One giver, one receiver, then swap if you want. This is research, not a performance."), h$1("Setup"), p$1("A yes/yellow/no list for tonight. Lube. A towel. Ordinary light — you need to see. Agree that “no” on a body part is not a rejection of the person."), h$1("The scan"), ol$1("Receiver lies down. Giver starts at the scalp and moves slowly: scalp, nape, ears, mouth (if allowed), throat, shoulders, inner arms, hands, chest, belly, hips, inner thighs, knees, calves, feet, then the sexual map you both named.", "On each place, try two pressures and two speeds. Wait. Watch breath.", "Receiver says green, yellow, or never — or a number 1–5 if they like numbers. Giver writes it down. Do not argue with a never.", "Mark three “linger here” spots and one “do not surprise me here.”"), h$1("The sexual close (optional)"), p$1("If you are both still in it, give five minutes of the best thing you learned. No proving. Then water."), h$1("Debrief"), p$1("Read the notes back. Put keepers in Notes. Do this again in a season, or after a medication change, a birth, a surgery, or a long drought. Bodies move."))
	},
	{
		key: "act-edging-lab",
		title: "Edging lab",
		category: "exercises",
		subcategory: "body",
		sort: 140,
		body: doc$1(p$1("Time: 25–40 minutes. One person is edged. The other is the operator. Swap another night. Read <em>How to edge your partner effectively</em> first."), h$1("Agree"), ul$1("Whether a slip is a laugh, a reset, or the end.", "Whether they will come at the end or not. Do not change that in the last ten seconds unless they ask.", "A colour check every edge."), h$1("The lab"), ol$1("Warm-up until the body is actually interested, not polite.", "Edge one: stop when they say “close.” Note what you were doing.", "Rest until they can talk in a full sentence.", "Edge two: stop one breath earlier. Note the tell you used.", "Edge three: change only one variable (speed, or location, or talk).", "If tonight includes a finish, use the same technique that worked, plus the cue if you are also training command.", "If tonight is denial, stop after three, wrap them, and do not add a barbed joke."), h$1("Write"), p$1("One tell. One technique that lasted. One that rushed them. Put it in the body-map note. That is the whole point of a lab."))
	},
	{
		key: "act-orgasm-touch",
		title: "Orgasm on command — with stimulation",
		category: "exercises",
		subcategory: "body",
		sort: 150,
		body: doc$1(p$1("Time: 20–30 minutes, twice a week if you can, not once as a stunt. Pick a single cue and do not change it this month."), h$1("The drill"), ol$1("Arousal first. No cue until they are actually close.", "When they are close, give the cue and keep the exact stimulation that was working.", "If they come, still the hands, praise, repeat the cue once more in a warm voice so the pairing sticks.", "If they do not, rest. One more try or stop. No scoreboard.", "After three sessions of mostly-yes, you may shorten the build by a little. Not by half."), h$1("Rules"), ul$1("Same time of day if you can. Bodies like context.", "No new kinks in this drill. The drill is the pairing.", "If they are on a medication that dulls orgasm, lower the ambition. Celebrate a swell, a shiver, a “close.”", "Write dates and yes/no in the Journal. Patterns beat memory."))
	},
	{
		key: "act-orgasm-voice",
		title: "Orgasm on command — without stimulation",
		category: "exercises",
		subcategory: "body",
		sort: 160,
		body: doc$1(p$1("Time: 15 minutes. Only after the with-stimulation drill works most of the time. This may never be reliable. Treat any success as a gift, not a standard."), h$1("The drill"), ol$1("They take the posture you used in the touch drill. You use the same cue.", "They may breathe, clench, rock, or hear you describe the last time they came. You do not touch genitals. A hand on a sternum or nape is allowed if that is an anchor, not a cheat you pretend not to notice — agree it.", "Give the cue when they say they are close, or after a build of talk and breath you have used before.", "Wait. Do not stare like a referee. Stay kind in the face.", "Whatever happens, praise the attempt. Then ordinary closeness."), h$1("If nothing happens"), p$1("That is the most common outcome. Do not add a toy “just to finish the job” unless they ask. You can run the with-stimulation drill another night. You may not punish a quiet body."), h$1("If something happens"), p$1("Mark it. Same cue next time. Do not immediately raise the difficulty or take it public."))
	},
	{
		key: "act-brat-needs",
		title: "Name the brat's need",
		category: "exercises",
		subcategory: "bratting",
		sort: 130,
		body: doc$1(p$1("Time: 20 minutes, out of scene. You are practising the read from <em>Recognising a brat's needs</em>."), h$1("Alone, five minutes"), p$1("Brat (or the person who brats) writes three recent pushes and, for each, the need they suspect was underneath: caught, seen, wanted, discharge, safety-check, avoided ask, effect, rest. They may write “it was just fun.” That is a valid need too — play."), h$1("Together"), ol$1("Read the list. The tamer does not argue. They may say which need they thought it was.", "Pick one need for this week. Agree a clean way to ask for it, and a play way to ask for it.", "Agree the catch if they still choose the play way."), h$1("This week"), p$1("When a push happens, the tamer may ask once: “Play or need?” Then they either catch or meet. Debrief on Sunday in one line each."))
	},
	{
		key: "act-why-brat",
		title: "Decode the brat",
		category: "exercises",
		subcategory: "bratting",
		sort: 140,
		body: doc$1(p$1("Time: 15 minutes after a real brat moment, not in the heat of it. Wait until you can sit. Read <em>Why they brat, and how to deal with it</em> first."), h$1("The five questions"), ol$1("What did they actually do, in one sentence, without adjectives.", "What did it get them (attention, delay, sex, a rise, space, a laugh).", "Was the body play-bright or fight-flat.", "What would a clean ask have been.", "What catch or care should we run if a twin of this shows up tomorrow."), h$1("Output"), p$1("One line in Notes: “When X, we will Y.” If Y is a talk, put it on the calendar. If Y is a catch, put it in Punishments or Training so you do not invent it angry."))
	}
];
function p(text) {
	return `<p>${text}</p>`;
}
function h(text) {
	return `<h2>${text}</h2>`;
}
function ul(...items) {
	return `<ul>${items.map((item) => `<li>${item}</li>`).join("")}</ul>`;
}
function ol(...items) {
	return `<ol>${items.map((item) => `<li>${item}</li>`).join("")}</ol>`;
}
function callout(text) {
	return `<blockquote><p><strong>Hold this.</strong> ${text}</p></blockquote>`;
}
function doc(...parts) {
	return parts.join("");
}
var PLAYBOOK_LIBRARY = [
	{
		key: "pb-curious",
		title: "Curious — first language",
		category: "curious",
		sort: 10,
		body: doc(p("Curious means you are naming power on purpose for the first time, or the first time with this person. You do not need a dungeon, a wardrobe, or a title. You need words, a safeword, and the humility to go smaller than the fantasy."), callout("Nothing you saw in porn is a lesson plan. Your first job is not intensity. It is a clean yes, a usable no, and a landing."), h("What this level is for"), ul("Learning the difference between a picture you like and a practice you can run.", "Building a yes / maybe / no list while you are clothed and fed.", "Trying one flavour at a time: voice, a kneel, a hold, a light spank, a collar that comes off.", "Finding out whether you want to lead, follow, or flip — without marrying an identity this month."), h("Do this"), ol("Write hard nos. Breath, blood, face, bathrooms, names, anything that is simply off. Nos do not need a speech.", "Pick a traffic-light: green, yellow, red. Practise saying yellow when nothing is wrong, so the word exists in your mouth.", "Negotiate one small scene with a clock. Twenty minutes is a scene. Close it out loud.", "Do aftercare even if the scene was mild. You are training the landing, not proving toughness.", "Debrief the next day: keep, tweak, never. Put keepers in Notes."), h("Do not do this yet"), ul("CNC, breath play, leaving someone bound, public play with strangers in it, stacking three kinks because you are excited.", "24/7 protocol. You do not have the repair skill for a life you have not practised in an evening.", "Punishments for ordinary relationship friction. That is a fight, not a scene."), h("For the Dominant-curious"), p("Your ego wants to look like you already know. Your partner needs you to ask, watch breath, and stop on yellow without sulking. Read Aftercare and How to negotiate a scene in Education. Lead a small thing well."), h("For the submissive-curious"), p("You are allowed to want it and still say no to the version in front of you. Subspace is not a test you pass. If you go quiet, they should check, not add more. Read Subspace. Use the word."), h("For switches"), p("Pick a seat per scene. Flipping mid-way is a later skill. Say who is running tonight before anyone is naked."))
	},
	{
		key: "pb-exploring",
		title: "Exploring — first structure",
		category: "exploring",
		sort: 20,
		body: doc(p("Exploring means you have had enough play to know it is not a one-off mood. You want language, a few standing agreements, and experiments that are still reversible. This is where people either get precise or get sloppy because they are bored of being careful."), callout("Curiosity without a debrief is just chaos with better lighting. Write what you try."), h("What this level is for"), ul("Building a small protocol: a title, a check-in, a kneel, a collar rule that has an off switch.", "Trying impact, bondage, or orgasm control as named practices, not accidents.", "Learning your drop and theirs. Aftercare stops being a vibe and becomes a kit.", "Meeting brat energy as a game with catches, not as a personality defect."), h("Practices"), ol("Keep a living yes/maybe/no. Review it monthly, not only after a scare.", "Add one toy or one restraint from the Catalogue. Learn it on a calm night.", "Run a scene from a written outline in Scenes: who leads, acts, intensity, aftercare, next-day check.", "If you brat or tame, write three catches you both think are fair. Do not invent cruelty in the moment.", "Open Education: Aftercare, Subspace, Domspace. You are now deep enough to miss a yellow."), h("Risks of this stage"), ul("Skipping negotiation because “we know each other now.” That is how limits quietly move.", "Using the dynamic to avoid a real fight. Out of dynamic means out.", "Comparing your bedroom to people who have been doing this for a decade.", "Topping from panic, or submitting from people-pleasing. Both feel like heat until they do not."), h("A week of exploring"), p("One negotiated scene. One ordinary night with no protocol so you remember you like each other. One journal page. One conversation that is not horny: sleep, food, a limit that wobbled."))
	},
	{
		key: "pb-practiced",
		title: "Practiced — a regular dynamic",
		category: "practiced",
		sort: 30,
		body: doc(p("Practiced means this is part of how you love, not a costume you take out on Fridays. You know your tastes. You can negotiate them. You have dropped, repaired, and come back. The work now is consistency — and not confusing familiarity with consent."), callout("A regular dynamic still needs a yellow. History is not a safeword."), h("What this level is for"), ul("Standing rules that are few enough to remember. Review them when you are not high.", "Scenes with an arc, not only a peak. Aftercare that is specific to this body.", "Training that has a marker and a mercy. Positions, cues, service — drilled, then used.", "Owning your archetype without forcing your partner into the matching cliché."), h("The craft"), ol("Write protocol that survives a bad week. If you cannot keep it on a worknight, it is theatre. Cut it.", "Build a toy and restraint literacy: materials, circulation, time-caps, a cutting tool in reach.", "Learn each other's drop windows. Put the next-day check in the calendar, not in hope.", "Practise ending. A scene that fizzles because someone got tired is a drop you scheduled by accident.", "Keep Education and the Playbook beside the fun. Edging, orgasm on command, brat-taming — skill, not mood."), h("Power that lasts"), p("The Dominant's job is still the frame, the check, the landing. The submissive's job is still the truth soon enough to be usable. Switches need a way to hand the hat over that is not a sulk. If you are 24/7-curious, run longer protocol in bounded blocks before you call your life a total power exchange."), h("Repair"), p("You will miss. You will use a word that was out. You will drop and go sharp. Repair is: name it, stop the dynamic if needed, make the next round safer, do not extract a performance of forgiveness. Put ruptures in Journal if that helps you not repeat them as folklore."))
	},
	{
		key: "pb-seasoned",
		title: "Seasoned — specific and durable",
		category: "seasoned",
		sort: 40,
		body: doc(p("Seasoned means you are specific. You know the difference between a kink you can run and a kink you only like in a story. You have done repair that was ugly and still true. Intensity is available. So is boredom, which is the real test of a dynamic that was built on novelty."), callout("At this depth, sloppiness is a choice. You already know better. Act like it."), h("What this level is for"), ul("Heavy protocol that is still kind. Titles that mean something on a grocery run, or a clear off-switch.", "Edge-adjacent play only with study: long bondage, serious impact, humiliation with a written lexicon, orgasm control measured in days not minutes.", "Mentoring your own past selves — the urge to skip the skeleton because you are good at this.", "Holding a brat or a sadist without becoming the worst version of the role."), h("Standards"), ol("Re-negotiate after life changes: meds, grief, a new job, a pregnancy scare, an injury. Last year's yes is not this body's.", "First aid for the play you actually do. Marks versus problems. When to stop and when to go to a clinician without shame.", "No stacking edge on a night you are angry at each other.", "Domspace and subspace are known states. You have tells, and you have a close. Read those Education notes until they are boring.", "If you play with fear, CNC, or public-shaped fantasy, it is scripted, sober, and has a non-verbal red. No exceptions because you are seasoned."), h("The long dynamic"), p("Pride looks like they are more themselves with you, not less. They can still say never. You can still stop. The collar is not a substitute for a relationship. If the only time you are tender is after you have hurt them, that is a pattern, not a style. Fix the pattern."))
	},
	{
		key: "pb-established",
		title: "Established — long power, studied edge",
		category: "established",
		sort: 50,
		body: doc(p("Established means this has years in it, or the weight of edge play you have actually studied — not just survived. You may run heavy protocol, TPE-shaped structures, or scenes that would be reckless in curious hands. The standard is higher, not lower. People get hurt here when they confuse seniority with immunity."), callout("Breath, blood, fire, electricity, leaving someone bound, CNC that is not a script — these are still edge. Experience is not a force field. Study, tools, a way out that does not depend on the person in the scene keeping their nerve."), h("What this level is for"), ul("Structures that govern more than the bedroom, with reviews, not just intensity.", "Edge play with educators, medical literacy, and the willingness to refuse a scene that is fashionable but stupid.", "Holding a partner through drops that last days, and having your own aftercare without making them parent you.", "Knowing when to stop being in role because the person is in trouble."), h("Non-negotiables"), ol("A safeword that always works, including non-verbal, including when you are in deep domspace.", "No play that requires you to ignore a yellow to get the aesthetic.", "Contracts and rules written, dated, revisable. A total power exchange without a revision clause is a trap.", "If you use fear, pain, or humiliation at this depth, you debrief. You watch for damage that looks like loyalty.", "You still read Aftercare. You still eat. You still sleep. A high-protocol Dominant who cannot keep a body alive is not elite."), h("The quiet work"), p("The fantasy is the dungeon. The practice is the Tuesday you are both tired and the collar still means something because you chose it again. Established play is mostly character: you stop when it is time, you repair without theatre, you do not need an audience. If you are bored, do not reach for danger. Reach for a conversation, a new negotiated flavour, or rest."), p("Keep the rest of Education beside this page. Depth is a privilege you pay for with attention."))
	}
];
var PLAYBOOK_CATEGORIES = EXPERIENCE_LEVELS.map((item) => ({
	value: item.value,
	label: item.label
}));
var TASK_STATUSES = [
	{
		value: "open",
		label: "Open"
	},
	{
		value: "done",
		label: "Done"
	},
	{
		value: "skipped",
		label: "Skipped"
	}
];
var KINDS = {
	task: {
		kind: "task",
		path: "/tasks",
		title: "Tasks",
		kicker: "The day",
		blurb: "Daily, weekly, custom-day, and one-off assignments — either of you can write them.",
		addLabel: "New task",
		emptyTitle: "No tasks yet",
		emptyBody: "Set the first daily, weekly, or custom assignment.",
		layout: "list",
		statuses: TASK_STATUSES,
		assignable: true,
		catalogLink: true,
		stakes: true,
		reminders: true,
		fields: [{
			key: "cadence",
			label: "Cadence",
			type: "cadence",
			store: "column"
		}, {
			key: "body",
			label: "Instructions",
			type: "textarea",
			placeholder: "What is expected, and how it should be done.",
			store: "column"
		}],
		completeLabel: "Mark done",
		reopenLabel: "Reopen"
	},
	rabbit: {
		kind: "rabbit",
		path: "/training",
		title: "Training",
		kicker: "The school",
		blurb: "Protocol, positions, commands, and rituals you are training.",
		addLabel: "New training",
		emptyTitle: "No training posted",
		emptyBody: "Add a protocol, position, command, or ritual to train.",
		layout: "grid",
		assignable: true,
		catalogLink: true,
		stakes: true,
		reminders: true,
		categories: [
			{
				value: "protocol",
				label: "Protocol"
			},
			{
				value: "position",
				label: "Position"
			},
			{
				value: "command",
				label: "Command"
			},
			{
				value: "ritual",
				label: "Ritual"
			}
		],
		statuses: [
			{
				value: "open",
				label: "Learning"
			},
			{
				value: "done",
				label: "Mastered"
			},
			{
				value: "archived",
				label: "Archived"
			}
		],
		fields: [
			{
				key: "cadence",
				label: "Cadence",
				type: "cadence",
				store: "column"
			},
			{
				key: "category",
				label: "Type",
				type: "select",
				store: "column",
				options: []
			},
			{
				key: "command",
				label: "Cue / command",
				type: "text",
				placeholder: "The spoken or gestured cue",
				store: "meta"
			},
			{
				key: "body",
				label: "How it is done",
				type: "textarea",
				placeholder: "Posture, duration, etiquette, corrections.",
				store: "column"
			},
			{
				key: "treat",
				label: "Treat or marker",
				type: "text",
				placeholder: "What marks a good performance",
				store: "meta"
			},
			{
				key: "intensity",
				label: "Demand",
				type: "intensity",
				store: "column"
			}
		],
		completeLabel: "Mark mastered",
		reopenLabel: "Reopen"
	},
	punishment: {
		kind: "punishment",
		path: "/punishments",
		title: "Punishments",
		kicker: "Corrections",
		blurb: "Assigned corrections, how many times each was earned, and whether they have been served.",
		addLabel: "New punishment",
		emptyTitle: "No punishments posted",
		emptyBody: "Record a correction, with optional photo evidence.",
		layout: "list",
		assignable: true,
		catalogLink: true,
		wheel: true,
		statuses: [
			{
				value: "open",
				label: "Assigned"
			},
			{
				value: "done",
				label: "Served"
			},
			{
				value: "archived",
				label: "Waived"
			}
		],
		fields: [
			{
				key: "reason",
				label: "Reason",
				type: "text",
				placeholder: "What earned this",
				store: "meta"
			},
			{
				key: "body",
				label: "The correction",
				type: "textarea",
				placeholder: "What must be done, and any limits.",
				store: "column"
			},
			{
				key: "intensity",
				label: "Severity",
				type: "intensity",
				store: "column"
			}
		],
		completeLabel: "Mark served",
		reopenLabel: "Reassign"
	},
	reward: {
		kind: "reward",
		path: "/rewards",
		title: "Rewards",
		kicker: "Grace",
		blurb: "Privileges, treats, and tokens that can be earned, granted, or bought with points.",
		addLabel: "New reward",
		emptyTitle: "No rewards posted",
		emptyBody: "Offer something worth earning.",
		layout: "grid",
		assignable: true,
		catalogLink: true,
		shop: true,
		wheel: true,
		statuses: [
			{
				value: "open",
				label: "Available"
			},
			{
				value: "done",
				label: "Completed"
			},
			{
				value: "archived",
				label: "Retired"
			}
		],
		fields: [
			{
				key: "earn",
				label: "How it is earned",
				type: "text",
				placeholder: "What unlocks this",
				store: "meta"
			},
			{
				key: "body",
				label: "The reward",
				type: "textarea",
				placeholder: "What is given, and any conditions.",
				store: "column"
			},
			{
				key: "intensity",
				label: "Indulgence",
				type: "intensity",
				store: "column"
			}
		],
		completeLabel: "Complete",
		reopenLabel: "Make available"
	},
	game: {
		kind: "game",
		path: "/games",
		title: "Games",
		kicker: "Play",
		blurb: "Write games with their own cards, prompts, and catalogue pieces — draw at random, or buy them with points.",
		addLabel: "New game",
		emptyTitle: "No custom games yet",
		emptyBody: "Write a game with cards, prompts, or a catalogue piece to draw.",
		layout: "grid",
		catalogLink: true,
		shop: true,
		categories: [{
			value: "card",
			label: "Cards"
		}],
		statuses: [
			{
				value: "open",
				label: "Ready"
			},
			{
				value: "done",
				label: "Played"
			},
			{
				value: "archived",
				label: "Archived"
			}
		],
		fields: [
			{
				key: "category",
				label: "Type",
				type: "select",
				store: "column"
			},
			{
				key: "body",
				label: "Rules",
				type: "textarea",
				placeholder: "How to play, scoring, and limits.",
				store: "column"
			},
			{
				key: "intensity",
				label: "Heat",
				type: "intensity",
				store: "column"
			}
		],
		completeLabel: "Mark played",
		reopenLabel: "Make ready"
	},
	scene: {
		kind: "scene",
		path: "/scenes",
		title: "Scenes",
		kicker: "The floor",
		blurb: "Plan, run, and archive scenes — with aftercare, photos, and an optional points cost.",
		addLabel: "New scene",
		emptyTitle: "No scenes booked",
		emptyBody: "Sketch the next scene, or log one you already ran.",
		layout: "list",
		catalogLink: true,
		shop: true,
		wheel: true,
		statuses: [
			{
				value: "open",
				label: "Planned"
			},
			{
				value: "done",
				label: "Completed"
			},
			{
				value: "archived",
				label: "Cancelled"
			}
		],
		fields: [
			{
				key: "when",
				label: "When",
				type: "text",
				placeholder: "Date, time, or ‘tonight’",
				store: "meta"
			},
			{
				key: "duration",
				label: "Duration",
				type: "text",
				placeholder: "e.g. 45 minutes",
				store: "meta"
			},
			{
				key: "body",
				label: "Outline",
				type: "textarea",
				placeholder: "Arc, roles, toys, limits, safeword.",
				store: "column"
			},
			{
				key: "aftercare",
				label: "Aftercare",
				type: "textarea",
				placeholder: "What happens after.",
				store: "meta"
			},
			{
				key: "intensity",
				label: "Intensity",
				type: "intensity",
				store: "column"
			}
		],
		completeLabel: "Mark completed",
		reopenLabel: "Reopen plan"
	},
	journal: {
		kind: "journal",
		path: "/journal",
		title: "Journal",
		kicker: "The page",
		blurb: "Private or shared entries. Shared pages can take comments from your partner.",
		addLabel: "New entry",
		emptyTitle: "The journal is blank",
		emptyBody: "Write the first page. Keep it private, or share it for comments.",
		layout: "timeline",
		statuses: [{
			value: "open",
			label: "Open"
		}, {
			value: "archived",
			label: "Filed"
		}],
		fields: [
			{
				key: "mood",
				label: "Mood",
				type: "text",
				placeholder: "A word for the weather inside",
				store: "meta"
			},
			{
				key: "body",
				label: "Entry",
				type: "textarea",
				placeholder: "Write freely.",
				store: "column"
			},
			{
				key: "intensity",
				label: "Charge",
				type: "intensity",
				store: "column"
			}
		]
	},
	note: {
		kind: "note",
		path: "/notes",
		title: "Notes",
		kicker: "The desk",
		blurb: "Contracts, agreements, rules, limits, aftercare, and ideas you both keep — plus Education and Activities. Check an idea or activity to add it to another page, and choose the category.",
		addLabel: "New note",
		emptyTitle: "No notes",
		emptyBody: "Pin a contract, a rule, a limit, aftercare, or an idea. Education and activities are already on the desk. Ideas start empty — add your own, and nest subcategories if you want them finer.",
		layout: "grid",
		categories: [
			{
				value: "contract",
				label: "Contract"
			},
			{
				value: "agreements",
				label: "Agreements"
			},
			{
				value: "rules",
				label: "Rules"
			},
			{
				value: "limits",
				label: "Limits"
			},
			{
				value: "aftercare",
				label: "Aftercare"
			},
			{
				value: "ideas",
				label: "Ideas"
			},
			...NOTE_LIBRARY_CATEGORIES
		],
		statuses: [{
			value: "open",
			label: "Active"
		}, {
			value: "archived",
			label: "Filed"
		}],
		fields: [{
			key: "category",
			label: "Type",
			type: "select",
			store: "column"
		}, {
			key: "body",
			label: "Note",
			type: "textarea",
			placeholder: "Anything worth keeping.",
			store: "column"
		}]
	},
	catalog: {
		kind: "catalog",
		path: "/catalog",
		title: "Catalogue",
		kicker: "The shelf",
		blurb: "Toys, outfits, accessories, restraints, furniture, and spaces.",
		addLabel: "New item",
		emptyTitle: "The catalogue is empty",
		emptyBody: "Photograph a toy, an outfit, a restraint, a piece of furniture, or a space.",
		layout: "grid",
		categories: [
			{
				value: "toy",
				label: "Toys"
			},
			{
				value: "outfit",
				label: "Outfits"
			},
			{
				value: "lingerie",
				label: "Lingerie"
			},
			{
				value: "accessory",
				label: "Accessories"
			},
			{
				value: "restraint",
				label: "Restraints"
			},
			{
				value: "furniture",
				label: "Furniture"
			},
			{
				value: "room",
				label: "Spaces"
			}
		],
		statuses: [{
			value: "open",
			label: "In rotation"
		}, {
			value: "archived",
			label: "Packed away"
		}],
		fields: [
			{
				key: "category",
				label: "Kind",
				type: "select",
				store: "column"
			},
			{
				key: "brand",
				label: "Maker / brand",
				type: "text",
				placeholder: "Optional",
				store: "meta"
			},
			{
				key: "body",
				label: "Notes",
				type: "textarea",
				placeholder: "Use, care, limits, favourites.",
				store: "column"
			},
			{
				key: "intensity",
				label: "Intensity",
				type: "intensity",
				store: "column"
			}
		]
	},
	talk: {
		kind: "talk",
		path: "/talk",
		title: "Talk",
		kicker: "The table",
		blurb: "One shared card each day, kinks, quizzes, fantasies, and issues — both of you answer here. More info on a prompt opens Education and Activities in Notes.",
		addLabel: "New prompt",
		emptyTitle: "Nothing on the table",
		emptyBody: "Add a question, a kink, a fantasy, or an issue.",
		layout: "list",
		categories: [
			{
				value: "question",
				label: "Questions"
			},
			{
				value: "kink",
				label: "Kinks"
			},
			{
				value: "fantasy",
				label: "Fantasies"
			},
			{
				value: "quiz",
				label: "Quizzes"
			},
			{
				value: "issues",
				label: "Issues"
			}
		],
		statuses: [{
			value: "open",
			label: "Open"
		}, {
			value: "done",
			label: "Answered"
		}],
		fields: [{
			key: "category",
			label: "Type",
			type: "select",
			store: "column"
		}, {
			key: "body",
			label: "Prompt",
			type: "textarea",
			placeholder: "The question, kink, fantasy, or issue.",
			store: "column"
		}]
	},
	roleplay: {
		kind: "roleplay",
		path: "/roleplay",
		title: "Roleplay",
		kicker: "The scene",
		blurb: "Characters, prompts, and scripts you both can run — or buy with points.",
		addLabel: "New roleplay",
		emptyTitle: "No roleplay yet",
		emptyBody: "Write a prompt, a character, or a script.",
		layout: "list",
		catalogLink: true,
		shop: true,
		wheel: true,
		categories: [
			{
				value: "prompt",
				label: "Prompts"
			},
			{
				value: "character",
				label: "Characters"
			},
			{
				value: "script",
				label: "Scripts"
			},
			{
				value: "setting",
				label: "Settings"
			}
		],
		statuses: [
			{
				value: "open",
				label: "Ready"
			},
			{
				value: "done",
				label: "Completed"
			},
			{
				value: "archived",
				label: "Shelved"
			}
		],
		fields: [
			{
				key: "category",
				label: "Type",
				type: "select",
				store: "column"
			},
			{
				key: "body",
				label: "Scene",
				type: "textarea",
				placeholder: "Who you are, the setup, limits, and how it ends.",
				store: "column"
			},
			{
				key: "intensity",
				label: "Heat",
				type: "intensity",
				store: "column"
			}
		],
		completeLabel: "Complete",
		reopenLabel: "Make ready"
	},
	challenge: {
		kind: "challenge",
		path: "/challenges",
		title: "Challenges",
		kicker: "The month",
		blurb: "Daily practice for your role, plus challenges you assign each other.",
		addLabel: "Assign a challenge",
		emptyTitle: "No assigned challenges",
		emptyBody: "Write a challenge for your partner — or for both of you.",
		layout: "list",
		assignable: true,
		statuses: TASK_STATUSES,
		fields: [{
			key: "body",
			label: "Practice",
			type: "textarea",
			placeholder: "What to do.",
			store: "column"
		}],
		completeLabel: "Mark done",
		reopenLabel: "Reopen"
	},
	playbook: {
		kind: "playbook",
		path: "/playbook",
		title: "The Playbook",
		kicker: "The craft",
		blurb: "How to practise this dynamic at your experience — Curious through Established. Add your own notes under each level.",
		addLabel: "New playbook note",
		emptyTitle: "This level is empty",
		emptyBody: "Add a note for this experience, or open the seeded guide.",
		layout: "list",
		categories: PLAYBOOK_CATEGORIES,
		statuses: [{
			value: "open",
			label: "Active"
		}, {
			value: "archived",
			label: "Filed"
		}],
		fields: [{
			key: "category",
			label: "Experience",
			type: "select",
			store: "column"
		}, {
			key: "body",
			label: "Note",
			type: "textarea",
			placeholder: "Practice, cautions, and what you actually do at this depth.",
			store: "column"
		}]
	}
};
function isLeadRole(role) {
	return role === "dominant" || role === "switch";
}
function fillSelectOptions(config) {
	const fields = config.fields.map((field) => {
		if (field.type !== "select") return field;
		const options = field.options?.length ? field.options : (config.categories ?? []).filter((item) => !item.parent);
		return {
			...field,
			options
		};
	});
	const statuses = config.statuses.some((item) => item.value === "archived") ? config.statuses : [...config.statuses, {
		value: "archived",
		label: "Archived"
	}];
	return {
		...config,
		fields,
		statuses
	};
}
function isArchivedEntry(entry) {
	return entry.status === "archived" || entry.effectiveStatus === "archived";
}
function builtinSlugs(kind) {
	return new Set((KINDS[kind].categories ?? []).map((item) => item.value));
}
function slugify(name) {
	return name.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) || "item";
}
var DEFAULT_PLAY = {
	wheelTitle: "The wheel",
	wheelSlices: [
		"Dominant's choice",
		"A reward",
		"A punishment",
		"Training command",
		"Scene beat",
		"Free pass",
		"Write a journal page",
		"Photograph an item"
	],
	wheelBody: "Spin for a beat of the evening.",
	wheelPrompts: [],
	wheelCatalogIds: [],
	drawTitle: "Draw a command",
	drawCards: [
		{
			title: "Present",
			body: "Kneel until you are acknowledged. Then wait for the next command."
		},
		{
			title: "Hold still",
			body: "Stay in position until released."
		},
		{
			title: "Speak last",
			body: "Do not speak unless spoken to for the next ten minutes."
		}
	],
	drawBody: "Your deck. One card per line: Title — the command.",
	drawPrompts: [],
	drawCatalogIds: [],
	diceTitle: "Dice of service",
	diceActs: [
		"A glance. Soft.",
		"A small service.",
		"A training command.",
		"A timed hold.",
		"A punishment or reward of their choosing.",
		"A scene beat. Negotiate first."
	],
	diceBody: "Six acts. Edit each face.",
	dicePrompts: [],
	diceCatalogIds: [],
	timerTitle: "Timer",
	timerBody: "A timed kneel, present, or silence. Set any time you like."
};
var DEFAULT_HOUSE = {
	subEdit: {
		tasks: true,
		habits: true,
		rewards: true,
		punishments: true,
		training: true,
		games: true,
		costs: true,
		earnedCounts: true,
		countdowns: true
	},
	vacation: false,
	vacationSince: null,
	play: DEFAULT_PLAY,
	wheels: {},
	lastWeeklyReset: null
};
var DEFAULT_OPTIONS = {
	honorific: "",
	addressAs: "",
	safeword: "",
	checkIn: "",
	hideCompleted: false,
	showReminders: true,
	autoCompleteNote: false,
	noteTask: "Good {name}. {title} is done. I'm pleased with you.",
	noteHabit: "{title} is kept. That's my good {name}.",
	noteTraining: "Well trained. {title} is marked. I'm proud of you.",
	quickNav: [
		"/",
		"/tasks",
		"/games",
		"/talk"
	]
};
var EMPTY_ME = {
	profile: null,
	partner: null,
	lastPartner: null,
	partners: [],
	house: DEFAULT_HOUSE,
	options: DEFAULT_OPTIONS
};
var EDIT_SCOPES = [
	{
		key: "tasks",
		label: "Tasks",
		hint: "Daily, weekly, and one-off assignments"
	},
	{
		key: "habits",
		label: "Habits",
		hint: "Repeating habit cards"
	},
	{
		key: "rewards",
		label: "Rewards",
		hint: "Treats and privileges"
	},
	{
		key: "punishments",
		label: "Punishments",
		hint: "Corrections and consequences"
	},
	{
		key: "training",
		label: "Training",
		hint: "Protocols, positions, and commands"
	},
	{
		key: "games",
		label: "Games",
		hint: "Games and play cards"
	},
	{
		key: "costs",
		label: "Points costs",
		hint: "Set the price on rewards, scenes, roleplay, and games. Buying with points still belongs to them."
	},
	{
		key: "earnedCounts",
		label: "Counts",
		hint: "Change how many times punishments, rewards, scenes, roleplay, and games have been used. Completing them still belongs to them."
	},
	{
		key: "countdowns",
		label: "Timers",
		hint: "Set days, hours, and minutes on tasks, challenges, punishments, and rewards. Completing them still belongs to them."
	}
];
var HOUSE_TABS = [
	"you",
	"partner",
	"options",
	"app",
	"calendar",
	"archive",
	"location",
	"permissions"
];
function parseHouseTab(hash) {
	const value = (hash ?? "").replace(/^#/, "");
	return HOUSE_TABS.includes(value) ? value : "you";
}
function parseHouse(raw) {
	const base = structuredClone(DEFAULT_HOUSE);
	const parsed = asObject(raw);
	const sub = asObject(parsed.subEdit);
	for (const key of Object.keys(base.subEdit)) if (typeof sub[key] === "boolean") base.subEdit[key] = sub[key];
	if (typeof parsed.vacation === "boolean") base.vacation = parsed.vacation;
	if (typeof parsed.vacationSince === "string" && parsed.vacationSince) base.vacationSince = parsed.vacationSince;
	else if (parsed.vacationSince === null) base.vacationSince = null;
	if (typeof parsed.lastWeeklyReset === "string" && parsed.lastWeeklyReset) base.lastWeeklyReset = parsed.lastWeeklyReset;
	base.play = parsePlay(asObject(parsed.play));
	const wheels = asObject(parsed.wheels);
	const nextWheels = {};
	for (const [key, value] of Object.entries(wheels)) if (Array.isArray(value)) nextWheels[key] = value.filter((item) => typeof item === "string" && item.trim().length > 0).slice(0, 40);
	base.wheels = nextWheels;
	return base;
}
function parsePlay(raw) {
	const base = structuredClone(DEFAULT_PLAY);
	const parsed = asObject(raw);
	if (typeof parsed.wheelTitle === "string" && parsed.wheelTitle.trim()) base.wheelTitle = parsed.wheelTitle.trim().slice(0, 80);
	if (typeof parsed.wheelBody === "string") base.wheelBody = parsed.wheelBody.slice(0, 4e3);
	if (typeof parsed.drawTitle === "string" && parsed.drawTitle.trim()) base.drawTitle = parsed.drawTitle.trim().slice(0, 80);
	if (typeof parsed.drawBody === "string") base.drawBody = parsed.drawBody.slice(0, 4e3);
	if (typeof parsed.diceTitle === "string" && parsed.diceTitle.trim()) base.diceTitle = parsed.diceTitle.trim().slice(0, 80);
	if (typeof parsed.diceBody === "string") base.diceBody = parsed.diceBody.slice(0, 4e3);
	if (typeof parsed.timerTitle === "string" && parsed.timerTitle.trim()) base.timerTitle = parsed.timerTitle.trim().slice(0, 80);
	if (typeof parsed.timerBody === "string") base.timerBody = parsed.timerBody.slice(0, 4e3);
	if (Array.isArray(parsed.wheelSlices)) {
		const slices = parsed.wheelSlices.filter((item) => typeof item === "string" && item.trim().length > 0).map((item) => item.trim().slice(0, 80));
		if (slices.length) base.wheelSlices = slices.slice(0, 24);
	}
	if (Array.isArray(parsed.wheelPrompts)) base.wheelPrompts = parsed.wheelPrompts.filter((item) => typeof item === "string").map((item) => item.trim()).filter(Boolean).slice(0, 40);
	if (Array.isArray(parsed.drawPrompts)) base.drawPrompts = parsed.drawPrompts.filter((item) => typeof item === "string").map((item) => item.trim()).filter(Boolean).slice(0, 40);
	if (Array.isArray(parsed.dicePrompts)) base.dicePrompts = parsed.dicePrompts.filter((item) => typeof item === "string").map((item) => item.trim()).filter(Boolean).slice(0, 40);
	if (Array.isArray(parsed.wheelCatalogIds)) base.wheelCatalogIds = parsed.wheelCatalogIds.filter((item) => typeof item === "string").slice(0, 24);
	if (Array.isArray(parsed.drawCatalogIds)) base.drawCatalogIds = parsed.drawCatalogIds.filter((item) => typeof item === "string").slice(0, 24);
	if (Array.isArray(parsed.diceCatalogIds)) base.diceCatalogIds = parsed.diceCatalogIds.filter((item) => typeof item === "string").slice(0, 24);
	if (Array.isArray(parsed.drawCards)) {
		const cards = parsed.drawCards.map((item) => {
			const card = asObject(item);
			const title = typeof card.title === "string" ? card.title.trim().slice(0, 80) : "";
			const body = typeof card.body === "string" ? card.body.trim().slice(0, 800) : "";
			if (!title && !body) return null;
			return {
				title: title || "Card",
				body
			};
		}).filter((item) => Boolean(item));
		if (cards.length) base.drawCards = cards.slice(0, 40);
	}
	if (Array.isArray(parsed.diceActs)) {
		const acts = parsed.diceActs.filter((item) => typeof item === "string").map((item) => item.trim().slice(0, 160));
		if (acts.length >= 6) base.diceActs = acts.slice(0, 6);
		else if (acts.length) base.diceActs = [...acts, ...base.diceActs].slice(0, 6);
	}
	return base;
}
function parseOptions(raw) {
	const base = { ...DEFAULT_OPTIONS };
	const parsed = asObject(raw);
	if (typeof parsed.honorific === "string") base.honorific = parsed.honorific;
	if (typeof parsed.addressAs === "string") base.addressAs = parsed.addressAs;
	if (typeof parsed.safeword === "string") base.safeword = parsed.safeword;
	if (typeof parsed.checkIn === "string") base.checkIn = parsed.checkIn;
	if (typeof parsed.hideCompleted === "boolean") base.hideCompleted = parsed.hideCompleted;
	if (typeof parsed.showReminders === "boolean") base.showReminders = parsed.showReminders;
	if (typeof parsed.autoCompleteNote === "boolean") base.autoCompleteNote = parsed.autoCompleteNote;
	if (typeof parsed.noteTask === "string") base.noteTask = parsed.noteTask;
	if (typeof parsed.noteHabit === "string") base.noteHabit = parsed.noteHabit;
	if (typeof parsed.noteTraining === "string") base.noteTraining = parsed.noteTraining;
	if (Array.isArray(parsed.quickNav)) base.quickNav = parsed.quickNav.filter((item) => typeof item === "string").slice(0, 4);
	return base;
}
function completeNoteKind(kind, cadence) {
	if (kind === "rabbit") return "training";
	if (kind === "task") return cadence === "habit" ? "habit" : "task";
	return null;
}
function fillCompleteNote(template, vars) {
	const name = vars.name.trim() || "you";
	const you = vars.you.trim() || name;
	const title = vars.title.trim() || "that";
	return template.replace(/\{name\}/gi, name).replace(/\{title\}/gi, title).replace(/\{you\}/gi, you).replace(/[ \t]+\n/g, "\n").trim().slice(0, 4e3);
}
function asObject(raw) {
	if (!raw) return {};
	if (typeof raw === "string") {
		try {
			const parsed = JSON.parse(raw);
			if (parsed && typeof parsed === "object") return parsed;
		} catch {
			return {};
		}
		return {};
	}
	if (typeof raw === "object") return raw;
	return {};
}
function canEditKind(house, kind, cadence) {
	if (kind === "task") {
		if (cadence === "habit") return house.subEdit.habits;
		if (cadence == null || cadence === "") return house.subEdit.tasks || house.subEdit.habits;
		return house.subEdit.tasks;
	}
	if (kind === "rabbit") return house.subEdit.training;
	if (kind === "reward") return house.subEdit.rewards;
	if (kind === "punishment") return house.subEdit.punishments;
	if (kind === "game") return house.subEdit.games;
	return true;
}
function canMutate(me, kind, cadence) {
	if (!me?.profile) return false;
	if (isLeadRole(me.profile.role)) return true;
	return canEditKind(me.house, kind, cadence);
}
function canSetCost(me) {
	if (!me?.profile) return false;
	if (isLeadRole(me.profile.role)) return true;
	return Boolean(me.house.subEdit.costs);
}
function canSetEarnedCount(me) {
	if (!me?.profile) return false;
	if (isLeadRole(me.profile.role)) return true;
	return Boolean(me.house.subEdit.earnedCounts);
}
function canSetCountdown(me) {
	if (!me?.profile) return false;
	if (isLeadRole(me.profile.role)) return true;
	return Boolean(me.house.subEdit.countdowns);
}
function assignmentLocked(me, entry) {
	if (!me?.profile) return false;
	if (entry.kind !== "task" && entry.kind !== "challenge") return false;
	if (!entry.createdBy || entry.createdBy === me.profile.userId) return false;
	const assigned = entry.assignedTo;
	if (!assigned) return false;
	return assigned === me.profile.userId || assigned === "both";
}
function canEditEntry(me, entry) {
	if (assignmentLocked(me, entry)) return false;
	return canMutate(me, entry.kind, entry.cadence);
}
function isDutyKind(kind) {
	return kind === "task" || kind === "rabbit";
}
function dutiesPaused(house) {
	return Boolean(house?.vacation);
}
function lockedCopy(kind) {
	return `Your Dominant has locked editing for ${kind === "rabbit" ? "training" : kind === "task" ? "tasks" : kind === "game" ? "games" : kind === "reward" ? "rewards" : kind === "punishment" ? "punishments" : "this category"}.`;
}
function assignmentLockedCopy() {
	return "Only the person who assigned this can edit it.";
}
function editDeniedCopy(me, entry) {
	if (assignmentLocked(me, entry)) return assignmentLockedCopy();
	return lockedCopy(entry.kind);
}
function googleMapsEmbed(lat, lng) {
	return `https://maps.google.com/maps?q=${lat},${lng}&z=16&hl=en&output=embed`;
}
function googleMapsLink(lat, lng) {
	return `https://www.google.com/maps?q=${lat},${lng}`;
}
function haversineMeters(a, b) {
	const R = 6371e3;
	const dLat = (b.lat - a.lat) * Math.PI / 180;
	const dLng = (b.lng - a.lng) * Math.PI / 180;
	const s = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
	return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}
function formatMeters(meters) {
	if (!Number.isFinite(meters)) return "";
	if (meters < 1e3) return `${Math.round(meters)} m`;
	return `${(meters / 1e3).toFixed(meters >= 1e4 ? 0 : 1)} km`;
}
function formatAgo(iso, now = Date.now()) {
	if (!iso) return "";
	const then = new Date(iso).getTime();
	if (!Number.isFinite(then)) return "";
	const delta = now - then;
	if (delta < 2e4) return "just now";
	if (delta < 6e4) return `${Math.round(delta / 1e3)}s ago`;
	if (delta < 36e5) return `${Math.round(delta / 6e4)}m ago`;
	if (delta < 864e5) return `${Math.round(delta / 36e5)}h ago`;
	return new Intl.DateTimeFormat(void 0, {
		month: "short",
		day: "numeric"
	}).format(new Date(then));
}
function formatNominatimAddress(json) {
	if (!json) return "";
	const a = json.address ?? {};
	const street = [a.house_number, a.road || a.pedestrian || a.footway || a.path || a.residential].filter(Boolean).join(" ");
	const locality = a.suburb || a.neighbourhood || a.quarter || a.city_district || a.hamlet;
	const city = a.city || a.town || a.village || a.municipality;
	const region = a.state;
	const postcode = a.postcode;
	const parts = [];
	if (street) parts.push(street);
	if (locality && locality !== city) parts.push(locality);
	if (city) parts.push(city);
	if (region) parts.push(region);
	if (postcode) parts.push(postcode);
	if (parts.length) return parts.join(", ");
	return (json.display_name ?? "").split(",").slice(0, 4).map((part) => part.trim()).filter(Boolean).join(", ");
}
var LOCATION_EVENT = "sanctum:location";
function notifyLocationChanged() {
	if (typeof window === "undefined") return;
	window.dispatchEvent(new Event(LOCATION_EVENT));
}
function roleLabel(role) {
	if (role === "dominant") return "Dominant";
	if (role === "switch") return "Switch";
	return "Submissive";
}
function sexLabel(value) {
	return SEX_OPTIONS.find((item) => item.value === value)?.label ?? "";
}
function formatWhen(iso) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return "";
	return new Intl.DateTimeFormat(void 0, {
		month: "short",
		day: "numeric",
		hour: "numeric",
		minute: "2-digit"
	}).format(date);
}
function greeting() {
	const hour = (/* @__PURE__ */ new Date()).getHours();
	if (hour < 5) return "Late night";
	if (hour < 12) return "Morning";
	if (hour < 18) return "Afternoon";
	return "Evening";
}
function intensityMarks(value) {
	const n = value ?? 0;
	return Array.from({ length: 5 }, (_, i) => i < n);
}
//#endregion
export { greeting as A, parseHouseTab as B, fillSelectOptions as C, formatWhen as D, formatNominatimAddress as E, isLeadRole as F, roleLabel as G, parsePlay as H, isLibraryNote as I, sexLabel as K, lockedCopy as L, intensityMarks as M, isArchivedEntry as N, googleMapsEmbed as O, isDutyKind as P, notifyLocationChanged as R, fillCompleteNote as S, formatMeters as T, plainExcerpt as U, parseOptions as V, resolveIdeaSlug as W, canSetEarnedCount as _, EMPTY_ME as a, dutiesPaused as b, NOTES_LIBRARY as c, builtinSlugs as d, canEditEntry as f, canSetCountdown as g, canSetCost as h, EDIT_SCOPES as i, haversineMeters as j, googleMapsLink as k, NOTE_LIBRARY_CATEGORIES as l, canMutate as m, DEFAULT_OPTIONS as n, KINDS as o, canEditKind as p, slugify as q, DEFAULT_PLAY as r, LOCATION_EVENT as s, DEFAULT_HOUSE as t, PLAYBOOK_LIBRARY as u, clipIdeaTitle as v, formatAgo as w, editDeniedCopy as x, completeNoteKind as y, parseHouse as z };
