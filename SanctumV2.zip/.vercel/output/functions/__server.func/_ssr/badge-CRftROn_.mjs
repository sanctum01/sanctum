import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { d as useRouterState, v as Link, y as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, l as require_react_dom, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { D as encodeTagBag, F as kinksFor, H as parseTagBag, L as matchKnownTag, M as isVideoDataUrl, O as encodeTagList, Q as traitsFor, U as parseTagList, X as tagLabel, a as DEFAULT_COMPANION, b as companionRevealDelay, f as clampCompanionAge, n as ALL_TRAIT_OPTIONS, r as COMPANION_HEAT, s as MEDIA_ACCEPT, t as ALL_KINK_OPTIONS, v as companionPortrait, x as companionRoleKind } from "./video-DfU4zp6z.mjs";
import { B as parseHouseTab, D as formatWhen, a as EMPTY_ME, b as dutiesPaused, s as LOCATION_EVENT } from "./format-Dsk7inZY.mjs";
import { i as signOut } from "./client-CVqXY6bk.mjs";
import { a as hasGateSessionMarker } from "./server-mSvqDINc.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { i as cn, n as Input, r as Label, t as Button } from "./input-CkY6TqOo.mjs";
import { $ as BookOpen, B as Flame, D as Menu, E as MessageCircle, I as ImagePlus, K as Clapperboard, L as House, M as ListChecks, N as Italic, O as MapPin, Q as Calendar, R as GraduationCap, S as Pause, T as Mic, U as EllipsisVertical, W as Dices, a as Trophy, b as Plus, c as Theater, d as SquareCheckBig, et as BookMarked, f as Sparkles, g as Settings, h as Shield, i as Underline, j as List, k as Mail, l as StickyNote, m as Shirt, n as Users, p as SlidersHorizontal, r as UserRound, rt as Archive, t as X, tt as Bold, u as Square, v as Send, w as Minus, x as Play, y as Repeat, z as Gem } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as useEditor, t as EditorContent } from "../_libs/fast-equals+tiptap__react.mjs";
import { $ as saveCompanion, A as getCompanion, D as dropCompanionMemory, H as listMessages, J as recordAppOpen, K as pingLocation, N as getLocationBoard, O as generateCompanionPortrait, P as getMe, R as listCompanionMemories, T as deletePrivatePhoto, U as listPrivatePhotos, W as listRecentEvents, a as Onboarding, at as saveVacation, c as PhotoSourceButtons, ct as sendMessage, d as Select, ft as stageFiles, h as addPrivatePhoto, i as NeedinessField, k as getBondSync, mt as tickCompanion, n as Lightbox, o as PendingMediaTray, st as sendCompanionMessage, v as clearCompanionMessages, vt as useCurrentUser, x as deleteAccount, yt as useCurrentUserState, z as listCompanionMessages } from "./use-current-user-nzqgiI2T.mjs";
import { n as src_default } from "../_libs/tiptap__extension-underline.mjs";
import { t as src_default$1 } from "../_libs/@tiptap/extension-placeholder+[...].mjs";
import { t as src_default$2 } from "../_libs/tiptap__starter-kit.mjs";
import { n as FontSize, r as TextStyle, t as FontFamily } from "../_libs/tiptap__extension-text-style.mjs";
import { t as src_default$3 } from "../_libs/tiptap__extension-task-list.mjs";
import { t as src_default$4 } from "../_libs/tiptap__extension-task-item.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-CRftROn_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom());
function TagPickField({ label, hint = "Pick as many as you want. Add ones that are not on the list.", catalog, value, onChange, addPlaceholder = "Add one" }) {
	const [draft, setDraft] = (0, import_react.useState)("");
	new Set(catalog.map((item) => item.value));
	const room = Math.max(0, 50 - value.length);
	function toggle(slug) {
		if (value.includes(slug)) onChange(value.filter((item) => item !== slug));
		else if (room > 0) onChange([...value, slug]);
	}
	function addCustom() {
		const next = matchKnownTag(draft, catalog);
		setDraft("");
		if (!next) return;
		if (value.some((item) => item.toLowerCase() === next.toLowerCase())) return;
		if (room <= 0) return;
		onChange([...value, next]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [value.length, " chosen"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: hint
			}),
			value.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground",
					children: "Chosen — tap × to remove"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: value.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-pressed": true,
						onClick: () => toggle(item),
						className: "inline-flex h-9 items-center gap-1 rounded-full bg-primary px-3 text-xs text-primary-foreground",
						children: [tagLabel(item, catalog), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })]
					}, item))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: catalog.map((item) => {
					const on = value.includes(item.value);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": on,
						onClick: () => toggle(item.value),
						className: cn("h-9 rounded-full px-3 text-xs", on ? "bg-primary/20 text-foreground" : "bg-secondary text-muted-foreground"),
						children: item.label
					}, item.value);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					addCustom();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: draft,
					onChange: (event) => setDraft(event.target.value.slice(0, 48)),
					placeholder: addPlaceholder,
					maxLength: 48,
					disabled: room <= 0
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "submit",
					variant: "outline",
					className: "shrink-0",
					disabled: room <= 0 || !draft.trim(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add"]
				})]
			})
		]
	});
}
function KinkField({ role, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagPickField, {
		label: "Kinks",
		hint: "These follow your role. Pick as many as you want. Add your own. Remove any from Chosen.",
		catalog: kinksFor(role),
		value,
		onChange,
		addPlaceholder: "Add a kink"
	});
}
function KinkList({ values, role }) {
	if (!values.length) return null;
	const catalog = role ? kinksFor(role) : ALL_KINK_OPTIONS;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-[0.14em] text-muted-foreground",
			children: "Kinks"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 flex flex-wrap gap-1.5",
			children: values.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full bg-secondary px-3 py-1 text-xs text-foreground",
				children: tagLabel(item, catalog)
			}, item))
		})]
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-28 w-full rounded-lg border border-input bg-secondary px-3 py-2.5 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring/60 disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
function useAutoSave(signature, save, options) {
	const delay = options?.delay ?? 500;
	const enabled = options?.enabled ?? true;
	const resetKey = options?.resetKey;
	const skip = (0, import_react.useRef)(true);
	const saveRef = (0, import_react.useRef)(save);
	saveRef.current = save;
	const gen = (0, import_react.useRef)(0);
	const [status, setStatus] = (0, import_react.useState)("saved");
	(0, import_react.useEffect)(() => {
		skip.current = true;
	}, [resetKey]);
	(0, import_react.useEffect)(() => {
		if (skip.current) {
			skip.current = false;
			return;
		}
		if (!enabled) return;
		const id = ++gen.current;
		const timer = window.setTimeout(() => {
			setStatus("saving");
			saveRef.current().then(() => {
				if (gen.current === id) setStatus("saved");
			}).catch((err) => {
				if (gen.current === id) setStatus("error");
				toast.error(err instanceof Error ? err.message : "Could not save.");
			});
		}, delay);
		return () => window.clearTimeout(timer);
	}, [
		signature,
		delay,
		enabled
	]);
	return status;
}
function SaveHint({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs text-muted-foreground",
		children: status === "saving" ? "Saving…" : status === "error" ? "Could not save." : "Saved."
	});
}
var EVENT$1 = "sanctum:me";
function broadcastMe(me) {
	if (typeof window === "undefined") return;
	window.dispatchEvent(new CustomEvent(EVENT$1, { detail: me }));
}
function subscribeMe(cb) {
	if (typeof window === "undefined") return () => {};
	const handler = (event) => {
		const next = event.detail;
		if (next) cb(next);
	};
	window.addEventListener(EVENT$1, handler);
	return () => window.removeEventListener(EVENT$1, handler);
}
function eventNotice(event, actorName) {
	const who = actorName.trim() || "Your partner";
	const subject = event.title.trim();
	const entity = event.entity.replace(/_/g, " ");
	switch (event.action) {
		case "message": return {
			title: `${who} sent a message`,
			body: subject || "Open Messages to read it."
		};
		case "photo": return {
			title: `${who} sent a photo`,
			body: subject || "A still from the album."
		};
		case "video": return {
			title: `${who} sent a video`,
			body: subject || "Open Messages to watch it."
		};
		case "voice": return {
			title: `${who} sent a voice note`,
			body: subject || "Open Messages to listen."
		};
		case "completed": return {
			title: `${who} completed a ${entity || "item"}`,
			body: subject || "Marked done."
		};
		case "created": return {
			title: `${who} added a ${entity || "entry"}`,
			body: subject || "Something new is on the page."
		};
		case "updated": return {
			title: `${who} changed a ${entity || "entry"}`,
			body: subject || event.detail || "An update in Sanctum."
		};
		case "deleted": return {
			title: `${who} removed a ${entity || "entry"}`,
			body: subject || "It is gone."
		};
		case "bought": return {
			title: `${who} bought ${subject || "an item"}`,
			body: event.detail || "Paid with points."
		};
		case "talk": return {
			title: `${who} answered in Talk`,
			body: subject || "A prompt, quiz, or weekly card."
		};
		case "journal": return {
			title: `${who} shared a journal page`,
			body: subject || "Open Journal to read it."
		};
		case "points": return {
			title: `${who} moved points`,
			body: event.detail || subject || "The ledger changed."
		};
		case "permissions": return {
			title: `${who} changed permissions`,
			body: event.detail || "Check Settings."
		};
		case "reopened": return {
			title: `${who} reopened a ${entity || "item"}`,
			body: subject
		};
		default:
			if (!entity && !subject) return null;
			return {
				title: `${who} updated Sanctum`,
				body: [
					entity,
					subject,
					event.detail
				].filter(Boolean).join(" · ")
			};
	}
}
function requestAlertPermission() {
	if (typeof window === "undefined" || !("Notification" in window)) return;
	if (Notification.permission === "default") Notification.requestPermission();
}
function showAlert(title, body) {
	if (typeof window === "undefined") return;
	toast.message(title, { description: body });
	if ("Notification" in window && Notification.permission === "granted") try {
		new Notification(title, {
			body,
			tag: `sanctum-${title}`
		});
	} catch {}
}
var SEEN_KEY = "sanctum-notify-seen";
function loadSeenEventId() {
	if (typeof window === "undefined") return 0;
	const n = Number(window.localStorage.getItem(SEEN_KEY) ?? "0");
	return Number.isFinite(n) ? n : 0;
}
function storeSeenEventId(id) {
	if (typeof window === "undefined") return;
	window.localStorage.setItem(SEEN_KEY, String(id));
}
var EVENT = "sanctum:live";
var VISIBLE_MS$1 = 800;
var HIDDEN_MS$1 = 5e3;
function subscribeLive(cb) {
	if (typeof window === "undefined") return () => {};
	const handler = () => cb();
	window.addEventListener(EVENT, handler);
	return () => window.removeEventListener(EVENT, handler);
}
function useLiveReload(load) {
	(0, import_react.useEffect)(() => {
		return subscribeLive(() => {
			Promise.resolve(load()).catch(() => {});
		});
	}, [load]);
}
function emitLive() {
	if (typeof window === "undefined") return;
	window.dispatchEvent(new Event(EVENT));
}
async function flushPartnerNotices() {
	try {
		const [events, me] = await Promise.all([listRecentEvents(), getMe()]);
		if (!events.length) return;
		const seen = loadSeenEventId();
		const fresh = events.filter((item) => item.id > seen).sort((a, b) => a.id - b.id);
		if (!fresh.length) {
			storeSeenEventId(Math.max(seen, events[0]?.id ?? 0));
			return;
		}
		const partnerName = me.partner?.displayName || "Your partner";
		for (const event of fresh) {
			const notice = eventNotice(event, partnerName);
			if (!notice) continue;
			showAlert(notice.title, notice.body);
		}
		storeSeenEventId(fresh[fresh.length - 1].id);
	} catch {}
}
function startLiveSync() {
	if (typeof window === "undefined") return () => {};
	let stopped = false;
	let revision = null;
	let timer = null;
	let inFlight = false;
	let primed = false;
	async function tick() {
		if (stopped || inFlight) {
			if (!stopped && !inFlight) schedule();
			return;
		}
		inFlight = true;
		try {
			const snap = await getBondSync();
			if (stopped) return;
			if (revision != null && snap.revision !== revision) {
				emitLive();
				try {
					broadcastMe(await getMe());
				} catch {}
				if (primed) flushPartnerNotices();
			}
			revision = snap.revision;
			if (!primed) {
				primed = true;
				try {
					const maxId = (await listRecentEvents())[0]?.id ?? 0;
					if (loadSeenEventId() === 0) storeSeenEventId(maxId);
				} catch {}
			}
		} catch {} finally {
			inFlight = false;
			schedule();
		}
	}
	function schedule() {
		if (stopped) return;
		if (timer) window.clearTimeout(timer);
		const ms = document.visibilityState === "visible" ? VISIBLE_MS$1 : HIDDEN_MS$1;
		timer = window.setTimeout(() => void tick(), ms);
	}
	function kick() {
		if (timer) window.clearTimeout(timer);
		tick();
	}
	document.addEventListener("visibilitychange", kick);
	window.addEventListener("focus", kick);
	requestAlertPermission();
	tick();
	return () => {
		stopped = true;
		if (timer) window.clearTimeout(timer);
		document.removeEventListener("visibilitychange", kick);
		window.removeEventListener("focus", kick);
	};
}
function CompanionPanel({ me, open }) {
	const [tab, setTab] = (0, import_react.useState)("chat");
	const [profile, setProfile] = (0, import_react.useState)(DEFAULT_COMPANION);
	const [memories, setMemories] = (0, import_react.useState)([]);
	const loadMemories = (0, import_react.useCallback)(async () => {
		try {
			setMemories(await listCompanionMemories());
		} catch {
			setMemories([]);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		getCompanion().then(setProfile).catch((err) => {
			toast.error(err instanceof Error ? err.message : "Could not open the companion.");
		});
		loadMemories();
	}, [
		open,
		tab,
		loadMemories
	]);
	useLiveReload(loadMemories);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-x-0 top-14 z-40 mx-auto w-[min(100%,28rem)] px-3 sm:right-4 sm:left-auto sm:mx-0 sm:w-[26rem] sm:px-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-hidden rounded-xl border border-border bg-popover shadow-soft",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 border-b border-border p-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTab("chat"),
						className: cn("h-10 rounded-lg text-sm", tab === "chat" ? "bg-secondary text-foreground" : "text-muted-foreground"),
						children: "Companion"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTab("shape"),
						className: cn("h-10 rounded-lg text-sm", tab === "shape" ? "bg-secondary text-foreground" : "text-muted-foreground"),
						children: "Shape"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: tab === "chat" ? "block" : "hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanionChat, {
						me,
						profile,
						onShape: () => setTab("shape")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: tab === "shape" ? "block" : "hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanionShape, {
						profile,
						memories,
						onSaved: setProfile,
						onMemories: setMemories
					})
				})
			]
		})
	});
}
function CompanionChat({ me, profile, onShape }) {
	const [messages, setMessages] = (0, import_react.useState)([]);
	const [text, setText] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [writing, setWriting] = (0, import_react.useState)(false);
	const [queue, setQueue] = (0, import_react.useState)([]);
	const scroller = (0, import_react.useRef)(null);
	const knownIds = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const queueRef = (0, import_react.useRef)([]);
	const busyRef = (0, import_react.useRef)(false);
	const countRef = (0, import_react.useRef)(0);
	queueRef.current = queue;
	busyRef.current = busy;
	countRef.current = messages.length;
	function flushQueue() {
		const waiting = queueRef.current;
		if (!waiting.length) return;
		setQueue([]);
		setWriting(false);
		setMessages((prev) => {
			const have = new Set(prev.map((item) => item.id));
			return [...prev, ...waiting.filter((item) => !have.has(item.id))];
		});
	}
	function ingest(rows, drip) {
		const fresh = rows.filter((item) => item.id > 0 && !knownIds.current.has(item.id));
		if (!fresh.length) return;
		for (const item of fresh) knownIds.current.add(item.id);
		if (!drip) {
			setMessages(rows);
			setQueue([]);
			setWriting(false);
			return;
		}
		const users = fresh.filter((item) => item.role === "user");
		const assistants = fresh.filter((item) => item.role === "assistant");
		if (users.length) setMessages((prev) => {
			const have = new Set(prev.map((item) => item.id));
			return [...prev.filter((item) => item.id > 0 || item.role !== "user"), ...users.filter((item) => !have.has(item.id))];
		});
		if (assistants.length) setQueue((prev) => [...prev, ...assistants]);
	}
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		listCompanionMessages().then((rows) => {
			if (cancelled) return;
			const thread = rows;
			knownIds.current = new Set(thread.filter((item) => item.id > 0).map((item) => item.id));
			setMessages(thread);
			if (!thread.some((item) => item.role === "assistant")) {
				setWriting(true);
				tickCompanion().then((result) => {
					if (cancelled) return;
					const rows = result.messages ?? [];
					ingest(rows, true);
					if (!rows.length) setWriting(false);
				}).catch(() => {
					if (!cancelled) setWriting(false);
				});
			}
		}).catch((err) => {
			toast.error(err instanceof Error ? err.message : "Could not open the companion.");
		});
		return () => {
			cancelled = true;
		};
	}, []);
	useLiveReload(async () => {
		if (busyRef.current) return;
		ingest(await listCompanionMessages(), true);
	});
	(0, import_react.useEffect)(() => {
		if (!queue.length) {
			setWriting(false);
			return;
		}
		setWriting(true);
		const next = queue[0];
		const wait = companionRevealDelay(next.body, countRef.current === 0 ? 0 : 1);
		const timer = window.setTimeout(() => {
			setMessages((prev) => prev.some((item) => item.id === next.id) ? prev : [...prev, next]);
			setQueue((prev) => prev.slice(1));
		}, wait);
		return () => window.clearTimeout(timer);
	}, [queue]);
	(0, import_react.useEffect)(() => {
		scroller.current?.scrollTo({ top: scroller.current.scrollHeight });
	}, [
		messages.length,
		busy,
		pending.length,
		writing,
		queue.length
	]);
	async function onPick(files) {
		if (!files?.length) return;
		try {
			const staged = await stageFiles(files, {
				allowImage: true,
				allowVideo: true,
				max: 1
			});
			if (!staged.length) {
				toast.error("Choose a photo or video from your gallery.");
				return;
			}
			setPending(staged.slice(0, 1));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not attach that file.");
		}
	}
	async function send() {
		const body = text.trim();
		const media = pending[0] ?? null;
		if (!body && !media || busy) return;
		flushQueue();
		setText("");
		setPending([]);
		setBusy(true);
		const optimistic = {
			id: -Date.now(),
			role: "user",
			body,
			photoData: media?.data ?? null,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		setMessages((prev) => [...prev, optimistic]);
		try {
			const result = await sendCompanionMessage({ data: {
				body,
				photoData: media?.data ?? null
			} });
			knownIds.current.add(result.user.id);
			for (const item of result.messages ?? []) knownIds.current.add(item.id);
			setMessages((prev) => {
				const without = prev.filter((item) => item.id !== optimistic.id && item.id > 0);
				if (without.some((item) => item.id === result.user.id)) return without;
				return [...without, result.user];
			});
			const incoming = (result.messages ?? []).filter((item) => !queueRef.current.some((q) => q.id === item.id));
			if (incoming.length) setQueue((prev) => [...prev, ...incoming.filter((item) => !prev.some((q) => q.id === item.id))]);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "They could not answer.");
		} finally {
			setBusy(false);
		}
	}
	async function wipe() {
		flushQueue();
		knownIds.current.clear();
		try {
			await clearCompanionMessages();
			setMessages([]);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not clear.");
		}
	}
	const name = profile.name || DEFAULT_COMPANION.name;
	const heat = COMPANION_HEAT.find((item) => item.value === profile.heat)?.label;
	const face = companionPortrait(profile);
	const empty = messages.length === 0 && !writing && !busy && !queue.length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-[min(68dvh,34rem)] min-h-0 flex-col overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex shrink-0 items-center gap-3 border-b border-border px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-10 shrink-0 place-items-center overflow-hidden rounded-full border border-border bg-secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: face,
							alt: "",
							className: "size-full object-cover"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-medium",
							children: name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
							children: [
								profile.role,
								profile.gender,
								heat
							].filter(Boolean).join(" · ") || "Unshaped"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-xs text-muted-foreground",
						onClick: onShape,
						children: "Shape"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: scroller,
				className: "min-h-0 flex-1 space-y-3 overflow-y-auto px-3 py-3",
				children: [empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-2 py-8 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto mb-4 size-20 overflow-hidden rounded-full border border-border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: face,
								alt: "",
								className: "size-full object-cover"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl",
							children: name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: "Private. Adult. They write when they want — you do not have to answer every text."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs text-muted-foreground",
							children: [
								"Hello ",
								me.profile?.displayName || "",
								"."
							]
						})
					]
				}) : messages.map((message) => {
					const mine = message.role === "user";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("flex", mine ? "justify-end" : "justify-start"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cn("max-w-[88%] rounded-lg px-3 py-2 text-sm whitespace-pre-wrap", mine ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"),
							children: [
								message.photoData ? isVideoDataUrl(message.photoData) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
									src: message.photoData,
									controls: true,
									playsInline: true,
									className: "mb-2 max-h-48 w-full rounded-md"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: message.photoData,
									alt: "",
									className: "mb-2 max-h-48 rounded-md object-cover"
								}) : null,
								message.body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: message.body }) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: cn("mt-1 text-[10px]", mine ? "text-primary-foreground/70" : "text-muted-foreground"),
									children: formatWhen(message.createdAt)
								})
							]
						})
					}, message.id);
				}), busy || writing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					"data-companion-writing": "1",
					className: "text-xs uppercase tracking-[0.14em] text-muted-foreground",
					children: [name, " is writing…"]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shrink-0 space-y-2 border-t border-border p-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendingMediaTray, {
						items: pending,
						onRemove: () => setPending([]),
						onCommit: () => void send(),
						onDiscard: () => setPending([]),
						commitLabel: "Send",
						busy
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoSourceButtons, {
						onFiles: onPick,
						busy,
						galleryLabel: "Gallery",
						cameraLabel: "Camera",
						accept: MEDIA_ACCEPT
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex items-center gap-2",
						onSubmit: (e) => {
							e.preventDefault();
							send();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: text,
							onChange: (e) => setText(e.target.value),
							placeholder: `Write to ${name}…`,
							className: "h-11",
							maxLength: 4e3,
							disabled: busy
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							disabled: busy || !text.trim() && !pending.length,
							"aria-label": "Send",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {}), "Send"]
						})]
					}),
					messages.length || queue.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "px-1 text-[11px] text-muted-foreground",
						onClick: () => void wipe(),
						children: "Clear thread"
					}) : null
				]
			})
		]
	});
}
function CompanionShape({ profile, memories, onSaved, onMemories }) {
	const [draft, setDraft] = (0, import_react.useState)(profile);
	const [ageText, setAgeText] = (0, import_react.useState)(() => String(clampCompanionAge(profile.age)));
	const [ageFocused, setAgeFocused] = (0, import_react.useState)(false);
	const [painting, setPainting] = (0, import_react.useState)(false);
	const [pendingFace, setPendingFace] = (0, import_react.useState)([]);
	const dirty = (0, import_react.useRef)(false);
	const ageId = (0, import_react.useId)();
	const draftRef = (0, import_react.useRef)(draft);
	const ageTextRef = (0, import_react.useRef)(ageText);
	draftRef.current = draft;
	ageTextRef.current = ageText;
	(0, import_react.useEffect)(() => {
		if (dirty.current || ageFocused) return;
		setDraft(profile);
		setAgeText(String(clampCompanionAge(profile.age)));
	}, [profile, ageFocused]);
	(0, import_react.useEffect)(() => {
		return () => {
			if (!dirty.current) return;
			const current = draftRef.current;
			const typed = Number.parseInt(ageTextRef.current.replace(/\D/g, ""), 10);
			const age = Number.isFinite(typed) && typed >= 21 && typed <= 99 ? typed : clampCompanionAge(current.age);
			saveCompanion({ data: {
				name: current.name,
				gender: current.gender,
				pronouns: current.pronouns,
				age,
				role: current.role,
				dynamic: current.dynamic,
				addressAs: current.addressAs,
				voice: current.voice,
				persona: current.persona,
				appearance: current.appearance,
				kinks: current.kinks,
				limits: current.limits,
				heat: current.heat,
				extra: current.extra,
				avatarData: current.avatarData,
				neediness: current.neediness
			} });
		};
	}, []);
	function touchDraft(update) {
		dirty.current = true;
		setDraft(update);
	}
	function applyAge(next) {
		const age = clampCompanionAge(next);
		setAgeText(String(age));
		touchDraft((p) => p.age === age ? p : {
			...p,
			age
		});
	}
	function onAgeChange(raw) {
		const digits = raw.replace(/\D/g, "").slice(0, 2);
		setAgeText(digits);
		dirty.current = true;
		if (digits.length !== 2) return;
		const parsed = Number.parseInt(digits, 10);
		if (Number.isFinite(parsed) && parsed >= 21 && parsed <= 99) touchDraft((p) => p.age === parsed ? p : {
			...p,
			age: parsed
		});
	}
	function onAgeBlur() {
		setAgeFocused(false);
		const digits = ageTextRef.current.replace(/\D/g, "");
		if (!digits) {
			setAgeText(String(draftRef.current.age));
			return;
		}
		applyAge(Number.parseInt(digits, 10));
	}
	function bumpAge(delta) {
		const parsed = Number.parseInt(ageTextRef.current, 10);
		applyAge((Number.isFinite(parsed) ? parsed : draftRef.current.age) + delta);
	}
	const saveStatus = useAutoSave(JSON.stringify({
		name: draft.name,
		gender: draft.gender,
		pronouns: draft.pronouns,
		age: draft.age,
		role: draft.role,
		dynamic: draft.dynamic,
		addressAs: draft.addressAs,
		voice: draft.voice,
		persona: draft.persona,
		appearance: draft.appearance,
		kinks: draft.kinks,
		limits: draft.limits,
		heat: draft.heat,
		extra: draft.extra,
		neediness: draft.neediness,
		avatarData: draft.avatarData ? `${draft.avatarData.length}:${draft.avatarData.slice(-32)}` : ""
	}), async () => {
		const current = draftRef.current;
		const typed = Number.parseInt(ageTextRef.current.replace(/\D/g, ""), 10);
		const age = Number.isFinite(typed) && typed >= 21 && typed <= 99 ? typed : clampCompanionAge(current.age);
		const saved = await saveCompanion({ data: {
			name: current.name,
			gender: current.gender,
			pronouns: current.pronouns,
			age,
			role: current.role,
			dynamic: current.dynamic,
			addressAs: current.addressAs,
			voice: current.voice,
			persona: current.persona,
			appearance: current.appearance,
			kinks: current.kinks,
			limits: current.limits,
			heat: current.heat,
			extra: current.extra,
			avatarData: current.avatarData,
			neediness: current.neediness
		} });
		if (saved.age !== current.age) {
			setDraft((prev) => ({
				...prev,
				age: saved.age
			}));
			if (!ageFocused) setAgeText(String(saved.age));
		}
		onSaved(saved);
	}, {
		delay: 500,
		enabled: !painting
	});
	async function paintPortrait() {
		const look = draft.appearance.trim();
		if (look.length < 8) {
			toast.error("Write how they look first.");
			return;
		}
		if (painting) return;
		setPainting(true);
		try {
			const saved = await generateCompanionPortrait({ data: {
				appearance: look,
				name: draft.name,
				gender: draft.gender,
				pronouns: draft.pronouns,
				age: clampCompanionAge(draft.age)
			} });
			dirty.current = true;
			setDraft((prev) => ({
				...prev,
				avatarData: saved.avatarData,
				appearance: saved.appearance
			}));
			onSaved({
				...draft,
				avatarData: saved.avatarData,
				appearance: saved.appearance
			});
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not make that portrait.");
		} finally {
			setPainting(false);
		}
	}
	const face = pendingFace[0]?.data || companionPortrait(draft);
	const roleKind = companionRoleKind(draft.role);
	const traitCatalog = traitsFor(roleKind);
	const kinkCatalog = kinksFor(roleKind);
	const personaBag = parseTagBag(draft.persona, ALL_TRAIT_OPTIONS);
	const kinkTags = parseTagList(draft.kinks, ALL_KINK_OPTIONS);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-h-[min(68dvh,34rem)] space-y-5 overflow-y-auto p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Entirely yours. Name them, write the face, make the image. They keep what you tell them. They only write onto your pages when they are your live partner."
			}),
			memories.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
					children: "What they know"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-1.5",
					children: memories.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-2 rounded-lg bg-secondary px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground",
									children: item.kind
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm",
									children: item.body
								}),
								item.dueAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: formatWhen(item.dueAt)
								}) : null
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-0.5 text-muted-foreground hover:text-destructive",
							"aria-label": "Forget this",
							onClick: () => {
								dropCompanionMemory({ data: { id: item.id } }).then(() => onMemories(memories.filter((row) => row.id !== item.id))).catch((err) => toast.error(err instanceof Error ? err.message : "Could not forget that."));
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}, item.id))
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "They will keep facts, kinks, hobbies, and appointments you tell them in chat."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
						children: "Who they are"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.name,
							onChange: (e) => touchDraft((p) => ({
								...p,
								name: e.target.value
							})),
							maxLength: 80
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "block space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: ageId,
								children: "Age"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "outline",
										size: "icon",
										className: "shrink-0",
										"aria-label": "Decrease age",
										onClick: () => bumpAge(-1),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: ageId,
										type: "text",
										inputMode: "numeric",
										autoComplete: "off",
										autoCorrect: "off",
										spellCheck: false,
										maxLength: 2,
										value: ageText,
										placeholder: "21–99",
										className: "min-w-0 flex-1 text-center tabular-nums",
										onFocus: () => setAgeFocused(true),
										onChange: (e) => onAgeChange(e.target.value),
										onBlur: onAgeBlur
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "outline",
										size: "icon",
										className: "shrink-0",
										"aria-label": "Increase age",
										onClick: () => bumpAge(1),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Adult characters only, 21–99. Saved on its own."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Pronouns" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.pronouns,
							onChange: (e) => touchDraft((p) => ({
								...p,
								pronouns: e.target.value
							})),
							placeholder: "she/her"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						values: [
							"she/her",
							"he/him",
							"they/them"
						],
						current: draft.pronouns,
						onPick: (pronouns) => touchDraft((p) => ({
							...p,
							pronouns
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Gender" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.gender,
							onChange: (e) => touchDraft((p) => ({
								...p,
								gender: e.target.value
							})),
							placeholder: "Feminine, masculine, your words"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						values: [
							"feminine",
							"masculine",
							"androgynous"
						],
						current: draft.gender,
						onPick: (gender) => touchDraft((p) => ({
							...p,
							gender
						}))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
						children: "Look"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative overflow-hidden rounded-xl border border-border bg-secondary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: face,
							alt: draft.name || "Companion",
							className: "aspect-square w-full object-cover"
						}), painting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-0 grid place-items-center bg-background/70",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
								children: "Creating their face…"
							})
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "How they look" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							className: "min-h-28",
							value: draft.appearance,
							onChange: (e) => touchDraft((p) => ({
								...p,
								appearance: e.target.value
							})),
							placeholder: "Face, hair, body, clothes, marks — all adults. This is what we paint.",
							maxLength: 4e3,
							disabled: painting
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [draft.appearance.trim().length, "/4000 · Write the person, then create the portrait. You can still use a photo instead."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "w-full",
						onClick: () => void paintPortrait(),
						disabled: painting || draft.appearance.trim().length < 8,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }), painting ? "Creating…" : draft.avatarData ? "Create a new portrait" : "Create portrait"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoSourceButtons, {
						onFiles: async (files) => {
							try {
								const staged = await stageFiles(files, {
									allowImage: true,
									max: 1
								});
								if (!staged.length) {
									toast.error("Choose a JPEG or PNG from your gallery.");
									return;
								}
								setPendingFace(staged.slice(0, 1));
							} catch (err) {
								toast.error(err instanceof Error ? err.message : "Could not read that photo.");
							}
						},
						busy: painting,
						galleryLabel: "Use a photo",
						cameraLabel: "Camera"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendingMediaTray, {
						items: pendingFace,
						onRemove: () => setPendingFace([]),
						onCommit: () => {
							const nextFace = pendingFace[0];
							if (!nextFace) return;
							touchDraft((p) => ({
								...p,
								avatarData: nextFace.data
							}));
							setPendingFace([]);
						},
						onDiscard: () => setPendingFace([]),
						commitLabel: "Send",
						busy: painting
					}),
					draft.avatarData ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-xs text-muted-foreground",
						onClick: () => touchDraft((p) => ({
							...p,
							avatarData: null
						})),
						children: "Remove portrait"
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
						children: "Dynamic"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Role" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.role,
							onChange: (e) => touchDraft((p) => ({
								...p,
								role: e.target.value
							})),
							placeholder: "Dominant, pet, your word"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						values: [
							"dominant",
							"submissive",
							"switch",
							"service",
							"brat",
							"caretaker",
							"owner",
							"pet"
						],
						current: draft.role,
						onPick: (role) => touchDraft((p) => ({
							...p,
							role
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "They are to you" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.dynamic,
							onChange: (e) => touchDraft((p) => ({
								...p,
								dynamic: e.target.value
							})),
							placeholder: "Private companion, owner, pet…"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						values: [
							"private companion",
							"owner",
							"pet",
							"partner",
							"mistress",
							"servant"
						],
						current: draft.dynamic,
						onPick: (dynamic) => touchDraft((p) => ({
							...p,
							dynamic
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "They address you as" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.addressAs,
							onChange: (e) => touchDraft((p) => ({
								...p,
								addressAs: e.target.value
							})),
							placeholder: "Sir, girl, by your name…"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
					children: "Heat"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-5 gap-1",
					children: COMPANION_HEAT.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => touchDraft((p) => ({
							...p,
							heat: item.value
						})),
						className: cn("h-11 rounded-lg text-[11px]", draft.heat === item.value ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
						children: item.label
					}, item.value))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "space-y-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedinessField, {
					value: draft.neediness,
					onChange: (neediness) => touchDraft((p) => ({
						...p,
						neediness
					}))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
						children: "Voice and mind"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Voice" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							className: "min-h-20",
							value: draft.voice,
							onChange: (e) => touchDraft((p) => ({
								...p,
								voice: e.target.value
							})),
							placeholder: "How they sound on the page"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagPickField, {
						label: "Personality",
						hint: "These follow their role. Pick several. Add your own. Remove any from Chosen.",
						catalog: traitCatalog,
						value: personaBag.tags,
						onChange: (tags) => touchDraft((p) => ({
							...p,
							persona: encodeTagBag({
								tags,
								notes: parseTagBag(p.persona, ALL_TRAIT_OPTIONS).notes
							}, ALL_TRAIT_OPTIONS)
						})),
						addPlaceholder: "Add a trait"
					}),
					personaBag.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "More about them" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							className: "min-h-20",
							value: personaBag.notes,
							onChange: (e) => touchDraft((p) => ({
								...p,
								persona: encodeTagBag({
									tags: parseTagBag(p.persona, ALL_TRAIT_OPTIONS).tags,
									notes: e.target.value
								}, ALL_TRAIT_OPTIONS)
							})),
							placeholder: "Anything else about how they are"
						})]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
						children: "Hunger and law"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagPickField, {
						label: "Kinks",
						hint: "These follow their role. Pick several. Add your own. Remove any from Chosen.",
						catalog: kinkCatalog,
						value: kinkTags,
						onChange: (kinks) => touchDraft((p) => ({
							...p,
							kinks: encodeTagList(kinks, ALL_KINK_OPTIONS)
						})),
						addPlaceholder: "Add a kink"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Limits" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							className: "min-h-20",
							value: draft.limits,
							onChange: (e) => touchDraft((p) => ({
								...p,
								limits: e.target.value
							})),
							placeholder: "What they will not do"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Anything else" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							className: "min-h-20",
							value: draft.extra,
							onChange: (e) => touchDraft((p) => ({
								...p,
								extra: e.target.value
							})),
							placeholder: "Freeform instructions they must follow"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveHint, { status: saveStatus })
		]
	});
}
function Chips({ values, current, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-1",
		children: values.map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onPick(value),
			className: cn("h-8 rounded-full px-3 text-xs capitalize", current === value ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
			children: value
		}, value))
	});
}
function AppOpenBeacon() {
	(0, import_react.useEffect)(() => {
		recordAppOpen().catch(() => void 0);
		function onVisible() {
			if (document.visibilityState === "visible") recordAppOpen().catch(() => void 0);
		}
		document.addEventListener("visibilitychange", onVisible);
		window.addEventListener("focus", onVisible);
		return () => {
			document.removeEventListener("visibilitychange", onVisible);
			window.removeEventListener("focus", onVisible);
		};
	}, []);
	return null;
}
function LocationBeacon() {
	const watchRef = (0, import_react.useRef)(null);
	const lastSent = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		function stop() {
			if (watchRef.current != null && navigator.geolocation) {
				navigator.geolocation.clearWatch(watchRef.current);
				watchRef.current = null;
			}
		}
		async function start() {
			stop();
			try {
				const board = await getLocationBoard();
				if (cancelled || !board.mine.sharing || !navigator.geolocation) return;
				watchRef.current = navigator.geolocation.watchPosition((pos) => {
					const now = Date.now();
					if (now - lastSent.current < 12e3) return;
					lastSent.current = now;
					pingLocation({ data: {
						lat: pos.coords.latitude,
						lng: pos.coords.longitude,
						accuracy: Number.isFinite(pos.coords.accuracy) ? pos.coords.accuracy : null
					} }).catch(() => void 0);
				}, () => void 0, {
					enableHighAccuracy: true,
					maximumAge: 8e3,
					timeout: 2e4
				});
			} catch {}
		}
		start();
		const onChange = () => {
			lastSent.current = 0;
			start();
		};
		window.addEventListener(LOCATION_EVENT, onChange);
		return () => {
			cancelled = true;
			window.removeEventListener(LOCATION_EVENT, onChange);
			stop();
		};
	}, []);
	return null;
}
var ALLOWED_TAGS = /* @__PURE__ */ new Set([
	"P",
	"BR",
	"STRONG",
	"B",
	"EM",
	"I",
	"U",
	"S",
	"STRIKE",
	"UL",
	"OL",
	"LI",
	"SPAN",
	"DIV",
	"H1",
	"H2",
	"H3",
	"BLOCKQUOTE",
	"LABEL",
	"INPUT"
]);
var ALLOWED_ATTR = /* @__PURE__ */ new Set([
	"style",
	"class",
	"data-type",
	"data-checked",
	"type",
	"checked",
	"disabled"
]);
var STYLE_OK = /^(font-family|font-size|font-weight|font-style|text-decoration)\s*:/i;
function looksLikeHtml(value) {
	return /<\/?(p|br|strong|b|em|i|u|ul|ol|li|span|div|h[1-3]|blockquote)\b/i.test(value);
}
function escapeText(value) {
	return value.replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">");
}
function toEditorHtml(value) {
	if (!value.trim()) return "";
	if (looksLikeHtml(value)) return value;
	return value.split(/\n{2,}/).map((block) => `<p>${escapeText(block).replace(/\n/g, "<br>")}</p>`).join("");
}
function cleanStyle(style) {
	return style.split(";").map((part) => part.trim()).filter((part) => part && STYLE_OK.test(part) && !/expression|url\s*\(/i.test(part)).join("; ");
}
function stripScripts(html) {
	return html.replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?>[\s\S]*?<\/style>/gi, "").replace(/\son\w+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, "").replace(/javascript:/gi, "");
}
function sanitizeNode(node) {
	const children = Array.from(node.childNodes);
	for (const child of children) {
		if (child.nodeType === 8) {
			child.parentNode?.removeChild(child);
			continue;
		}
		if (child.nodeType !== 1) continue;
		const el = child;
		if (!ALLOWED_TAGS.has(el.tagName)) {
			const text = el.textContent ?? "";
			const textNode = el.ownerDocument.createTextNode(text);
			el.replaceWith(textNode);
			continue;
		}
		for (const attr of Array.from(el.attributes)) {
			const name = attr.name.toLowerCase();
			if (!ALLOWED_ATTR.has(name) && !name.startsWith("data-")) {
				el.removeAttribute(attr.name);
				continue;
			}
			if (name === "style") {
				const cleaned = cleanStyle(attr.value);
				if (cleaned) el.setAttribute("style", cleaned);
				else el.removeAttribute("style");
			}
			if (name === "type" && attr.value.toLowerCase() !== "checkbox") el.removeAttribute("type");
		}
		if (el.tagName === "INPUT") el.setAttribute("type", "checkbox");
		sanitizeNode(el);
	}
}
function sanitizeRichHtml(html) {
	if (!html) return "";
	const stripped = stripScripts(html);
	if (typeof DOMParser === "undefined") return stripped;
	const doc = new DOMParser().parseFromString(stripped, "text/html");
	sanitizeNode(doc.body);
	return doc.body.innerHTML;
}
function toggleChecklistAt(html, index) {
	if (typeof DOMParser === "undefined") return html;
	const doc = new DOMParser().parseFromString(sanitizeRichHtml(html), "text/html");
	const box = Array.from(doc.querySelectorAll("ul[data-type=\"taskList\"] input[type=\"checkbox\"]"))[index];
	if (!box) return html;
	const li = box.closest("li");
	const next = box.getAttribute("checked") == null;
	if (next) box.setAttribute("checked", "");
	else box.removeAttribute("checked");
	if (li) li.setAttribute("data-checked", next ? "true" : "false");
	return doc.body.innerHTML;
}
var WRITE_FONTS = [
	{
		label: "Sans",
		value: "Outfit, ui-sans-serif, sans-serif"
	},
	{
		label: "Display",
		value: "\"Cormorant Garamond\", Georgia, serif"
	},
	{
		label: "Literata",
		value: "Literata, Georgia, serif"
	},
	{
		label: "Source Serif",
		value: "\"Source Serif 4\", Georgia, serif"
	},
	{
		label: "Plex",
		value: "\"IBM Plex Sans\", ui-sans-serif, sans-serif"
	}
];
var WRITE_SIZES = [
	{
		label: "Small",
		value: "0.85em"
	},
	{
		label: "Body",
		value: ""
	},
	{
		label: "Large",
		value: "1.25em"
	},
	{
		label: "Title",
		value: "1.55em"
	}
];
function extensions(placeholder) {
	return [
		src_default$2.configure({
			heading: { levels: [2, 3] },
			codeBlock: false,
			code: false
		}),
		TextStyle,
		FontFamily,
		FontSize,
		src_default,
		src_default$3,
		src_default$4.configure({ nested: true }),
		src_default$1.configure({ placeholder: placeholder || "Write…" })
	];
}
function RichEditor({ value, onChange, placeholder, compact = false }) {
	const editor = useEditor({
		immediatelyRender: false,
		shouldRerenderOnTransaction: true,
		extensions: extensions(placeholder),
		content: toEditorHtml(value),
		editorProps: { attributes: { class: cn("rich-text min-h-28 px-3 py-2.5 text-sm outline-none", compact && "min-h-20") } },
		onUpdate: ({ editor: instance }) => {
			onChange(instance.isEmpty ? "" : instance.getHTML());
		}
	});
	(0, import_react.useEffect)(() => {
		if (!editor) return;
		if (editor.isFocused) return;
		const next = toEditorHtml(value);
		if (next === (editor.isEmpty ? "" : editor.getHTML())) return;
		editor.commands.setContent(next || "", { emitUpdate: false });
	}, [value, editor]);
	if (!editor) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "min-h-28 rounded-lg border border-input bg-secondary" });
	const font = String(editor.getAttributes("textStyle").fontFamily ?? "");
	const size = String(editor.getAttributes("textStyle").fontSize ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-lg border border-input bg-secondary focus-within:ring-2 focus-within:ring-ring/60",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-1 border-b border-border px-2 py-1.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: font,
					onChange: (event) => {
						const next = event.target.value;
						if (!next) editor.chain().focus().unsetFontFamily().run();
						else editor.chain().focus().setFontFamily(next).run();
					},
					className: "h-9 w-[7.8rem] min-w-0 px-2 pr-8 text-xs",
					"aria-label": "Font",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Font"
					}), WRITE_FONTS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item.value,
						style: { fontFamily: item.value },
						children: item.label
					}, item.label))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					value: size,
					onChange: (event) => {
						const next = event.target.value;
						if (!next) editor.chain().focus().unsetFontSize().run();
						else editor.chain().focus().setFontSize(next).run();
					},
					className: "h-9 w-[5.6rem] min-w-0 px-2 pr-8 text-xs",
					"aria-label": "Size",
					children: WRITE_SIZES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: item.value,
						children: item.label
					}, item.label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkButton, {
					label: "Bold",
					active: editor.isActive("bold"),
					onClick: () => editor.chain().focus().toggleBold().run(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bold, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkButton, {
					label: "Italic",
					active: editor.isActive("italic"),
					onClick: () => editor.chain().focus().toggleItalic().run(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Italic, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkButton, {
					label: "Underline",
					active: editor.isActive("underline"),
					onClick: () => editor.chain().focus().toggleUnderline().run(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Underline, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkButton, {
					label: "Bullet list",
					active: editor.isActive("bulletList"),
					onClick: () => editor.chain().focus().toggleBulletList().run(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkButton, {
					label: "Checklist",
					active: editor.isActive("taskList"),
					onClick: () => editor.chain().focus().toggleTaskList().run(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListChecks, { className: "size-4" })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditorContent, { editor })]
	});
}
function MarkButton({ label, active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		"aria-pressed": active,
		onMouseDown: (event) => event.preventDefault(),
		onClick,
		className: cn("grid size-9 place-items-center rounded-md text-muted-foreground hover:bg-raised hover:text-foreground", active && "bg-primary/15 text-foreground"),
		children
	});
}
function RichText({ html, className, clamp, onChange }) {
	if (!html) return null;
	if (!looksLikeHtml(html)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("whitespace-pre-wrap text-sm text-muted-foreground", clamp && "line-clamp-4", className),
		children: html
	});
	function handleClick(event) {
		if (!onChange) return;
		const input = event.target?.closest("input[type='checkbox']");
		if (!input) return;
		event.preventDefault();
		const root = event.currentTarget;
		const index = Array.from(root.querySelectorAll("input[type='checkbox']")).indexOf(input);
		if (index < 0) return;
		onChange(toggleChecklistAt(html, index));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rich-text text-sm text-muted-foreground", clamp && "line-clamp-4", onChange && "rich-text-live", className),
		dangerouslySetInnerHTML: { __html: sanitizeRichHtml(html) },
		onClick: onChange ? handleClick : void 0
	});
}
function MessagesPanel({ me, open, tab, onTab }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-x-0 top-14 z-40 mx-auto w-[min(100%,28rem)] px-3 sm:right-4 sm:left-auto sm:mx-0 sm:w-[24rem] sm:px-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-hidden rounded-xl border border-border bg-popover shadow-soft",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 border-b border-border p-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onTab("messages"),
					className: cn("h-10 rounded-lg text-sm", tab === "messages" ? "bg-secondary text-foreground" : "text-muted-foreground"),
					children: "Messages"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onTab("photos"),
					className: cn("h-10 rounded-lg text-sm", tab === "photos" ? "bg-secondary text-foreground" : "text-muted-foreground"),
					children: "Photos"
				})]
			}), tab === "messages" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chat, { me }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Album, { me })]
		})
	});
}
function Chat({ me }) {
	const [messages, setMessages] = (0, import_react.useState)([]);
	const [text, setText] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [recording, setRecording] = (0, import_react.useState)(false);
	const scroller = (0, import_react.useRef)(null);
	const recorder = (0, import_react.useRef)(null);
	const chunks = (0, import_react.useRef)([]);
	const userId = me.profile?.userId;
	const load = (0, import_react.useCallback)(async () => {
		try {
			setMessages(await listMessages());
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		load();
	}, [load]);
	useLiveReload(load);
	(0, import_react.useEffect)(() => {
		scroller.current?.scrollTo({ top: scroller.current.scrollHeight });
	}, [messages.length]);
	async function send(photoData, audioData) {
		const body = text.trim();
		const photo = photoData ?? pending[0]?.data ?? null;
		if (!body && !photo && !audioData) return;
		setBusy(true);
		try {
			const message = await sendMessage({ data: {
				body,
				photoData: photo,
				audioData: audioData ?? null
			} });
			setMessages((prev) => [...prev, message]);
			setText("");
			setPending([]);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not send.");
		} finally {
			setBusy(false);
		}
	}
	async function onPhoto(files) {
		if (!files?.length) return;
		try {
			const staged = await stageFiles(files, {
				allowImage: true,
				allowVideo: true,
				max: 1
			});
			if (!staged.length) {
				toast.error("Choose a photo or video from your gallery.");
				return;
			}
			setPending(staged.slice(0, 1));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not attach that photo.");
		}
	}
	async function toggleRecord() {
		if (recording) {
			recorder.current?.stop();
			return;
		}
		try {
			const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
			const mime = MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "audio/mp4";
			const rec = new MediaRecorder(stream, { mimeType: mime });
			chunks.current = [];
			rec.ondataavailable = (event) => {
				if (event.data.size) chunks.current.push(event.data);
			};
			rec.onstop = () => {
				stream.getTracks().forEach((track) => track.stop());
				setRecording(false);
				const blob = new Blob(chunks.current, { type: rec.mimeType || "audio/webm" });
				if (blob.size > 14e5) {
					toast.error("Voice note is too long. Keep it under about a minute.");
					return;
				}
				const reader = new FileReader();
				reader.onload = () => {
					const data = String(reader.result ?? "");
					if (data.startsWith("data:")) send(null, data);
				};
				reader.readAsDataURL(blob);
			};
			recorder.current = rec;
			rec.start();
			setRecording(true);
		} catch {
			toast.error("Microphone access was denied.");
		}
	}
	if (!me.partner) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-5 py-10 text-center text-sm text-muted-foreground",
		children: "Connect a partner from Settings → Partner to send private messages."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-[min(62dvh,28rem)] min-h-0 flex-col overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: scroller,
			className: "min-h-0 flex-1 space-y-3 overflow-y-auto px-3 py-3",
			children: messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "py-8 text-center text-sm text-muted-foreground",
				children: [
					"Private between you and ",
					me.partner.displayName || "your partner",
					"."
				]
			}) : messages.map((message) => {
				const mine = message.senderId === userId;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("flex", mine ? "justify-end" : "justify-start"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("max-w-[85%] rounded-lg px-3 py-2 text-sm", mine ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"),
						children: [
							message.photoData ? isVideoDataUrl(message.photoData) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
								src: message.photoData,
								controls: true,
								playsInline: true,
								className: "mb-2 max-h-48 w-full rounded-md"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: message.photoData,
								alt: "",
								className: "mb-2 max-h-48 rounded-md object-cover"
							}) : null,
							message.audioData ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
								src: message.audioData,
								controls: true,
								className: "mb-2 w-full"
							}) : null,
							message.body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, {
								html: message.body,
								className: mine ? "text-primary-foreground" : "text-foreground"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: cn("mt-1 text-[10px]", mine ? "text-primary-foreground/70" : "text-muted-foreground"),
								children: formatWhen(message.createdAt)
							})
						]
					})
				}, message.id);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "shrink-0 space-y-2 border-t border-border p-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichEditor, {
					value: text,
					onChange: setText,
					placeholder: "Write privately…",
					compact: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendingMediaTray, {
					items: pending,
					onRemove: () => setPending([]),
					onCommit: () => void send(),
					onDiscard: () => setPending([]),
					commitLabel: "Send",
					busy
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoSourceButtons, {
					onFiles: onPhoto,
					busy,
					galleryLabel: "Gallery",
					cameraLabel: "Camera",
					accept: MEDIA_ACCEPT
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "icon",
						variant: recording ? "default" : "outline",
						disabled: busy,
						"aria-label": recording ? "Stop recording" : "Voice note",
						onClick: () => void toggleRecord(),
						children: recording ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						disabled: busy || !text.trim() && !pending.length,
						"aria-label": "Send",
						onClick: () => void send(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {}), "Send"]
					})]
				})
			]
		})]
	});
}
function Album({ me }) {
	const [photos, setPhotos] = (0, import_react.useState)([]);
	const [lightbox, setLightbox] = (0, import_react.useState)(null);
	const [caption, setCaption] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const load = (0, import_react.useCallback)(async () => {
		try {
			setPhotos(await listPrivatePhotos());
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not load photos.");
		}
	}, []);
	(0, import_react.useEffect)(() => {
		load();
	}, [load]);
	useLiveReload(load);
	async function onPick(files) {
		if (!files?.length) return;
		try {
			const staged = await stageFiles(files, {
				allowImage: true,
				max: 1
			});
			if (!staged.length) {
				toast.error("Choose a photo from your gallery.");
				return;
			}
			setPending(staged.slice(0, 1));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not add photo.");
		}
	}
	async function send() {
		const media = pending[0];
		if (!media) return;
		setBusy(true);
		try {
			const saved = await addPrivatePhoto({ data: {
				photoData: media.data,
				caption
			} });
			setPhotos((prev) => [saved, ...prev]);
			setCaption("");
			setPending([]);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not add photo.");
		} finally {
			setBusy(false);
		}
	}
	async function remove(id) {
		try {
			await deletePrivatePhoto({ data: { id } });
			setPhotos((prev) => prev.filter((item) => item.id !== id));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not delete.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-[min(62dvh,28rem)] min-h-0 flex-col overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto p-3",
				children: photos.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-8 text-center text-sm text-muted-foreground",
					children: "A private album for the two of you. Choose photos from your gallery or take a new one."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2",
					children: photos.map((photo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
						className: "overflow-hidden rounded-md bg-secondary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "block w-full",
							onClick: () => setLightbox(photo.photoData),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: photo.photoData,
								alt: "",
								className: "h-28 w-full object-cover"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
							className: "flex items-center justify-between gap-2 px-2 py-1.5 text-[11px] text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: photo.caption || formatWhen(photo.createdAt)
							}), photo.uploadedBy === me.profile?.userId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => void remove(photo.id),
								className: "hover:text-foreground",
								children: "Remove"
							}) : null]
						})]
					}, photo.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shrink-0 space-y-2 border-t border-border p-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: caption,
						onChange: (e) => setCaption(e.target.value),
						placeholder: "Caption (optional)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoSourceButtons, {
						onFiles: onPick,
						busy
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendingMediaTray, {
						items: pending,
						onRemove: () => setPending([]),
						onCommit: () => void send(),
						onDiscard: () => setPending([]),
						commitLabel: "Send",
						busy
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbox, {
				src: lightbox,
				onClose: () => setLightbox(null)
			})
		]
	});
}
async function persist(on, onChange) {
	const next = await saveVacation({ data: { on } });
	broadcastMe(next);
	onChange(next);
	toast.success(on ? "Vacation started. Duties are paused." : "Vacation ended. Duties are live again.");
	return next;
}
function VacationToggle({ me, onChange, compact = false }) {
	const on = dutiesPaused(me.house);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function setOn(next) {
		setBusy(true);
		try {
			await persist(next, onChange);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not update vacation.");
		} finally {
			setBusy(false);
		}
	}
	if (compact) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		disabled: busy,
		onClick: () => void setOn(!on),
		className: cn("flex min-h-12 w-full items-center justify-between rounded-lg px-3 py-2 text-sm", on ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex min-w-0 items-center gap-2 text-left",
			children: [on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 shrink-0" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block",
					children: "Vacation"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs opacity-80",
					children: on ? "Duties paused" : "Pause tasks, habits, training"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs opacity-80",
			children: on ? "On" : "Off"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-2 rounded-lg bg-background p-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			disabled: busy,
			onClick: () => void setOn(true),
			className: cn("h-10 rounded-md text-sm", on ? "bg-primary text-primary-foreground" : "text-muted-foreground"),
			children: "Pause"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			disabled: busy,
			onClick: () => void setOn(false),
			className: cn("h-10 rounded-md text-sm", !on ? "bg-primary text-primary-foreground" : "text-muted-foreground"),
			children: "Live"
		})]
	});
}
function VacationBanner({ me, onChange }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (!dutiesPaused(me.house)) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-b border-border bg-primary/15",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex min-w-0 items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "On vacation — tasks, habits, training, and protocols are paused."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				disabled: busy,
				className: "flex h-9 shrink-0 items-center gap-1.5 rounded-md border border-border px-3 text-sm",
				onClick: () => {
					setBusy(true);
					persist(false, onChange).catch((err) => {
						toast.error(err instanceof Error ? err.message : "Could not resume.");
					}).finally(() => setBusy(false));
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), busy ? "Resuming…" : "Resume"]
			})]
		})
	});
}
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-ink/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
		...props
	});
}
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed inset-0 z-50 m-auto grid h-fit w-[min(100%-1.5rem,40rem)] max-h-[min(92dvh,44rem)] gap-4 overflow-y-auto rounded-xl border border-border bg-card p-5 shadow-[0_24px_60px_rgb(0_0_0_/_0.35)] outline-none", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-3 right-3 grid size-11 place-items-center rounded-md text-muted-foreground hover:bg-secondary hover:text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Close"
			})]
		})]
	})] });
}
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1 pr-8", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-2xl font-medium text-foreground", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
function AccountMenu() {
	const btnRef = (0, import_react.useRef)(null);
	const menuRef = (0, import_react.useRef)(null);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [pos, setPos] = (0, import_react.useState)({
		top: 0,
		left: 16
	});
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	function toggle() {
		if (!open && btnRef.current) {
			const rect = btnRef.current.getBoundingClientRect();
			setPos({
				top: rect.top,
				left: Math.min(Math.max(8, rect.right + 6), window.innerWidth - 176 - 8)
			});
		}
		setOpen((value) => !value);
	}
	(0, import_react.useEffect)(() => {
		if (!open) return;
		function onDoc(event) {
			const target = event.target;
			if (menuRef.current?.contains(target) || btnRef.current?.contains(target)) return;
			setOpen(false);
		}
		function onKey(event) {
			if (event.key === "Escape") setOpen(false);
		}
		document.addEventListener("mousedown", onDoc);
		document.addEventListener("keydown", onKey);
		return () => {
			document.removeEventListener("mousedown", onDoc);
			document.removeEventListener("keydown", onKey);
		};
	}, [open]);
	async function wipe() {
		setBusy(true);
		try {
			await deleteAccount();
			try {
				await signOut("/login");
			} catch {
				window.location.href = "/login";
			}
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not delete the account.");
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-0.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				ref: btnRef,
				type: "button",
				"aria-label": "Account menu",
				"aria-haspopup": "menu",
				"aria-expanded": open,
				onClick: toggle,
				className: "grid size-9 shrink-0 place-items-center rounded-md text-muted-foreground hover:bg-secondary hover:text-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EllipsisVertical, { className: "size-4" })
			}),
			open && typeof document !== "undefined" ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: menuRef,
				role: "menu",
				className: "fixed z-[80] min-w-44 rounded-lg border border-border bg-card p-1 shadow-soft",
				style: {
					top: pos.top,
					left: pos.left
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "menuitem",
					className: "w-full rounded-md px-3 py-2 text-left text-sm text-destructive hover:bg-secondary",
					onClick: () => {
						setOpen(false);
						setConfirm(true);
					},
					children: "Delete account"
				})
			}), document.body) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: confirm,
				onOpenChange: setConfirm,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Delete this account?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "This removes your login, profile, companion, and private answers. A connected partner is unlinked and keeps the shared pages. This cannot be undone." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setConfirm(false),
						disabled: busy,
						children: "Keep it"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "destructive",
						onClick: () => void wipe(),
						disabled: busy,
						children: busy ? "Deleting…" : "Delete account"
					})]
				})] })
			})
		]
	});
}
var VISIBLE_MS = 22e3;
var HIDDEN_MS = 55e3;
var FIRST_MS = 8e3;
function startCompanionLive(options) {
	if (typeof window === "undefined") return () => {};
	let stopped = false;
	let timer = null;
	let inFlight = false;
	let first = true;
	async function tick() {
		if (stopped || inFlight) {
			if (!stopped && !inFlight) schedule();
			return;
		}
		inFlight = true;
		try {
			if (first && options.panelOpen()) return;
			const result = await tickCompanion();
			if (stopped) return;
			const messages = result?.messages ?? [];
			if (messages.length) {
				emitLive();
				window.dispatchEvent(new Event("sanctum:companion-ping"));
				if (!options.panelOpen()) showAlert(result?.name || "Companion", (messages[0]?.body?.trim() || "Wrote to you.").slice(0, 140));
			}
		} catch {} finally {
			inFlight = false;
			first = false;
			schedule();
		}
	}
	function schedule() {
		if (stopped) return;
		if (timer) window.clearTimeout(timer);
		const ms = first ? FIRST_MS : document.visibilityState === "visible" ? VISIBLE_MS : HIDDEN_MS;
		timer = window.setTimeout(() => void tick(), ms);
	}
	function kick() {
		if (document.visibilityState !== "visible") return;
		if (timer) window.clearTimeout(timer);
		first = false;
		tick();
	}
	document.addEventListener("visibilitychange", kick);
	schedule();
	return () => {
		stopped = true;
		if (timer) window.clearTimeout(timer);
		document.removeEventListener("visibilitychange", kick);
	};
}
var HOUSE_NAV = [
	{
		hash: "you",
		label: "You",
		icon: UserRound
	},
	{
		hash: "partner",
		label: "Partner",
		icon: Users
	},
	{
		hash: "options",
		label: "Options",
		icon: SlidersHorizontal
	},
	{
		hash: "app",
		label: "App",
		icon: Settings
	},
	{
		hash: "calendar",
		label: "Calendar",
		icon: Calendar
	},
	{
		hash: "archive",
		label: "Archived",
		icon: Archive
	},
	{
		hash: "location",
		label: "Location",
		icon: MapPin
	},
	{
		hash: "permissions",
		label: "Permissions",
		icon: Shield
	}
];
var NAV = [
	{
		to: "/",
		label: "Home",
		icon: House,
		primary: true
	},
	{
		to: "/tasks",
		label: "Tasks",
		icon: SquareCheckBig,
		primary: true
	},
	{
		to: "/habits",
		label: "Habits",
		icon: Repeat
	},
	{
		to: "/training",
		label: "Training",
		icon: GraduationCap,
		primary: true
	},
	{
		to: "/punishments",
		label: "Punishments",
		icon: Flame
	},
	{
		to: "/rewards",
		label: "Rewards",
		icon: Gem
	},
	{
		to: "/games",
		label: "Games",
		icon: Dices,
		primary: true
	},
	{
		to: "/talk",
		label: "Talk",
		icon: MessageCircle,
		primary: true
	},
	{
		to: "/roleplay",
		label: "Roleplay",
		icon: Theater
	},
	{
		to: "/challenges",
		label: "Challenges",
		icon: Trophy
	},
	{
		to: "/scenes",
		label: "Scenes",
		icon: Clapperboard
	},
	{
		to: "/journal",
		label: "Journal",
		icon: BookOpen
	},
	{
		to: "/notes",
		label: "Notes",
		icon: StickyNote
	},
	{
		to: "/playbook",
		label: "Playbook",
		icon: BookMarked
	},
	{
		to: "/catalog",
		label: "Catalogue",
		icon: Shirt
	}
];
var PRIMARY_NAV = NAV.filter((item) => item.primary);
NAV.filter((item) => !item.primary);
var DEFAULT_QUICK_NAV = [
	"/",
	"/tasks",
	"/games",
	"/talk"
];
function navFor(paths) {
	const found = (paths?.length ? paths : DEFAULT_QUICK_NAV).slice(0, 4).map((to) => NAV.find((item) => item.to === to)).filter((item) => Boolean(item));
	return found.length ? found : PRIMARY_NAV.slice(0, 4);
}
function AppShell({ children }) {
	const { user, isPending } = useCurrentUserState();
	const location = useRouterState({ select: (s) => s.location });
	const pathname = location.pathname;
	const hash = location.hash;
	const [me, setMe] = (0, import_react.useState)(null);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [moreOpen, setMoreOpen] = (0, import_react.useState)(false);
	const [privateOpen, setPrivateOpen] = (0, import_react.useState)(false);
	const [privateTab, setPrivateTab] = (0, import_react.useState)("messages");
	const [companionOpen, setCompanionOpen] = (0, import_react.useState)(false);
	const companionOpenRef = (0, import_react.useRef)(false);
	companionOpenRef.current = companionOpen;
	const [companionPing, setCompanionPing] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!user) {
			setReady(!isPending);
			return;
		}
		let cancelled = false;
		getMe().then((data) => {
			if (!cancelled) setMe(data);
		}).catch(() => {
			if (!cancelled) setMe(EMPTY_ME);
		}).finally(() => {
			if (!cancelled) setReady(true);
		});
		return () => {
			cancelled = true;
		};
	}, [user, isPending]);
	(0, import_react.useEffect)(() => subscribeMe(setMe), []);
	(0, import_react.useEffect)(() => {
		if (!me?.profile) return;
		const stopLive = startLiveSync();
		const stopCompanion = startCompanionLive({ panelOpen: () => companionOpenRef.current });
		return () => {
			stopLive();
			stopCompanion();
		};
	}, [me?.profile?.userId, me?.profile?.bondId]);
	(0, import_react.useEffect)(() => {
		function onPing() {
			if (!companionOpenRef.current) setCompanionPing(true);
		}
		window.addEventListener("sanctum:companion-ping", onPing);
		return () => window.removeEventListener("sanctum:companion-ping", onPing);
	}, []);
	(0, import_react.useEffect)(() => {
		setMoreOpen(false);
		setPrivateOpen(false);
	}, [pathname, hash]);
	(0, import_react.useEffect)(() => {
		setCompanionOpen(false);
	}, [pathname]);
	if (isPending || !ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center bg-background vignette px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-4xl tracking-tight",
				children: "Sanctum"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Opening Sanctum"
			})]
		})
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (!me?.profile || !me.profile.setupDone) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-background vignette px-5 py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Onboarding, {
			userName: user.displayName,
			me,
			onDone: setMe
		})
	});
	const quick = navFor(me.options.quickNav);
	const morePages = NAV.filter((item) => !quick.some((q) => q.to === item.to));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-14 max-w-6xl items-center gap-3 px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "font-display text-xl tracking-tight",
						children: "Sanctum"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center rounded-full border border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										setPrivateOpen(false);
										setCompanionOpen((open) => !open);
										setCompanionPing(false);
									},
									className: cn("relative flex h-10 items-center gap-1.5 rounded-l-full px-3 text-sm", companionOpen ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"),
									"aria-label": "Companion",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hidden sm:inline",
											children: "Companion"
										}),
										companionPing && !companionOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1.5 right-1.5 size-2 rounded-full bg-primary" }) : null
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										setCompanionOpen(false);
										setPrivateTab("messages");
										setPrivateOpen((open) => !(open && privateTab === "messages"));
									},
									className: cn("flex h-10 items-center gap-1.5 border-l border-border px-3 text-sm", privateOpen && privateTab === "messages" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden sm:inline",
										children: "Messages"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setCompanionOpen(false);
										setPrivateTab("photos");
										setPrivateOpen((open) => !(open && privateTab === "photos"));
									},
									className: cn("flex h-10 items-center rounded-r-full px-3 text-sm", privateOpen && privateTab === "photos" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"),
									children: "Photos"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/house",
							hash: "you",
							className: "ml-0.5 grid size-10 place-items-center overflow-hidden rounded-full border border-border",
							"aria-label": "Profile",
							children: me.profile.avatarData ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: me.profile.avatarData,
								alt: "",
								className: "size-full object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: (me.profile.username || me.profile.displayName).charAt(0) || "S"
							})
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VacationBanner, {
				me,
				onChange: setMe
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppOpenBeacon, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocationBeacon, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanionPanel, {
				me,
				open: companionOpen,
				onClose: () => setCompanionOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessagesPanel, {
				me,
				open: privateOpen,
				tab: privateTab,
				onTab: (tab) => {
					setPrivateTab(tab);
					setPrivateOpen(true);
				}
			}),
			privateOpen || companionOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "fixed inset-0 z-30 bg-ink/40",
				"aria-label": "Close panel",
				onClick: () => {
					setPrivateOpen(false);
					setCompanionOpen(false);
				}
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl gap-8 px-4 py-8 pb-28 md:pb-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "hidden w-56 shrink-0 md:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sticky top-24 flex max-h-[calc(100dvh-7rem)] flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "min-h-0 flex-1 space-y-1 overflow-y-auto pr-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VacationToggle, {
									me,
									onChange: setMe,
									compact: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "px-3 pb-1 pt-4 text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
									children: "Settings"
								}),
								HOUSE_NAV.map((item) => {
									const Icon = item.icon;
									const active = pathname === "/house" && parseHouseTab(hash) === item.hash;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/house",
										hash: item.hash,
										className: cn("flex h-10 items-center gap-2 rounded-lg px-3 text-sm", active ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
									}, item.hash);
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "px-3 pb-1 pt-5 text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
									children: "Categories"
								}),
								NAV.map((item) => {
									const Icon = item.icon;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: item.to,
										className: cn("flex h-11 items-center gap-2 rounded-lg px-3 text-sm", pathname === item.to ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
									}, item.to);
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 shrink-0 border-t border-border pt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountMenu, {})
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "min-w-0 flex-1",
					children
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-5",
					children: [quick.map((item) => {
						const Icon = item.icon;
						const active = pathname === item.to;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex h-16 flex-col items-center justify-center gap-1 text-[11px]", active ? "text-primary" : "text-muted-foreground"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label]
						}, item.to);
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setMoreOpen((v) => !v),
						className: cn("flex h-16 flex-col items-center justify-center gap-1 text-[11px]", moreOpen ? "text-primary" : "text-muted-foreground"),
						children: [moreOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" }), "More"]
					})]
				})
			}),
			moreOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-x-0 bottom-16 z-30 max-h-[70dvh] overflow-y-auto border-t border-border bg-card p-3 md:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VacationToggle, {
						me,
						onChange: setMe,
						compact: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-1 pb-2 pt-4 text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
						children: "Settings"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: HOUSE_NAV.map((item) => {
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/house",
								hash: item.hash,
								className: "flex h-12 items-center gap-2 rounded-lg bg-secondary px-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
							}, item.hash);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-1 pb-2 pt-4 text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
						children: "Categories"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: morePages.map((item) => {
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: "flex h-12 items-center gap-2 rounded-lg bg-secondary px-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
							}, item.to);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 px-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountMenu, {})
					})
				]
			}) : null
		]
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full border px-2.5 py-0.5 text-[11px] font-medium tracking-wide", {
	variants: { variant: {
		default: "border-transparent bg-primary/15 text-primary",
		outline: "border-border text-muted-foreground",
		solid: "border-transparent bg-primary text-primary-foreground",
		muted: "border-transparent bg-secondary text-muted-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
//#endregion
export { useAutoSave as _, DialogDescription as a, HOUSE_NAV as c, NAV as d, RichEditor as f, subscribeMe as g, VacationToggle as h, DialogContent as i, KinkField as l, SaveHint as m, Badge as n, DialogHeader as o, RichText as p, Dialog as r, DialogTitle as s, AppShell as t, KinkList as u, useLiveReload as v };
