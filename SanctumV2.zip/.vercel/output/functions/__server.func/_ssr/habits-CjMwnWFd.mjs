import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as AppShell } from "./badge-CRftROn_.mjs";
import { a as KindPage } from "./kind-page-GHqW5OYA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/habits-CjMwnWFd.js
var import_jsx_runtime = require_jsx_runtime();
function Habits() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindPage, {
		kind: "task",
		defaultCadence: "habit",
		entryFilter: (entry) => entry.cadence === "habit",
		addLabel: "New habit",
		title: "Habits",
		kicker: "Kept",
		blurb: "Repeating habits you keep each week — either of you can write them.",
		emptyTitle: "No habits yet",
		emptyBody: "Set the first habit to keep."
	}) });
}
//#endregion
export { Habits as component };
