import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as useNavigate, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { B as parseExperience, l as VIDEO_META_KEY, u as applyVideos } from "./video-DfU4zp6z.mjs";
import { C as fillSelectOptions, D as formatWhen, I as isLibraryNote, L as lockedCopy, M as intensityMarks, N as isArchivedEntry, P as isDutyKind, U as plainExcerpt, W as resolveIdeaSlug, _ as canSetEarnedCount, b as dutiesPaused, c as NOTES_LIBRARY, f as canEditEntry, g as canSetCountdown, h as canSetCost, l as NOTE_LIBRARY_CATEGORIES, m as canMutate, o as KINDS, v as clipIdeaTitle, x as editDeniedCopy } from "./format-Dsk7inZY.mjs";
import { A as usesRewards, C as shopCost, D as usesCountdown, E as urgencyOf, O as usesPoints, S as shopBuyLabel, T as stakesModeOf, _ as parseIdList, a as countdownLabel, b as readPdfFile, c as encodeCustomDays, f as isPdfFile, g as parseCustomDays, h as parseCountdown, i as countWord, k as usesPunishments, l as isBought, m as outcomeMessage, n as URGENCY, o as countdownMode, r as applyPdfs, s as earnedCountOf, t as PDF_META_KEY, u as isCountedKind, w as sortNamed, y as parsePoints } from "./sort-CKxFQEP9.mjs";
import { i as cn, n as Input, r as Label, t as Button } from "./input-CkY6TqOo.mjs";
import { P as Info, V as FileText, X as ChevronDown, _ as Settings2, b as Plus, q as ChevronUp, rt as Archive, s as Trash2, t as X, w as Minus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { B as listEntries, C as deleteEntry, F as getPoints, L as listCategories, P as getMe, Q as reorderEntries, S as deleteCategory, Z as reorderCategories, _ as buyEntry, _t as updateEntry, b as createEntry, d as Select, dt as setUrgency, f as VideoStrip, gt as updateCategory, ht as toggleEntry, l as PhotoStrip, lt as setEarnedCount, n as Lightbox, p as addCategory, r as MediaField, tt as savePlay } from "./use-current-user-nzqgiI2T.mjs";
import { _ as useAutoSave, a as DialogDescription, f as RichEditor, g as subscribeMe, i as DialogContent, m as SaveHint, n as Badge, o as DialogHeader, p as RichText, r as Dialog, s as DialogTitle, v as useLiveReload } from "./badge-CRftROn_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kind-page-GHqW5OYA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ChanceWheel({ title, copy, slices, extras = [], empty = "Add a few items, then spin.", canEdit = false, onAddExtra, onRemoveExtra }) {
	const [angle, setAngle] = (0, import_react.useState)(0);
	const [spinning, setSpinning] = (0, import_react.useState)(false);
	const [result, setResult] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)("");
	const labels = slices.length ? slices : ["Add items first"];
	const slice = 360 / labels.length;
	const showLabels = labels.length >= 2 && labels.length <= 12;
	const gradient = (0, import_react.useMemo)(() => labels.map((_, i) => {
		return `${i % 2 === 0 ? "var(--color-raised)" : "var(--color-primary)"} ${i * slice}deg ${(i + 1) * slice}deg`;
	}).join(", "), [labels, slice]);
	function spin() {
		if (spinning || !slices.length) return;
		setSpinning(true);
		setResult(null);
		const index = Math.floor(Math.random() * labels.length);
		const target = 360 - index * slice - slice / 2;
		setAngle((prev) => {
			const current = (prev % 360 + 360) % 360;
			const delta = (target - current + 360) % 360;
			return prev + 2160 + delta;
		});
		window.setTimeout(() => {
			setResult(labels[index] ?? null);
			setSpinning(false);
		}, 2400);
	}
	function add() {
		const label = draft.trim();
		if (!label || !onAddExtra) return;
		onAddExtra(label);
		setDraft("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-card p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-sm text-muted-foreground",
				children: copy
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto size-56",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-full rounded-full border border-border",
						style: {
							background: `conic-gradient(${gradient})`,
							transform: `rotate(${angle}deg)`,
							transition: spinning ? "transform 2.3s cubic-bezier(0.22, 1, 0.36, 1)" : "none"
						},
						children: showLabels ? labels.map((label, i) => {
							const mid = i * slice + slice / 2;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pointer-events-none absolute top-1/2 left-1/2 w-[4.4rem] origin-left -translate-y-1/2 text-center text-[10px] leading-tight text-foreground",
								style: { transform: `rotate(${mid - 90}deg) translate(2.6rem)` },
								children: label.slice(0, 18)
							}, `${label}-${i}`);
						}) : null
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-1/2 left-1/2 size-8 -translate-x-1/2 -translate-y-1/2 rounded-full border border-border bg-background" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-1 left-1/2 h-6 w-0 -translate-x-1/2 border-x-8 border-b-[14px] border-x-transparent border-b-primary" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 min-h-6 text-center font-display text-xl",
				children: result ?? (slices.length ? " " : empty)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-3 w-full",
				onClick: spin,
				disabled: spinning || !slices.length,
				children: spinning ? "Spinning…" : "Spin"
			}),
			canEdit && onAddExtra ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 space-y-2 border-t border-border pt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.14em] text-muted-foreground",
						children: "Wheel extras"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft,
							onChange: (e) => setDraft(e.target.value),
							placeholder: "Add a slice",
							onKeyDown: (e) => {
								if (e.key === "Enter") {
									e.preventDefault();
									add();
								}
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: add,
							disabled: !draft.trim(),
							children: "Add"
						})]
					}),
					extras.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1",
						children: extras.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: item
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-xs text-muted-foreground hover:text-foreground",
								onClick: () => onRemoveExtra?.(item),
								children: "Remove"
							})]
						}, item))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Page entries spin too. Add extra slices here."
					})
				]
			}) : null
		]
	});
}
var CATALOG_ROLES = [
	{
		value: "prop",
		label: "Prop",
		hint: "On the table, not drawn"
	},
	{
		value: "card",
		label: "Card",
		hint: "Joins the card pile"
	},
	{
		value: "prompt",
		label: "Prompt",
		hint: "Joins the prompt pile"
	}
];
function parseLineList(raw) {
	if (!raw) return [];
	try {
		const parsed = JSON.parse(raw);
		if (Array.isArray(parsed)) return parsed.map((item) => {
			if (typeof item === "string") return item;
			if (item && typeof item === "object" && "title" in item) {
				const title = String(item.title ?? "").trim();
				const body = "body" in item ? String(item.body ?? "").trim() : "";
				return body ? `${title} — ${body}` : title;
			}
			return "";
		}).map((line) => line.trim()).filter(Boolean);
	} catch {}
	return raw.split("\n").map((line) => line.trim()).filter(Boolean);
}
function parseDeckLine(line) {
	const [left, ...rest] = line.split("—");
	return {
		title: (left ?? "").trim() || "Card",
		body: rest.join("—").trim()
	};
}
function parseCatalogRoles(meta) {
	const ids = (meta.catalogIds ?? "").split(",").map((value) => value.trim()).filter(Boolean);
	const roles = {};
	try {
		const parsed = JSON.parse(meta.catalogRoles || "{}");
		if (parsed && typeof parsed === "object") {
			for (const [key, value] of Object.entries(parsed)) if (value === "prop" || value === "card" || value === "prompt") roles[key] = value;
		}
	} catch {}
	for (const id of ids) if (!roles[id]) roles[id] = "prop";
	return roles;
}
function plainText(html) {
	return html.replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();
}
function catalogTitleAt(meta, index) {
	return (meta.catalogTitles ?? "").split(" · ").map((value) => value.trim()).filter(Boolean)[index];
}
function buildGameDecks(entry, catalog) {
	const byId = new Map(catalog.map((item) => [String(item.id), item]));
	const roles = parseCatalogRoles(entry.meta);
	const cards = parseLineList(entry.meta.cards).map((line, index) => {
		const parsed = parseDeckLine(line);
		return {
			key: `card:${index}:${parsed.title}`,
			...parsed,
			photo: null,
			source: "written"
		};
	});
	const prompts = parseLineList(entry.meta.prompts).map((line, index) => {
		const parsed = parseDeckLine(line);
		return {
			key: `prompt:${index}:${parsed.title}`,
			...parsed,
			photo: null,
			source: "written"
		};
	});
	(entry.meta.catalogIds ?? "").split(",").map((value) => value.trim()).filter(Boolean).forEach((id, index) => {
		const role = roles[id];
		if (role !== "card" && role !== "prompt") return;
		const item = byId.get(id);
		const deckItem = {
			key: `catalog:${id}`,
			title: item?.title || catalogTitleAt(entry.meta, index) || "Catalogue item",
			body: item ? plainText(item.body).slice(0, 180) : "",
			photo: item?.photos[0] ?? null,
			source: "catalog"
		};
		if (role === "card") cards.push(deckItem);
		else prompts.push(deckItem);
	});
	return {
		cards,
		prompts
	};
}
function shuffleItems(items) {
	const next = [...items];
	for (let i = next.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[next[i], next[j]] = [next[j], next[i]];
	}
	return next;
}
function GameDeckPlay({ entry, catalog }) {
	const decks = (0, import_react.useMemo)(() => buildGameDecks(entry, catalog), [entry, catalog]);
	if (!decks.cards.length && !decks.prompts.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [decks.cards.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrawPile, {
			label: "Card",
			items: decks.cards,
			empty: "Add cards, or set a catalogue piece as a card."
		}) : null, decks.prompts.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrawPile, {
			label: "Prompt",
			items: decks.prompts,
			empty: "Add prompts, or set a catalogue piece as a prompt."
		}) : null]
	});
}
function DrawPile({ label, items, empty }) {
	const signature = items.map((item) => item.key).join("|");
	const [pile, setPile] = (0, import_react.useState)([]);
	const [current, setCurrent] = (0, import_react.useState)(null);
	const itemsRef = (0, import_react.useRef)(items);
	itemsRef.current = items;
	(0, import_react.useEffect)(() => {
		setPile(shuffleItems(itemsRef.current));
		setCurrent(null);
	}, [signature]);
	function draw() {
		const deck = itemsRef.current;
		if (!deck.length) return;
		const [picked, ...rest] = pile.length ? pile : shuffleItems(deck);
		setCurrent(picked ?? null);
		setPile(rest);
	}
	function reshuffle() {
		setPile(shuffleItems(itemsRef.current));
		setCurrent(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-secondary/60 p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
					children: [
						label,
						"s · ",
						items.length
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] text-muted-foreground",
					children: pile.length ? `${pile.length} left in the pile` : current ? "Pile empty" : "Shuffled"
				})]
			}),
			current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrawnCard, { item: current }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md border border-dashed border-border px-3 py-4 text-center text-sm text-muted-foreground",
				children: items.length ? `Draw a ${label.toLowerCase()}.` : empty
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					className: "flex-1",
					onClick: draw,
					disabled: !items.length,
					children: ["Draw ", label.toLowerCase()]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: reshuffle,
					disabled: !items.length,
					children: "Shuffle"
				})]
			})
		]
	});
}
function DrawnCard({ item }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("overflow-hidden rounded-md border border-border bg-card", item.photo ? "" : "p-3"),
		children: [item.photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: item.photo,
			alt: "",
			className: "h-36 w-full object-cover"
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: item.photo ? "p-3" : void 0,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl leading-snug",
					children: item.title
				}),
				item.body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: item.body
				}) : null,
				item.source === "catalog" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-[11px] uppercase tracking-[0.14em] text-primary",
					children: "From the catalogue"
				}) : null
			]
		})]
	});
}
var DAILY_QUESTIONS = [
	"When do you feel the most loved by me?",
	"What is a small thing I do that you hope I never stop doing?",
	"When did you first realise this was more than a crush?",
	"What is a memory of us you would replay if you could only keep one?",
	"What does a perfect ordinary Sunday with me look like?",
	"What is something about me you noticed before I ever said a word?",
	"When do you feel safest with me?",
	"What is a dream of yours I still don't know enough about?",
	"How do you want to be comforted when the day has gone badly?",
	"What is a compliment from me that actually lands?",
	"Where in our story would you press pause and stay a while?",
	"What is one way I can make you feel chosen this week?",
	"What did our first real conversation teach you about me?",
	"What is a tradition you want us to keep, even when life gets loud?",
	"When do you feel most proud of us?",
	"What is a fear you can name without needing me to fix it?",
	"What does home mean to you, with me in it?",
	"What is a part of your childhood you want me to understand better?",
	"How do you know you are in love — in your body, not just your head?",
	"What is something you want us to be brave enough to try?",
	"Would you rather a spontaneous night out, or a planned evening in with no phones?",
	"Would you rather travel for a year with two bags, or build a house and stay put?",
	"Would you rather always cook together, or take turns surprising each other?",
	"Would you rather relive our first date, or skip ahead to a quiet night ten years from now?",
	"Would you rather know one true thing about the future, or keep every surprise?",
	"Would you rather be rich in time, or rich in money — and what would we do with it?",
	"Would you rather a cabin in the woods, or a flat in a city we don't know yet?",
	"Would you rather I plan every anniversary, or we make them up as we go?",
	"Would you rather always be ten minutes early, or fashionably late — together?",
	"Would you rather slow-dance in the kitchen, or get dressed up for a proper night out?",
	"What is a value you will not compromise on, even for me?",
	"What does loyalty look like to you on an ordinary Tuesday?",
	"How do you want us to handle money as a pair?",
	"What does a good apology from me sound like?",
	"What is a boundary you need me to treat as sacred?",
	"How do you want conflict to go — in the moment, and after?",
	"What is a family pattern you want us to leave behind?",
	"What is a family pattern you hope we keep?",
	"What does partnership mean to you when one of us is unwell?",
	"How much space do you need, and how should I give it without disappearing?",
	"What is the kindest thing anyone has ever done for you?",
	"Who shaped the way you love, for better or worse?",
	"What is a story from before we met that still lives in you?",
	"What did you believe about love at eighteen, and what do you believe now?",
	"What is a place that still feels like you, and would you take me there?",
	"What is a song that knows something about us?",
	"What is a smell, a season, or a time of day that reminds you of me?",
	"What is something you miss from the beginning of us?",
	"What is something better now than it was then?",
	"If we could write a letter to our future selves, what would you put in it?",
	"Where do you hope we are living in five years?",
	"What is a skill you want us to learn together?",
	"What kind of old people do you want us to be?",
	"What is a trip we talk about but have not booked — and why not?",
	"What would you want our friends to say about us when we are not in the room?",
	"What is a risk you want us to take this year?",
	"If we had a free month and no obligations, how would we spend it?",
	"What does a life that feels like ours — not anyone else's — look like?",
	"What is a promise you want to make, even if it is small?",
	"What is one thing you want more of from me, without making it a complaint?",
	"What is one thing you want less of, without blame?",
	"When do you feel unheard, and what would help?",
	"What is a habit of mine that secretly delights you?",
	"What is a habit of mine you wish I would notice?",
	"How can I make mornings easier for you?",
	"How can I make evenings feel like we came home to each other?",
	"What is a chore you would happily trade, and for what?",
	"What does help look like when you are stressed — doing, sitting, or leaving you be?",
	"What is a tiny ritual we could add this month?",
	"When we have a free hour, what would you rather we did with it?",
	"What is a way I can flirt with you that still works?",
	"What is a way I can show desire without it having to become a scene?",
	"When do you feel most beautiful, or most yourself, with me?",
	"What kind of touch do you crave when you are tired, not hungry?",
	"What is something you want me to ask for, instead of waiting?",
	"What is an intimacy you want more of that is not about sex?",
	"What is a night you still think about when you want to feel close?",
	"How do you want to be looked at?",
	"What should I never joke about in bed, or after?",
	"What aftercare — in the broadest sense — actually lands for you lately?",
	"What is a fantasy you are curious about but not ready to run?",
	"What would make you feel pursued in a way that is welcome?",
	"Where should we leave more room for no?",
	"What does 'good' look like after a hard conversation?",
	"How do you want to be spoken to when you are dropping, sad, or small?",
	"What praise do you believe, and what praise bounces off?",
	"Ask the question you wish I would ask you.",
	"What would make tomorrow feel held?",
	"Where did we miss each other recently?",
	"What are you proud of in us right now?",
	"What did you need from me today that you did not ask for?",
	"A word you want used more. A word you want used less.",
	"What would make you feel chosen without a grand gesture?",
	"If I had one hour only for you this week, how should I spend it?",
	"What is a secret joy of yours that the world does not see?",
	"What is something you pretend not to care about, but do?",
	"What is a hill you will die on that still makes me smile?",
	"What is your most unpopular opinion, and do you want me to share it?",
	"What is a movie, book, or game that explains a piece of you?",
	"What would your ideal birthday with me include — and exclude?",
	"What is a gift you would never buy yourself that you still want?",
	"If we hosted one dinner, who would be there and what would we cook?",
	"What is a nickname you actually like?",
	"What should our house rule be about phones in bed?",
	"Would you rather I surprise you with a trip, or plan it with you from the first tab?",
	"Would you rather always share a dessert, or always order two?",
	"Would you rather a life full of parties, or a life full of quiet rooms?",
	"Would you rather I text you all day, or save it for when we are together?",
	"Would you rather be known for how we love, or for what we build?",
	"Would you rather never have to pack, or never have to unpack?",
	"Would you rather I tell you the truth immediately, or wait until I have the kind version?",
	"Would you rather a grand romantic speech, or a letter you can reread?",
	"Would you rather we always holiday somewhere new, or return to one place that is ours?",
	"Would you rather I take the lead in a crisis, or decide together even when it is slow?",
	"What is a dream you put down that you might pick up again with me?",
	"What would you want me to remember about you if I ever forgot the details?",
	"What is a way I can support the person you are becoming?",
	"What does success look like for you this year — and how can I stand next to it?",
	"What is a conversation we keep postponing?",
	"What would you like me to ask your friends about you?",
	"How do you want to be introduced — as what, to whom?",
	"What is a piece of my world you want more of?",
	"What is a piece of your world you want me to enter more carefully?",
	"If we wrote a one-page agreement for how we treat each other, what is clause one?",
	"What does forgiveness look like in practice, not in theory?",
	"When you are angry with me, what do you need first: space, a walk, or the talk?",
	"What is a repair that actually works for you after we snap?",
	"How can I tell the difference between you needing comfort and you needing a solution?",
	"What is something I do when I am stressed that you wish I would flag sooner?",
	"What is a 'we' decision you want more say in?",
	"What is a 'you' decision you want me to stop managing?",
	"What does respect from me look like in public?",
	"What does respect from me look like when no one else is watching?",
	"If we could steal a weekend from a film, which one and why?",
	"What is a city, landscape, or climate you can picture us growing old in?",
	"What is a cause or kindness you want us to practice together?",
	"What would you put in a time capsule of this year of us?",
	"What is a photograph of us you want taken, and one you never want taken?",
	"What is a story about us you like telling other people?",
	"What is a story about us you want to keep just for the two of us?",
	"When did I surprise you — in a way you still think about?",
	"What is the most 'us' meal we have?",
	"What would you want whispered at the end of a long day?",
	"If we had a motto on the door, what would it be?",
	"What is a way I can make you laugh when you do not want to?",
	"What is something you hope I never find ordinary about you?",
	"What does being on the same team look like this month?",
	"What is a future version of us you are already a little in love with?",
	"If tonight had no agenda, what would you want from me?",
	"What is one true thing about you that still feels hard to say out loud?",
	"How will we know, years from now, that we did this well?",
	"Which kink of ours still feels like a secret, even between us?",
	"A kink you want more of this month — and one you want to rest.",
	"What does protocol do for you that a scene does not?",
	"When does service feel like devotion, and when does it feel like a chore?",
	"What praise actually lands — words, tone, or being used well?",
	"How do you want to be spoken to when we are in dynamic?",
	"A title, name, or honorific you want used more. One you want used less.",
	"What does kneeling (or being knelt to) mean to you, beyond the picture of it?",
	"Where should restraint start — wrists, voice, time, or attention?",
	"Bondage: what is the point for you — still, helpless, displayed, or held?",
	"Impact: what are we actually chasing — sting, thud, marks, or the talk after?",
	"A sensation you want more of: temperature, texture, pressure, or none of those.",
	"Denial and control: what is being withheld, and what is being given instead?",
	"Exhibition — even private. Who is the audience, and what are they allowed to see?",
	"Pet play: what animal, what rules, and what takes you out of it?",
	"Primal: chase, bite, pin, or the quiet after the catch?",
	"Uniform and outfit: what do you want to put on me, or be put in, next?",
	"A ritual you want at the start of play. One you want at the end.",
	"What aftercare do you actually need after kink, not after sex?",
	"A hard limit that has not changed. A soft limit that might.",
	"What would a yellow look like in the middle of a scene we both want?",
	"How should I check in without breaking the spell?",
	"What does drop feel like in your body, and what should I do first?",
	"A rule that still serves. A rule that has gone ceremonial and empty.",
	"Where do you want more protocol in ordinary life — and where should it stay in the chamber?",
	"What does being owned (or owning) mean to you on a Tuesday, not a Friday night?",
	"A command you want to be given. A command you never want to hear.",
	"What kind of pain, if any, is a gift — and what kind is just noise?",
	"Marks: keep, photograph, hide, or none at all?",
	"How public can the dynamic be — a glance, a collar, a word, or never outside this room?",
	"What should happen if a task is missed: talk, punishment, both, or a rewrite of the task?",
	"A punishment that corrects you. A punishment that only stings your pride.",
	"A reward that actually feels like one, not a consolation.",
	"Which toy, restraint, or catalogue piece do you want in the next scene — and why that one?",
	"Sensory: more sight, sound, smell, or take one away?",
	"Orgasm — whose, when, and who decides?",
	"What does 'use me' or 'use you' actually include, and what does it never include?",
	"A kink you used to want and no longer do. Say it without apology.",
	"A kink you judged in other people that you now want named between us.",
	"How much planning do you want before a scene — script, beats, or walk in cold?",
	"Who should start the next scene, and how do they ask?",
	"What is the difference, for you, between a scene and a night of sex?",
	"Where did we go too far, even a little — and what would make that safe to say?",
	"Where did we not go far enough, and you wished I had pushed?",
	"What role do you want to try that we have never properly run?",
	"A roleplay you want: stranger, hotel, service, teacher, owner, or something you have not named yet.",
	"If we played strangers, where does it start — a bar, a hallway, a message, a look?",
	"If we played service, what is being served, and what is forbidden to the one serving?",
	"If we played owner and kept thing, what are the house rules of that hour?",
	"If we played interrogation, what is the 'crime', and what is the way out?",
	"A uniform or costume that would put you in a role before anyone speaks.",
	"What name should I call you in that role — and what name pulls you out?",
	"How long should a roleplay last: a scene, an evening, or a weekend thread?",
	"When the role slips, do you want me to catch you back in, or let it become us again?",
	"A roleplay that is tender. A roleplay that is cruel. Which do you want first?",
	"What is off-limits even in play-acting — words, roles, stories, power?",
	"Write the first three lines of a scene you want us to walk into.",
	"A fantasy you can say out loud now that you could not a year ago.",
	"A fantasy that should stay a story, not become a scene. Why?",
	"A fantasy you want photographed. A fantasy you never want recorded.",
	"What is the hottest unplayed scene still sitting in your head?",
	"If we had one free night and no limits but our real ones, what would we run?",
	"A group, public, or watched fantasy: is it a story, a maybe, or a never?",
	"What would a slow-burn fantasy look like — days of messages before we ever touch?",
	"A fantasy about power that is not pain. Describe it.",
	"A fantasy about being taken care of that is not sex. Describe it.",
	"What should I whisper in a fantasy that I would not say at breakfast?",
	"Which of your fantasies am I still not in — and do you want me there?",
	"A fantasy you want me to surprise you with, versus one you want to plan together.",
	"If this week's card became a scene, what would the aftercare be?",
	"What would you put on a 'curious, not yet' list — and what would move it to yes?",
	"Name a fantasy in one sentence, then name the fear sitting next to it.",
	"What does 'ruin me a little' mean, and what does it never mean?",
	"How should a fantasy we outgrow be retired — talked out, or just left?",
	"Would you rather a long negotiated scene, or a short sharp one with a lot of aftercare?",
	"Would you rather be told what you are, or asked what you need, in the middle of play?",
	"Would you rather earn a reward through service, or be given one for nothing?",
	"Would you rather the next roleplay be set in our real life, or somewhere we have never been?",
	"Would you rather I pick the kink tonight, or you put three in a hat?"
];
var STARTER_KINKS = [
	{
		slug: "protocol",
		label: "Protocol"
	},
	{
		slug: "service",
		label: "Service"
	},
	{
		slug: "praise",
		label: "Praise"
	},
	{
		slug: "pet-play",
		label: "Pet play"
	},
	{
		slug: "bondage",
		label: "Bondage"
	},
	{
		slug: "restraints",
		label: "Restraints"
	},
	{
		slug: "impact",
		label: "Impact"
	},
	{
		slug: "temperature",
		label: "Temperature"
	},
	{
		slug: "sensory",
		label: "Sensory"
	},
	{
		slug: "denial",
		label: "Denial"
	},
	{
		slug: "exhibition",
		label: "Exhibition"
	},
	{
		slug: "primal",
		label: "Primal"
	},
	{
		slug: "power",
		label: "Power exchange"
	},
	{
		slug: "uniform",
		label: "Uniform / outfit"
	},
	{
		slug: "voice",
		label: "Voice / commands"
	},
	{
		slug: "ritual",
		label: "Ritual"
	},
	{
		slug: "aftercare",
		label: "Aftercare ritual"
	},
	{
		slug: "public",
		label: "Quiet public protocol"
	}
];
var KINK_RATINGS = [
	{
		value: "yes",
		label: "Yes"
	},
	{
		value: "maybe",
		label: "Maybe"
	},
	{
		value: "curious",
		label: "Curious"
	},
	{
		value: "no",
		label: "No"
	},
	{
		value: "hard",
		label: "Hard limit"
	}
];
function mulberry32(seed) {
	return () => {
		let t = seed += 1831565813;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function yearOrder(length, year) {
	const order = Array.from({ length }, (_, i) => i);
	const rand = mulberry32(year * 9973 + length);
	for (let i = order.length - 1; i > 0; i--) {
		const j = Math.floor(rand() * (i + 1));
		[order[i], order[j]] = [order[j], order[i]];
	}
	return order;
}
function dayKey(date = /* @__PURE__ */ new Date()) {
	return date.toISOString().slice(0, 10);
}
function dayOfYearUtc(date = /* @__PURE__ */ new Date()) {
	const year = date.getUTCFullYear();
	const start = Date.UTC(year, 0, 0);
	return Math.floor((date.getTime() - start) / 864e5);
}
function todaysCard(date = /* @__PURE__ */ new Date()) {
	const order = yearOrder(DAILY_QUESTIONS.length, date.getUTCFullYear());
	const index = order[dayOfYearUtc(date) % order.length];
	return {
		prompt: DAILY_QUESTIONS[index],
		number: index + 1,
		total: DAILY_QUESTIONS.length,
		date: dayKey(date)
	};
}
var WEEK_KIND_LIBRARY = {
	communication: [
		"edu-instructions",
		"ex-instructions",
		"ex-role-voice"
	],
	public: [
		"edu-kinks",
		"edu-difficult-talk",
		"ex-explore-kink"
	],
	scene: ["edu-negotiate-scene", "ex-create-scene"],
	roleplay: ["edu-roleplay", "ex-create-roleplay"],
	task: [
		"edu-instructions",
		"ex-instructions",
		"edu-good-dom"
	],
	game: [
		"edu-good-dom",
		"edu-good-sub",
		"ex-confidence"
	],
	training: [
		"edu-good-dom",
		"edu-good-sub",
		"edu-instructions"
	],
	reward: ["edu-aftercare", "edu-good-dom"],
	punishment: [
		"edu-difficult-talk",
		"edu-good-dom",
		"edu-train-brat"
	],
	kink: ["edu-kinks", "ex-explore-kink"]
};
var QUIZ_LIBRARY = {
	love: ["ex-know-partner", "ex-dynamic"],
	kink: ["edu-kinks", "ex-explore-kink"],
	roleplay: [
		"edu-roleplay",
		"ex-create-roleplay",
		"ex-role-voice"
	],
	scene: ["edu-negotiate-scene", "ex-create-scene"],
	aftercare: [
		"edu-aftercare",
		"edu-subspace",
		"edu-domspace"
	],
	relationship: [
		"ex-dynamic",
		"edu-difficult-talk",
		"edu-partner-body"
	],
	communication: [
		"edu-difficult-talk",
		"ex-communication",
		"edu-instructions"
	],
	voice: [
		"edu-instructions",
		"ex-role-voice",
		"ex-instructions"
	],
	appetite: [
		"edu-negotiate-scene",
		"ex-create-scene",
		"edu-kinks"
	]
};
var KINK_LIBRARY = {
	protocol: [
		"edu-good-dom",
		"edu-good-sub",
		"ex-dynamic"
	],
	service: [
		"edu-good-sub",
		"ex-confidence",
		"edu-kinks"
	],
	praise: ["ex-role-voice", "edu-good-dom"],
	"pet-play": ["edu-kinks", "ex-explore-kink"],
	bondage: ["edu-restraints", "ex-explore-kink"],
	restraints: ["edu-restraints", "edu-toys"],
	impact: [
		"edu-kinks",
		"edu-toys",
		"ex-explore-kink"
	],
	temperature: ["edu-kinks", "edu-toys"],
	sensory: ["edu-kinks", "ex-explore-kink"],
	denial: [
		"edu-edging",
		"edu-orgasm-command",
		"act-edging-lab"
	],
	exhibition: ["edu-kinks", "ex-explore-kink"],
	primal: ["edu-kinks", "ex-explore-kink"],
	power: [
		"edu-good-dom",
		"edu-good-sub",
		"ex-confidence"
	],
	uniform: ["edu-kinks", "edu-roleplay"],
	voice: [
		"edu-instructions",
		"ex-role-voice",
		"ex-instructions"
	],
	ritual: ["edu-good-dom", "ex-dynamic"],
	aftercare: [
		"edu-aftercare",
		"edu-subspace",
		"edu-domspace"
	],
	public: ["edu-kinks", "edu-difficult-talk"]
};
var TEXT_RULES = [
	{
		re: /\baftercare\b|sub ?drop|dom ?drop/i,
		keys: [
			"edu-aftercare",
			"edu-subspace",
			"edu-domspace"
		]
	},
	{
		re: /\bsubspace\b/i,
		keys: ["edu-subspace", "edu-aftercare"]
	},
	{
		re: /\bdomspace\b|topspace|top space/i,
		keys: ["edu-domspace", "edu-aftercare"]
	},
	{
		re: /\bbrat|tamer|\bsass\b/i,
		keys: [
			"edu-brat-needs",
			"edu-why-brat",
			"edu-train-brat"
		]
	},
	{
		re: /\bedg(e|ing)\b|orgasm on command|come on command|come when (told|you say)/i,
		keys: [
			"edu-edging",
			"edu-orgasm-command",
			"act-edging-lab"
		]
	},
	{
		re: /\b(partner'?s body|body map|where they like to be touched|learn(ing)? (their|your partner))/i,
		keys: ["edu-partner-body", "act-body-map"]
	},
	{
		re: /\bbondage|restrain|\bcuffs?\b|\brope\b|tied|wrists|hogtie/i,
		keys: ["edu-restraints", "ex-explore-kink"]
	},
	{
		re: /\btoys?\b|\bplug\b|wand|vibrator|paddle|dildo|catalogue piece/i,
		keys: ["edu-toys", "ex-explore-kink"]
	},
	{
		re: /\broleplay|role play|strangers? who|inspection|in that role|costume|interrogation/i,
		keys: [
			"edu-roleplay",
			"ex-create-roleplay",
			"ex-role-voice"
		]
	},
	{
		re: /\binstruction|command you|commands\b|spoken to when we are in dynamic|better instructions/i,
		keys: [
			"edu-instructions",
			"ex-instructions",
			"ex-role-voice"
		]
	},
	{
		re: /\bsafeword|yellow\b|negotiate|check in without breaking/i,
		keys: ["edu-negotiate-scene", "ex-create-scene"]
	},
	{
		re: /\bscene\b|who should start the next scene|walk into/i,
		keys: ["edu-negotiate-scene", "ex-create-scene"]
	},
	{
		re: /\bdifficult|conflict|apology|unheard|when you are angry|repair that actually|hard conversation/i,
		keys: ["edu-difficult-talk", "ex-communication"]
	},
	{
		re: /\bdominant\b|submissive|kneel|protocol|honorific|being owned|owning\)|in dynamic/i,
		keys: [
			"edu-good-dom",
			"edu-good-sub",
			"ex-confidence"
		]
	},
	{
		re: /\bkink|impact\b|primal|pet play|exhibition|denial|degrad|orgasm|sensation you want|what kind of pain/i,
		keys: ["edu-kinks", "ex-explore-kink"]
	},
	{
		re: /\bdynamic\b|strengthen|ritual you want|rule that still serves|confidence in your role/i,
		keys: ["ex-dynamic", "ex-confidence"]
	},
	{
		re: /\bfantasy|curious about but not ready/i,
		keys: [
			"edu-kinks",
			"ex-explore-kink",
			"edu-negotiate-scene"
		]
	}
];
var MAX_KEYS = 3;
function pushKeys(into, keys) {
	if (!keys) return;
	for (const key of keys) {
		if (into.includes(key)) continue;
		if (NOTES_LIBRARY.some((doc) => doc.key === key)) into.push(key);
		if (into.length >= MAX_KEYS) return;
	}
}
function relatedLibraryKeys(input) {
	const keys = [];
	if (input.weekKind) pushKeys(keys, WEEK_KIND_LIBRARY[input.weekKind]);
	if (input.quizId) pushKeys(keys, QUIZ_LIBRARY[input.quizId]);
	if (input.kinkSlug) pushKeys(keys, KINK_LIBRARY[input.kinkSlug]);
	if (keys.length >= MAX_KEYS) return keys.slice(0, MAX_KEYS);
	const blob = [input.text, ...input.texts ?? []].filter(Boolean).join(" \n ");
	if (blob) for (const rule of TEXT_RULES) {
		if (!rule.re.test(blob)) continue;
		pushKeys(keys, rule.keys);
		if (keys.length >= MAX_KEYS) break;
	}
	return keys;
}
function talkPromptsForLibrary(key, limit = 3) {
	const out = [];
	for (const prompt of DAILY_QUESTIONS) {
		if (!relatedLibraryKeys({ text: prompt }).includes(key)) continue;
		out.push(prompt);
		if (out.length >= limit) break;
	}
	return out;
}
function libraryDocsForKeys(keys) {
	return keys.map((key) => NOTES_LIBRARY.find((doc) => doc.key === key)).filter((doc) => Boolean(doc));
}
function to(kind, extra) {
	const config = KINDS[kind];
	const habit = extra?.cadence === "habit";
	return {
		kind,
		category: extra?.category,
		cadence: extra?.cadence,
		label: extra?.label ?? (habit ? "Habits" : config.title),
		path: extra?.path ?? (habit ? "/habits" : config.path)
	};
}
var IDEA_LINKS = {
	scenes: to("scene"),
	roleplay: to("roleplay", { category: "prompt" }),
	"public-play": to("scene"),
	exhibitionism: to("scene"),
	voyeurism: to("scene"),
	voyerism: to("scene"),
	praise: to("reward"),
	humiliation: to("scene"),
	punishments: to("punishment"),
	rewards: to("reward"),
	tasks: to("task", { cadence: "once" }),
	commands: to("rabbit", { category: "command" }),
	training: to("rabbit", { category: "protocol" }),
	"temperature-play": to("scene"),
	"sensory-deprivation": to("scene"),
	masochism: to("scene"),
	sadism: to("scene"),
	bondage: to("scene"),
	"cock-worship": to("scene"),
	"double-penetration": to("scene"),
	"triple-penetration": to("scene"),
	electrostimulation: to("scene"),
	"impact-play": to("scene"),
	shibari: to("scene"),
	"orgasm-control": to("scene"),
	games: to("game", { category: "card" }),
	"dominant-self-improvement": to("journal"),
	"submissive-self-improvement": to("journal")
};
var ACTIVITY_LINKS = {
	self: to("rabbit", { category: "protocol" }),
	partner: to("talk", { category: "question" }),
	dynamic: to("rabbit", { category: "ritual" }),
	kinks: to("talk", { category: "kink" }),
	communication: to("talk", { category: "question" }),
	play: to("scene"),
	roles: to("roleplay", { category: "prompt" }),
	bratting: to("rabbit", { category: "protocol" }),
	body: to("scene")
};
var LIBRARY_LINKS = {
	"ex-confidence": to("rabbit", { category: "protocol" }),
	"ex-improve-self": to("task", {
		cadence: "habit",
		label: "Habits",
		path: "/habits"
	}),
	"ex-know-partner": to("talk", { category: "question" }),
	"ex-dynamic": to("rabbit", { category: "ritual" }),
	"ex-explore-kink": to("talk", { category: "kink" }),
	"ex-communication": to("talk", { category: "question" }),
	"ex-instructions": to("rabbit", { category: "command" }),
	"ex-create-scene": to("scene"),
	"ex-create-roleplay": to("roleplay", { category: "script" }),
	"ex-role-voice": to("rabbit", { category: "command" }),
	"ex-deal-brat": to("punishment"),
	"ex-be-brat": to("rabbit", { category: "protocol" }),
	"act-body-map": to("journal"),
	"act-edging-lab": to("scene"),
	"act-orgasm-touch": to("rabbit", { category: "ritual" }),
	"act-orgasm-voice": to("rabbit", { category: "ritual" }),
	"act-brat-needs": to("talk", { category: "question" }),
	"act-why-brat": to("talk", { category: "issues" })
};
var ASSIGN_PAGES = [
	to("scene"),
	to("roleplay", { category: "prompt" }),
	to("task", { cadence: "once" }),
	to("task", {
		cadence: "habit",
		label: "Habits",
		path: "/habits"
	}),
	to("rabbit", { category: "protocol" }),
	to("punishment"),
	to("reward"),
	to("game", { category: "card" }),
	to("talk", { category: "fantasy" }),
	to("challenge"),
	to("journal"),
	to("catalog", { category: "toy" })
];
function escapeHtml(text) {
	return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function linkForIdea(slug) {
	if (!slug) return null;
	return IDEA_LINKS[slug] ?? IDEA_LINKS[resolveIdeaSlug(slug)] ?? null;
}
function linkForActivity(slug) {
	if (!slug) return null;
	return ACTIVITY_LINKS[slug] ?? null;
}
function linkForEntry(entry) {
	const meta = entry.meta ?? {};
	if (meta.libraryKey && LIBRARY_LINKS[meta.libraryKey]) return LIBRARY_LINKS[meta.libraryKey];
	if (meta.ideaBank && IDEA_LINKS[meta.ideaBank]) return IDEA_LINKS[meta.ideaBank];
	if (entry.category === "ideas") return linkForIdea(entry.subcategory);
	if (entry.category === "exercises") return linkForActivity(entry.subcategory);
	return null;
}
function sourceKeyFor(entry) {
	const meta = entry.meta ?? {};
	if (meta.libraryKey) return `library:${meta.libraryKey}`;
	if (meta.ideaBank && meta.ideaIndex) return `idea:${meta.ideaBank}:${meta.ideaIndex}`;
	return `note:${entry.id}`;
}
function spawnedPathsOf(meta) {
	const fromPages = (meta?.spawnedPages ?? "").split(",").map((item) => item.trim()).filter((item) => ASSIGN_PAGES.some((page) => page.path === item));
	if (fromPages.length) return fromPages;
	if (meta?.spawnedKind && KINDS[meta.spawnedKind]) return [KINDS[meta.spawnedKind].path];
	return [];
}
function mergeSpawnedPages(meta, path) {
	const next = new Set(spawnedPathsOf(meta));
	next.add(path);
	return [...next].join(",");
}
function spawnTitle(title) {
	return clipIdeaTitle(title, 160);
}
function spawnBody(link, title, html) {
	if (link.kind === "talk") {
		const excerpt = plainExcerpt(html, 240);
		return `<p>${escapeHtml(title)}</p>${excerpt ? `<p>${escapeHtml(excerpt)}</p>` : ""}`;
	}
	if (!html.trim()) return `<p>${escapeHtml(title)}</p>`;
	return html;
}
function spawnFields(link, title, html, sourceKey) {
	const wheel = Boolean(KINDS[link.kind].wheel);
	return {
		kind: link.kind,
		title: spawnTitle(title),
		body: spawnBody(link, title, html),
		category: link.category ?? null,
		subcategory: link.subcategory ?? null,
		cadence: link.cadence ?? (link.kind === "task" ? "once" : null),
		status: "open",
		meta: {
			spawnedFrom: sourceKey,
			...link.kind === "journal" ? { visibility: "shared" } : {},
			...wheel ? { onWheel: "1" } : {}
		}
	};
}
function assignLabel(link) {
	const cat = KINDS[link.kind].categories?.find((item) => item.value === link.category)?.label ?? link.category;
	const sub = KINDS[link.kind].categories?.find((item) => item.value === link.subcategory)?.label ?? link.subcategory;
	return [
		link.label,
		cat,
		sub
	].filter(Boolean).join(" · ");
}
function canAssign(me, link) {
	return canMutate(me, link.kind, link.cadence);
}
function catChildren(cats, parent) {
	const key = parent ?? "";
	return cats.filter((item) => !item.archived && (item.parentSlug ?? "") === key);
}
function catPath(cats, slug) {
	if (!slug) return [];
	const bySlug = new Map(cats.map((item) => [item.slug, item]));
	const out = [];
	const seen = /* @__PURE__ */ new Set();
	let current = bySlug.get(slug);
	while (current && !seen.has(current.slug)) {
		seen.add(current.slug);
		out.unshift(current);
		current = current.parentSlug ? bySlug.get(current.parentSlug) : void 0;
	}
	return out;
}
function catDescendants(cats, slug) {
	const ids = /* @__PURE__ */ new Set([slug]);
	let added = true;
	while (added) {
		added = false;
		for (const item of cats) if (item.parentSlug && ids.has(item.parentSlug) && !ids.has(item.slug)) {
			ids.add(item.slug);
			added = true;
		}
	}
	return ids;
}
function catLabelPath(cats, slug) {
	return catPath(cats, slug).map((item) => item.name).join(" · ");
}
/** Persist the tree root in `category` and the selected leaf in `subcategory`. */
function catStore(cats, selected) {
	if (!selected) return {
		category: null,
		subcategory: null
	};
	const path = catPath(cats, selected);
	if (!path.length) return {
		category: selected,
		subcategory: null
	};
	return {
		category: path[0].slug,
		subcategory: path.length > 1 ? path[path.length - 1].slug : null
	};
}
function catTree(cats) {
	const result = [];
	const seen = /* @__PURE__ */ new Set();
	const walk = (parent) => {
		for (const item of cats.filter((c) => (c.parentSlug ?? "") === parent)) {
			if (seen.has(item.slug)) continue;
			seen.add(item.slug);
			result.push(item);
			walk(item.slug);
		}
	};
	walk("");
	for (const item of cats) if (!seen.has(item.slug)) result.push(item);
	return result;
}
function catName(cats, slug) {
	if (!slug) return "";
	return cats.find((item) => item.slug === slug)?.name ?? slug;
}
function SpawnCheckbox({ suggested, title, body, sourceKey, sourceEntry, already = [], me, onSpawned }) {
	const navigate = useNavigate();
	const alreadyKey = already.join("|");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [pending, setPending] = (0, import_react.useState)(false);
	const [added, setAdded] = (0, import_react.useState)(() => {
		const fromMeta = spawnedPathsOf(sourceEntry?.meta);
		return Array.from(/* @__PURE__ */ new Set([...fromMeta, ...already]));
	});
	const [page, setPage] = (0, import_react.useState)(null);
	const [catTrail, setCatTrail] = (0, import_react.useState)([]);
	const [cats, setCats] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		const fromMeta = spawnedPathsOf(sourceEntry?.meta);
		setAdded((prev) => Array.from(/* @__PURE__ */ new Set([
			...prev,
			...fromMeta,
			...already
		])));
	}, [
		alreadyKey,
		sourceEntry?.meta.spawnedPages,
		sourceEntry?.meta.spawnedId
	]);
	const done = added.length > 0;
	const last = (0, import_react.useMemo)(() => ASSIGN_PAGES.find((item) => item.path === added[added.length - 1]) ?? suggested ?? null, [added, suggested]);
	const parents = catChildren(cats, null);
	function resetPick() {
		setPage(null);
		setCatTrail([]);
		setCats([]);
	}
	async function commit(target, cat, sub, live = cats) {
		const link = {
			...target,
			category: cat || void 0,
			subcategory: sub || void 0
		};
		if (added.includes(link.path)) {
			toast.message(`Already on ${link.label}.`);
			return;
		}
		if (!canAssign(me, link)) {
			toast.message(lockedCopy(link.kind));
			return;
		}
		setPending(true);
		try {
			const created = await createEntry({ data: spawnFields(link, title, body, sourceKey) });
			let source = sourceEntry ?? void 0;
			if (source) try {
				source = await updateEntry({ data: {
					id: source.id,
					kind: source.kind,
					meta: {
						...source.meta,
						spawnedFrom: sourceKey,
						spawnedKind: link.kind,
						spawnedId: String(created.id),
						spawnedPages: mergeSpawnedPages(source.meta, link.path)
					}
				} });
			} catch {
				source = {
					...source,
					meta: {
						...source.meta,
						spawnedKind: link.kind,
						spawnedId: String(created.id),
						spawnedPages: mergeSpawnedPages(source.meta, link.path)
					}
				};
			}
			setAdded((prev) => Array.from(/* @__PURE__ */ new Set([...prev, link.path])));
			setOpen(false);
			resetPick();
			onSpawned?.(created, source, link);
			const where = [
				link.label,
				catName(live, link.category),
				catName(live, link.subcategory)
			].filter(Boolean).join(" · ");
			toast.success(`Added to ${where || assignLabel(link)}.`, { action: {
				label: "Open",
				onClick: () => navigate({ to: link.path })
			} });
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not add that entry.");
		} finally {
			setPending(false);
		}
	}
	async function choosePage(next) {
		if (added.includes(next.path)) {
			toast.message(`Already on ${next.label}.`);
			return;
		}
		if (!canAssign(me, next)) {
			toast.message(lockedCopy(next.kind));
			return;
		}
		setPage(next);
		setCatTrail([]);
		setPending(true);
		try {
			const usable = (await listCategories({ data: { kind: next.kind } })).filter((item) => !item.archived);
			setCats(usable);
			if (!catChildren(usable, null).length) await commit(next, null, null, usable);
		} catch {
			setCats([]);
			await commit(next, null, null, []);
		} finally {
			setPending(false);
		}
	}
	function chooseCat(slug, at) {
		if (!page) return;
		if (!slug) {
			const used = at === 0 ? null : catTrail[at - 1] ?? null;
			const stored = catStore(cats, used);
			commit(page, stored.category, stored.subcategory);
			return;
		}
		if (!catChildren(cats, slug).length) {
			const stored = catStore(cats, slug);
			commit(page, stored.category, stored.subcategory);
			return;
		}
		setCatTrail([...catTrail.slice(0, at), slug]);
	}
	const nestedRows = catTrail.map((slug, i) => ({
		slug,
		items: catChildren(cats, slug),
		at: i + 1
	})).filter((row) => row.items.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full min-w-0",
		onClick: (event) => event.stopPropagation(),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: cn("inline-flex min-h-9 cursor-pointer items-center gap-2 text-sm", pending && "cursor-default"),
			title: done ? "Add this to another page" : "Choose a page, category, and subcategory",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				className: "size-4 accent-primary",
				checked: done || open,
				disabled: pending,
				onChange: (event) => {
					if (event.target.checked) {
						resetPick();
						setOpen(true);
					} else if (!done) {
						setOpen(false);
						resetPick();
					} else setOpen((value) => {
						if (value) resetPick();
						return !value;
					});
				}
			}), done && last && !open ? last.path === "/talk" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/talk",
				className: "text-primary underline-offset-2 hover:underline",
				onClick: (e) => e.stopPropagation(),
				children: ["Added to ", added.length > 1 ? `${added.length} pages` : last.label]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-foreground",
				children: ["Added to ", added.length > 1 ? `${added.length} pages` : last.label]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: open ? page ? "Choose a category" : "Choose a page" : "Add to a page"
			})]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 rounded-xl border border-border bg-secondary/50 p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
					children: page ? `${page.label} — pick a category` : "Tap a page, then a category if it has one."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex flex-wrap gap-1.5",
					children: ASSIGN_PAGES.map((item) => {
						const allowed = canAssign(me, item);
						const selected = added.includes(item.path);
						const current = page?.path === item.path;
						const isSuggested = suggested?.path === item.path && !page;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: !allowed || pending || selected,
							onClick: () => void choosePage(item),
							className: cn("h-9 rounded-full px-3 text-sm", selected ? "bg-primary text-primary-foreground" : current || isSuggested ? "border border-primary bg-card text-primary" : "bg-card text-muted-foreground hover:text-foreground", (!allowed || pending) && "opacity-40"),
							title: !allowed ? lockedCopy(item.kind) : selected ? `Already on ${item.label}` : `Add to ${item.label}`,
							children: pending && current ? "Adding…" : selected ? `On ${item.label}` : item.label
						}, item.path);
					})
				}),
				page && parents.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
						children: "Category"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap gap-1.5",
						children: [parents.map((item) => {
							const current = catTrail[0] === item.slug;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: pending,
								onClick: () => chooseCat(item.slug, 0),
								className: cn("h-9 rounded-full px-3 text-sm", current ? "border border-primary bg-card text-primary" : "bg-card text-muted-foreground hover:text-foreground", pending && "opacity-40"),
								children: item.name
							}, item.slug);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: pending,
							onClick: () => chooseCat(null, 0),
							className: "h-9 rounded-full bg-card px-3 text-sm text-muted-foreground hover:text-foreground",
							children: "No category"
						})]
					})]
				}) : null,
				page ? nestedRows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
						children: row.at === 1 ? "Subcategory" : "Nested category"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap gap-1.5",
						children: [row.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: pending,
							onClick: () => chooseCat(item.slug, row.at),
							className: cn("h-9 rounded-full px-3 text-sm", catTrail[row.at] === item.slug ? "border border-primary bg-card text-primary" : "bg-card text-muted-foreground hover:text-foreground", pending && "opacity-40"),
							children: item.name
						}, item.slug)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: pending,
							onClick: () => chooseCat(null, row.at),
							className: "h-9 rounded-full bg-card px-3 text-sm text-muted-foreground hover:text-foreground",
							children: "Stop here"
						})]
					})]
				}, `${row.slug}-${row.at}`)) : null
			]
		}) : done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-1 text-xs text-muted-foreground underline-offset-2 hover:text-foreground hover:underline",
			onClick: () => {
				resetPick();
				setOpen(true);
			},
			children: "Add to another page"
		}) : null]
	});
}
function categoryLabel(slug) {
	if (!slug) return "";
	return NOTE_LIBRARY_CATEGORIES.find((item) => item.value === slug)?.label ?? slug;
}
function liveForKey(entries, key) {
	return entries.find((item) => item.meta.libraryKey === key && item.status !== "archived") ?? null;
}
function LibraryDocDialog({ entry, doc, open, canEdit, catName, subName, onClose, onEdit, relatedKeys, me, onSpawned }) {
	const key = entry?.meta.libraryKey || doc?.key || "";
	const title = entry?.title ?? doc?.title ?? "Note";
	const body = entry?.body ?? doc?.body ?? "";
	const cat = catName || categoryLabel(entry?.category ?? doc?.category);
	const sub = subName || categoryLabel(entry?.subcategory ?? doc?.subcategory);
	const talk = key ? talkPromptsForLibrary(key) : [];
	const extras = libraryDocsForKeys((relatedKeys ?? []).filter((item) => item !== key));
	const spawnLink = entry ? linkForEntry(entry) : doc ? LIBRARY_LINKS[doc.key] ?? (doc.category === "exercises" ? linkForActivity(doc.subcategory) : doc.category === "ideas" ? linkForIdea(doc.subcategory) : null) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (next) => {
			if (!next) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "w-[min(100%-1.5rem,44rem)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: [cat, sub].filter(Boolean).join(" · ") || "Library" })] }),
				body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, {
					html: body,
					className: "text-sm text-foreground"
				}) : null,
				extras.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 border-t border-border pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
						children: "Also in Notes"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5",
						children: extras.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/notes",
							className: "rounded-full bg-secondary px-3 py-1.5 text-xs text-muted-foreground hover:text-foreground",
							onClick: onClose,
							children: item.title
						}, item.key))
					})]
				}) : null,
				talk.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 border-t border-border pt-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
							children: "Talk prompts"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-1.5 text-sm text-muted-foreground",
							children: talk.map((prompt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "rounded-lg bg-secondary/70 px-3 py-2",
								children: prompt
							}, prompt))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/talk",
							className: "inline-flex text-sm text-primary underline-offset-2 hover:underline",
							onClick: onClose,
							children: "Open Talk"
						})
					]
				}) : null,
				entry ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-t border-border pt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpawnCheckbox, {
						suggested: spawnLink,
						title,
						body,
						sourceKey: sourceKeyFor(entry),
						sourceEntry: entry,
						me,
						onSpawned
					})
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-end gap-2",
					children: [canEdit && onEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: onEdit,
						children: "Personalise"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/notes",
							onClick: onClose,
							children: "Open Notes"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: onClose,
						children: "Close"
					})]
				})
			]
		})
	});
}
function MoreInfoButton({ keys, text, texts, weekKind, quizId, kinkSlug, className, tone = "default" }) {
	const resolved = (0, import_react.useMemo)(() => (keys?.length ? keys : relatedLibraryKeys({
		text,
		texts,
		weekKind,
		quizId,
		kinkSlug
	})).slice(0, 3), [
		keys,
		text,
		texts,
		weekKind,
		quizId,
		kinkSlug
	]);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [active, setActive] = (0, import_react.useState)(resolved[0] ?? "");
	const [entries, setEntries] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setActive(resolved[0] ?? "");
		listEntries({ data: { kind: "note" } }).then(setEntries).catch(() => setEntries([]));
	}, [open, resolved]);
	if (!resolved.length) return null;
	const docs = libraryDocsForKeys(resolved);
	const current = docs.find((item) => item.key === active) ?? docs[0] ?? null;
	const live = current ? liveForKey(entries, current.key) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: (event) => {
			event.preventDefault();
			event.stopPropagation();
			setOpen(true);
		},
		className: cn("inline-flex h-9 items-center gap-1.5 rounded-full px-3 text-xs font-medium uppercase tracking-[0.14em]", tone === "onIvory" ? "bg-oxblood/10 text-oxblood hover:bg-oxblood/16" : "bg-secondary text-muted-foreground hover:text-foreground", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-3.5" }), "More info"]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "w-[min(100%-1.5rem,44rem)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: live?.title ?? current?.title ?? "More info" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: [categoryLabel(current?.category), categoryLabel(current?.subcategory)].filter(Boolean).join(" · ") || "From Notes" })] }),
				docs.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: docs.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setActive(item.key),
						className: cn("h-8 rounded-full px-3 text-xs", (current?.key ?? "") === item.key ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
						children: item.title
					}, item.key))
				}) : null,
				live?.body || current?.body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, {
					html: live?.body ?? current?.body ?? "",
					className: "text-sm text-foreground"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/notes",
							onClick: () => setOpen(false),
							children: "Open Notes"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => setOpen(false),
						children: "Close"
					})]
				})
			]
		})
	})] });
}
function PdfField({ pdfs, onChange, max = 3, label = "PDFs" }) {
	const inputRef = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function onPick(event) {
		const files = Array.from(event.currentTarget.files ?? []);
		event.currentTarget.value = "";
		if (!files.length) return;
		const room = max - pdfs.length;
		if (room <= 0) {
			toast.error(`You can attach up to ${max} PDFs.`);
			return;
		}
		setBusy(true);
		try {
			const next = [...pdfs];
			for (const file of files.slice(0, room)) {
				if (!isPdfFile(file)) {
					toast.error(`${file.name} is not a PDF.`);
					continue;
				}
				next.push(await readPdfFile(file));
			}
			onChange(next);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not read that PDF.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						pdfs.length,
						"/",
						max
					]
				})]
			}),
			pdfs.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1.5",
				children: pdfs.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2 rounded-md bg-secondary px-2 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4 shrink-0 text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 flex-1 truncate text-sm",
							children: item.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-9 place-items-center rounded-md text-muted-foreground hover:text-foreground",
							onClick: () => onChange(pdfs.filter((_, i) => i !== index)),
							"aria-label": `Remove ${item.name}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
						})
					]
				}, `${item.name}-${index}`))
			}) : null,
			pdfs.length < max ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: cn("relative flex h-11 w-full cursor-pointer items-center justify-center gap-2 rounded-md border border-dashed border-input text-sm text-muted-foreground hover:border-primary/50 hover:text-foreground", busy && "pointer-events-none opacity-60"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4" }),
					busy ? "Adding…" : "Add PDF",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: inputRef,
						type: "file",
						accept: "application/pdf,.pdf",
						multiple: max - pdfs.length > 1,
						className: "absolute inset-0 cursor-pointer opacity-0",
						onChange: (event) => void onPick(event)
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [
					"Up to ",
					max,
					" files, 2 MB each. Opens from the entry later."
				]
			})] }) : null
		]
	});
}
function PdfStrip({ pdfs, className }) {
	if (!pdfs.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: cn("space-y-1", className),
		children: pdfs.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			href: item.data,
			download: item.name,
			target: "_blank",
			rel: "noreferrer",
			className: "flex h-10 items-center gap-2 rounded-md bg-secondary px-2 text-sm text-foreground hover:bg-raised",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0 truncate",
				children: item.name
			})]
		}) }, `${item.name}-${index}`))
	});
}
var WEEKDAYS = [
	"Sun",
	"Mon",
	"Tue",
	"Wed",
	"Thu",
	"Fri",
	"Sat"
];
var CADENCES = [
	"daily",
	"habit",
	"weekly",
	"custom",
	"once"
];
function catalogIdsFrom(meta) {
	return (meta.catalogIds ?? "").split(",").map((s) => s.trim()).filter(Boolean);
}
function fromEntry(entry, defaultAssignee = "", defaultCadence) {
	const meta = { ...entry?.meta ?? {} };
	return {
		title: entry?.title ?? "",
		body: entry?.body ?? "",
		cadence: entry?.cadence ?? (entry?.kind === "task" ? defaultCadence || "daily" : defaultCadence || ""),
		weekday: entry?.weekday ?? null,
		status: entry?.status ?? "open",
		category: entry?.category ?? "",
		subcategory: entry?.subcategory ?? "",
		assignedTo: entry?.assignedTo ?? defaultAssignee,
		intensity: entry?.intensity ?? null,
		photos: entry?.photos ?? (entry?.photoData ? [entry.photoData] : []),
		videos: entry?.videos ?? [],
		pdfs: entry?.pdfs ?? [],
		catalogIds: catalogIdsFrom(meta),
		visibility: meta.visibility === "private" ? "private" : "shared",
		stakesMode: stakesModeOf(meta),
		points: meta.points ?? "",
		skipPoints: meta.skipPoints ?? "",
		rewardIds: parseIdList(meta.rewardIds).map(String),
		punishmentIds: parseIdList(meta.punishmentIds).map(String),
		reminderEnabled: meta.reminderEnabled === "1",
		reminderTime: meta.reminderTime ?? "09:00",
		customDays: parseCustomDays(meta.customDays),
		urgency: urgencyOf(meta),
		cost: meta.cost ?? "",
		earnedCount: meta.earnedCount ?? (entry?.kind === "punishment" && entry.assignedTo ? "1" : "0"),
		cards: parseLineList(meta.cards).join("\n"),
		prompts: parseLineList(meta.prompts).join("\n"),
		catalogRoles: parseCatalogRoles(meta),
		countdownDays: String(parseCountdown(meta).days || ""),
		countdownHours: String(parseCountdown(meta).hours || ""),
		countdownMinutes: String(parseCountdown(meta).minutes || ""),
		onWheel: meta.onWheel !== "0",
		meta
	};
}
function EntryForm({ config, entry, open, onOpenChange, onSaved, defaultCadence, defaultCategory, defaultSubcategory, addLabel, readOnly = false }) {
	const spec = fillSelectOptions(config);
	const [me, setMe] = (0, import_react.useState)(null);
	const [cats, setCats] = (0, import_react.useState)([]);
	const [catalog, setCatalog] = (0, import_react.useState)([]);
	const [rewards, setRewards] = (0, import_react.useState)([]);
	const [punishments, setPunishments] = (0, import_react.useState)([]);
	const [draft, setDraft] = (0, import_react.useState)(() => fromEntry(entry, "", defaultCadence));
	const [saving, setSaving] = (0, import_react.useState)(false);
	const entryId = entry?.id ?? null;
	const entryRef = (0, import_react.useRef)(entry);
	entryRef.current = entry;
	const persistSeq = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const current = entryRef.current;
		setDraft(fromEntry(current, current?.assignedTo ?? "", defaultCadence));
		let cancelled = false;
		getMe().then((data) => {
			if (cancelled) return;
			setMe(data);
			const fallback = data.partner?.userId ?? data.profile?.userId ?? "";
			setDraft((prev) => {
				const next = { ...prev };
				if (!next.assignedTo || next.assignedTo === "both" && !data.partner) next.assignedTo = current?.assignedTo && current.assignedTo !== "both" ? current.assignedTo : fallback;
				if (!current && spec.kind === "game" && !next.category) next.category = "card";
				if (!current && spec.kind === "task" && defaultCadence && !next.cadence) next.cadence = defaultCadence;
				if (!current && defaultCategory && !next.category) {
					next.category = defaultCategory;
					next.subcategory = defaultSubcategory ?? "";
				}
				return next;
			});
		});
		listCategories({ data: { kind: spec.kind } }).then(setCats).catch(() => setCats([]));
		if (spec.catalogLink) listEntries({ data: { kind: "catalog" } }).then(setCatalog).catch(() => setCatalog([]));
		if (spec.stakes) {
			listEntries({ data: { kind: "reward" } }).then(setRewards).catch(() => setRewards([]));
			listEntries({ data: { kind: "punishment" } }).then(setPunishments).catch(() => setPunishments([]));
		}
		return () => {
			cancelled = true;
		};
	}, [
		open,
		entryId,
		spec.kind,
		spec.catalogLink,
		spec.stakes,
		defaultCadence,
		defaultCategory,
		defaultSubcategory
	]);
	const parents = (0, import_react.useMemo)(() => catChildren(cats, null), [cats]);
	const catChain = (0, import_react.useMemo)(() => {
		const leaf = draft.subcategory || draft.category;
		const path = catPath(cats, leaf);
		if (path.length && path[0]?.slug === draft.category) return path;
		const root = cats.find((c) => c.slug === draft.category);
		return root ? [root, ...path.filter((item) => item.slug !== root.slug)] : path;
	}, [
		cats,
		draft.category,
		draft.subcategory
	]);
	const nestedLevels = (0, import_react.useMemo)(() => {
		const levels = [];
		if (!draft.category) return levels;
		let parent = draft.category;
		for (let i = 1; i < 8; i += 1) {
			const items = catChildren(cats, parent);
			if (!items.length) break;
			const value = catChain[i]?.slug ?? "";
			levels.push({
				parent,
				items,
				value
			});
			if (!value) break;
			parent = value;
		}
		return levels;
	}, [
		cats,
		catChain,
		draft.category
	]);
	const cadenceOptions = (0, import_react.useMemo)(() => {
		if (!entry && defaultCadence === "habit") return ["habit"];
		if (!entry && defaultCadence) return CADENCES.filter((value) => value !== "habit");
		return CADENCES;
	}, [entry, defaultCadence]);
	const catalogGroups = (0, import_react.useMemo)(() => {
		const known = new Set((KINDS.catalog.categories ?? []).map((group) => group.value));
		const groups = (KINDS.catalog.categories ?? []).map((group) => ({
			...group,
			items: catalog.filter((item) => item.category === group.value)
		}));
		const rest = catalog.filter((item) => !item.category || !known.has(item.category));
		if (rest.length) groups.push({
			value: "other",
			label: "Other",
			items: rest
		});
		return groups.filter((group) => group.items.length > 0);
	}, [catalog]);
	function setMeta(key, value) {
		setDraft((prev) => ({
			...prev,
			meta: {
				...prev.meta,
				[key]: value
			}
		}));
	}
	async function persist(close) {
		if (!draft.title.trim()) {
			if (close) toast.error("Give it a title.");
			return;
		}
		const current = entryRef.current;
		const seq = ++persistSeq.current;
		setSaving(true);
		try {
			const titles = catalog.filter((item) => draft.catalogIds.includes(String(item.id))).map((item) => item.title);
			const rewardTitles = rewards.filter((item) => draft.rewardIds.includes(String(item.id))).map((item) => item.title);
			const punishmentTitles = punishments.filter((item) => draft.punishmentIds.includes(String(item.id))).map((item) => item.title);
			const meta = applyVideos(applyPdfs({ ...draft.meta }, draft.pdfs), draft.videos);
			meta.catalogIds = draft.catalogIds.join(",");
			meta.catalogTitles = titles.join(" · ");
			if (spec.kind === "journal") meta.visibility = draft.visibility;
			if (spec.kind === "task") meta.urgency = draft.urgency || "normal";
			else delete meta.urgency;
			if (draft.cadence === "custom") meta.customDays = encodeCustomDays(draft.customDays);
			else delete meta.customDays;
			if (spec.shop) {
				if (canSetCost(me)) {
					const cost = parsePoints(draft.cost);
					if (cost != null && cost > 0) meta.cost = String(cost);
					else delete meta.cost;
				} else if (current?.meta.cost) meta.cost = current.meta.cost;
				else delete meta.cost;
			}
			if (isCountedKind(spec.kind)) {
				if (canSetEarnedCount(me)) {
					const n = Number(draft.earnedCount);
					meta.earnedCount = String(Number.isFinite(n) && n >= 0 ? Math.min(999, Math.trunc(n)) : 0);
				} else if (current?.meta.earnedCount != null && current.meta.earnedCount !== "") meta.earnedCount = current.meta.earnedCount;
				else meta.earnedCount = spec.kind === "punishment" && draft.assignedTo ? "1" : "0";
			}
			if (spec.kind === "game") {
				const cards = parseLineList(draft.cards).slice(0, 60);
				const prompts = parseLineList(draft.prompts).slice(0, 60);
				if (cards.length) meta.cards = JSON.stringify(cards);
				else delete meta.cards;
				if (prompts.length) meta.prompts = JSON.stringify(prompts);
				else delete meta.prompts;
				const roles = {};
				for (const id of draft.catalogIds) roles[id] = draft.catalogRoles[id] ?? "prop";
				if (Object.keys(roles).length) meta.catalogRoles = JSON.stringify(roles);
				else delete meta.catalogRoles;
			} else {
				delete meta.cards;
				delete meta.prompts;
				delete meta.catalogRoles;
			}
			if (spec.wheel) meta.onWheel = draft.onWheel ? "1" : "0";
			else delete meta.onWheel;
			if (usesCountdown(spec.kind, draft.cadence)) {
				if (canSetCountdown(me)) {
					const days = Math.max(0, Math.min(365, Math.trunc(Number(draft.countdownDays) || 0)));
					const hours = Math.max(0, Math.min(23, Math.trunc(Number(draft.countdownHours) || 0)));
					const minutes = Math.max(0, Math.min(59, Math.trunc(Number(draft.countdownMinutes) || 0)));
					if (days || hours || minutes) {
						meta.countdownDays = String(days);
						meta.countdownHours = String(hours);
						meta.countdownMinutes = String(minutes);
						const prev = current ? parseCountdown(current.meta) : {
							days: 0,
							hours: 0,
							minutes: 0
						};
						meta.countdownAnchor = !current || prev.days !== days || prev.hours !== hours || prev.minutes !== minutes || !current?.meta.countdownAnchor ? (/* @__PURE__ */ new Date()).toISOString() : current.meta.countdownAnchor;
					} else {
						delete meta.countdownDays;
						delete meta.countdownHours;
						delete meta.countdownMinutes;
						delete meta.countdownAnchor;
					}
				} else if (current) for (const key of [
					"countdownDays",
					"countdownHours",
					"countdownMinutes",
					"countdownAnchor"
				]) if (current.meta[key]) meta[key] = current.meta[key];
				else delete meta[key];
			} else {
				delete meta.countdownDays;
				delete meta.countdownHours;
				delete meta.countdownMinutes;
				delete meta.countdownAnchor;
			}
			if (spec.stakes) {
				meta.stakesMode = draft.stakesMode;
				const pts = parsePoints(draft.points);
				const skip = parsePoints(draft.skipPoints);
				if (usesPoints(draft.stakesMode) && pts != null) meta.points = String(pts);
				else delete meta.points;
				if (usesPoints(draft.stakesMode) && skip != null) meta.skipPoints = String(skip);
				else delete meta.skipPoints;
				if (usesRewards(draft.stakesMode)) {
					meta.rewardIds = draft.rewardIds.join(",");
					meta.rewardTitles = rewardTitles.join(" · ");
				} else {
					delete meta.rewardIds;
					delete meta.rewardTitles;
				}
				if (usesPunishments(draft.stakesMode)) {
					meta.punishmentIds = draft.punishmentIds.join(",");
					meta.punishmentTitles = punishmentTitles.join(" · ");
				} else {
					delete meta.punishmentIds;
					delete meta.punishmentTitles;
				}
				meta.reminderEnabled = draft.reminderEnabled ? "1" : "0";
				meta.reminderTime = draft.reminderEnabled ? draft.reminderTime : "";
			}
			const payload = {
				kind: spec.kind,
				title: draft.title.trim(),
				body: draft.body,
				cadence: spec.kind === "task" ? draft.cadence || "daily" : draft.cadence || null,
				weekday: draft.weekday,
				status: draft.status,
				category: draft.category || null,
				subcategory: draft.subcategory || null,
				assignedTo: spec.assignable ? draft.assignedTo || null : null,
				intensity: draft.intensity,
				photos: draft.photos,
				photoData: draft.photos[0] ?? null,
				meta
			};
			const saved = current ? await updateEntry({ data: {
				id: current.id,
				...payload
			} }) : await createEntry({ data: payload });
			if (seq !== persistSeq.current) return;
			if (current) entryRef.current = saved;
			onSaved(saved);
			if (close) onOpenChange(false);
		} catch (err) {
			if (close) toast.error(err instanceof Error ? err.message : "Could not save.");
			else throw err;
		} finally {
			setSaving(false);
		}
	}
	const autoStatus = useAutoSave(JSON.stringify(draft), () => persist(false), {
		delay: 700,
		enabled: Boolean(open && entryId && !readOnly && draft.title.trim()),
		resetKey: `${open}:${entryId ?? "new"}`
	});
	async function remove() {
		if (!entry) return;
		if (typeof window !== "undefined" && !window.confirm(`Delete “${entry.title}”? This cannot be undone.`)) return;
		setSaving(true);
		try {
			await deleteEntry({ data: { id: entry.id } });
			onSaved(entry, true);
			onOpenChange(false);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not delete.");
		} finally {
			setSaving(false);
		}
	}
	async function archiveNow() {
		if (!entry) return;
		const nextStatus = draft.status === "archived" ? "open" : "archived";
		setSaving(true);
		try {
			onSaved(await updateEntry({ data: {
				id: entry.id,
				kind: spec.kind,
				status: nextStatus
			} }));
			onOpenChange(false);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not archive.");
		} finally {
			setSaving(false);
		}
	}
	const profile = me?.profile;
	const partner = me?.partner;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (next) => {
			if (!next && entryId && !readOnly && draft.title.trim()) persist(false).catch(() => {});
			onOpenChange(next);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: entry ? readOnly ? "View" : "Edit" : addLabel ?? spec.addLabel }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: spec.blurb })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("space-y-4", readOnly && "pointer-events-none opacity-90"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Title",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: draft.title,
						onChange: (e) => setDraft((p) => ({
							...p,
							title: e.target.value
						})),
						placeholder: "Name this",
						maxLength: 160
					})
				}),
				spec.kind === "journal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					label: "Visibility",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-1 rounded-lg bg-secondary p-1",
						children: ["shared", "private"].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setDraft((p) => ({
								...p,
								visibility: value
							})),
							className: cn("h-9 rounded-md text-sm capitalize", draft.visibility === value ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"),
							children: value
						}, value))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: draft.visibility === "private" ? "Only you can read this page." : "Your partner can read this page and leave comments."
					})]
				}) : null,
				spec.assignable && profile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Assign to",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: draft.assignedTo,
						onChange: (e) => setDraft((p) => ({
							...p,
							assignedTo: e.target.value
						})),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: profile.userId,
								children: [
									profile.displayName || "Me",
									" (",
									profile.role,
									")"
								]
							}),
							partner ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: partner.userId,
								children: [
									partner.displayName || "Partner",
									" (",
									partner.role,
									")"
								]
							}) : null,
							partner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "both",
								children: "Both of us"
							}) : null
						]
					})
				}) : null,
				isCountedKind(spec.kind) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					label: `Times ${countWord(spec.kind)}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: 0,
						max: 999,
						inputMode: "numeric",
						value: draft.earnedCount,
						disabled: !canSetEarnedCount(me),
						onChange: (e) => setDraft((p) => ({
							...p,
							earnedCount: e.target.value
						})),
						placeholder: "0"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: canSetEarnedCount(me) ? `How many times this has been ${countWord(spec.kind)}. Completing it still adds to this.` : "Your Dominant has locked these counts. Completing still belongs to you."
					})]
				}) : null,
				spec.kind === "task" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Importance",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-4 gap-1 rounded-lg bg-secondary p-1",
						children: URGENCY.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setDraft((p) => ({
								...p,
								urgency: item.value
							})),
							className: cn("h-9 rounded-md text-sm", draft.urgency === item.value ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"),
							children: item.label
						}, item.value))
					})
				}) : null,
				spec.shop ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					label: "Points cost",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: 0,
						inputMode: "numeric",
						value: draft.cost,
						disabled: !canSetCost(me),
						onChange: (e) => setDraft((p) => ({
							...p,
							cost: e.target.value
						})),
						placeholder: "Leave blank if it is not for sale"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: canSetCost(me) ? "The Submissive can spend their points to buy this. Leave empty to grant it without a price." : "Your Dominant has locked price changes. You can still buy it with your points."
					})]
				}) : null,
				parents.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Category",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: draft.category,
						onChange: (e) => setDraft((p) => ({
							...p,
							category: e.target.value,
							subcategory: ""
						})),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Choose…"
						}), parents.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: opt.slug,
							children: opt.name
						}, opt.slug))]
					})
				}) : null,
				nestedLevels.map((level, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: index === 0 ? "Sub-category" : "Nested category",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: level.value,
						onChange: (e) => {
							const next = e.target.value;
							setDraft((p) => {
								if (!next) return {
									...p,
									subcategory: index === 0 ? "" : catChain[index]?.slug ?? ""
								};
								const stored = catStore(cats, next);
								return {
									...p,
									category: stored.category ?? p.category,
									subcategory: stored.subcategory ?? next
								};
							});
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "None"
						}), level.items.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: opt.slug,
							children: opt.name
						}, opt.slug))]
					})
				}, `${level.parent}-${index}`)),
				spec.fields.map((field) => {
					if (field.key === "category") return null;
					if (field.key === "body") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: field.label,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichEditor, {
							value: draft.body,
							onChange: (html) => setDraft((p) => ({
								...p,
								body: html
							})),
							placeholder: field.placeholder
						})
					}, field.key);
					if (field.type === "cadence") {
						if (cadenceOptions.length <= 1) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
							label: field.label,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-1 rounded-lg bg-secondary p-1",
									children: cadenceOptions.map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setDraft((p) => ({
											...p,
											cadence: value
										})),
										className: cn("h-9 min-w-14 flex-1 rounded-md px-2 text-sm capitalize", draft.cadence === value ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"),
										children: value
									}, value))
								}),
								draft.cadence === "weekly" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex flex-wrap gap-1",
									children: WEEKDAYS.map((day, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setDraft((p) => ({
											...p,
											weekday: p.weekday === i ? null : i
										})),
										className: cn("h-9 min-w-11 rounded-md px-2 text-xs", draft.weekday === i ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"),
										children: day
									}, day))
								}) : null,
								draft.cadence === "custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mb-1 text-xs text-muted-foreground",
										children: "Set days"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap gap-1",
										children: WEEKDAYS.map((day, i) => {
											const on = draft.customDays.includes(i);
											return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setDraft((p) => ({
													...p,
													customDays: on ? p.customDays.filter((d) => d !== i) : [...p.customDays, i].sort((a, b) => a - b)
												})),
												className: cn("h-9 min-w-11 rounded-md px-2 text-xs", on ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"),
												children: day
											}, day);
										})
									})]
								}) : null
							]
						}, field.key);
					}
					if (field.type === "select") {
						if (field.key === "category" && parents.length) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: field.label,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: draft.category,
								onChange: (e) => setDraft((p) => ({
									...p,
									category: e.target.value,
									subcategory: ""
								})),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Choose…"
								}), (field.options ?? []).map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: opt.value,
									children: opt.label
								}, opt.value))]
							})
						}, field.key);
					}
					if (field.type === "intensity") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: field.label,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-1.5",
							children: [
								1,
								2,
								3,
								4,
								5
							].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setDraft((p) => ({
									...p,
									intensity: p.intensity === n ? null : n
								})),
								className: cn("size-9 rounded-full border", (draft.intensity ?? 0) >= n ? "border-primary bg-primary" : "border-input bg-transparent"),
								"aria-label": `${n}`
							}, n))
						})
					}, field.key);
					if (field.type === "textarea") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: field.label,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichEditor, {
							value: draft.meta[field.key] ?? "",
							onChange: (html) => setMeta(field.key, html),
							placeholder: field.placeholder,
							compact: true
						})
					}, field.key);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: field.label,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: draft.meta[field.key] ?? "",
							onChange: (e) => setMeta(field.key, e.target.value),
							placeholder: field.placeholder
						})
					}, field.key);
				}),
				spec.stakes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskStakes, {
					draft,
					setDraft,
					rewards,
					punishments,
					canSkip: spec.kind === "task" || spec.kind === "rabbit"
				}) : null,
				spec.catalogLink ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "From the catalogue" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: spec.kind === "game" ? "Attach a piece as a prop, or use it as a card or a prompt you can draw." : "Attach toys, outfits, accessories, restraints, furniture, or spaces."
						}),
						catalog.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "rounded-md bg-secondary px-3 py-3 text-sm text-muted-foreground",
							children: [
								"The catalogue is empty.",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/catalog",
									className: "text-primary underline-offset-2 hover:underline",
									children: "Add items"
								}),
								", then attach them here."
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "max-h-64 space-y-3 overflow-y-auto",
							children: catalogGroups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-1 text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground",
								children: group.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 gap-1 sm:grid-cols-2",
								children: group.items.map((item) => {
									const id = String(item.id);
									const on = draft.catalogIds.includes(id);
									const role = on ? draft.catalogRoles[id] ?? "prop" : null;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: cn("rounded-md border px-2 py-2", on ? "border-primary bg-primary/10" : "border-border"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setDraft((p) => {
												if (on) {
													const nextRoles = { ...p.catalogRoles };
													delete nextRoles[id];
													return {
														...p,
														catalogIds: p.catalogIds.filter((value) => value !== id),
														catalogRoles: nextRoles
													};
												}
												return {
													...p,
													catalogIds: [...p.catalogIds, id],
													catalogRoles: {
														...p.catalogRoles,
														[id]: "prop"
													}
												};
											}),
											className: "flex w-full items-center gap-2 text-left text-xs",
											children: [item.photos[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: item.photos[0],
												alt: "",
												className: "size-8 shrink-0 rounded object-cover"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "grid size-8 shrink-0 place-items-center rounded bg-secondary text-[10px] uppercase text-muted-foreground",
												children: group.label.slice(0, 2)
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "truncate",
												children: item.title
											})]
										}), on && spec.kind === "game" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-2 flex flex-wrap gap-1",
											children: CATALOG_ROLES.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												title: option.hint,
												onClick: () => setDraft((p) => ({
													...p,
													catalogRoles: {
														...p.catalogRoles,
														[id]: option.value
													}
												})),
												className: cn("h-7 rounded-full px-2.5 text-[11px]", role === option.value ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
												children: option.label
											}, option.value))
										}) : null]
									}, item.id);
								})
							})] }, group.value))
						})
					]
				}) : null,
				spec.kind === "game" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					label: "Cards",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: draft.cards,
						disabled: readOnly,
						onChange: (e) => setDraft((p) => ({
							...p,
							cards: e.target.value
						})),
						placeholder: "Present — Kneel until you are acknowledged.\nHold still — Stay in position until released.",
						className: "min-h-28 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "One card per line. Use Title — the command if you want a subtitle. Catalogue pieces set to Card join this pile when you draw."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					label: "Prompts",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: draft.prompts,
						disabled: readOnly,
						onChange: (e) => setDraft((p) => ({
							...p,
							prompts: e.target.value
						})),
						placeholder: "What would you do if I asked you to wait here?\nName a limit you want restated.",
						className: "min-h-28 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "One prompt per line. Catalogue pieces set to Prompt join this pile."
					})]
				})] }) : null,
				spec.wheel ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 rounded-lg bg-secondary/70 px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Add to the wheel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Spin this page's chance wheel and this title can come up."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: readOnly,
						onClick: () => setDraft((p) => ({
							...p,
							onWheel: !p.onWheel
						})),
						className: cn("h-9 rounded-full px-3 text-sm", draft.onWheel ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
						children: draft.onWheel ? "On the wheel" : "Off"
					})]
				}) : null,
				usesCountdown(spec.kind, draft.cadence) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: countdownMode(spec.kind) === "starts" ? "Time until it starts" : "Time until it ends" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-xs text-muted-foreground",
									children: ["Days", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										min: 0,
										max: 365,
										disabled: readOnly || !canSetCountdown(me),
										value: draft.countdownDays,
										onChange: (e) => setDraft((p) => ({
											...p,
											countdownDays: e.target.value
										}))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-xs text-muted-foreground",
									children: ["Hours", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										min: 0,
										max: 23,
										disabled: readOnly || !canSetCountdown(me),
										value: draft.countdownHours,
										onChange: (e) => setDraft((p) => ({
											...p,
											countdownHours: e.target.value
										}))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-xs text-muted-foreground",
									children: ["Minutes", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										min: 0,
										max: 59,
										disabled: readOnly || !canSetCountdown(me),
										value: draft.countdownMinutes,
										onChange: (e) => setDraft((p) => ({
											...p,
											countdownMinutes: e.target.value
										}))
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: canSetCountdown(me) ? "Shown as a countdown on Home. Saving a new duration starts the clock from now." : "Your Dominant has locked timers. Completing this still belongs to you."
						})
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Status",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						value: draft.status,
						onChange: (e) => setDraft((p) => ({
							...p,
							status: e.target.value
						})),
						children: spec.statuses.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: status.value,
							children: status.label
						}, status.value))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaField, {
					photos: draft.photos,
					videos: draft.videos,
					onPhotos: (photos) => setDraft((p) => ({
						...p,
						photos
					})),
					onVideos: (videos) => setDraft((p) => ({
						...p,
						videos
					}))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PdfField, {
					pdfs: draft.pdfs,
					onChange: (pdfs) => setDraft((p) => ({
						...p,
						pdfs
					}))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap items-center gap-2 pt-1",
					children: entry && !readOnly ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveHint, { status: saving ? "saving" : autoStatus }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => void persist(true),
								disabled: saving,
								children: "Done"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => void archiveNow(),
								disabled: saving,
								children: draft.status === "archived" ? "Unarchive" : "Archive"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => void remove(),
								disabled: saving,
								children: "Delete"
							})
						]
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void persist(true),
						disabled: saving || readOnly,
						className: "flex-1",
						children: readOnly ? "View only" : saving ? "Saving…" : "Save"
					})
				})
			]
		})] })
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function TaskStakes({ draft, setDraft, rewards, punishments, canSkip }) {
	const modes = [
		{
			value: "none",
			label: "None"
		},
		{
			value: "points",
			label: "Points"
		},
		{
			value: "items",
			label: "Reward"
		},
		{
			value: "punishments",
			label: "Punishments"
		}
	];
	const openRewards = rewards.filter((item) => item.status !== "archived");
	const openPunishments = punishments.filter((item) => item.status !== "archived");
	const selectedMode = draft.stakesMode === "both" ? "punishments" : draft.stakesMode;
	function toggleId(key, id) {
		setDraft((p) => {
			const on = p[key].includes(id);
			return {
				...p,
				[key]: on ? p[key].filter((item) => item !== id) : [...p[key], id]
			};
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-lg border border-border p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "Stakes",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-4 gap-1 rounded-lg bg-secondary p-1",
					children: modes.map((mode) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setDraft((p) => ({
							...p,
							stakesMode: mode.value
						})),
						className: cn("h-9 rounded-md text-xs", selectedMode === mode.value ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"),
						children: mode.label
					}, mode.value))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Completing assigns points or a reward. Skipping or missing the due time assigns a punishment."
				})]
			}),
			usesPoints(draft.stakesMode) ? canSkip ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Points if done",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						inputMode: "numeric",
						value: draft.points,
						onChange: (e) => setDraft((p) => ({
							...p,
							points: e.target.value
						})),
						placeholder: "e.g. 10"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Points if missed",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						inputMode: "numeric",
						value: draft.skipPoints,
						onChange: (e) => setDraft((p) => ({
							...p,
							skipPoints: e.target.value
						})),
						placeholder: "e.g. -5"
					})
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Points if done",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					inputMode: "numeric",
					value: draft.points,
					onChange: (e) => setDraft((p) => ({
						...p,
						points: e.target.value
					})),
					placeholder: "e.g. 10"
				})
			}) : null,
			usesRewards(draft.stakesMode) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Rewards on complete" }), openRewards.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "No rewards posted yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1",
					children: openRewards.map((item) => {
						const on = draft.rewardIds.includes(String(item.id));
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => toggleId("rewardIds", String(item.id)),
							className: cn("rounded-full border px-3 py-1.5 text-xs", on ? "border-primary bg-primary/10" : "border-border text-muted-foreground"),
							children: item.title
						}, item.id);
					})
				})]
			}) : null,
			usesPunishments(draft.stakesMode) && canSkip ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Punishments if skipped or overdue" }), openPunishments.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "No punishments posted yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1",
					children: openPunishments.map((item) => {
						const on = draft.punishmentIds.includes(String(item.id));
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => toggleId("punishmentIds", String(item.id)),
							className: cn("rounded-full border px-3 py-1.5 text-xs", on ? "border-primary bg-primary/10" : "border-border text-muted-foreground"),
							children: item.title
						}, item.id);
					})
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "Reminder",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setDraft((p) => ({
							...p,
							reminderEnabled: !p.reminderEnabled
						})),
						className: cn("h-9 rounded-full px-3 text-sm", draft.reminderEnabled ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
						children: draft.reminderEnabled ? "On" : "Off"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "time",
						value: draft.reminderTime,
						disabled: !draft.reminderEnabled,
						onChange: (e) => setDraft((p) => ({
							...p,
							reminderTime: e.target.value
						})),
						className: "max-w-40"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Shown on Home while this is still open."
				})]
			})
		]
	});
}
var HIDDEN_META = /* @__PURE__ */ new Set([
	"catalogIds",
	"catalogTitles",
	"visibility",
	"stakesMode",
	"points",
	"skipPoints",
	"rewardIds",
	"punishmentIds",
	"rewardTitles",
	"punishmentTitles",
	"reminderTime",
	"reminderEnabled",
	PDF_META_KEY,
	VIDEO_META_KEY,
	"customDays",
	"urgency",
	"sortOrder",
	"overdueOn",
	"month",
	"day",
	"cost",
	"boughtBy",
	"boughtAt",
	"boughtCost",
	"earnedCount",
	"cards",
	"prompts",
	"catalogRoles",
	"onWheel",
	"countdownDays",
	"countdownHours",
	"countdownMinutes",
	"countdownAnchor",
	"libraryKey",
	"ideaBank",
	"ideaIndex",
	"spawnedFrom",
	"spawnedKind",
	"spawnedId",
	"spawnedPages"
]);
function KindPage({ kind, hideHeader = false, wheel, initialFilter, entryFilter, defaultCadence, addLabel, title, kicker, blurb, emptyTitle, emptyBody }) {
	const config = fillSelectOptions({
		...KINDS[kind],
		...title ? { title } : {},
		...kicker ? { kicker } : {},
		...blurb ? { blurb } : {},
		...addLabel ? { addLabel } : {},
		...emptyTitle ? { emptyTitle } : {},
		...emptyBody ? { emptyBody } : {}
	});
	const [entries, setEntries] = (0, import_react.useState)([]);
	const [cats, setCats] = (0, import_react.useState)([]);
	const [me, setMe] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [filter, setFilter] = (0, import_react.useState)(initialFilter ?? "all");
	const [trail, setTrail] = (0, import_react.useState)([]);
	const [editing, setEditing] = (0, import_react.useState)(void 0);
	const [reading, setReading] = (0, import_react.useState)(null);
	const [lightbox, setLightbox] = (0, import_react.useState)(null);
	const [manage, setManage] = (0, import_react.useState)(false);
	const [points, setPoints] = (0, import_react.useState)(null);
	const [catalog, setCatalog] = (0, import_react.useState)([]);
	const load = (0, import_react.useCallback)(async () => {
		try {
			const [rows, categories, mine, board, shelf] = await Promise.all([
				listEntries({ data: { kind } }),
				listCategories({ data: { kind } }),
				getMe(),
				config.shop ? getPoints() : Promise.resolve(null),
				kind === "game" ? listEntries({ data: { kind: "catalog" } }) : Promise.resolve([])
			]);
			setEntries(rows);
			setCats(categories);
			setMe(mine);
			if (board) setPoints(board);
			setCatalog(shelf);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not load.");
		} finally {
			setLoading(false);
		}
	}, [kind, config.shop]);
	(0, import_react.useEffect)(() => {
		setLoading(true);
		setFilter(initialFilter ?? "all");
		setTrail([]);
		setReading(null);
		load();
	}, [load, initialFilter]);
	(0, import_react.useEffect)(() => subscribeMe(setMe), []);
	useLiveReload(load);
	const playbookPrefill = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (kind !== "playbook" || playbookPrefill.current || !me?.profile?.experience) return;
		playbookPrefill.current = true;
		setFilter(parseExperience(me.profile.experience));
		setTrail([]);
	}, [kind, me?.profile?.experience]);
	const parents = sortNamed(cats.filter((c) => !c.parentSlug && !c.archived));
	const nestedRows = (0, import_react.useMemo)(() => {
		if (!parents.some((c) => c.slug === filter)) return [];
		const rows = [];
		let parent = filter;
		for (let i = 0; i <= trail.length; i += 1) {
			const items = sortNamed(catChildren(cats, parent));
			if (!items.length) break;
			const selected = trail[i] ?? "all";
			rows.push({
				parent,
				items,
				selected
			});
			if (selected === "all") break;
			parent = selected;
			if (i > 8) break;
		}
		return rows;
	}, [
		cats,
		filter,
		parents,
		trail
	]);
	const visible = (0, import_react.useMemo)(() => {
		return sortNamed(entries.filter((item) => {
			if (entryFilter && !entryFilter(item)) return false;
			const archived = isArchivedEntry(item);
			if (filter === "archived") return archived;
			if (archived) return false;
			if (filter === "all") return true;
			if (parents.some((c) => c.slug === filter)) {
				if (!trail.length) return item.category === filter || item.subcategory === filter;
				const focus = trail[trail.length - 1];
				return catDescendants(cats, focus).has(item.subcategory ?? "") || item.category === focus;
			}
			return item.effectiveStatus === filter || item.status === filter;
		}));
	}, [
		entries,
		filter,
		trail,
		parents,
		cats,
		entryFilter
	]);
	function onSaved(next, removed) {
		setEntries((prev) => {
			if (removed) return prev.filter((item) => item.id !== next.id);
			return prev.some((item) => item.id === next.id) ? prev.map((item) => item.id === next.id ? next : item) : [next, ...prev];
		});
	}
	async function toggle(entry) {
		if (dutiesPaused(me?.house) && isDutyKind(entry.kind)) {
			toast.message("Vacation is on. Resume it to complete duties.");
			return;
		}
		try {
			const done = entry.effectiveStatus !== "done";
			const updated = await toggleEntry({ data: {
				id: entry.id,
				done
			} });
			setEntries((prev) => prev.map((item) => item.id === updated.id ? updated : item));
			const note = outcomeMessage(entry, updated);
			if (note?.tone === "success") toast.success(note.text);
			else if (note) toast.message(note.text);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not update.");
		}
	}
	async function buy(entry) {
		try {
			const result = await buyEntry({ data: { id: entry.id } });
			setEntries((prev) => prev.map((item) => item.id === result.entry.id ? result.entry : item));
			setPoints(result.points);
			toast.success(`Bought for ${shopCost(result.entry.meta) ?? result.entry.meta.boughtCost} points.`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not buy.");
		}
	}
	async function saveBody(entry, html) {
		try {
			const updated = await updateEntry({ data: {
				id: entry.id,
				kind: entry.kind,
				body: html
			} });
			setEntries((prev) => prev.map((item) => item.id === updated.id ? updated : item));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not update.");
		}
	}
	async function archive(entry) {
		if (!canEditEntry(me, entry)) {
			toast.message(editDeniedCopy(me, entry));
			return;
		}
		try {
			const next = entry.status === "archived" ? "open" : "archived";
			const updated = await updateEntry({ data: {
				id: entry.id,
				kind: entry.kind,
				status: next
			} });
			setEntries((prev) => prev.map((item) => item.id === updated.id ? updated : item));
			toast.success(next === "archived" ? "Archived." : "Restored.");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not archive.");
		}
	}
	async function remove(entry) {
		if (!canEditEntry(me, entry)) {
			toast.message(editDeniedCopy(me, entry));
			return;
		}
		if (isLibraryNote(entry)) {
			await archive(entry);
			return;
		}
		if (typeof window !== "undefined" && !window.confirm(`Delete “${entry.title}”? This cannot be undone.`)) return;
		try {
			await deleteEntry({ data: { id: entry.id } });
			setEntries((prev) => prev.filter((item) => item.id !== entry.id));
			toast.success("Deleted.");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not delete.");
		}
	}
	async function moveEntry(entry, dir) {
		const ids = visible.map((item) => item.id);
		const index = ids.indexOf(entry.id);
		const next = index + dir;
		if (index < 0 || next < 0 || next >= ids.length) return;
		const swapped = [...ids];
		[swapped[index], swapped[next]] = [swapped[next], swapped[index]];
		const order = new Map(swapped.map((id, i) => [id, i + 1]));
		setEntries((prev) => prev.map((item) => order.has(item.id) ? {
			...item,
			sortOrder: order.get(item.id)
		} : item));
		try {
			await reorderEntries({ data: { ids: swapped } });
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not reorder.");
			load();
		}
	}
	async function setEntryUrgency(entry, value) {
		try {
			const updated = await setUrgency({ data: {
				id: entry.id,
				urgency: value
			} });
			setEntries((prev) => prev.map((item) => item.id === updated.id ? updated : item));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not set importance.");
		}
	}
	async function setEntryEarned(entry, count) {
		const next = Math.max(0, Math.min(999, Math.trunc(count)));
		try {
			const updated = await setEarnedCount({ data: {
				id: entry.id,
				count: next
			} });
			setEntries((prev) => prev.map((item) => item.id === updated.id ? updated : item));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not change the count.");
		}
	}
	const names = {};
	if (me?.profile) names[me.profile.userId] = me.profile.displayName || "Me";
	if (me?.partner) names[me.partner.userId] = me.partner.displayName || "Partner";
	names.both = "Both";
	const allowed = canMutate(me, kind, defaultCadence);
	const extras = me?.house.wheels?.[kind] ?? [];
	const heading = title ?? config.title;
	const createLabel = addLabel ?? config.addLabel;
	const activitiesMode = kind === "note" && filter === "exercises";
	function spawnProps(entry) {
		if (kind !== "note") return {};
		const dest = linkForEntry(entry);
		if (!dest && entry.category !== "ideas" && entry.category !== "exercises") return {};
		return {
			spawnLink: dest,
			me,
			onSpawned: (_created, source) => {
				if (source) onSaved(source);
			}
		};
	}
	async function saveWheelExtras(next) {
		if (!me) return;
		try {
			const updated = await savePlay({ data: { wheels: {
				...me.house.wheels,
				[kind]: next
			} } });
			setMe(updated);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not update the wheel.");
		}
	}
	function openEditor(entry) {
		if (entry) {
			setEditing(entry);
			return;
		}
		if (!allowed) {
			toast.message(lockedCopy(kind));
			return;
		}
		setEditing(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			hideHeader ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end gap-2",
				children: allowed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => setManage(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, {}), "Categories"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => openEditor(null),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), createLabel]
				})] }) : null
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.2em] text-primary",
						children: kicker ?? config.kicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-4xl font-medium",
						children: heading
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-sm text-muted-foreground",
						children: blurb ?? config.blurb
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex shrink-0 flex-wrap items-center justify-end gap-2",
					children: [config.shop && me?.profile?.role === "submissive" && points ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: "outline",
						children: [points.mine, " pts"]
					}) : null, allowed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => setManage(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "Categories"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => openEditor(null),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), createLabel]
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "outline",
						children: "Editing locked"
					})]
				})]
			}),
			wheel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChanceWheel, {
				title: wheel.title,
				copy: wheel.copy,
				slices: [...entries.filter((e) => e.effectiveStatus !== "archived" && e.meta.onWheel !== "0").map((e) => e.title), ...extras],
				extras,
				canEdit: allowed,
				onAddExtra: (label) => void saveWheelExtras([...extras, label]),
				onRemoveExtra: (label) => void saveWheelExtras(extras.filter((item) => item !== label))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
						active: filter === "all",
						onClick: () => {
							setFilter("all");
							setTrail([]);
						},
						children: "All"
					}),
					(parents.length ? parents : config.statuses.filter((item) => item.value !== "archived")).map((item) => {
						const value = "slug" in item ? item.slug : item.value;
						const label = "name" in item ? item.name : item.label;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
							active: filter === value,
							onClick: () => {
								setFilter(value);
								setTrail([]);
							},
							children: label
						}, value);
					}),
					parents.length && config.completeLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
						active: filter === "done",
						onClick: () => {
							setFilter("done");
							setTrail([]);
						},
						children: config.statuses.find((item) => item.value === "done")?.label ?? "Completed"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
						active: filter === "archived",
						onClick: () => {
							setFilter("archived");
							setTrail([]);
						},
						children: "Archived"
					})
				]
			}),
			nestedRows.map((row, rowIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: row.selected === "all",
					onClick: () => setTrail(trail.slice(0, rowIndex)),
					children: "All"
				}), row.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: row.selected === item.slug,
					onClick: () => setTrail([...trail.slice(0, rowIndex), item.slug]),
					children: item.name
				}, item.slug))]
			}, `${row.parent}-${rowIndex}`)),
			activitiesMode && !loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-border bg-secondary/60 px-4 py-3 text-sm text-muted-foreground",
				children: "Check an original entry, then choose the page, category, and subcategory it should appear on."
			}) : null,
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					0,
					1,
					2
				].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-36 animate-pulse rounded-xl bg-card" }, i))
			}) : visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: filter === "ideas" ? "No ideas yet" : emptyTitle ?? config.emptyTitle,
				body: allowed ? filter === "ideas" ? "These shelves are empty on purpose. Add your own idea, and nest subcategories if you want them finer." : emptyBody ?? config.emptyBody : lockedCopy(kind),
				action: allowed ? createLabel : void 0,
				onAction: allowed ? () => openEditor(null) : void 0
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("grid gap-3", config.layout === "grid" ? "sm:grid-cols-2" : "grid-cols-1"),
				children: visible.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntryCard, {
					entry,
					config,
					cats,
					assignee: entry.assignedTo === "both" ? "Both" : entry.assignedTo ? names[entry.assignedTo] ?? null : null,
					onOpen: () => {
						if (isLibraryNote(entry)) setReading(entry);
						else openEditor(entry);
					},
					onToggle: () => void toggle(entry),
					onArchive: () => void archive(entry),
					onDelete: () => void remove(entry),
					onPhoto: setLightbox,
					onBody: canEditEntry(me, entry) && !isLibraryNote(entry) ? (html) => void saveBody(entry, html) : void 0,
					paused: dutiesPaused(me?.house) && isDutyKind(entry.kind),
					canEdit: canEditEntry(me, entry),
					onMoveUp: visible[0]?.id === entry.id ? void 0 : () => void moveEntry(entry, -1),
					onMoveDown: visible[visible.length - 1]?.id === entry.id ? void 0 : () => void moveEntry(entry, 1),
					onUrgency: kind === "task" ? (value) => void setEntryUrgency(entry, value) : void 0,
					onEarnedChange: isCountedKind(kind) && canSetEarnedCount(me) ? (count) => void setEntryEarned(entry, count) : void 0,
					onBuy: me?.profile?.role === "submissive" && shopCost(entry.meta) && !isBought(entry.meta) ? () => void buy(entry) : void 0,
					balance: points?.mine ?? 0,
					boughtByName: entry.meta.boughtBy ? names[entry.meta.boughtBy] ?? (entry.meta.boughtBy === me?.profile?.userId ? "You" : "Bought") : null,
					catalog: kind === "game" ? catalog : [],
					...spawnProps(entry)
				}, entry.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntryForm, {
				config,
				entry: editing ?? void 0,
				open: editing !== void 0,
				addLabel: createLabel,
				defaultCadence,
				defaultCategory: parents.some((c) => c.slug === filter) ? filter : void 0,
				defaultSubcategory: trail[trail.length - 1],
				readOnly: Boolean(editing && !canEditEntry(me, editing)),
				onOpenChange: (open) => {
					if (!open) setEditing(void 0);
				},
				onSaved: (entry, removed) => {
					onSaved(entry, removed);
					listCategories({ data: { kind } }).then(setCats);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibraryDocDialog, {
				entry: reading,
				open: Boolean(reading),
				canEdit: reading ? canEditEntry(me, reading) : false,
				catName: reading ? cats.find((c) => c.slug === reading.category)?.name ?? config.categories?.find((c) => c.value === reading.category)?.label ?? reading.category : null,
				subName: reading ? cats.find((c) => c.slug === reading.subcategory)?.name ?? reading.subcategory : null,
				relatedKeys: reading ? relatedLibraryKeys({ text: `${reading.title} ${reading.body ?? ""}` }) : [],
				me,
				onSpawned: (_created, source) => {
					if (source) {
						onSaved(source);
						setReading(source);
					}
				},
				onClose: () => setReading(null),
				onEdit: () => {
					if (!reading) return;
					const row = reading;
					setReading(null);
					openEditor(row);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryManager, {
				kind,
				open: manage,
				cats,
				onClose: () => setManage(false),
				onChange: setCats
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbox, {
				src: lightbox,
				onClose: () => setLightbox(null)
			})
		]
	});
}
function CategoryManager({ kind, open, cats, onClose, onChange }) {
	const [name, setName] = (0, import_react.useState)("");
	const [parent, setParent] = (0, import_react.useState)("");
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [editName, setEditName] = (0, import_react.useState)("");
	const ordered = catTree(sortNamed(cats));
	const parentChoices = ordered.filter((c) => !c.archived);
	async function refresh() {
		onChange(await listCategories({ data: { kind } }));
	}
	async function add() {
		if (!name.trim()) return;
		try {
			await addCategory({ data: {
				kind,
				name: name.trim(),
				parentSlug: parent || null
			} });
			setName("");
			await refresh();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not add category.");
		}
	}
	async function saveName(item) {
		const next = editName.trim();
		if (!next) return;
		try {
			await updateCategory({ data: {
				kind,
				slug: item.slug,
				id: item.id ?? void 0,
				name: next
			} });
			setEditing(null);
			await refresh();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not rename.");
		}
	}
	async function archive(item) {
		try {
			await updateCategory({ data: {
				kind,
				slug: item.slug,
				id: item.id ?? void 0,
				archived: !item.archived
			} });
			await refresh();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not archive.");
		}
	}
	async function remove(item) {
		if (typeof window !== "undefined" && !window.confirm(`Delete “${item.name}”? Entries keep their old label.`)) return;
		try {
			await deleteCategory({ data: {
				id: item.id ?? void 0,
				kind,
				slug: item.slug
			} });
			await refresh();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not delete.");
		}
	}
	async function moveCat(item, dir) {
		const slugs = ordered.filter((c) => (c.parentSlug ?? "") === (item.parentSlug ?? "")).map((c) => c.slug);
		const index = slugs.indexOf(item.slug);
		const next = index + dir;
		if (index < 0 || next < 0 || next >= slugs.length) return;
		const swappedSiblings = [...slugs];
		[swappedSiblings[index], swappedSiblings[next]] = [swappedSiblings[next], swappedSiblings[index]];
		const siblingSet = new Set(slugs);
		let cursor = 0;
		const swapped = ordered.map((c) => {
			if (!siblingSet.has(c.slug)) return c.slug;
			return swappedSiblings[cursor++];
		});
		try {
			await reorderCategories({ data: {
				kind,
				slugs: swapped
			} });
			await refresh();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not reorder.");
		}
	}
	function siblingIndex(item) {
		const siblings = ordered.filter((c) => (c.parentSlug ?? "") === (item.parentSlug ?? ""));
		return {
			index: siblings.findIndex((c) => c.slug === item.slug),
			last: siblings.length - 1
		};
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Categories" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Edit, archive, or delete any category — including the built-in ones. A subcategory can sit under another subcategory. Archived categories stay out of new entries." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "e.g. Kneeling"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Parent (for a sub-category)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: parent,
						onChange: (e) => setParent(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "None — top level"
						}), parentChoices.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item.slug,
							children: catLabelPath(cats, item.slug) || item.name
						}, item.slug))]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void add(),
					className: "w-full",
					children: "Add"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "max-h-56 space-y-1 overflow-y-auto text-sm",
					children: ordered.map((item) => {
						const sib = siblingIndex(item);
						const depth = Math.max(0, catPath(cats, item.slug).length - 1);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: cn("flex items-center justify-between gap-2 rounded-md px-3 py-2", item.archived ? "bg-muted/60" : "bg-secondary"),
							style: { marginLeft: depth ? `${Math.min(depth, 6) * 12}px` : void 0 },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "min-w-0 flex-1",
								children: editing === item.slug ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: editName,
									onChange: (e) => setEditName(e.target.value),
									onBlur: () => void saveName(item),
									onKeyDown: (e) => {
										if (e.key === "Enter") saveName(item);
										if (e.key === "Escape") setEditing(null);
									},
									autoFocus: true
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "block min-h-9 w-full truncate text-left",
									onClick: () => {
										setEditing(item.slug);
										setEditName(item.name);
									},
									children: [
										item.parentSlug ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted-foreground",
											children: [
												catLabelPath(cats, item.parentSlug) || item.parentSlug,
												" /",
												" "
											]
										}) : null,
										item.name,
										item.builtin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-2 text-xs text-muted-foreground",
											children: "built-in"
										}) : null,
										item.archived ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-2 text-xs text-muted-foreground",
											children: "archived"
										}) : null
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex shrink-0 gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "grid size-9 place-items-center text-muted-foreground hover:text-foreground disabled:opacity-30",
										onClick: () => void moveCat(item, -1),
										disabled: sib.index <= 0,
										"aria-label": "Move up",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "grid size-9 place-items-center text-muted-foreground hover:text-foreground disabled:opacity-30",
										onClick: () => void moveCat(item, 1),
										disabled: sib.index >= sib.last,
										"aria-label": "Move down",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "h-9 rounded-md px-2 text-xs text-muted-foreground hover:text-foreground",
										onClick: () => void archive(item),
										children: item.archived ? "Restore" : "Archive"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "h-9 rounded-md px-2 text-xs text-muted-foreground hover:text-foreground",
										onClick: () => void remove(item),
										children: "Delete"
									})
								]
							})]
						}, `${item.slug}-${item.id ?? "b"}`);
					})
				})
			]
		})] })
	});
}
function FilterChip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-9 rounded-full px-3 text-sm", active ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
		children
	});
}
function UrgencyControl({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-1",
		children: URGENCY.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onChange(item.value),
			className: cn("h-7 rounded-full px-2 text-[11px]", value === item.value ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"),
			children: item.label
		}, item.value))
	});
}
function EmptyState({ title, body, action, onAction }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-dashed border-border bg-card/60 px-6 py-14 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-medium",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-md text-sm text-muted-foreground",
				children: body
			}),
			action && onAction ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-5",
				onClick: onAction,
				children: action
			}) : null
		]
	});
}
function EntryCard({ entry, config, cats = [], assignee, onOpen, onToggle, onArchive, onDelete, onPhoto, onBody, paused, canEdit, onMoveUp, onMoveDown, onUrgency, onEarnedChange, onBuy, balance = 0, boughtByName, catalog = [], spawnLink, me: spawnMe, onSpawned }) {
	const status = config.statuses.find((item) => item.value === entry.effectiveStatus || item.value === entry.status);
	const done = entry.effectiveStatus === "done";
	const cost = shopCost(entry.meta);
	const bought = isBought(entry.meta);
	const countdown = countdownLabel(entry);
	const catName = cats.find((c) => c.slug === entry.category)?.name ?? config.categories?.find((c) => c.value === entry.category)?.label ?? entry.category;
	const subName = cats.find((c) => c.slug === entry.subcategory)?.name ?? entry.subcategory;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "overflow-hidden rounded-xl border border-border bg-card",
		children: [entry.photos[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "block w-full",
			onClick: () => onPhoto?.(entry.photos[0]),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: entry.photos[0],
				alt: "",
				className: "h-44 w-full object-cover"
			})
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onOpen,
						className: "text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-medium leading-snug",
							children: entry.title
						}), catName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs uppercase tracking-[0.14em] text-muted-foreground",
							children: [
								catName,
								subName ? ` · ${subName}` : "",
								isLibraryNote(entry) ? " · Library" : ""
							]
						}) : isLibraryNote(entry) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs uppercase tracking-[0.14em] text-muted-foreground",
							children: "Library"
						}) : null]
					}), status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: done || entry.status === "archived" ? "muted" : "default",
						children: status.label
					}) : null]
				}),
				entry.kind === "talk" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoreInfoButton, { text: `${entry.title} ${entry.body ?? ""}` }) : null,
				isCountedKind(entry.kind) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2",
					children: onEarnedChange ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-8 place-items-center rounded-md bg-secondary text-muted-foreground disabled:opacity-30",
							onClick: () => onEarnedChange(earnedCountOf(entry.meta) - 1),
							disabled: earnedCountOf(entry.meta) <= 0,
							"aria-label": `Fewer ${countWord(entry.kind)}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3.5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "min-w-16 text-xs uppercase tracking-[0.14em] text-primary",
							children: [
								earnedCountOf(entry.meta),
								" ",
								countWord(entry.kind)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-8 place-items-center rounded-md bg-secondary text-muted-foreground disabled:opacity-30",
							onClick: () => onEarnedChange(earnedCountOf(entry.meta) + 1),
							disabled: earnedCountOf(entry.meta) >= 999,
							"aria-label": `More ${countWord(entry.kind)}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" })
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs uppercase tracking-[0.14em] text-primary",
						children: [
							earnedCountOf(entry.meta),
							" ",
							countWord(entry.kind)
						]
					})
				}) : null,
				assignee ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: ["Assigned to ", assignee]
				}) : null,
				cost ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: bought ? `Bought${boughtByName ? ` · ${boughtByName}` : ""} · ${cost} pts` : `${cost} pts to buy`
				}) : null,
				onUrgency ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UrgencyControl, {
					value: urgencyOf(entry.meta),
					onChange: onUrgency
				}) : entry.kind === "task" && urgencyOf(entry.meta) !== "normal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.14em] text-primary",
					children: urgencyOf(entry.meta)
				}) : null,
				entry.body ? isLibraryNote(entry) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: plainExcerpt(entry.body)
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, {
					html: entry.body,
					clamp: !onBody,
					className: "text-sm",
					onChange: onBody
				}) : null,
				entry.kind === "game" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameDeckPlay, {
					entry,
					catalog
				}) : null,
				entry.cadence ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs uppercase tracking-[0.14em] text-muted-foreground",
					children: [
						entry.cadence,
						entry.weekday != null ? ` · ${[
							"Sun",
							"Mon",
							"Tue",
							"Wed",
							"Thu",
							"Fri",
							"Sat"
						][entry.weekday]}` : "",
						entry.cadence === "custom" ? ` · ${parseCustomDays(entry.meta.customDays).map((d) => [
							"Sun",
							"Mon",
							"Tue",
							"Wed",
							"Thu",
							"Fri",
							"Sat"
						][d]).join(" ")}` : ""
					]
				}) : null,
				Object.entries(entry.meta).filter(([k, v]) => v && !HIDDEN_META.has(k)).slice(0, 3).map(([key, value]) => {
					const field = config.fields.find((f) => f.key === key);
					if (field?.type === "textarea") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted-foreground",
							children: field.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichText, {
							html: value,
							clamp: true,
							className: "mt-1"
						})]
					}, key);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: [field?.label ?? key, ": "]
						}), value]
					}, key);
				}),
				entry.meta.catalogTitles ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1",
					children: (() => {
						const ids = (entry.meta.catalogIds ?? "").split(",").map((value) => value.trim()).filter(Boolean);
						const titles = entry.meta.catalogTitles.split(" · ").filter(Boolean);
						const roles = entry.kind === "game" ? parseCatalogRoles(entry.meta) : {};
						return titles.map((title, index) => {
							const role = ids[index] ? roles[ids[index]] : void 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-full bg-secondary px-2 py-1 text-[11px] text-muted-foreground",
								children: [title, role && role !== "prop" ? ` · ${role}` : ""]
							}, `${title}-${index}`);
						});
					})()
				}) : null,
				entry.meta.points ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						Number(entry.meta.points) >= 0 ? "+" : "",
						entry.meta.points,
						" pts if done",
						entry.meta.skipPoints ? ` · ${entry.meta.skipPoints} if skipped` : ""
					]
				}) : null,
				entry.meta.rewardTitles ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: ["Earns ", entry.meta.rewardTitles]
				}) : null,
				entry.meta.punishmentTitles ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: ["If skipped: ", entry.meta.punishmentTitles]
				}) : null,
				entry.meta.reminderEnabled === "1" && entry.meta.reminderTime ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: ["Reminder ", entry.meta.reminderTime]
				}) : null,
				countdown ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: countdown
				}) : null,
				spawnLink || spawnMe ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpawnCheckbox, {
					suggested: spawnLink,
					title: entry.title,
					body: entry.body ?? "",
					sourceKey: sourceKeyFor(entry),
					sourceEntry: entry,
					me: spawnMe,
					onSpawned
				}) : null,
				entry.kind === "journal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.14em] text-muted-foreground",
					children: entry.meta.visibility === "private" ? "Private" : "Shared"
				}) : null,
				entry.intensity ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1",
					"aria-label": `Intensity ${entry.intensity}`,
					children: intensityMarks(entry.intensity).map((on, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2 rounded-full", on ? "bg-primary" : "bg-border") }, i))
				}) : null,
				entry.photos.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoStrip, {
					photos: entry.photos.slice(1),
					onOpen: onPhoto
				}) : null,
				entry.videos?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoStrip, { videos: entry.videos }) : null,
				entry.pdfs?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PdfStrip, { pdfs: entry.pdfs }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2 pt-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: formatWhen(entry.updatedAt || entry.createdAt)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap justify-end gap-2",
						children: [
							canEdit && (onMoveUp || onMoveDown) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "grid size-9 place-items-center text-muted-foreground disabled:opacity-30",
									onClick: onMoveUp,
									disabled: !onMoveUp,
									"aria-label": "Move up",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "grid size-9 place-items-center text-muted-foreground disabled:opacity-30",
									onClick: onMoveDown,
									disabled: !onMoveDown,
									"aria-label": "Move down",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4" })
								})]
							}) : null,
							onBuy && cost && !bought ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col items-end gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: onBuy,
									children: shopBuyLabel(entry.kind, cost)
								}), balance < cost ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] text-muted-foreground",
									children: [
										"You have ",
										balance,
										" pts"
									]
								}) : null]
							}) : null,
							config.completeLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: done ? "outline" : "default",
								onClick: onToggle,
								disabled: paused || Boolean(onBuy && cost && !bought),
								children: paused ? "Paused" : onBuy && cost && !bought ? config.completeLabel : done ? config.reopenLabel ?? "Reopen" : config.completeLabel
							}) : null,
							canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: onOpen,
									children: isLibraryNote(entry) ? "Read" : "Edit"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: onArchive,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { className: "size-3.5" }), entry.status === "archived" ? "Restore" : "Archive"]
								}),
								isLibraryNote(entry) ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: onDelete,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), "Delete"]
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: onOpen,
								children: "View"
							})
						]
					})]
				})
			]
		})]
	});
}
//#endregion
export { KindPage as a, STARTER_KINKS as c, parseLineList as d, todaysCard as f, KINK_RATINGS as i, UrgencyControl as l, EmptyState as n, MoreInfoButton as o, EntryForm as r, PdfStrip as s, CategoryManager as t, dayKey as u };
